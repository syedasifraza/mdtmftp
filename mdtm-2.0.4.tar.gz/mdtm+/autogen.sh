#! /bin/sh

set -eu pipefail

# `autoreconf' will run `autoconf' (and `autoheader', `aclocal',
# `automake', `autopoint' (previously known as `gettextize'), and
# `libtoolize' where appropriate) to remake the build system files.

autoreconf --install --force --verbose
