//
// We use direct I/O, but sometimes it is not supported by some
// filesystems.  This is a quick check to see if things work.
//

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    const char *filename = "directio-test.txt";

    int fd = open(filename, O_WRONLY, O_CREAT|O_DIRECT);

    if (fd < -1) {
        fprintf(stderr, "Error when opening %s: %s\n",
                filename,
                strerror(errno));

        return 1;
    }

    const char *teststr = "hello world!\n";
    auto const len = strlen(teststr);

    for (auto i = 0; i < 100; ++i) {
        if (write(fd, teststr, len) != len) {
            fprintf(stderr, "Error writing to %s: %s\n",
                    filename,
                    strerror(errno));
            close(fd);
            return 1;
        }
    }

    close(fd);

    return 0;
}

