/*
 * hello.cpp
 *
 *  Created on: Jan 1, 2014
 *      Author: liangz
 */


#include <stdio.h>
#include <inttypes.h>

#include <mdtm.h>

int main(void)
{
    printf("hello world!\n");
    mdtm_show_version();
    return 0;
}

