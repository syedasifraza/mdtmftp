/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <memory.h>
#include <math.h>
#include <ctime>       /* time */
#include <dirent.h>
#include <stdint.h>
#include <iostream>
#include <vector>
#include <assert.h>
#include <cstdlib>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>
#include <signal.h>
#include <mdtm.h>
#include <mdtm_parser.h>
#include <mdtm_cpuset.h>
#include <mdtm_ipc.h>
#include <mdtm_mem.h>
#include <numatop.h>

using namespace std;

#define DAEMON_NAME             "mdtm_daemon"

static int                      g_daemon_terminated = 0;
int                             pidFilehandle;

void daemonize(char *rundir, char *pidfile);

static
void signal_callback_handler(int signum)
{
  switch(signum) {
  case SIGHUP:
    syslog(LOG_INFO | LOG_USER, "Received SIGHUP signal.");
    g_daemon_terminated = 1;
    break;
  case SIGTERM:
    syslog(LOG_INFO | LOG_USER, "Received SIGTERM signal.");
    g_daemon_terminated = 1;
    break;
  case SIGINT:
    syslog(LOG_INFO | LOG_USER, "Received SIGINT signal.");
    g_daemon_terminated = 1;
    break;
  default:
      syslog(LOG_WARNING, "Unhandled signal %s", strsignal(signum));
      g_daemon_terminated = 1;
      break;
  }
}

void
daemonize(char *rundir, char *pidfile) {
  char str[10];

  // Register signal handlers
  signal(SIGTERM, signal_callback_handler);
  signal(SIGINT,  signal_callback_handler);
  signal(SIGHUP, signal_callback_handler);
  signal(SIGKILL, signal_callback_handler);

  //Fork the process and have the parent exit
  if(pid_t pid = fork()) {
      if (pid < 0) {
          syslog(LOG_ERR | LOG_USER, "Fork() failed: %m");
          exit(EXIT_FAILURE);
      }

      //We got a good pid, Close the Parent Process
      if (pid > 0) { exit(EXIT_SUCCESS); }
  }

  //Change File Mask
  umask(0);

  //Create a new Signature Id for our child
  pid_t sid = setsid();
  if (sid < 0) { exit(EXIT_FAILURE); }

  //Change Directory
  //If we cant find the directory we exit with failure.
  if ((chdir(rundir)) < 0) { exit(EXIT_FAILURE); }

  //Close Standard File Descriptors
  close(STDIN_FILENO);
  close(STDOUT_FILENO);
  close(STDERR_FILENO);

  // daemon does not have standard input
  if (open("/dev/null", O_RDONLY) < 0)
  {
    syslog(LOG_ERR | LOG_USER, "Unable to open /dev/null: %m");
    exit(EXIT_FAILURE);
  }

  // Send standard output to a log file.
  const char* output = "/tmp/mdtm.daemon.out";
  const int flags = O_WRONLY | O_CREAT | O_APPEND;
  const mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
  if (open(output, flags, mode) < 0)
  {
    syslog(LOG_ERR | LOG_USER, "Unable to open output file %s: %m", output);
    exit(EXIT_FAILURE);
  }

  // Also send standard error to the same log file.
  if (dup(1) < 0)
  {
    syslog(LOG_ERR | LOG_USER, "Unable to dup output descriptor: %m");
    exit(EXIT_FAILURE);
  }

  /* Ensure only one copy */
  pidFilehandle = open(pidfile, O_RDWR|O_CREAT, 0600);

  if (pidFilehandle == -1 )
  {
      /* Couldn't open lock file */
      syslog(LOG_INFO, "Could not open PID lock file %s, exiting", pidfile);
      exit(EXIT_FAILURE);
  }

  /* Try to lock file */
  if (lockf(pidFilehandle,F_TLOCK,0) == -1)
  {
      /* Couldn't get lock on lock file */
      syslog(LOG_INFO, "Could not lock PID lock file %s, exiting", pidfile);
      exit(EXIT_FAILURE);
  }

  /* Get and format PID */
  sprintf(str,"%d\n",getpid());

  /* write pid to lockfile */
  write(pidFilehandle, str, strlen(str));
}

void daemonShutdown()
{
    close(pidFilehandle);
}

int main(int argc, char** argv) {
  char  rundir[] = "/";
  char  pidfile[] = "/var/run/mdtmd.pid";

  try {
      //Set our Logging Mask and open the Log
//      setlogmask(LOG_UPTO(LOG_NOTICE));
      openlog(DAEMON_NAME, LOG_CONS | LOG_NDELAY | LOG_PERROR | LOG_PID, LOG_USER);

      daemonize(rundir, pidfile);
      syslog(LOG_INFO | LOG_USER, "MDTM Daemon started.");

      // init mdtm module
      if(mdtm_init(MDTM_OPMODE_SERVER) >= 0) {
          syslog(LOG_INFO | LOG_USER, "Ready for coming commands.");
          while(!g_daemon_terminated){
              mdtm_poll();
          }

          mdtm_deinit();
      }
      else {
          syslog(LOG_INFO | LOG_USER, "mdtm library initialization failed.");
      }

      daemonShutdown();
      syslog(LOG_INFO | LOG_USER, "MDTM Daemon stopped.");

  } catch(std::exception& e) {
      syslog(LOG_ERR | LOG_USER, "MDTM Daemon failed on exceptions: %s", e.what());
  }
  return 0;
}
