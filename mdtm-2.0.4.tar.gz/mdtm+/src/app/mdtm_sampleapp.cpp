/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string>

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#include "bitmask.h"

#include "mdtm.h"
#include "mdtm/mdtm_tree.h"

#ifdef __cplusplus
extern "C"
{
#endif

void *print_message_function ( void *ptr )
{
  int *thread_id = (int*)ptr;
//  *thread_id = gettid();
  printf("Hello from thread %lu\n", pthread_self());

  return 0;
}

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

void
test_big_file(int argc, char **argv) {
  int                                 flags = 0 | O_RDONLY;
  unsigned long                       mode;
  off_t offset = 402387;//13 * 1024 *1024 *1024 + 1;
  int fd;

  printf("open file %s\n", argv[1]);

  flags = 16384;
  mode = 420;

  if((fd = open(argv[1], flags, mode))< 0){
    printf("Lseek error: %s\n", strerror(errno));
    return;
  }

  if(lseek(fd, offset, SEEK_SET) < 0){
    printf("Lseek error: %s\n", strerror(errno));
    return;
  }

  close(fd);
}

//
// command line: src/app/mdtm_sampleapp /data4/gt5.2.5-all-source-installer
//
void test_meta_create3(int argc, char **argv)
{
  void *q;
  char *buff;
  size_t entry_size = 512, buffSize;
  size_t nentries;
  long long		used;

  q = (void*)mdtm_dir_queue_create(argv[1]);

  printf("entries in dirq: %ld\n",\
      nentries=mdtm_dir_queue_size(q, MDTM_DIR_QUEUE_SIZE_FILE|MDTM_DIR_QUEUE_SIZE_DIR));

  buffSize = entry_size * nentries * 2;
  buff = (char*)malloc(buffSize);
  memset(buff,0, entry_size * nentries);
  used = mdtm_dir_queue_create_meta2(q, (void*) buff, buffSize);
  printf("used=%lld buff=%p\n",used, buff);
  for(int i = 0; i< 16; i++) {
      for(int j = 0; j < 8; j++)
        printf("%c ",buff[i * 8 + j]);
      printf("\n");
  }
}

//
// command line: src/app/mdtm_sampleapp /data4/gt5.2.5-all-source-installer
//
void test_meta_extract3(int argc, char **argv)
{
  void *q, *outq;
  char *buff;
  size_t buffSize = 1024*1024*256;
  long long used;

  // create dirq from disk
  q = (void*)mdtm_dir_queue_create(argv[1]);

  // make meta data in buffer
  buff = (char*)malloc(buffSize);
  memset(buff,0, buffSize);
  used = mdtm_dir_queue_create_meta2(q, (void*) buff, buffSize);
  printf("file:%s used=%lld buff=%p\n",argv[1], used, buff);

  outq = (void*)mdtm_dir_queue_create(0);
  mdtm_dir_queue_parse_meta2(outq, buff, used,(char*)std::string("\tmp").c_str());
//  mdtm_dir_queue_iter(outq);

  printf("orig queue size=%d, recoverd queue size=%d\n",
      mdtm_dir_queue_size(q, MDTM_DIR_QUEUE_SIZE_FILE),
  mdtm_dir_queue_size(outq, MDTM_DIR_QUEUE_SIZE_FILE));

//  mdtm_dir_queue_compare(q, outq);


//  {
//    long long location = 10000;
//    mdtm_file_entry_t entry;
//    mdtm_dir_queue_find(q, 10000, &entry);
//    printf("Bytes @location %d: file=%s size=%ld offset=%ld\n", location, entry.path, entry.size, entry.offset);
//
//#define BUF_SIZE        128
//    int input_fd, output_fd;    /* Input and output file descriptors */
//    ssize_t ret_in, ret_out;    /* Number of bytes returned by read() and write() */
//    char buffer[BUF_SIZE];      /* Character buffer */
//
//    /* Create output file descriptor */
//    output_fd = open(entry.path, O_WRONLY | O_CREAT, 0644);
//    if(output_fd == -1){
//        perror("open");
//        assert(0);
//    }
//
//    /* Copy process */
//    {
//      lseek(output_fd, entry.offset, SEEK_SET);
//        strcpy(buffer, "Hello World!\n");
//        ret_in = strlen(buffer);
//        ret_out = write (output_fd, &buffer, (ssize_t) ret_in);
//        if(ret_out != ret_in){
//            /* Write error */
//            perror("write");
//            assert(0);
//        }
//    }
//
//    /* Close file descriptors */
//    close (output_fd);
//  }
}

//
// command line: src/app/mdtm_sampleapp mymeta /data4/gt5.2.5-all-source-installer
//
void test_meta_create2(int argc, char **argv)
{
  void *q;
  const char *pathname;

  q = (void*)mdtm_dir_queue_create(argv[2]);

  mdtm_dir_queue_create_meta(q, argv[1]);
}

//
// command line: src/app/mdtm_sampleapp mymeta
//
void test_meta_extract2(int argc, char **argv)
{
  void *q;
  const char *pathname;

  q = (void*)mdtm_dir_queue_create(NULL);

  mdtm_dir_queue_parse_meta(q, argv[1]);

  {
    long long location = 10000;
    mdtm_file_entry_t entry;
    mdtm_dir_queue_find(q, 10000, &entry);
    printf("Bytes @location %lld: file=%s size=%ld offset=%lld\n", location, entry.path, entry.size, entry.offset);

#define BUF_SIZE        128
    int input_fd, output_fd;    /* Input and output file descriptors */
    ssize_t ret_in, ret_out;    /* Number of bytes returned by read() and write() */
    char buffer[BUF_SIZE];      /* Character buffer */

    /* Create output file descriptor */
    output_fd = open(entry.path, O_WRONLY | O_CREAT, 0644);
    if(output_fd == -1){
        perror("open");
        assert(0);
    }

    /* Copy process */
    {
      lseek(output_fd, entry.offset, SEEK_SET);
        strcpy(buffer, "Hello World!\n");
        ret_in = strlen(buffer);
        ret_out = write (output_fd, &buffer, (ssize_t) ret_in);
        if(ret_out != ret_in){
            /* Write error */
            perror("write");
            assert(0);
        }
    }

    /* Close file descriptors */
    close (output_fd);
  }
}

#if 0
//
// command line: src/app/mdtm_sampleapp mymeta textfile.txt tmp
//
void
test_meta_create(int argc, char **argv)
{
  struct archive *a;
  struct archive_entry *entry;
  struct stat     statinfo;
  int r;
  const char* pathname, *filename;
  int i;

  filename = argv[1];

  printf("\n=================================================\n");
  printf("Creating meta file.\n");
  printf("=================================================\n");

  a = archive_write_new();
  archive_write_set_format_ustar(a);

  archive_write_open_filename(a, filename);
  //  archive_read_open_memory(a, (void *)(uintptr_t) data, sizeof(data));
  for(i = 2; i < argc; i++) {
      pathname = argv[i];
      if (lstat(pathname, &statinfo) != 0){
          printf("error: %s: %s\n",pathname, strerror(errno));
          return;
      }
      printf("path=%s, size=%d\n", pathname, statinfo.st_size);

      entry = archive_entry_new();
      //      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, pathname);
      archive_entry_set_size(entry, statinfo.st_size); // Note 3
      if(S_ISDIR(statinfo.st_mode))
        archive_entry_set_filetype(entry, AE_IFDIR);
      else if(S_ISREG(statinfo.st_mode))
        archive_entry_set_filetype(entry, AE_IFREG);
      else
        assert(0);

      //      archive_entry_set_perm(entry, 0777);
      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          //              errmsg(": ");
          //              errmsg(archive_error_string(a));
          //              needcr = 1;
          printf("error: %s: %s\n",__FILE__,__FUNCTION__);
      }
      if (r == ARCHIVE_FATAL)
        exit(1);
      if (r > ARCHIVE_FAILED) {
          //#if 0
          //              /* Ideally, we would be able to use
          //               * the same code to copy a body from
          //               * an archive_read_disk to an
          //               * archive_write that we use for
          //               * copying data from an archive_read
          //               * to an archive_write_disk.
          //               * Unfortunately, this doesn't quite
          //               * work yet. */
          //              copy_data(disk, a);
          //#else
          //              /* For now, we use a simpler loop to copy data
          //               * into the target archive. */
          //              fd = open(archive_entry_sourcepath(entry), O_RDONLY);
          //              len = read(fd, buff, sizeof(buff));
          //              while (len > 0) {
          //                      archive_write_data(a, buff, len);
          //                      len = read(fd, buff, sizeof(buff));
          //              }
          //              close(fd);
          //#endif
      }
      archive_entry_free(entry);
  }

  archive_write_close(a);
  archive_write_free(a);
  return;
}

//
// command line: src/app/mdtm_sampleapp mymeta textfile.txt tmp
//
void
test_meta_extract(const char *filename, int do_extract, int flags)
{
        struct archive *a;
        struct archive *ext;
        struct archive_entry *entry;
        int r;

        printf("\n=================================================\n");
        printf("Extracting meta file.\n");
        printf("=================================================\n");

        a = archive_read_new();

        assert(ARCHIVE_OK == archive_read_support_format_tar(a));

        if (filename != NULL && strcmp(filename, "-") == 0)
                filename = NULL;
        if ((r = archive_read_open_filename(a, filename, 10240))) {
//                errmsg(archive_error_string(a));
//                errmsg("\n");
                exit(r);
        }
        for (;;) {
                r = archive_read_next_header(a, &entry);
                if (r == ARCHIVE_EOF)
                        break;
                if (r != ARCHIVE_OK) {
//                        errmsg(archive_error_string(a));
//                        errmsg("\n");
                        exit(1);
                }
//                if (verbose && do_extract)
//                        msg("x ");
//                if (verbose || !do_extract)
//                        msg(archive_entry_pathname(entry));

                printf("path=%s, type=%s size=%d\n",
                    archive_entry_pathname(entry),
                    archive_entry_filetype(entry) == AE_IFREG ? "AE_IFREG" : "AE_IFDIR",
                    archive_entry_size(entry));
                if (do_extract) {
//                        r = archive_write_header(ext, entry);
//                        printf("%s:Ready to read header from %s\n",__FUNCTION__,filename);

//                        if (r != ARCHIVE_OK)
//                                errmsg(archive_error_string(a));
//                        else
//                                copy_data(a, ext);
                }
//                if (verbose || !do_extract)
//                        msg("\n");
//                archive_read_data_skip(a);
        }
        archive_read_close(a);
        archive_read_free(a);
//        exit(0);
}
#endif


//
// command line: src/app/mdtm_sampleapp /data4/gt5.2.5-all-source-installer/
//
static void
test_dirqueue(int argc, char **argv)
{
  void *q;
  const char *pathname;

  q = (void*)mdtm_dir_queue_create(argv[1]);


//  printf("Check Iterator\n");
//  mdtm_dir_queue_iter(q);

  printf( "Start to dequeue\n");
  while((pathname = strdup(mdtm_dir_queue_dequeue(q)))){
    printf("%s\n",pathname);
  }

}
#

//static void
//test_qdu(int argc, char **argv)
//{
//  char *data[2];
//  data[0] = argv[1];
//  data[1] = argv[2];
//  qdumain(data);
////  extractmain(argv);
//}

static void
test_mdtm_config_api(int argc, char **argv)
{
  struct mdtm_device_s* devices;
  int i, n;

  mdtm_init(MDTM_OPMODE_CLIENT);

  n= mdtm_config_getpcidevices(&devices);
  for(i = 0; i < n; i++) {
      printf("devices[%d]: %s %d\n", i, devices[i].name, devices[i].classid);
  }

  printf("Threads=%d\n",mdtm_config_get_threadsperdevice((char*)std::string("sda").c_str()));
}

static void
test_filemap_api(char* filepath)
{
  mdtm_lv_seg_t *       segments;
  int                   nsegments, i;

  nsegments =
      mdtm_map_file2(filepath, 0, &segments);

  printf("seg\trange\t\tdevice\n");
  for(i = 0; i < nsegments; i++)
    printf("%d\t%lu %lu\t %s\n",i, segments[i].m_start, segments[i].m_end, segments[i].dev);
}

typedef struct {
  long iden[2];
  int pipefd[2];
} mdtm_pipefd_t;

static void
test_pipe_api() {
  mdtm_pipefd_t *pipes;
  char buff[16];
  int rc;

  printf("*******************\n%s\n*******************\n",__FUNCTION__);

  mdtm_pipe_init(20, 1024*1024);
  pipes = (mdtm_pipefd_t *)mdtm_pipe_get(0, 4,(void**)&pipes);
  if(pipes)
    printf("%d pipes allocated\n", rc);

  if(write(pipes[0].pipefd[1], buff, 15) < 0) {
      printf("write failed: %s\n",strerror(errno));
  }
  else
    printf("write succeeds\n");
}

static void
test_mapping() {
  char path[] = "/boot";
  char buf[1024];
  int buflen = 1024;

  printf("*******************\n%s\n*******************\n",__FUNCTION__);

  mdtm_map_file(path, buf, buflen);
  printf("%s is on device: %s\n", path, buf);
  printf("%s is on numa:%d\n",path, mdtm_find_numa_of_file(path));
}

static void
test_loc_malloc()
{
  int numa = 0;
  int size = 102400;
  void *buff;

  printf("*******************\n%s\n*******************\n",__FUNCTION__);

//  for(int numa = 0; numa < 2; numa++) {
//      buff = mdtm_loc_malloc(numa, size);
//      if(!buff)
//        printf("mdtm_loc_malloc failed on numa %d\n", numa);
//      else {
//          char *test_str = "I am happy with mem";
//        printf("mdtm_loc_malloc succeed: addr=%p, size=%d\n", buff, size);
//        strcpy((char*)buff, test_str);
//        printf("write to mem: %s \t read from mem: %s\n",test_str, (char*)buff);
//        mdtm_loc_mfree(buff, size);
//      }
//  }

  for(int numa = 0; numa < 4; numa++) {
        int result = mdtm_loc_malloc2(numa, &buff, size);
        if(result < 0 || !buff)
          printf("mdtm_loc_malloc2 failed on numa %d\n", numa);
        else {
            char *test_str = (char*)std::string("I am happy with mem").c_str();
          printf("mdtm_loc_malloc2 succeed: addr=%p, size=%d\n", buff, size);
          strcpy((char*)buff, test_str);
          printf("write to mem: %s \t read from mem: %s\n",test_str, (char*)buff);
          mdtm_loc_mfree(buff, size);
        }
    }

  return;
}

#include "../libmdtm/mdtm_df.h"

static void
test_df_api()
{
  char *dev;
  char path[256];

  printf("Path\tDevice Name\n");
  strcpy(path, "/home/liangz/");
  if(mdtm_df_file(path, &dev) != -1)
    printf("%s\t%s\n",path, dev);

  strcpy(path, "/");
  if(mdtm_df_file(path, &dev) != -1)
    printf("%s\t%s\n",path, dev);

  strcpy(path, "/boot");
  if(mdtm_df_file(path, &dev) != -1)
    printf("%s\t%s\n",path, dev);

  return;
}

#include "../libmdtm/mdtm_lustre.h"
static void
test_lustre_api()
{
  char fs[]="localhost@fs1";  //"131.225.2.16@fs1";
  char *dev = 0;

  dev = mdtm_lustre_devname(fs);
  if(dev)
    printf("lustre %s attached to %s\n", fs, dev);
  else
    printf("lustre %s attached to NULL\n", fs);
}


static void
test_mdtm_private_api(int argc, char **argv)
{

  // pre-test
  mdtm_node_t* tree = 0;
  char *arg = argv[1];

  printf("*****************************\n%s\n*****************************\n",__FUNCTION__);

  if(mdtm_create_sys_info(&tree, 0) < 0)
    printf("%s init failed.\n",__FUNCTION__);
  if(!arg) {
      printf("Usage: test_mdtm_tree [--option]\n");
      printf("topology:         show the topology\n");
      printf("cpuaffinity:      show cpus in affinity of devices\n");
      return;
  }

  // Test Cases
  if(!strcmp(arg, "--all") || !strcmp(arg, "--topology")) {
    printf("\n=================================================\n");
    printf("System Topology Tree\n");
    printf("=================================================\n");
    mdtm_tree_print_preorder(tree, 0);
  }
  if(!strcmp(arg, "--all") || !strcmp(arg, "--cpuaffinity")) {
      const mdtm_node_t *mnode;// = first_device;
      unsigned *ids;
      int nd;

      int numDevices = mdtm_getdevices(&mnode);
      printf("\n=================================================\n");
      printf("Device\t\tCPU set in affinity\n");
      printf("=================================================\n");
      for(int i=0; i < numDevices; i++) {
          if(mdtm_device_isconfig(mnode) == true){
              mnode = mdtm_nextnode(mnode);
              continue;
          }
          nd = mdtm_online_cpuset(mnode,&ids);
          printf("%s:\t\t", mdtm_nodename(mnode));
          for(int j=0; j<nd; j++)
            printf("%d ",ids[j]);
          printf("\n");
          do {
                mnode = mdtm_nextnode(mnode); i++;
          }while((mdtm_isdevice(mnode) == false) && (i < numDevices));
          i--;
      }
  }
  if(!strcmp(arg, "--all") || !strcmp(arg, "--deviceaffinity")) {
      mdtm_node_t **numas = (mdtm_node_t **)malloc(sizeof(mdtm_node_t *)*16);
      int nnuma = 0, ncores, ndevices=0;
      unsigned *ids;
      struct mdtm_device_s* devices;// = (struct mdtm_device_s*)malloc(sizeof(struct mdtm_device_s)*16);
      printf("\n=================================================\n");
      printf("Core\t\tDevices in affinity\n");
      printf("=================================================\n");

      mdtm_getnodesbytype(tree, "NUMANode", numas, &nnuma);
      if(nnuma == 0) {
        mdtm_getnodesbytype(tree, "Machine", numas, &nnuma);
      }
      for(int i=0; i < nnuma; i++) {
          ncores = mdtm_online_cpuset(numas[i], &ids);
          mdtm_getdevicesaffinity2(numas[i], &devices, &ndevices);
          for(int j = 0; j < ncores; j++) {
              printf("%d\t\t", ids[j]);
              for(int k = 0; k < ndevices; k++)
                printf("%s ", mdtm_devicename(devices,k));
              printf("\n");
          }
          ndevices = 0;
      }
    }
//    if (!strcmp(arg, "--all") || !strcmp(arg, "--listdevices"))
//      {
//        int nnuma = 0, ncores, ndevices = 0;
//        struct mdtm_device_s* devices;
//        printf("\n=================================================\n");
//        printf("Device\t\tAttributes\n");
//        printf("=================================================\n");
//
////        mdtm_getdevicesaffinity2(tree, &devices, &ndevices);
////        for (int i = 0; i < ndevices; i++)
////          {
////            printf("%s",mdtm_devicename(devices,i));
////            if(mdtm_deviceattr(devices,i))
////              printf("\t\t%s", mdtm_deviceattr(devices,i));
////            printf("\n");
////          }
////        printf("\n");
//
//        ndevices = mdtm_getdevicesbytype(tree, 0, &devices);
//        for(int i = 0; i < ndevices; i++) {
//            if(devices[i].classid == MDTM_DEVICE_CLASS_NETWORK) {
//                printf("%s", devices[i].name);
//                printf("\t\t%s", devices[i].attr.network.operstate);
//                printf("\t%dM", devices[i].attr.network.speed);
//                printf("\t%d\n",devices[i].attr.network.type);
//            }
//            else if(devices[i].classid == MDTM_DEVICE_CLASS_STORAGE) {
//                printf("%s", devices[i].name);
//                printf("\t\t0x%04x", devices[i].attr.storage.devid);
//                printf("\t%dk", devices[i].attr.storage.size >> 1);
//                printf("\t%d\n",devices[i].attr.storage.type);
//            }
//        }
//      }
    if (!strcmp(arg, "--all") || !strcmp(arg, "--distance"))
      {
        float *matrix;
        int n;
        printf("\n=================================================\n");
        printf("NUMA Distances\n");
        printf("=================================================\n");

        n = mdtm_getnumadistance(&matrix);
        printf("Latency matrix between %u %ss:\n", n,"NUMANode");

        for(int i = 0; i < n; i++) {
          for(int j = 0; j < n; j++) {
              printf("%f ", matrix[i*n + j]);
          }
          printf("\n");
        }

      }
    if(!strcmp(arg, "--all") || !strcmp(arg, "--path"))
      {
        mdtm_node_t *spt;
        char *srcdev = 0;
        char *dstdev = 0;

        if(argc == 3)
          srcdev = argv[2];
        else if (argc >= 4){
          srcdev = argv[2];
          dstdev = argv[3];
        }


        if(!srcdev || !dstdev) {
            int ndevices = 0;
            struct mdtm_device_s* devices;
            mdtm_getdevicesaffinity2(tree, &devices, &ndevices);
            if(!srcdev)
              srcdev = strdup(mdtm_devicename(devices,0));
            if(!dstdev)
              dstdev = strdup(mdtm_devicename(devices,ndevices>>1));
        }

        printf("\n=================================================\n");
        printf("Print Path Between Devices\n");
        printf("=================================================\n");
        mdtm_printpath(srcdev, dstdev, tree);
      }
    if(!strcmp(arg, "--all") || !strcmp(arg, "--sched_spt"))
      {
        mdtm_node_t *spt;
        char *srcdev=0;
        char *dstdev=0;

        if(argc == 3)
          srcdev = argv[2];
        else if (argc >= 4){
          srcdev = argv[2];
          dstdev = argv[3];
        }

        if(!srcdev || !dstdev) {
            int ndevices = 0;
            struct mdtm_device_s* devices;
            mdtm_getdevicesaffinity2(tree, &devices, &ndevices);
            if(!srcdev)
              srcdev = strdup(mdtm_devicename(devices,0));
            if(!dstdev)
              dstdev = strdup(mdtm_devicename(devices,ndevices>>1));
        }

        printf("\n=================================================\n");
        printf("Shortest Path Tree (SPT) Scheduling\n");
        printf("=================================================\n");
        mdtm_printschedresult(srcdev, dstdev, tree);

      }
    if(!strcmp(arg, "--all") || !strcmp(arg, "--sched_one")) {
        mdtm_thread_desc_t desc;

        desc.flags = MDTM_CPUBIND_PROC;
        desc.id.pid = 0;
        desc.devices[0] = (char*)std::string("eth1").c_str();
        desc.numaindex = -1;

        printf("\n=================================================\n");
        printf("Scheduling from one device\n");
        printf("=================================================\n");
        mdtm_sched_per_single_device(&desc, tree);
    }
//    if(!strcmp(arg, "--all") || !strcmp(arg, "--sched")) {
//        mdtm_thread_desc_t descs[1];
//
//        memset(descs, 0, sizeof(mdtm_thread_desc_t));
//        descs[0].pid = 0;
//        descs[0].firstdevice = "eth1";
//
//        printf("\n=================================================\n");
//        printf("Scheduling from one device\n");
//        printf("=================================================\n");
//        mdtm_init();
//        mdtm_schedule_threads(descs, 1);
//        mdtm_deinit();
//    }
    if(!strcmp(arg, "--all") || !strcmp(arg, "--lustre")) {
        mdtm_thread_desc_t desc;

        printf("\n=================================================\n");
        printf("Lustre Find Device\n");
        printf("=================================================\n");
        test_lustre_api();
    }
    // Test Cases

  // post-test
  mdtm_delete_sys_info(tree);
}


static void
test_mdtm_public_api(int argc, char **argv)
{

  char *arg = argv[1];

  printf("*****************************\n%s\n*****************************\n",__FUNCTION__);

  if(mdtm_init(MDTM_OPMODE_CLIENT) < 0) {
      printf("mdtm_init() failed.\n");
      goto done;
  }

  if (!strcmp(arg, "--all") || !strcmp(arg, "--listdevices"))
    {
      int nnuma = 0, ncores, ndevices = 0;
      struct mdtm_device_s* devices;
      printf("\n======================================================\n");
      printf("Device\t\tstat/id\tnuma\ttype\tsize/speed\n");
      printf("======================================================\n");

      ndevices = mdtm_getpcidevices(&devices);
      for(int i = 0; i < ndevices; i++) {
          if(devices[i].classid == MDTM_DEVICE_CLASS_NETWORK) {
              printf("%s", devices[i].name);
              printf("\t\t%s", devices[i].attr.network.operstate);
              printf("\t%d",devices[i].numaid);
              printf("\t%d",devices[i].attr.network.type);
              printf("\t%luM\n", devices[i].attr.network.speed);
          }
          else if(devices[i].classid == MDTM_DEVICE_CLASS_STORAGE) {
              printf("%s", devices[i].name);
              printf("\t\t0x%04x", devices[i].attr.storage.devid);
              printf("\t%d",devices[i].numaid);
              printf("\t%d",devices[i].attr.storage.type);
              printf("\t%lluk\n", devices[i].attr.storage.size >> 1);
          }
      }
    }

  if(!strcmp(arg, "--all") || !strcmp(arg, "--sched")) {
      mdtm_thread_desc_t descs[1];

      pthread_t thread1;
      int data1 = 1;
      if(pthread_create (&thread1, NULL, print_message_function, (void *) &data1) != 0  ) {
        perror("pthread_create");
        return;
      }

      {
        int nnuma = 0, ncores, ndevices = 0;
        struct mdtm_device_s* devices;
        ndevices = mdtm_getpcidevices(&devices);

        printf("\n=================================================\n");
        printf("Scheduling from one device\n");
        printf("=================================================\n");
        for(int i = 0; i < ndevices; i++) {
            memset(descs, 0, sizeof(mdtm_thread_desc_t));
            //      descs[0].pid = 0;
            descs[0].flags = MDTM_CPUBIND_THREAD;
            descs[0].id.tid = thread1;
            descs[0].devices[0] = devices[i].name;
//            descs[0].numaindex = 1;
            mdtm_schedule_threads(descs, 1);
            printf("bound cpu = %d\t numa = %d\n", descs[0].boundcpu, descs[0].numaindex);
        }
      }
  }

  if(!strcmp(arg, "--all") || !strcmp(arg, "--zone")) {
      struct bitmask *cpus, *mems;
      char cpus_buf[128], mems_buf[128];
      int result;

      cpus = bitmask_alloc(24);
      mems = bitmask_alloc(24);

      printf("\n=================================================\n");
      printf("Zone\n");
      printf("=================================================\n");
      if ((result = mdtm_zone_getmask(cpus, mems)) < 0) {
          printf("Zone failed. result = %d: (-1: error -2: opmode not support zone)\n", result);
          goto done;
      }

      bitmask_displaylist(cpus_buf, 128, cpus);
      bitmask_displaylist(mems_buf, 128, mems);
      printf("Get current Zone: \ncpus: %s\nmems: %s\n", cpus_buf, mems_buf);

      bitmask_clearrange(cpus,0,24);
      bitmask_clearrange(mems,0,24);
      bitmask_setrange(cpus, 4, 8);
      bitmask_setrange(mems, 4, 8);
      bitmask_displaylist(cpus_buf, 128, cpus);
      bitmask_displaylist(mems_buf, 128, mems);
      printf("Set new zone: \ncpus: %s\nmems: %s\n", cpus_buf, mems_buf);

      pid_t pid = getpid();
      result = mdtm_zone_movetask(pid);
      printf("Move task: pid=%d result=%d\n", pid, result);

      pid = getpid();
      result = mdtm_zone_migratetask(pid);
      printf("Migrate task: pid=%d result=%d\n", pid, result);
  }

  if(!strcmp(arg, "--all") || !strcmp(arg, "--numa")) {
      int nodes, i;
      long long totalm, freem;
      printf("\n=================================================\n");
      printf("System functions\n");
      printf("=================================================\n");
      nodes = mdtm_numa_nodes();
      for(i = 0; i < nodes; i++) {
          totalm = mdtm_numa_nodesize(i, &freem);
          printf("node = %d, size=%llu free=%llu\n", i, totalm, freem);
      }

  }

  if(!strcmp(arg, "--all") || !strcmp(arg, "--mem")) {
      int numa = 0;
      int size = 102400;
      void *buff;

      printf("\n=================================================\n");
      printf("Memory functions\n");
      printf("=================================================\n");

      for(int numa = 0; numa < mdtm_numa_nodes(); numa++) {
          int result = mdtm_loc_malloc2(numa, &buff, size);
          if(result < 0 || !buff)
            printf("mdtm_loc_malloc2 failed on numa %d\n", numa);
          else {
              char *test_str = (char*)std::string("I am happy with mem").c_str();
              printf("mdtm_loc_malloc2 succeed: addr=%p, size=%d\n", buff, size);
              strcpy((char*)buff, test_str);
              printf("write to mem: %s \t read from mem: %s\n",test_str, (char*)buff);
              mdtm_loc_mfree(buff, size);
          }
      }
  }

  if(!strcmp(arg, "--all") || !strcmp(arg, "--filemap")) {
      char                  filepath[] = "/home";

      printf("\n=================================================\n");
      printf("API: mdtm_map_file2()\n");
      printf("=================================================\n");
      test_filemap_api(filepath);
  }

done:
  mdtm_deinit();
}

int main(int argc, char** argv) {
  char *arg = argv[1];
  if(!arg) {
       printf("Usage: test_mdtm_tree [--option]\n");
       printf("topology:         show the topology\n");
       printf("cpuaffinity:      show cpus in affinity of devices\n");
       return -1;
   }

//  test_big_file(argc, argv);
//  test_meta_create3(argc, argv);
//  test_meta_extract3(argc, argv);

//  test_meta_create2(argc, argv);
//  test_meta_extract2(argc, argv);

//  test_meta_create(argc, argv);
//  test_meta_extract(argv[1], 1, 0);

//  test_dirqueue(argc, argv);

//  test_qdu(argc, argv);
//  test_mdtm_config_api(argc,argv);
//  test_loc_malloc();
//  test_mapping();
//  test_pipe_api();
//  test_df_api();
//    test_fiemap_api();
//    test_lvm_api();
  test_mdtm_public_api(argc, argv);
  test_mdtm_private_api(argc, argv);
  return 0;
}

#ifdef __cplusplus
}
#endif




