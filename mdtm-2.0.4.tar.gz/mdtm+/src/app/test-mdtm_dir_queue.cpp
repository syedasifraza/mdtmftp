/*
 * test-mdtm_filefrag.cpp
 *
 *  Created on: Jan. 7, 2019
 *      Author: liangz
 */


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string>
#include <string.h>
#include <ctype.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include "mdtm.h"

#ifdef __cplusplus
extern "C"
{
#endif

static
void
print_queue_stat(void *q)
{
    size_t	nentries;

    printf("Queue Statistics\n--------------------------\n");
    nentries = mdtm_dir_queue_size(q, MDTM_DIR_QUEUE_SIZE_FILE);
    printf("Total number of files: %zu\n", nentries);

    nentries = mdtm_dir_queue_size(q, MDTM_DIR_QUEUE_SIZE_DIR);
    printf("Total number of directories: %zu\n", nentries);

    nentries = mdtm_dir_queue_size(q, MDTM_DIR_QUEUE_SIZE_FILE | MDTM_DIR_QUEUE_SIZE_DIR);
    printf("Total number of files and directories: %zu\n", nentries);
    printf("\n");
}

static
long
read_long_from_stdin()
{
	char line[1024], *p, *e;
	long v;

	fgets(line, sizeof(line), stdin);
	if(isdigit(line[0]) == 0)
		return -1;
	p = line;
	v = strtol(p, &e, 10);
	return v;
}

int main(int argc, char** argv) {
	void	*inq, *outq;
    char *	buff;
    char    path[256];
    size_t 	buffSize, nentries;
    long long used;
	long	offset;
    mdtm_file_entry_t	entry;
    int		rc;
    long	nblocks;

	char *arg = argv[1];
	if(argc < 3) {
		printf("Usage: test_mdtm_dir_queue path_to_directory path_to_temp_directory\n");
		printf("Example: test_dirq /data1/linux/ /tmp/linux/");
		return -1;
	}

	// create the queue from directory
    inq = (void*)mdtm_dir_queue_create(argv[1]);
    if(inq == 0) {
    	printf("mdtm_dir_queue_create() failed.\n");
    	return -1;
    }

    // print statistics of queue
    print_queue_stat(inq);

    // create meta data
    nentries = mdtm_dir_queue_size(inq, MDTM_DIR_QUEUE_SIZE_FILE | MDTM_DIR_QUEUE_SIZE_DIR);
    nblocks = mdtm_dir_queue_blocks(inq, 0);
//    buffSize = nentries * (MDTM_META_ENTRY_SIZE + MDTM_META_ENTRY_SIZE/2);
    buffSize = nblocks * MDTM_META_ENTRY_SIZE + 1024;
    buff = (char*)malloc(buffSize);
    if(buff == 0) {
    	printf("memory allocation failed.\n");
    	return -1;
    }
    memset(buff,0, buffSize);
    used = mdtm_dir_queue_create_meta2(inq, (void*) buff, buffSize);
    if(used < 0) {
    	printf("mdtm test: mdtm_dir_queue_create_meta2() failed\n");
    	return -1;
    }
    printf("Meta Data Statistics\n----------------------\n");
    printf("entries: %zu, meta buff size=%zu, meta buff used = %lld\n", nentries, buffSize, used);
    printf("\n");


    // recreate queue from meta data
    outq = (void*)mdtm_dir_queue_create(0);
    mdtm_dir_queue_parse_meta2(
    	outq,
        buff,
		used,
        argv[2]);

    // print statistics of queue
    print_queue_stat(outq);

    while(1) {
    	printf("\nEnter the offset: ");
    	offset = read_long_from_stdin();
    	if(offset < 0) {
    		printf("invalid value for offset: %ld. Exit.\n", offset);
    		break;
    	}
    	rc = mdtm_dir_queue_find3(
    			outq,
				offset,
				&entry);
    	if( rc != 0 ) {
    		printf("mdtm_dir_queue_find3 cannot find any entry @offset:%ld\n", offset);
    		continue;
    	}
    	printf("find an entry @%ld: %s, offset=%lld size=%zu\n", offset, entry.path, entry.offset, entry.size);
    }


//    mdtm_dir_queue_iter(outq);



    free(buff);

	return 0;
}

#ifdef __cplusplus
}
#endif
