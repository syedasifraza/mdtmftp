/*
 * test-mdtm_lvm.cpp
 *
 *  Created on: Oct 7, 2018
 *      Author: liangz
 */



#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <stdlib.h>
#include "libmdtm/mdtm_lvm.cpp"

int main(int argc, char** argv) {

#ifdef HAVE_LVM2APP_H

	  mdtm_lv_seg_t *segs;
	  uint64_t file_start, file_end;
	  int nsegs, i;
	  char *lvname; // = "vg_capecod-lv_home";

//	  mdtm_lvm_display();

	  if(argc < 3) {
		  printf("Usage: test_lvm lvname start_addr end_addr\n");
		  printf("\t\t Example: sudo test_lvm vg_capecod-lv_home 0 53687091200\n");
		  printf("\t\t NOTE: sudo privilege is required to access LVM functions.\n");
		  return -1;
	  }

	  lvname = argv[1];
	  file_start = atoll(argv[2]);	//0UL;
	  file_end = atoll(argv[3]);	//53687091200UL;

	  mdtm_lvm_init();
	  nsegs = mdtm_lvm_get_physical_devices(
	      lvname,
	      file_start, file_end,
	      &segs);

	  printf("Analyze file with range: %lu %lu\n", file_start, file_end);
	  printf("seg\trange\t\tdevice\n");
	  for(i= 0; i < nsegs; i++) {
	      printf("%d\t%lu %lu\t %s\n",i, segs[i].m_start, segs[i].m_end,segs[i].dev);
	  }

	  mdtm_lvm_fini();
#else
	  printf("LVM not supported\n");
#endif

	  return 0;
}

#ifdef __cplusplus
}
#endif



