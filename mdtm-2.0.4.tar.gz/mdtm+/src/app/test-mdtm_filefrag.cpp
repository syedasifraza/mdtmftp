/*
 * test-mdtm_filefrag.cpp
 *
 *  Created on: Oct 7, 2018
 *      Author: liangz
 */



#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <stdlib.h>
#include "libmdtm/mdtm_filefrag.cpp"


int main(int argc, char** argv) {
	mdtm_fileext_t *fileexts;
	int i, nexts;

	char *arg = argv[1];
	if(argc < 2) {
		printf("Usage: test_filefrag pathtofile\n");
		return -1;
	}

	printf("\nindex  offset_start    offset_end\n");

	nexts = mdtm_filefrag_get(argv[1], &fileexts);
	printf("mdtm_filefrag_get:\n");
	for(i = 0; i < nexts; i++) {
		printf("%d	%lu	%lu\n", i, fileexts[i].start, fileexts[i].end);
	}

	{
		int 			ret, fd;
		struct stat 	filestat;
		char *			fname;

		fname = argv[1];

		if(!fname) {
			fprintf(stderr, "[libmdtm] error @%s: invalid arguments.", __FUNCTION__);
			return -1;
		}

		fd = open(fname, O_RDONLY);
		if (fd == -1) {
			fprintf(stderr, "[libmdtm] error @%s: can not open %s: %s\n", __FUNCTION__, fname, strerror(errno));
			return -1;
		}

		if(fstat(fd, &filestat) != 0) {
			fprintf(stderr, "[libmdtm] error @%s: fstat failed: %d: \"%s\"\n",
					__FUNCTION__,
					errno,
					strerror(errno));
			close(fd);
			return -1;
		}

		if (!S_ISREG(filestat.st_mode)) {
			fprintf(stderr, "[libmdtm] %s: not a regular file\n", fname);
			close(fd);
			return -1;
		}

		if(filestat.st_size == 0) {
			fprintf(stderr, "[libmdtm] %s: zero bytes\n", fname);
			close(fd);
			return -1;
		}

		printf("mdtm_do_fiemap:\n");
		if ((nexts = do_fiemap(fd, &filestat, &fileexts)) < 0) {
			fprintf(stderr, "[libmdtm] %s: fiemap failed.\n", fname);
		}
		else {
			for(i = 0; i < nexts; i++) {
				printf("%d	%lu	%lu\n", i, fileexts[i].start, fileexts[i].end);
			}
		}

		printf("mdtm_do_fibmap:\n");
		if ((nexts = do_fibmap(fd, &filestat, &fileexts)) < 0) {
			fprintf(stderr, "[libmdtm] %s: fibmap failed.\n", fname);
		}
		else {
			for(i = 0; i < nexts; i++) {
				printf("%d	%lu	%lu\n", i, fileexts[i].start, fileexts[i].end);
			}
		}

		close(fd);
	}

	return 0;
}

#ifdef __cplusplus
}
#endif

