/*
 * Copyright (c) 2013, Intel Corporation
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *   * Neither the name of Intel Corporation nor the names of its contributors
 *     may be used to endorse or promote products derived from this software
 *     without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* This file contains main(). */

#include <inttypes.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <signal.h>
#include <libgen.h>
#include "include/types.h"
#include "include/util.h"
#include "include/proc.h"
#include "include/disp.h"
#include "include/perf.h"
#include "include/poll.h"
#include "include/metrics.h"
#include "include/util.h"
#include "include/os/plat.h"
#include "include/os/node.h"
#include "include/os/os_util.h"

//static void sigint_handler(int sig);
//static void print_usage(const char *exec_name);

int g_ncpus;
int g_sortkey;
precise_type_t g_precise;
pid_t g_numatop_pid;
struct timeval g_tvbase;

/* For automated test. */
int g_run_secs;

/* For log and dump files */
FILE *logp = NULL, *dump = NULL;

static int g_inited = 0;

/*
 * The main function.
 */
int
numatop_init(void)//int argc, char *argv[])
{
	int ret = 1, debug_level = 0;
	boolean_t locked = B_FALSE;
	char c;

	if (!os_authorized()) {
		return (1);
	}

	g_sortkey = SORT_KEY_CPU;
	g_precise = PRECISE_NORMAL;
	g_numatop_pid = getpid();
	g_run_secs = TIME_NSEC_MAX;
	optind = 1;
	opterr = 0;
#if 0
	/*
	 * Parse command line arguments.
	 */
	while ((c = getopt(argc, argv, "d:l:o:f:t:hf:s:")) != EOF) {
		switch (c) {
		case 'h':
			print_usage(argv[0]);
			ret = 0;
			goto L_EXIT0;

		case 'l':
			debug_level = atoi(optarg);
			if ((debug_level < 0) || (debug_level > 2)) {
				stderr_print("Invalid log_level %d.\n",
				    debug_level);
				print_usage(argv[0]);
				goto L_EXIT0;
			}
			break;

		case 'f':
			if (optarg == NULL) {
				stderr_print("Invalid output file.\n");
				goto L_EXIT0;
			}

			if ((logp = fopen(optarg, "w")) == NULL) {
				stderr_print("Cannot open '%s' for writing.\n",
				    optarg);
				goto L_EXIT0;
			}
			break;

		case 's':
			if (optarg == NULL) {
				print_usage(argv[0]);
				goto L_EXIT0;
			}

			if (strcasecmp(optarg, "high") == 0) {
				g_precise = PRECISE_HIGH;
				break;
			}

			if (strcasecmp(optarg, "low") == 0) {
				g_precise = PRECISE_LOW;
				break;
			}

			if (strcasecmp(optarg, "normal") == 0) {
				g_precise = PRECISE_NORMAL;
				break;
			}

			stderr_print("Invalid sampling_precision '%s'.\n",
			    optarg);
			print_usage(argv[0]);
			goto L_EXIT0;

		case 'd':
			if (optarg == NULL) {
				stderr_print("Invalid dump file.\n");
				goto L_EXIT0;
			}

			if ((dump = fopen(optarg, "w")) == NULL) {
				stderr_print("Cannot open '%s' for dump.\n",
				    optarg);
				goto L_EXIT0;
			}
			break;

		case 't':
			g_run_secs = atoi(optarg);
			if (g_run_secs <= 0) {
				stderr_print("Invalid run time %d.\n",
				    g_run_secs);
				print_usage(argv[0]);
				goto L_EXIT0;
			}
			break;

		case ':':
			stderr_print("Missed argument for option %c.\n",
			    optopt);
			print_usage(argv[0]);
			goto L_EXIT0;

		case '?':
			stderr_print("Unrecognized option %c.\n", optopt);
			print_usage(argv[0]);
			goto L_EXIT0;
		}
	}
#endif

	if (plat_detect() != 0) {
		stderr_print("CPU is not supported!\n");
		ret = 2;
		goto L_EXIT0;
	}

	/*
	 * Support only one numatop instance running.
	 */
	if (os_numatop_lock(&locked) != 0) {
		stderr_print("Fail to lock numatop!\n");
		goto L_EXIT0;
	}

	if (locked) {
		stderr_print("Another numatop instance is running!\n");
		goto L_EXIT0;
	}

	(void) gettimeofday(&g_tvbase, 0);

	if (debug_init(debug_level, logp) != 0) {
		goto L_EXIT1;
	}

	logp = NULL;

	if (dump_init(dump) != 0) {
		goto L_EXIT2;
	}

	dump = NULL;

	/*
	 * Calculate how many nanoseconds for a TSC cycle.
	 */
	os_calibrate();

	if (map_init() != 0) {
		goto L_EXIT3;
	}

	/*
	 * Initialize for the "window-switching" table.
	 */
	switch_table_init();

	if (proc_group_init() != 0) {
		goto L_EXIT4;
	}

	if (node_group_init() != 0) {
		stderr_print("The node/cpu number is out of range, \n"
		    "numatop supports up to %d nodes and %d CPUs\n",
		    NNODES_MAX, NCPUS_MAX);
		goto L_EXIT5;
	}

	debug_print(NULL, 2, "Detected %d online CPUs\n", g_ncpus);
	stderr_print("NumaTOP is starting ...\n");

	/*
	 * Initialize the perf sampling facility.
	 */
	if (perf_init() != 0) {
		debug_print(NULL, 2, "perf_init() is failed\n");
		goto L_EXIT7;
	}

        /*
         * Initialize for poll thread.
         */
	if(poll_init() != 0) {
            perf_fini();
            goto L_EXIT7;
        }
#if 0
	/*
	 * Initialize for display and create console thread & display thread.
	 */
	if (disp_init() != 0) {
		perf_fini();
		goto L_EXIT7;
	}

	/*
	 * Wait the disp thread to exit. The disp thread would
	 * exit when user hits the hotkey 'Q' or press "CTRL+C".
	 */
	disp_dispthr_quit_wait();

	/*
	 * Notify cons thread to exit.
	 */
	disp_consthr_quit();

	disp_fini();
	stderr_print("NumaTOP is exiting ...\n");
	(void) fflush(stdout);
#endif
	ret = 0;
	g_inited = 1;
	return ret;

L_EXIT7:
//	disp_cons_ctl_fini();

L_EXIT6:
	node_group_fini();

L_EXIT5:
	proc_group_fini();

L_EXIT4:
	map_fini();

L_EXIT3:
	dump_fini();

L_EXIT2:
	debug_fini();

L_EXIT1:
	os_numatop_unlock();
	exit_msg_print();

L_EXIT0:
	if (dump != NULL) {
		(void) fclose(dump);
	}

	if (logp != NULL) {
		(void) fclose(logp);
	}
	return (ret);
}

void
numatop_fini(void) {
        poll_fini();

        node_group_fini();
        proc_group_fini();
        map_fini();
        dump_fini();
        debug_fini();
        os_numatop_unlock();
        exit_msg_print();

        if (dump != NULL) {
                (void) fclose(dump);
        }

        if (logp != NULL) {
                (void) fclose(logp);
        }

        g_inited = 0;
        return;
}

int
numatop_nodes() {
  return node_num();
}

int
numatop_node_lat(int *lats) {
  if(g_inited == 0)
    return -2;

  if(!lats || (sizeof(lats)/sizeof(int) < node_num()))
    return -1;

  return ((metrics_get_lats(lats) > 0)? 0 : -1) ;
}
// end of new APIs
