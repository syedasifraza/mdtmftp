/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef SRC_LIBNUMATOP_COMMON_INCLUDE_METRICS_H_
#define SRC_LIBNUMATOP_COMMON_INCLUDE_METRICS_H_

#include <sys/types.h>
#include <sys/time.h>
#include <inttypes.h>
#include <pthread.h>
#include "types.h"
#include "reg.h"
#include "./os/os_win.h"

#ifdef __cplusplus
extern "C" {
#endif

extern boolean_t metrics_lat_dist(void);
extern int metrics_get_lats(int *lats);

#ifdef __cplusplus
}
#endif



#endif /* SRC_LIBNUMATOP_COMMON_INCLUDE_METRICS_H_ */
