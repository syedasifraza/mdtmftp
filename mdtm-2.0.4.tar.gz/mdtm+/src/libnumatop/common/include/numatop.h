/*
 * numaop.h
 *
 *  Created on: Oct 29, 2015
 *      Author: liangz
 */

#ifndef SRC_LIBNUMATOP_COMMON_INCLUDE_NUMATOP_H_
#define SRC_LIBNUMATOP_COMMON_INCLUDE_NUMATOP_H_

#ifdef __cplusplus
extern "C" {
#endif

int
numatop_init(void);

void
numatop_fini(void);

int
numatop_nodes();

int
numatop_node_lat(int *lats);

#ifdef __cplusplus
}
#endif

#endif /* SRC_LIBNUMATOP_COMMON_INCLUDE_NUMATOP_H_ */
