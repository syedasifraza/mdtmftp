/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef SRC_LIBNUMATOP_COMMON_INCLUDE_POLL_H_
#define SRC_LIBNUMATOP_COMMON_INCLUDE_POLL_H_

#include <sys/types.h>
#include <sys/time.h>
#include <inttypes.h>
#include <pthread.h>
#include "types.h"
#include "util.h"
#include "cmd.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
        POLL_FLAG_NONE = 0,
        POLL_FLAG_LL_DATA_READY,
        POLL_FLAG_QUIT
} poll_flag_t;

typedef struct _poll_ctl {
        pthread_mutex_t mutex;
        pthread_cond_t cond;
        pthread_t thr;
        boolean_t inited;
        cmd_t cmd;
        poll_flag_t flag;
        int intval_ms;
} poll_ctl_t;

extern int poll_init(void);
extern void poll_fini(void);
extern void poll_ll_data_ready(int);

#ifdef __cplusplus
}
#endif



#endif /* SRC_LIBNUMATOP_COMMON_INCLUDE_POLL_H_ */
