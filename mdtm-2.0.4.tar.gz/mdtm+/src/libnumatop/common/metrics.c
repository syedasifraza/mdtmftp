/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/
#include <inttypes.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <sys/mman.h>
#include <signal.h>
#include <curses.h>
#include <syslog.h>
#include "include/types.h"
#include "include/util.h"
#include "include/disp.h"
#include "include/reg.h"
#include "include/lwp.h"
#include "include/proc.h"
#include "include/page.h"
#include "include/perf.h"
#include "include/os/node.h"
#include "include/os/plat.h"
#include "include/os/os_util.h"
#include "include/os/os_win.h"

#define MAX_LATENCY     10000UL         // maximum legal value of latency

static void *g_buf = NULL;


static int
llrec2addr(track_proc_t *proc, track_lwp_t *lwp, void ***addr_arr,
        int **lat_arr, int *addr_num)
{
        perf_llrecgrp_t *grp;
        void **addr_buf;
        int *lat_buf;
        int i, ret = -1;

        (void) pthread_mutex_lock(&proc->mutex);

        if (lwp == NULL) {
                grp = &proc->llrec_grp;
        } else {
                grp = &lwp->llrec_grp;
        }

        if (grp->nrec_cur == 0) {
                *addr_arr = NULL;
                *lat_arr = NULL;
                *addr_num = 0;
                ret = 0;
                goto L_EXIT;
        }

        if ((addr_buf = zalloc(sizeof (void *) * grp->nrec_cur)) == NULL) {
                goto L_EXIT;
        }

        if ((lat_buf = zalloc(sizeof (int) * grp->nrec_cur)) == NULL) {
                free(addr_buf);
                goto L_EXIT;
        }

        for (i = 0; i < grp->nrec_cur; i++) {
                addr_buf[i] = (void *)(grp->rec_arr[i].addr);
                lat_buf[i] = grp->rec_arr[i].latency;
        }

        *addr_arr = addr_buf;
        *lat_arr = lat_buf;
        *addr_num = grp->nrec_cur;
        ret = 0;

L_EXIT:
        (void) pthread_mutex_unlock(&proc->mutex);
        return (ret);
}

static void
accdst_data_save(map_nodedst_t *nodedst_arr, int nnodes_max, int naccess_total,
        int nid_idx, accdst_line_t *line)
{
        node_t *node;
        int naccess;

        (void) memset(line, 0, sizeof (accdst_line_t));
        if ((node = node_valid_get(nid_idx)) == NULL) {
                return;
        }

        if ((node->nid < 0) || (node->nid >= nnodes_max)) {
                return;
        }

        line->nid = node->nid;
        naccess = nodedst_arr[node->nid].naccess;

        if (naccess_total > 0) {
                line->access_ratio = (double)naccess / (double)naccess_total;
        }

        if (naccess > 0) {
                line->latency = nodedst_arr[node->nid].total_lat / naccess;
        }
        syslog(LOG_NOTICE, "lines[%d].lat=%lld ns total_lat=%lld naccess=%d\n",
                nid_idx, (unsigned long long)cyc2ns(line->latency), (unsigned long long) nodedst_arr[node->nid].total_lat, naccess);
}

struct _nodedst_ {
  map_nodedst_t nodedst_arr[NNODES_MAX];
  int           naccess_total;
};

static int
metrics_lat_dist_calc(track_proc_t *proc, void* arg, boolean_t *note_out)
{
//        win_reg_t *r;
        track_lwp_t *lwp = NULL;
        void **addr_arr = NULL;
        int *lat_arr = NULL;
        int addr_num, i, nnodes, naccess_total = 0;
        map_nodedst_t nodedst_arr[NNODES_MAX];
        accdst_line_t *lines;
        char content[WIN_LINECHAR_MAX], intval_buf[16];
        boolean_t ret = B_FALSE;
        void *buf = NULL;
        int lwpid = 0;
        struct _nodedst_ *g_nodedst = (struct _nodedst_ *)arg;

        *note_out = B_FALSE;

        if ((lwpid != 0) &&
            (lwp = proc_lwp_find(proc, lwpid)) == NULL) {
                win_invalid_lwp();
                *note_out = B_TRUE;
                return (int)(B_FALSE);
        }

        if (llrec2addr(proc, lwp, &addr_arr, &lat_arr, &addr_num) != 0) {
                goto L_EXIT;
        }

//        (void) memset(nodedst_arr, 0, sizeof (map_nodedst_t) * NNODES_MAX);
        if (addr_num > 0) {
                if (map_addr2nodedst(proc->pid, addr_arr, lat_arr, addr_num,
                    g_nodedst->nodedst_arr, NNODES_MAX, &naccess_total) != 0) {
                        goto L_EXIT;
                }
                g_nodedst->naccess_total += naccess_total;
        }

        disp_intval(intval_buf, 16);

        if (lwp == NULL) {
                (void) snprintf(content, sizeof (content),
                    "Memory access node distribution overview "
                    "(pid: %d, interval: %s)",
                    proc->pid, intval_buf);
        } else {
                (void) snprintf(content, sizeof (content),
                    "Memory access node distribution overview "
                    "(lwpid: %d, interval: %s)",
                    lwp->id, intval_buf);
        }

L_EXIT:
        if (lwp != NULL) {
                lwp_refcount_dec(lwp);
        }

        if (addr_arr != NULL) {
                free(addr_arr);
        }

        if (lat_arr != NULL) {
                free(lat_arr);
        }

        return (int)(ret);
}

/*
 * The calculating of the latency distribution
 */
boolean_t
metrics_lat_dist(void)
{
        boolean_t ret = B_TRUE;
        int nnodes;
        int i;
        accdst_line_t *lines;
        struct _nodedst_ total_dst;

        memset(&total_dst, 0, sizeof (struct _nodedst_));

        proc_traverse_ext(metrics_lat_dist_calc, &total_dst);

        nnodes = node_num();

        if(!g_buf)
          if ((g_buf = zalloc(sizeof (accdst_line_t) * nnodes)) == NULL) {
              syslog(LOG_NOTICE, "zalloc failed\n");
              return B_FALSE;
          }

        lines = (accdst_line_t *)(g_buf);

        /*
         * Save the per-node data with metrics in scrolling buffer.
         */
        for (i = 0; i < nnodes; i++) {
                accdst_data_save(total_dst.nodedst_arr, NNODES_MAX, total_dst.naccess_total, i,
                    &lines[i]);
//                syslog(LOG_NOTICE, "lines[%d].lat=%lld\n", i, cyc2ns(lines[i].latency));
        }

//        proc_refcount_dec(proc);
        return (ret);
}

int
metrics_get_lats(int *lats)
{
  int i, nnodes;
  accdst_line_t *lines;

  nnodes = node_num();
  for (i = 0; i < nnodes; i++) {
      if(lines[i].latency < MAX_LATENCY)
        lats[i] = cyc2ns(lines[i].latency);
      else
        lats[i] = 0;
  }

  return nnodes;
}

