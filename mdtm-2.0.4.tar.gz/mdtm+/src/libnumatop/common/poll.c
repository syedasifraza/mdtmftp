/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <inttypes.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <strings.h>
#include <pthread.h>
#include <time.h>
#include <errno.h>
#include <curses.h>
#include "include/types.h"
#include "include/util.h"
#include "include/lwp.h"
#include "include/proc.h"
#include "include/disp.h"
#include "include/page.h"
#include "include/cmd.h"
#include "include/win.h"
#include "include/os/node.h"
#include "include/poll.h"
#include "include/perf.h"
#include "include/metrics.h"

static poll_ctl_t s_poll_ctl;
//static cons_ctl_t s_cons_ctl;

static int      poll_start(void);
static void     poll_stop(void);
static void*    poll_handler(void *);

/*
 * Initialization for the poll control structure.
 */
static int
poll_ctl_init(void)
{
        (void) memset(&s_poll_ctl, 0, sizeof (s_poll_ctl));
        if (pthread_mutex_init(&s_poll_ctl.mutex, NULL) != 0) {
                return (-1);
        }

        if (pthread_cond_init(&s_poll_ctl.cond, NULL) != 0) {
                (void) pthread_mutex_destroy(&s_poll_ctl.mutex);
                return (-1);
        }

        s_poll_ctl.inited = B_TRUE;
        return (0);
}

/*
 * Clean up the resources of poll control structure.
 */
static void
poll_ctl_fini(void)
{
        if (s_poll_ctl.inited) {
                (void) pthread_mutex_destroy(&s_poll_ctl.mutex);
                (void) pthread_cond_destroy(&s_poll_ctl.cond);
                s_poll_ctl.inited = B_FALSE;
        }
}

/*
 * Initialization for the display control structure and
 * creating 'disp thread'.
 */
int
poll_init(void)
{
        if (poll_ctl_init() != 0) {
                return (-1);
        }

        if (poll_start() != 0) {
            poll_ctl_fini();
            return (-1);
        }

        return (0);
}

/*
 * Before free the resources of poll control structure,
 * make sure the 'poll thread' quit yet.
 */
void
poll_fini(void)
{
        poll_stop();
        poll_ctl_fini();
}

static void
pollthr_flagset_nolock(poll_flag_t flag)
{
        s_poll_ctl.flag = flag;
        (void) pthread_cond_signal(&s_poll_ctl.cond);
}

/*
 * Notify 'poll thread' that the perf load latency data is ready.
 */
void
poll_ll_data_ready(int intval_ms)
{
        (void) pthread_mutex_lock(&s_poll_ctl.mutex);
        s_poll_ctl.intval_ms = intval_ms;
        pollthr_flagset_nolock(POLL_FLAG_LL_DATA_READY);
        (void) pthread_mutex_unlock(&s_poll_ctl.mutex);
}

/*
 * Create 'poll thread'.
 */
static int
poll_start(void)
{
        if (pthread_create(&s_poll_ctl.thr, NULL, poll_handler, NULL) != 0) {
                debug_print(NULL, 2, "Create poll thread failed.\n");
                return (-1);
        }

        return (0);
}

/*
 * Stoop 'poll thread'.
 */
static
void
poll_stop(void)
{
        (void) pthread_mutex_lock(&s_poll_ctl.mutex);
        pollthr_flagset_nolock(POLL_FLAG_QUIT);
        (void) pthread_mutex_unlock(&s_poll_ctl.mutex);
        (void) pthread_join(s_poll_ctl.thr, NULL);
}

static void
timeout_set(struct timespec *timeout, int nsec)
{
        struct timeval tv;

        (void) gettimeofday(&tv, NULL);
        timeout->tv_sec = tv.tv_sec + nsec;
        timeout->tv_nsec = tv.tv_usec * 1000;
}

/*
 * The handler of 'poll thread'.
 */
static void *
poll_handler(void *arg)
{
        poll_flag_t flag;
        int status = 0;
        cmd_t cmd;
        boolean_t quit, pagelist_inited = B_FALSE;
        struct timespec timeout;
        uint64_t start_ms;
        int64_t diff_ms;

        timeout_set(&timeout, 0);
        start_ms = current_ms();

        for (;;) {
                status = 0;
                (void) pthread_mutex_lock(&s_poll_ctl.mutex);
                flag = s_poll_ctl.flag;
                while (flag == POLL_FLAG_NONE) {
                        status = pthread_cond_timedwait(&s_poll_ctl.cond,
                            &s_poll_ctl.mutex, &timeout);
                        flag = s_poll_ctl.flag;
                        if (status == ETIMEDOUT) {
                                break;
                        }
                }

                s_poll_ctl.flag = POLL_FLAG_NONE;
                (void) pthread_mutex_unlock(&s_poll_ctl.mutex);

                diff_ms = current_ms() - start_ms;
                if (g_run_secs <= diff_ms / MS_SEC) {
                        g_run_secs = TIME_NSEC_MAX;
                        debug_print(NULL, 2,
                            "disp: it's time to exit\n");
                        continue;
                }

                if ((status == ETIMEDOUT) && (flag == POLL_FLAG_NONE)) {
                    /*
                     * Force a 'refresh' operation.
                     */
                    if (perf_ll_smpl(0, 0) == 0) {
//                        return (B_TRUE);
                    }
                    timeout_set(&timeout, DISP_DEFAULT_INTVAL);
                    continue;
                }

                switch (flag) {
                case POLL_FLAG_QUIT:
                        debug_print(NULL, 2,
                            "poll: received POLL_FLAG_QUIT\n");
                        goto L_EXIT;

                case POLL_FLAG_LL_DATA_READY:
                        /*
                         * Calculate metrics of latency distribution.
                         */
                        metrics_lat_dist();

                        timeout_set(&timeout, DISP_DEFAULT_INTVAL);
                        break;

                default:
                        break;
                }
        }

L_EXIT:

        /*
         * Let the perf thread exit first.
         */
        perf_fini();

        debug_print(NULL, 2, "poll thread is exiting\n");
        return (NULL);
}


