/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef FIRSTBLOCK_H_
#define FIRSTBLOCK_H_

#include <stdint.h>

extern uint64_t firstblock(const char *fname);





#endif /* FIRSTBLOCK_H_ */
