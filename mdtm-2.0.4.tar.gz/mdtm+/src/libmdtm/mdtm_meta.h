/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_META_H_
#define MDTM_META_H_

#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif
//platform
#include <errno.h>
#define ARCHIVE_ERRNO_FILE_FORMAT EINVAL
#ifndef ARCHIVE_ERRNO_MISC
#define ARCHIVE_ERRNO_MISC (-1)

//#define       UINT64_MAX (~(uint64_t)0)
//#define       INT64_MAX ((int64_t)(UINT64_MAX >> 1))
//#define       INT64_MIN ((int64_t)(~INT64_MAX))

#endif
//end platform

# define        __LA_MODE_T     int

#define AE_IFMT         ((__LA_MODE_T)0170000)
#define AE_IFREG        ((__LA_MODE_T)0100000)
#define AE_IFLNK        ((__LA_MODE_T)0120000)
#define AE_IFSOCK       ((__LA_MODE_T)0140000)
#define AE_IFCHR        ((__LA_MODE_T)0020000)
#define AE_IFBLK        ((__LA_MODE_T)0060000)
#define AE_IFDIR        ((__LA_MODE_T)0040000)
#define AE_IFIFO        ((__LA_MODE_T)0010000)

struct archive;
struct archive_entry;

#define ARCHIVE_EOF       1     /* Found end of archive. */
#define ARCHIVE_OK        0     /* Operation was successful. */
#define ARCHIVE_RETRY   (-10)   /* Retry might succeed. */
#define ARCHIVE_WARN    (-20)   /* Partial success. */
/* For example, if write_header "fails", then you can't push data. */
#define ARCHIVE_FAILED  (-25)   /* Current operation cannot complete. */
/* But if write_header is "fatal," then this archive is dead and useless. */
#define ARCHIVE_FATAL   (-30)   /* No more operations are possible. */

/*
 * Callbacks are invoked to automatically read/skip/write/open/close the
 * archive. You can provide your own for complex tasks (like breaking
 * archives across multiple tapes) or use standard ones built into the
 * library.
 */

/* Returns pointer and size of next block of data from archive. */
typedef ssize_t    archive_read_callback(struct archive *,
                            void *_client_data, const void **_buffer);

/* Seeks to specified location in the file and returns the position.
 * Whence values are SEEK_SET, SEEK_CUR, SEEK_END from stdio.h.
 * Return ARCHIVE_FATAL if the seek fails for any reason.
 */
typedef int64_t    archive_seek_callback(struct archive *,
    void *_client_data, int64_t offset, int whence);

/* Skips at most request bytes from archive and returns the skipped amount.
 * This may skip fewer bytes than requested; it may even skip zero bytes.
 * If you do skip fewer bytes than requested, libarchive will invoke your
 * read callback and discard data as necessary to make up the full skip.
 */
typedef int64_t    archive_skip_callback(struct archive *,
                            void *_client_data, int64_t request);
/* Returns size actually written, zero on EOF, -1 on error. */
typedef ssize_t    archive_write_callback(struct archive *,
                            void *_client_data,
                            const void *_buffer, size_t _length);

typedef int     archive_open_callback(struct archive *, void *_client_data);

typedef int     archive_close_callback(struct archive *, void *_client_data);

/* Switches from one client data object to the next/prev client data object.
 * This is useful for reading from different data blocks such as a set of files
 * that make up one large file.
 */
typedef int archive_switch_callback(struct archive *, void *_client_data1,
                            void *_client_data2);

/*
 * Codes to identify various stream filters.
 */
#define ARCHIVE_FILTER_NONE     0
#define ARCHIVE_FILTER_GZIP     1
#define ARCHIVE_FILTER_BZIP2    2
#define ARCHIVE_FILTER_COMPRESS 3
#define ARCHIVE_FILTER_PROGRAM  4
#define ARCHIVE_FILTER_LZMA     5
#define ARCHIVE_FILTER_XZ       6
#define ARCHIVE_FILTER_UU       7
#define ARCHIVE_FILTER_RPM      8
#define ARCHIVE_FILTER_LZIP     9
#define ARCHIVE_FILTER_LRZIP    10
#define ARCHIVE_FILTER_LZOP     11
#define ARCHIVE_FILTER_GRZIP    12

//private
void
__archive_errx(int retvalue, const char *msg);

void
__archive_ensure_cloexec_flag(int fd);
//end private

#define ARCHIVE_FORMAT_TAR                      0x30000
#define ARCHIVE_FORMAT_TAR_USTAR                (ARCHIVE_FORMAT_TAR | 1)
#define ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE      (ARCHIVE_FORMAT_TAR | 2)
#define ARCHIVE_FORMAT_TAR_PAX_RESTRICTED       (ARCHIVE_FORMAT_TAR | 3)
#define ARCHIVE_FORMAT_TAR_GNUTAR               (ARCHIVE_FORMAT_TAR | 4)

struct archive  *archive_read_new(void);
int archive_read_support_format_tar(struct archive *);

/* Set various callbacks. */
int archive_read_set_open_callback(struct archive *,
    archive_open_callback *);
int archive_read_set_read_callback(struct archive *,
    archive_read_callback *);
int archive_read_set_seek_callback(struct archive *,
    archive_seek_callback *);
int archive_read_set_skip_callback(struct archive *,
    archive_skip_callback *);
int archive_read_set_close_callback(struct archive *,
    archive_close_callback *);
/* Callback used to switch between one data object to the next */
int archive_read_set_switch_callback(struct archive *,
    archive_switch_callback *);

/* Opening freezes the callbacks. */
int archive_read_open1(struct archive *);

/*
 * A variety of shortcuts that invoke archive_read_open() with
 * canned callbacks suitable for common situations.  The ones that
 * accept a block size handle tape blocking correctly.
 */
/* Use this if you know the filename.  Note: NULL indicates stdin. */
int archive_read_open_filename(struct archive *,
                     const char *_filename, size_t _block_size);
/* Use this for reading multivolume files by filenames.
 * NOTE: Must be NULL terminated. Sorting is NOT done. */
int archive_read_open_filenames(struct archive *,
                     const char **_filenames, size_t _block_size);
int archive_read_open_filename_w(struct archive *,
                     const wchar_t *_filename, size_t _block_size);
/* archive_read_open_file() is a deprecated synonym for ..._open_filename(). */
int archive_read_open_file(struct archive *,
                     const char *_filename, size_t _block_size);
/* Read an archive that's stored in memory. */
int archive_read_open_memory(struct archive *,
                     void * buff, size_t size);
/* A more involved version that is only used for internal testing. */
int archive_read_open_memory2(struct archive *a, void *buff,
                     size_t size, size_t read_size);
/* Read an archive that's already open, using the file descriptor. */
int archive_read_open_fd(struct archive *, int _fd,
                     size_t _block_size);
/* Read an archive that's already open, using a FILE *. */
/* Note: DO NOT use this with tape drives. */
//int archive_read_open_FILE(struct archive *, FILE *_file);

/* Parses and returns next entry header. */
int archive_read_next_header(struct archive *,
                     struct archive_entry **);

/* Parses and returns next entry header using the archive_entry passed in */
int archive_read_next_header2(struct archive *,
                     struct archive_entry *);
/* Record the dev/ino of a file that will not be written.  This is
 * generally set to the dev/ino of the archive being read. */
void          archive_read_extract_set_skip_file(struct archive *,
                     int64_t, int64_t);

/* Close the file and release most resources. */
int            archive_read_close(struct archive *);
/* Release all resources and destroy the object. */
/* Note that archive_read_free will call archive_read_close for you. */
int            archive_read_free(struct archive *);

/*
 * A zero-copy version of archive_read_data that also exposes the file offset
 * of each returned block.  Note that the client has no way to specify
 * the desired size of the block.  The API does guarantee that offsets will
 * be strictly increasing and that returned blocks will not overlap.
 */
//__LA_DECL int archive_read_data_block(struct archive *a,
//                    const void **buff, size_t *size, __LA_INT64_T *offset);

/*-
 * Some convenience functions that are built on archive_read_data:
 *  'skip': skips entire entry
 *  'into_buffer': writes data into memory buffer that you provide
 *  'into_fd': writes data to specified filedes
 */
int archive_read_data_skip(struct archive *);
//__LA_DECL int archive_read_data_into_fd(struct archive *, int fd);

/* This sets the first data object. */
int archive_read_set_callback_data(struct archive *, void *);
/* This sets data object at specified index */
int archive_read_set_callback_data2(struct archive *, void *,
    unsigned int);
/* This adds a data object at the specified index. */
int archive_read_add_callback_data(struct archive *, void *,
    unsigned int);
/* This appends a data object to the end of list */
int archive_read_append_callback_data(struct archive *, void *);
/* This prepends a data object to the beginning of list */
int archive_read_prepend_callback_data(struct archive *, void *);

/* The "flags" argument selects optional behavior, 'OR' the flags you want. */

/* Default: Do not try to set owner/group. */
#define ARCHIVE_EXTRACT_OWNER                   (0x0001)
/* Default: Do obey umask, do not restore SUID/SGID/SVTX bits. */
#define ARCHIVE_EXTRACT_PERM                    (0x0002)
/* Default: Do not restore mtime/atime. */
#define ARCHIVE_EXTRACT_TIME                    (0x0004)
/* Default: Replace existing files. */
#define ARCHIVE_EXTRACT_NO_OVERWRITE            (0x0008)
/* Default: Try create first, unlink only if create fails with EEXIST. */
#define ARCHIVE_EXTRACT_UNLINK                  (0x0010)
/* Default: Do not restore ACLs. */
#define ARCHIVE_EXTRACT_ACL                     (0x0020)
/* Default: Do not restore fflags. */
#define ARCHIVE_EXTRACT_FFLAGS                  (0x0040)
/* Default: Do not restore xattrs. */
#define ARCHIVE_EXTRACT_XATTR                   (0x0080)
/* Default: Do not try to guard against extracts redirected by symlinks. */
/* Note: With ARCHIVE_EXTRACT_UNLINK, will remove any intermediate symlink. */
#define ARCHIVE_EXTRACT_SECURE_SYMLINKS         (0x0100)
/* Default: Do not reject entries with '..' as path elements. */
#define ARCHIVE_EXTRACT_SECURE_NODOTDOT         (0x0200)
/* Default: Create parent directories as needed. */
#define ARCHIVE_EXTRACT_NO_AUTODIR              (0x0400)
/* Default: Overwrite files, even if one on disk is newer. */
#define ARCHIVE_EXTRACT_NO_OVERWRITE_NEWER      (0x0800)
/* Detect blocks of 0 and write holes instead. */
#define ARCHIVE_EXTRACT_SPARSE                  (0x1000)
/* Default: Do not restore Mac extended metadata. */
/* This has no effect except on Mac OS. */
#define ARCHIVE_EXTRACT_MAC_METADATA            (0x2000)
/* Default: Use HFS+ compression if it was compressed. */
/* This has no effect except on Mac OS v10.6 or later. */
#define ARCHIVE_EXTRACT_NO_HFS_COMPRESSION      (0x4000)
/* Default: Do not use HFS+ compression if it was not compressed. */
/* This has no effect except on Mac OS v10.6 or later. */
#define ARCHIVE_EXTRACT_HFS_COMPRESSION_FORCED  (0x8000)

struct archive *
archive_write_new(void);

int archive_write_set_bytes_per_block(struct archive *,
                     int bytes_per_block);
int archive_write_get_bytes_per_block(struct archive *);

int
archive_write_set_bytes_in_last_block(struct archive *_a, int bytes);

int archive_write_get_bytes_in_last_block(struct archive *);

int
archive_write_set_skip_file(struct archive *_a, int64_t d, int64_t i);

struct archive_entry *
archive_entry_clear(struct archive_entry *entry);

void
archive_entry_free(struct archive_entry *entry);

struct archive_entry *
archive_entry_new(void);

/*
 * This form of archive_entry_new2() will pull character-set
 * conversion information from the specified archive handle.  The
 * older archive_entry_new(void) form is equivalent to calling
 * archive_entry_new2(NULL) and will result in the use of an internal
 * default character-set conversion.
 */
struct archive_entry  *archive_entry_new2(struct archive *);

/*
 * Retrieve fields from an archive_entry.
 *
 * There are a number of implicit conversions among these fields.  For
 * example, if a regular string field is set and you read the _w wide
 * character field, the entry will implicitly convert narrow-to-wide
 * using the current locale.  Similarly, dev values are automatically
 * updated when you write devmajor or devminor and vice versa.
 *
 * In addition, fields can be "set" or "unset."  Unset string fields
 * return NULL, non-string fields have _is_set() functions to test
 * whether they've been set.  You can "unset" a string field by
 * assigning NULL; non-string fields have _unset() functions to
 * unset them.
 *
 * Note: There is one ambiguity in the above; string fields will
 * also return NULL when implicit character set conversions fail.
 * This is usually what you want.
 */
//time_t         archive_entry_atime(struct archive_entry *);
// long           archive_entry_atime_nsec(struct archive_entry *);
// int            archive_entry_atime_is_set(struct archive_entry *);
// time_t         archive_entry_birthtime(struct archive_entry *);
// long           archive_entry_birthtime_nsec(struct archive_entry *);
// int            archive_entry_birthtime_is_set(struct archive_entry *);
// time_t         archive_entry_ctime(struct archive_entry *);
// long           archive_entry_ctime_nsec(struct archive_entry *);
// int            archive_entry_ctime_is_set(struct archive_entry *);
// dev_t          archive_entry_dev(struct archive_entry *);
// int            archive_entry_dev_is_set(struct archive_entry *);
// dev_t          archive_entry_devmajor(struct archive_entry *);
// dev_t          archive_entry_devminor(struct archive_entry *);
__LA_MODE_T     archive_entry_filetype(struct archive_entry *);
// void           archive_entry_fflags(struct archive_entry *,
//                            unsigned long * /* set */,
//                            unsigned long * /* clear */);
// const char    *archive_entry_fflags_text(struct archive_entry *);
int64_t       archive_entry_gid(struct archive_entry *);
const char    *archive_entry_gname(struct archive_entry *);
//__LA_DECL const wchar_t *archive_entry_gname_w(struct archive_entry *);
const char    *archive_entry_hardlink(struct archive_entry *);
//__LA_DECL const wchar_t *archive_entry_hardlink_w(struct archive_entry *);
//__LA_DECL __LA_INT64_T   archive_entry_ino(struct archive_entry *);
//__LA_DECL __LA_INT64_T   archive_entry_ino64(struct archive_entry *);
//__LA_DECL int            archive_entry_ino_is_set(struct archive_entry *);
__LA_MODE_T    archive_entry_mode(struct archive_entry *);
time_t         archive_entry_mtime(struct archive_entry *);
//__LA_DECL long           archive_entry_mtime_nsec(struct archive_entry *);
//__LA_DECL int            archive_entry_mtime_is_set(struct archive_entry *);
//__LA_DECL unsigned int   archive_entry_nlink(struct archive_entry *);
const char    *archive_entry_pathname(struct archive_entry *);
//__LA_DECL const wchar_t *archive_entry_pathname_w(struct archive_entry *);
//__LA_DECL __LA_MODE_T    archive_entry_perm(struct archive_entry *);
//__LA_DECL dev_t          archive_entry_rdev(struct archive_entry *);
dev_t          archive_entry_rdevmajor(struct archive_entry *);
dev_t          archive_entry_rdevminor(struct archive_entry *);
const char    *archive_entry_sourcepath(struct archive_entry *);
//__LA_DECL const wchar_t *archive_entry_sourcepath_w(struct archive_entry *);
int64_t   archive_entry_size(struct archive_entry *);
//__LA_DECL int            archive_entry_size_is_set(struct archive_entry *);
//__LA_DECL const char    *archive_entry_strmode(struct archive_entry *);
const char    *archive_entry_symlink(struct archive_entry *);
//__LA_DECL const wchar_t *archive_entry_symlink_w(struct archive_entry *);
int64_t   archive_entry_uid(struct archive_entry *);
const char    *archive_entry_uname(struct archive_entry *);
//__LA_DECL const wchar_t *archive_entry_uname_w(struct archive_entry *);


/*
 * Set fields in an archive_entry.
 *
 * Note: Before libarchive 2.4, there were 'set' and 'copy' versions
 * of the string setters.  'copy' copied the actual string, 'set' just
 * stored the pointer.  In libarchive 2.4 and later, strings are
 * always copied.
 */

//__LA_DECL void  archive_entry_set_atime(struct archive_entry *, time_t, long);
//__LA_DECL void  archive_entry_unset_atime(struct archive_entry *);
//#if defined(_WIN32) && !defined(__CYGWIN__)
//__LA_DECL void archive_entry_copy_bhfi(struct archive_entry *, BY_HANDLE_FILE_INFORMATION *);
//#endif
//__LA_DECL void  archive_entry_set_birthtime(struct archive_entry *, time_t, long);
//__LA_DECL void  archive_entry_unset_birthtime(struct archive_entry *);
//__LA_DECL void  archive_entry_set_ctime(struct archive_entry *, time_t, long);
//__LA_DECL void  archive_entry_unset_ctime(struct archive_entry *);
//__LA_DECL void  archive_entry_set_dev(struct archive_entry *, dev_t);
//__LA_DECL void  archive_entry_set_devmajor(struct archive_entry *, dev_t);
//__LA_DECL void  archive_entry_set_devminor(struct archive_entry *, dev_t);
void  archive_entry_set_filetype(struct archive_entry *, unsigned int);
//__LA_DECL void  archive_entry_set_fflags(struct archive_entry *,
//            unsigned long /* set */, unsigned long /* clear */);
///* Returns pointer to start of first invalid token, or NULL if none. */
///* Note that all recognized tokens are processed, regardless. */
//__LA_DECL const char *archive_entry_copy_fflags_text(struct archive_entry *,
//            const char *);
//__LA_DECL const wchar_t *archive_entry_copy_fflags_text_w(struct archive_entry *,
//            const wchar_t *);
//void  archive_entry_set_gid(struct archive_entry *, __LA_INT64_T);
void  archive_entry_set_gname(struct archive_entry *, const char *);
//void  archive_entry_copy_gname(struct archive_entry *, const char *);
//void  archive_entry_copy_gname_w(struct archive_entry *, const wchar_t *);
//int   archive_entry_update_gname_utf8(struct archive_entry *, const char *);
void  archive_entry_set_hardlink(struct archive_entry *, const char *);
void  archive_entry_copy_hardlink(struct archive_entry *, const char *);
void  archive_entry_copy_hardlink_w(struct archive_entry *, const wchar_t *);
int   archive_entry_update_hardlink_utf8(struct archive_entry *, const char *);
//void  archive_entry_set_ino(struct archive_entry *, __LA_INT64_T);
//void  archive_entry_set_ino64(struct archive_entry *, __LA_INT64_T);
void  archive_entry_set_link(struct archive_entry *, const char *);
void  archive_entry_copy_link(struct archive_entry *, const char *);
void  archive_entry_copy_link_w(struct archive_entry *, const wchar_t *);
int   archive_entry_update_link_utf8(struct archive_entry *, const char *);
void  archive_entry_set_mode(struct archive_entry *, mode_t);
void  archive_entry_set_mtime(struct archive_entry *, time_t, long);
void  archive_entry_unset_mtime(struct archive_entry *);
void  archive_entry_set_nlink(struct archive_entry *, unsigned int);
void  archive_entry_set_pathname(struct archive_entry *, const char *);
void  archive_entry_copy_pathname(struct archive_entry *, const char *);
void  archive_entry_copy_pathname_w(struct archive_entry *, const wchar_t *);
int   archive_entry_update_pathname_utf8(struct archive_entry *, const char *);
void  archive_entry_set_perm(struct archive_entry *, int);
//void  archive_entry_set_rdev(struct archive_entry *, dev_t);
//void  archive_entry_set_rdevmajor(struct archive_entry *, dev_t);
//void  archive_entry_set_rdevminor(struct archive_entry *, dev_t);
void  archive_entry_set_size(struct archive_entry *, int64_t s);
void  archive_entry_unset_size(struct archive_entry *);
void  archive_entry_copy_sourcepath(struct archive_entry *, const char *);
void  archive_entry_copy_sourcepath_w(struct archive_entry *, const wchar_t *);
void  archive_entry_set_symlink(struct archive_entry *, const char *);
void  archive_entry_copy_symlink(struct archive_entry *, const char *);
void  archive_entry_copy_symlink_w(struct archive_entry *, const wchar_t *);
int   archive_entry_update_symlink_utf8(struct archive_entry *, const char *);
void  archive_entry_set_uid(struct archive_entry *, int64_t);
void  archive_entry_set_uname(struct archive_entry *, const char *);
void  archive_entry_copy_uname(struct archive_entry *, const char *);
void  archive_entry_copy_uname_w(struct archive_entry *, const wchar_t *);
int   archive_entry_update_uname_utf8(struct archive_entry *, const char *);

void
archive_entry_copy_stat(struct archive_entry *entry, const struct stat *st);

int
archive_write_header(struct archive *a, struct archive_entry *entry);

int
archive_write_finish_entry(struct archive *a);

int
archive_write_set_format_ustar(struct archive *_a);

int
archive_write_set_format_gnutar(struct archive *);

int
archive_write_open(struct archive *, void *,
                     archive_open_callback *, archive_write_callback *,
                     archive_close_callback *);
int
archive_write_open_fd(struct archive *a, int fd);

int
archive_write_open_filename(struct archive *, const char *_file);

int              archive_write_close(struct archive *);

int              archive_write_free(struct archive *);

//int            archive_errno(struct archive *);
const char    *archive_error_string(struct archive *);
const char    *archive_format_name(struct archive *);
//int            archive_format(struct archive *);
//void           archive_clear_error(struct archive *);
void           archive_set_error(struct archive *, int _err,
    const char *fmt, ...);
//void           archive_copy_error(struct archive *dest,
//    struct archive *src);
//int            archive_file_count(struct archive *);

int
archive_write_open_memory(struct archive *a, void *buff, size_t buffSize, size_t *used);

int
archive_read_open_memory(struct archive *a, void *buff, size_t size);


/*
 * Utility functions to set and get entry attributes by translating
 * character-set. These are designed for use in format readers and writers.
 *
 * The return code and interface of these are quite different from other
 * functions for archive_entry defined in archive_entry.h.
 * Common return code are:
 *   Return 0 if the string conversion succeeded.
 *   Return -1 if the string conversion failed.
 */

#define archive_entry_gname_l   _archive_entry_gname_l
int _archive_entry_gname_l(struct archive_entry *,
    const char **, size_t *, struct archive_string_conv *);
#define archive_entry_hardlink_l        _archive_entry_hardlink_l
int _archive_entry_hardlink_l(struct archive_entry *,
    const char **, size_t *, struct archive_string_conv *);
#define archive_entry_pathname_l        _archive_entry_pathname_l
int _archive_entry_pathname_l(struct archive_entry *,
    const char **, size_t *, struct archive_string_conv *);
#define archive_entry_symlink_l _archive_entry_symlink_l
int _archive_entry_symlink_l(struct archive_entry *,
    const char **, size_t *, struct archive_string_conv *);
#define archive_entry_uname_l   _archive_entry_uname_l
int _archive_entry_uname_l(struct archive_entry *,
    const char **, size_t *, struct archive_string_conv *);
//#define archive_entry_acl_text_l _archive_entry_acl_text_l
//int _archive_entry_acl_text_l(struct archive_entry *, int,
//    const char **, size_t *, struct archive_string_conv *);
//
//
//#define archive_entry_copy_gname_l      _archive_entry_copy_gname_l
//int _archive_entry_copy_gname_l(struct archive_entry *,
//    const char *, size_t, struct archive_string_conv *);
//#define archive_entry_copy_hardlink_l   _archive_entry_copy_hardlink_l
//int _archive_entry_copy_hardlink_l(struct archive_entry *,
//    const char *, size_t, struct archive_string_conv *);
//#define archive_entry_copy_link_l       _archive_entry_copy_link_l
//int _archive_entry_copy_link_l(struct archive_entry *,
//    const char *, size_t, struct archive_string_conv *);
//#define archive_entry_copy_pathname_l   _archive_entry_copy_pathname_l
//int _archive_entry_copy_pathname_l(struct archive_entry *,
//    const char *, size_t, struct archive_string_conv *);
#define archive_entry_copy_symlink_l    _archive_entry_copy_symlink_l
int _archive_entry_copy_symlink_l(struct archive_entry *,
    const char *, size_t, struct archive_string_conv *);
//#define archive_entry_copy_uname_l      _archive_entry_copy_uname_l
//int _archive_entry_copy_uname_l(struct archive_entry *,
//    const char *, size_t, struct archive_string_conv *);



struct archive *
archive_write_disk_new(void);

#ifdef __cplusplus
}
#endif

#endif /* MDTM_META_H_ */
