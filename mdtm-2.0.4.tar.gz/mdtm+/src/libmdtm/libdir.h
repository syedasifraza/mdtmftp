/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/
#ifndef MDTM_LIBDIR_H_
#define MDTM_LIBDIR_H_

#include <iostream>
#include <vector>
//#include <algorithm>
#include <functional>
#include <deque>
#include <map>
#include <set>

#include <sys/types.h>
#include <dirent.h>
#include <err.h>
#include <fcntl.h>
#include <grp.h>
#include <pwd.h>
#include <sys/stat.h>
#include <unistd.h>

#include <vector>
#include <string>

#include <err.h>

#include <linux/fs.h>
//#include <linux/fiemap.h>

//typedef uint64_t __u64;
//typedef uint32_t __u32;
#include "fiemap.h"


#include "firstblock.h"

namespace libdir {
	struct dentry {
		mutable unsigned long d_ino;
		std::string d_name;
		std::string parent;
		char d_type;
		size_t d_position;

		// fiemap extents
//		struct fiemap *p_filemap;
		std::vector<struct fiemap_extent> fie_extents;

		dentry() : d_ino(0), d_type(0), st_initialized(false) {}
		dentry(struct dirent *de, std::string parent)
		                : d_ino(de->d_ino), d_type(de->d_type), st_initialized(false) {
			d_name = std::string(de->d_name);
			this->parent = parent;
		}
		//                              : d_position(0), st_initialized(false) {


		bool operator<(const struct dentry &other) const {
			return this->d_ino < other.d_ino;
		}

		bool operator>(const struct dentry &other) const {
			return this->d_ino > other.d_ino;
		}

		bool is_file() { return this->d_type == DT_REG; }
		bool is_dir() { return this->d_type == DT_DIR; }
		bool is_link() { return this->d_type == DT_LNK; }
		bool is_fifo() { return this->d_type == DT_FIFO; }
		bool is_unknown() { return this->d_type == 0; }

		void set_is_file() { this->d_type = DT_REG; }
		void set_is_dir() { this->d_type = DT_DIR; }
		void set_is_link() { this->d_type = DT_LNK; }
		void set_is_fifo() { this->d_type = DT_FIFO; }
		void set_is_unknown() { this->d_type = 0; }

		void set_stat(size_t s) { st.st_size = s; st_initialized = true;}
		void set_position(size_t p) { this->d_position = p; }
		void set_name(std::string name) { this->d_name = name; }
		void set_parent(std::string parent) { this->parent = parent; }

		size_t size() const {
			return st_initialized? (size_t)st.st_size : 0;
		}

		size_t position() const {
			return d_position;
		}

		const struct stat& stat() const {
			if (! st_initialized) {
				std::string name = fq();
				st_initialized = true;
				if (lstat(name.c_str(), &st) < 0)
					err(EXIT_FAILURE, "stat %s failed", name.c_str());
				if (d_ino == 0)
					d_ino = st.st_ino;
			}

			return st;
		}

		std::string fq() const {

			if (!parent.empty() && parent[parent.length() - 1] == '/')
				return parent + d_name;
			else if(!parent.empty())
			  return parent + "/" + d_name;
			else
			  return d_name;
		}

		// return path excluding the precedent of root
		std::string fq2(std::string root) const {
		  std::string t = parent;

		  std::size_t pos = root.rfind("/");
		  std::string str3 = root.substr (pos + 1);

		  std::string::size_type i = t.find(root);

		  if (i != std::string::npos)
		     t.erase(i, root.length() + 1);     //TODO: added extra 1 to remove the backslash

		  if((t == "") && (d_name == "."))
		    return str3;
		  else if(t == "")
		    return str3 + "/" + d_name;
		  else if(d_name == ".")
		    return str3 + "/" + t;
		  else
		    return str3 + "/" + t + "/" + d_name;
		}

		/* calculate the number of blocks to contain the path name compiling GNU Tar
		 *		root: the root directory
		 *		name_size: minimum size to split
		 *		block_size: the block size to contain name string
		 */
		long splitname(std::string root, int name_size, int block_size) const {

			long nbytes, nblocks;

			if( root.empty() )
				nbytes = fq().size();
			else
				nbytes = fq2(root).size();
			if(nbytes > name_size)
				// 1 block for @link, 1 block for tail, others for name string
				nblocks = 1 + (nbytes + block_size) / block_size + 1;
			else
				nblocks = 1;

			return nblocks;
		}

	private:
		mutable struct stat st;
		mutable bool st_initialized;
	};

	template<class T>
	struct CScan {
		std::set<T> elevator;
		uint64_t last_position;

		CScan() : last_position(0) {
		}

		void push(T item) { 
			elevator.insert(item);
		}

		T pop() {
			typename std::set<T>::iterator it;
			T bound;
			bound.d_ino = last_position;

			it = elevator.lower_bound(bound);
			if (it == elevator.end()) {
				if (last_position == 0)
					throw new std::exception();// "pop on empty queue"
				last_position = 0;
				return pop();
			}

			T ret = *it;
			elevator.erase(it);
			last_position = ret.d_ino;
			return ret;
		}

		bool empty() {
			return elevator.empty();
		}
	};

	class traverser {
		std::string root;

	public:
		traverser() {}

		void walk(std::string r) {
			root = r;

			dentry d;
			d.d_ino = -1;
			d.set_is_dir();
			d.parent = root;
			d.d_name = ".";

			if (add_directory(d)) {         //TODO: add_directory() should not be needed
				d.stat();
				dirheap.push(d);
			}

			while (!dirheap.empty()) {
				d = dirheap.pop();
				heapwalk(d);
			}

			flush();
//			std::cout <<"qdu finished"<<std::endl;

		}

		void flush() {
			while (!fileheap.empty()) {
				dentry d = fileheap.pop();
				add_file_data(d);
			}
		}

		std::string getroot() { return root;}
		void setroot(char * rootpath) {
		  if(rootpath)
		    root = std::string(rootpath);
		}

	private:
		CScan<dentry> dirheap;
		CScan<dentry> fileheap;

		virtual bool add_directory(const dentry& dir) = 0;
		virtual bool add_file(const dentry& dir) = 0;
		virtual bool add_fifo(const dentry& dir) = 0;
		virtual void add_file_data(const dentry& dir) = 0;
		virtual void add_zero_file(const dentry& dir) = 0;
		virtual void add_link_file(const dentry& dir) = 0;

		void queuefile(dentry& file) {
			if (! add_file(file))
				return;

			// The function firstblock() returns extent mapping info
			// that is used to sort files. If 0 is returned, it could
			// be because that file is zero-length or other cases like
			// spare. Then use stat() to get more details.
			file.d_ino = firstblock(file.fq().c_str());
			if(file.d_ino)
			  fileheap.push(file);
			else {
			    // On some file systems like ceph+xfs, fibmap()/fiemap()
			    // return 0 block for files created by fallocate() even
			    // the file size is non-zero. To address that issue, we
			    // use stat information instead for those cases.
			    file.stat();
			    if(file.d_ino && file.size() > 0)
			      fileheap.push(file);
			    else
			      add_zero_file(file);
			}
		}

		void heapwalk(dentry& d) {
			if (d.is_file()) {
				queuefile(d);
				return;
			}
			else if (d.is_fifo()) {
				d.set_is_fifo();
				add_fifo(d);
				return;
			}
			else if (d.is_unknown() || d.is_link()) {
				if (S_ISDIR(d.stat().st_mode)) {
				    d.set_is_dir();
				}
				else if(S_ISREG(d.stat().st_mode)) {
					d.set_is_file();
					queuefile(d);
					return;
				}
				else if(S_ISLNK(d.stat().st_mode)) {
				    d.set_is_link();
				    add_link_file(d);
				    return;
				}
				else if(S_ISFIFO(d.stat().st_mode)) {
					d.set_is_fifo();
					add_fifo(d);
					return;
				}
			}

			d.set_is_dir();
			if (! add_directory(d)){
				std::cout << "error: 2" <<std::endl;
				return;
			}

			std::string path;
			if (d.d_name != ".") {
				path = d.parent + "/" + d.d_name;
			} else  {
				path = d.parent;
			}

			std::vector<dentry> l;
			DIR *dir = opendir(path.c_str());
			struct dirent *de;
			if (!dir){
			    std::cout << "error: 3:" << path.c_str() <<std::endl;
			    return;
			}

			while ((de = readdir(dir)) != 0) {
				l.push_back(dentry(de, path));
			}
			closedir(dir);

			for (std::vector<dentry>::iterator it = l.begin(); it != l.end(); ++it) {
				if (it->d_name == "." || it->d_name == "..")
					continue;

				dirheap.push(*it);
			}
		}
	};
}
#endif /* MDTM_LIBDIR_H_ */
