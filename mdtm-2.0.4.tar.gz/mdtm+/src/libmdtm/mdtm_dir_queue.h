/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_DIR_QUEUE_H_
#define MDTM_DIR_QUEUE_H_
#include <assert.h>
#include <iostream>
#include <list>
#include <libdir.h>

#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>

#include <linux/fs.h>

//#include <sys/types.h>
//#include <sys/stat.h>
//#include <archive.h>
//#include <archive_entry.h>
//#include <fcntl.h>
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <unistd.h>


#define LINUX_STAT_BLOCK_SIZE 512
enum {
    MAX_EXTENT = 64
};

struct mdtm_dir_queue : public libdir::traverser {
        size_t  total_size;

        typedef std::list<libdir::dentry>::const_iterator const_iterator;

        const_iterator    cur_it;

        const_iterator begin() const {
          return( file_list.begin() ) ;
        }
        const_iterator end() const {
          return( file_list.end() ) ;
        }
        const_iterator begin2() const {
          return( dir_list.begin() ) ;
        }
        const_iterator end2() const {
          return( dir_list.end() ) ;
        }
        const_iterator begin3() const {
          return( zero_list.begin() ) ;
        }
        const_iterator end3() const {
          return( zero_list.end() ) ;
        }
        const_iterator begin4() const {
          return( link_list.begin() ) ;
        }
        const_iterator end4() const {
          return( link_list.end() ) ;
        }
        const_iterator begin_fifo() const {
          return( fifo_list.begin() ) ;
        }
        const_iterator end_fifo() const {
          return( fifo_list.end() ) ;
        }

        mdtm_dir_queue() : total_size(0), nblocks(0){};

        mdtm_dir_queue(const char *pathname);

        virtual ~mdtm_dir_queue();

        bool add_directory(const libdir::dentry& de);

        bool add_directory(std::string dirname);

        /* Called when file metadata is ready */
        bool add_file(const libdir::dentry& de);

        bool add_file(std::string filename, size_t size);

        bool add_fifo(const libdir::dentry& de);

        bool add_fifo(std::string filename, size_t size);

        /* Iff we return true from add_file,
         * this will be called when it is a good time for
         * reading file data.  Not used for du */
        void add_file_data(const libdir::dentry& de);

        void add_zero_file(const libdir::dentry& de);

        void add_link_file(const libdir::dentry& de);

        bool file_empty() const {
          return file_list.empty() && fifo_list.empty();
        }

        bool dir_empty() const {
          return dir_list.empty();
        }

        libdir::dentry
        remove_directory();

        libdir::dentry
        remove_file();

        libdir::dentry
        peek_file();

        bool add_sortedpaths(
            char **     path_array,
            size_t *    size_array,
            int         array_size);

        long blocks();

private:
        std::list<libdir::dentry> dir_list;
        std::list<libdir::dentry> file_list;
        std::list<libdir::dentry> zero_list;
        std::list<libdir::dentry> link_list;
        std::list<libdir::dentry> fifo_list;

        std::set<std::string> sorted_paths;
        long 					  nblocks;
};




#endif /* MDTM_DIR_QUEUE_H_ */
