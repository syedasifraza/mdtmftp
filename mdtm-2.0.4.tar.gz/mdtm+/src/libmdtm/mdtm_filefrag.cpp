/*
 * mdtm_filefrag.cpp
 *
 *  Created on: Jan 22, 2016
 *      Author: liangz
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>
#include <linux/fs.h>
#include "fiemap.h"
#include <errno.h>
#include <linux/fs.h>
#include <linux/fiemap.h>
#include "mdtm_filefrag.h"

#define FS_IOC_FIEMAP                   _IOWR('f', 11, struct fiemap)

#ifdef __cplusplus
extern "C" {
#endif

static
int do_fibmap (
		int 				fd,
		struct stat *		st,
		mdtm_fileext_t **	exts)
{
	int 					ret;
	unsigned long 			block = 0;
	unsigned long 			num_blocks;
	uint64_t 				blk_idx, hole = ~0ULL;
	struct file_extent 		ext;
    mdtm_fileext_t *        extents;
    int                     nextents = 0;

    num_blocks = (st->st_size + st->st_blksize - 1) / st->st_blksize;
    if (num_blocks <= 0)
    	return 0;

    extents = (mdtm_fileext_t*)calloc(num_blocks, sizeof(*extents));
    if(extents == NULL) {
    	fprintf(stderr, "[libmdtm] error @%s: calloc failed: %d: \"%s\"\n",
    			__FUNCTION__, errno, strerror(errno));
    	return -1;
    }

    memset(&ext, 0, sizeof(ext));

    for (blk_idx = 0; blk_idx < num_blocks; blk_idx++) {
    	unsigned int blknum = blk_idx;
    	uint64_t blknum64;
    	/*
    	 * FIBMAP takes a block index as input and on return replaces it with a
    	 * block number relative to the beginning of the filesystem/partition.
    	 * An output value of zero means "unallocated", or a "hole" in a sparse file.
    	 * Note that this is a 32-bit value, so it will not work properly on
    	 * files/filesystems with more than 4 billion blocks (~16TB),
    	 */
    	if (ioctl(fd, FIBMAP, &blknum) == -1) {
        	if (errno == EPERM)
        		fprintf(stderr, "[libmdtm] No permission to use FIBMAP ioctl; must have root privileges\n");
        	else
        		fprintf(stderr, "[libmdtm] FIBMAP %s\n", strerror(errno));
        	free(extents);
        	return -1;
    	}
    	blknum64 = blknum;	/* work in 64-bits as much as possible */

    	if (blk_idx && blknum64 == (ext.last_block + 1)) {
    		/*
    		 * Continuation of extent: Bump last_block and block_count.
    		 */
    		ext.last_block = blknum64 ? blknum64 : hole;
    		ext.block_count++;
    	} else {
    		/*
    		 * New extent: print previous extent (if any), and re-init the extent record.
    		 */
    		if (blk_idx) {
    			extents[nextents].start = ext.first_block * st->st_blksize;
    			extents[nextents].end = extents[nextents].start + ext.block_count * st->st_blksize - 1;
    			nextents++;
    		}
    		ext.first_block = blknum64;
    		ext.last_block  = blknum64 ? blknum64 : hole;
    		ext.block_count = 1;
    		ext.byte_offset = blk_idx * st->st_blksize;
    	}
    }
	extents[nextents].start = ext.first_block * st->st_blksize;
	extents[nextents].end = extents[nextents].start + ext.block_count * st->st_blksize - 1;
	nextents++;

	*exts = extents;

    return nextents;
}

static
int do_fiemap (
		int 				fd,
		struct stat *		st,
		mdtm_fileext_t **	exts)
{
	int 					ret;
    int 					needed;
    mdtm_fileext_t *        extents;
    int                     nextents;
    struct fiemap *			fiemap;

    fiemap = (struct fiemap *)calloc(1, sizeof(struct fiemap));
    if(fiemap == NULL) {
        fprintf(stderr, "[libmdtm] error @%s: calloc failed: %d: \"%s\"\n",
        		__FUNCTION__, errno, strerror(errno));
    	return -1;
    }

    fiemap->fm_start = 0;
    fiemap->fm_length = st->st_size;
    fiemap->fm_flags = 0;
    fiemap->fm_extent_count = 0;

    ret = ioctl(fd, FS_IOC_FIEMAP, fiemap);
    if (ret == -1) {
    	if (errno == EBADR)
    		fprintf(stderr, "[libmdtm] error @%s: Kernel does not support the flags: 0x%x\n",
    				__FUNCTION__, fiemap->fm_flags);
    	else if (errno == EPERM)
    		fprintf(stderr, "[libmdtm] No permission to use FIBMAP ioctl; must have root privileges\n");
    	else
    		fprintf(stderr, "[libmdtm] error @%s: fiemap info %d: \"%s\"\n",
    				__FUNCTION__, errno, strerror(errno));
    	free(fiemap);
    	return -1;
    }

    needed = fiemap->fm_mapped_extents;
    if(needed == 0) {
    	// done with zero ext
    	free((void*)fiemap);
    	return 0;
    }

    fiemap = (struct fiemap *)realloc((void*)fiemap,
            sizeof(struct fiemap) + needed * sizeof(struct fiemap_extent));
    if(fiemap == NULL) {
        fprintf(stderr, "[libmdtm] error @%s: calloc failed: %d: \"%s\"\n",
        		__FUNCTION__,
        		errno,
                strerror(errno));
    	return -1;
    }

    fiemap->fm_extent_count = needed;

    ret = ioctl(fd, FS_IOC_FIEMAP, fiemap);
    if (ret < 0) {
    	if (errno == EBADR)
    		fprintf(stderr, "[libmdtm] error @%s: Kernel does not the flags: 0x%x\n",
    				__FUNCTION__, fiemap->fm_flags);
    	else
    		fprintf(stderr, "[libmdtm] error @%s: fiemap info %d: \"%s\"\n",
    				__FUNCTION__, errno, strerror(errno));
    	free(fiemap);
    	return -1;
    }

    extents = (mdtm_fileext_t*)calloc(fiemap->fm_mapped_extents, sizeof(*extents));
    if(extents == NULL) {
        fprintf(stderr, "[libmdtm] error @%s: calloc failed: %d: \"%s\"\n",
        		__FUNCTION__, errno, strerror(errno));
        free(fiemap);
    	return -1;
    }
    else
    {
      int i;
      for(i= 0; i < fiemap->fm_mapped_extents; i++) {
          extents[i].start = fiemap->fm_extents[i].fe_physical;	//fiemap->fm_extents[i].fe_logical;
          extents[i].end = extents[i].start + fiemap->fm_extents[i].fe_length - 1;
      }
      *exts = extents;
      nextents = fiemap->fm_mapped_extents;
    }

    free((void*)fiemap);

    return nextents;
}

int
mdtm_filefrag_get(
    const char *		fname,
    mdtm_fileext_t **	exts)
{
        int 			ret, fd;
        struct stat 	filestat;

        if(!fname || !exts) {
        	fprintf(stderr, "[libmdtm] error @%s: invalid arguments.", __FUNCTION__);
        	return -1;
        }

        fd = open(fname, O_RDONLY);
        if (fd == -1) {
                fprintf(stderr, "[libmdtm] error @%s: can not open %s: %s\n", __FUNCTION__, fname, strerror(errno));
                return -1;
        }

        if(fstat(fd, &filestat) != 0) {
            fprintf(stderr, "[libmdtm] error @%s: fstat failed: %d: \"%s\"\n",
            		__FUNCTION__,
            		errno,
                    strerror(errno));
            close(fd);
        	return -1;
        }

    	if(filestat.st_size == 0) {
    		fprintf(stderr, "[libmdtm] %s has zero byte.\n", fname);
    		close(fd);
    		return 0;
    	}

    	if ((ret = do_fiemap(fd, &filestat, exts)) < 0) {
    		fprintf(stderr, "[libmdtm] %s: fiemap failed. Try fibmap.\n", fname);
    		ret = do_fibmap(fd, &filestat, exts);
    	}

    	close(fd);
    	return ret;
}

#ifdef __cplusplus
}
#endif


