/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/
#include <mdtm_utils.h>

#include <iostream>
#include <string>
#include <cctype>

bool compareChar(char & c1, char & c2)
{
  if (c1 == c2)
    return true;
  else if (std::toupper(c1) == std::toupper(c2))
    return true;
  return false;
}

/*
 * Case Insensitive String Comparision
 */
bool caseInSensStringCompare(std::string &str1, std::string &str2)
{
  return ( (str1.size() == str2.size() ) &&
      std::equal(str1.begin(), str1.end(), str2.begin(), &compareChar) );
}



