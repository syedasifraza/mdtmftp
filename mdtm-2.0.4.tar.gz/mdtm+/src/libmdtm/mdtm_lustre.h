/*
 * mdtm_lustre.h
 *
 *  Created on: Aug 23, 2016
 *      Author: liangz
 */

#ifndef SRC_LIBMDTM_MDTM_LUSTRE_H_
#define SRC_LIBMDTM_MDTM_LUSTRE_H_

#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
mdtm_lustre_islustre(char *fs);

char *
mdtm_lustre_devname(const char *fs);

#ifdef __cplusplus
}
#endif

#endif /* SRC_LIBMDTM_MDTM_LUSTRE_H_ */
