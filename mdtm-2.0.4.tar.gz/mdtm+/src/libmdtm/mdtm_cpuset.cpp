/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>
#include <sys/mount.h>
#include <cstring>
#include <string>
#include <iostream>
#include <stdexcept>

#include <mdtm_cpuset.h>

mdtm_cpuset::mdtm_cpuset()
  : MdtmIpcMessage(0),
    class_name_("mdtm_cpuset"),
    mountpoint("/dev/cpuset"),
    cpusetpath_("mdtm")
{
  // init message
  MdtmIpcMessage::set_message_name(class_name_.c_str());
  cmdline_ = 0; //reinterpret_cast<struct cmd_line_s*>(MdtmIpcMessage::get_message_data_ptr());
  result_ = 0;  //reinterpret_cast<struct result_s*>(MdtmIpcMessage::get_message_response_ptr());

  // init masks, cp and etc...
  cpu_maskbits = cpuset_cpus_nbits();
  mem_maskbits = cpuset_mems_nbits();
  if((cpu_mask = bitmask_alloc(cpu_maskbits)) == NULL ||
      (mem_mask = bitmask_alloc(mem_maskbits)) == NULL ||
      (cp = cpuset_alloc()) == NULL)
    throw std::runtime_error("memory allocation failed.");
}

mdtm_cpuset::mdtm_cpuset(MdtmIpc* ipc)
  : MdtmIpcMessage(ipc),
    class_name_("mdtm_cpuset"),
    mountpoint("/dev/cpuset"),
    cpusetpath_("mdtm")
{
  // init message
  MdtmIpcMessage::set_message_name(class_name_.c_str());
  cmdline_ = reinterpret_cast<struct cmd_line_s*>(MdtmIpcMessage::get_message_data_ptr());
  result_ = reinterpret_cast<struct result_s*>(MdtmIpcMessage::get_message_response_ptr());

  // init masks, cp and etc...
  cpu_maskbits = cpuset_cpus_nbits();
  mem_maskbits = cpuset_mems_nbits();
  if((cpu_mask = bitmask_alloc(cpu_maskbits)) == NULL ||
      (mem_mask = bitmask_alloc(mem_maskbits)) == NULL ||
      (cp = cpuset_alloc()) == NULL)
    throw std::runtime_error("memory allocation failed.");
}

mdtm_cpuset::~mdtm_cpuset() {
  cpuset_free(cp);
}

int
mdtm_cpuset::createpath() {
  int result;

  // mount the /dev/cpuset
  if((result = mount_fs()) < 0)
    return -1;

  result = cpuset_create(cpusetpath_.c_str(), cp);
  if(result) {
    syslog(LOG_NOTICE, "cpuset create path %s: %s", cpusetpath_.c_str(), strerror(errno));
    if(errno != EEXIST)
      return -1;
  }
  return 0;
}

void
mdtm_cpuset::deletepath() {
//  cpuset_move(0, "xyz");
  cpuset_delete("mdtm");
  umount(mountpoint.c_str());
}

void
mdtm_cpuset::setcpus(const struct bitmask *cpus) {
  cpuset_setcpus(cp, cpus);
}

void
mdtm_cpuset::setmems(const struct bitmask *mems) {
  cpuset_setmems(cp, mems);
}

int
mdtm_cpuset::getcpus(struct bitmask *cpus) {
  return cpuset_getcpus(cp, cpus);
}

int
mdtm_cpuset::getmems(struct bitmask *mems) {
  return cpuset_getmems(cp, mems);
}

void
mdtm_cpuset::modify() {
  cpuset_modify("mdtm", cp);
}

int
mdtm_cpuset::mount_fs()
{
  int result;
  struct stat st = {0};

  if (stat(mountpoint.c_str(), &st) == -1) {
      result = mkdir(mountpoint.c_str(), 0755);
      if(result) {
          syslog(LOG_NOTICE, "mkdir failed @ %s", strerror(errno));
          return -1;
      }
      else
        syslog(LOG_NOTICE, "mkdir %s", mountpoint.c_str());
  }

  if(stat("/dev/cpuset/tasks", &st) < 0) {
      result = system("mount -t cpuset cpuset /dev/cpuset");
      if (result == 0)
        syslog(LOG_NOTICE, "cpuset mounted @ %s", cpuset_mountpoint());
      else {
          syslog(LOG_NOTICE, "cpuset mounted failed: %s", strerror(errno));
          return -1;
      }
  }
  else
    syslog(LOG_NOTICE, "cpuset already mounted @ %s", cpuset_mountpoint());

  return 0;
}

int
mdtm_cpuset::addcpu(int cpu) {
  int mem;

  bitmask_setbit(cpu_mask, cpu);
  mem = cpuset_cpu2node(cpu);
  bitmask_setbit(mem_mask,mem);
  cpuset_setcpus(cp, cpu_mask);
  cpuset_setmems(cp, mem_mask);
  cpuset_modify(cpusetpath_.c_str(),cp);

  return 0;
}

int
mdtm_cpuset::addnode(int mem) {
  int cpu;

  bitmask_setbit(mem_mask, mem);
  cpuset_localcpus(mem_mask, cpu_mask);
  cpuset_setcpus(cp, cpu_mask);
  cpuset_setmems(cp, mem_mask);
  cpuset_modify(cpusetpath_.c_str(),cp);

  return 0;
}

int
mdtm_cpuset::getmasks(struct bitmask *cpus, struct bitmask *mems) {

  // fill the cmdline_
  cmdline_->cmd = GETMASKS;

  // send to remote process and wait for response
  MdtmIpcMessage::send();

  // parse response
  if(result_->returnval == 0) {
    bitmask_parselist(result_->getsetmasks.cpus_buf, cpus);
    bitmask_parselist(result_->getsetmasks.mems_buf, mems);
  }
  return result_->returnval;
}

int
mdtm_cpuset::setmasks(struct bitmask *cpus, struct bitmask *mems) {

  // fill the cmdline_
  cmdline_->cmd = SETMASKS;
  bitmask_displaylist(cmdline_->argv.getsetmasks.cpus_buf, 1024, cpus);
  bitmask_displaylist(cmdline_->argv.getsetmasks.mems_buf, 1024, mems);

  // send to remote process and wait for response
  MdtmIpcMessage::send();

  // parse response
  return result_->returnval;
}

int
mdtm_cpuset::movetask(pid_t pid) {

  // fill the cmdline_
  cmdline_->cmd = MOVETASK;
  cmdline_->argv.pid = pid;

  // send to remote process and wait for response
  MdtmIpcMessage::send();

  // parse response
  return result_->returnval;
}

int
mdtm_cpuset::migratetask(pid_t pid) {

  // fill the cmdline_
  cmdline_->cmd = MIGTASK;
  cmdline_->argv.pid = pid;

  // send to remote process and wait for response
  MdtmIpcMessage::send();

  // parse response
  return result_->returnval;
}

int
mdtm_cpuset::parseit(void* ibuf, int isize, void* obuf, int osize) {
  int used;

  syslog(LOG_NOTICE, "cmd=%d", cmdline_->cmd);

  memcpy(msg_buf_.bytestream, ibuf, isize);
  result_ = reinterpret_cast<struct result_s*>(obuf);

  switch(cmdline_->cmd) {
  case GETMASKS:
    if(cpuset_getcpus(cp, cpu_mask) < 0 || cpuset_getmems(cp, mem_mask) < 0)
      result_->returnval = -1;
    else
      result_->returnval = 0;
    bitmask_displaylist(result_->getsetmasks.cpus_buf, 1024, cpu_mask);
    bitmask_displaylist(result_->getsetmasks.mems_buf, 1024, mem_mask);
    used = sizeof(struct result_s);
    break;
  case SETMASKS:
    bitmask_parselist(cmdline_->argv.getsetmasks.cpus_buf, cpu_mask);
    bitmask_parselist(cmdline_->argv.getsetmasks.mems_buf, mem_mask);
    if(cpuset_setcpus(cp, cpu_mask) < 0 || cpuset_setcpus(cp, mem_mask) < 0)
      result_->returnval = -1;
    else
      result_->returnval = 0;
    used = sizeof(struct result_s);
    break;
  case MOVETASK:
    result_ = reinterpret_cast<struct result_s*>(obuf);
    result_->returnval = cpuset_move(cmdline_->argv.pid, cpusetpath_.c_str());
    break;
  case MIGTASK:
    result_ = reinterpret_cast<struct result_s*>(obuf);
    result_->returnval = cpuset_migrate(cmdline_->argv.pid, cpusetpath_.c_str());
    break;
  }


  return used;
}

