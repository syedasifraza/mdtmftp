/*
 * mdtm_filefrag.h
 *
 *  Created on: Jan 22, 2016
 *      Author: liangz
 */

#ifndef SRC_LIBMDTM_MDTM_FILEFRAG_H_
#define SRC_LIBMDTM_MDTM_FILEFRAG_H_

#include <stdint.h>   /* For uint64_t */
#include <inttypes.h> /* For PRIu64 */

#ifdef __cplusplus
extern "C" {
#endif

struct file_extent {
	uint64_t byte_offset;
	uint64_t first_block;
	uint64_t last_block;
	uint64_t block_count;
};

typedef struct __MDTM_FILE_EXT__ {
  uint64_t start;		// in byte
  uint64_t end;			// in byte
} mdtm_fileext_t;

/**
 * Get the extents of the file
 *
 * \param fname         file name
 * \param exts          pointer to the list of extents
 *
 * \return              The number of extents
 */
int
mdtm_filefrag_get(const char *fname, mdtm_fileext_t **exts);


#ifdef __cplusplus
}
#endif

#endif /* SRC_LIBMDTM_MDTM_FILEFRAG_H_ */
