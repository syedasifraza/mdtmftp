/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_IPC_H_
#define MDTM_IPC_H_

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <limits.h>
#include <iostream>
#include "mdtm_parser.h"

/*
 * MdtmIpc
 */
class MdtmIpc {
public:
  MdtmIpc(const char* ipcname);
  ~MdtmIpc();
  int   wait(void* user_args, int);
  bool  request(void* input, int isize, void*output, int osize);
  bool  respond(void *data, int size);
  int   open(const unsigned int);
  void  close();
  int   shmsize() { return BUF_SIZE; }

  static const unsigned int O_CREATE     = 0x01;
  static const unsigned int O_OPENONLY   = 0x02;
  static const unsigned int O_MAX        = 0x02;
  static const unsigned int BUF_SIZE     = 1024*1024;

private:
  static const int      OBJ_PERMS = 0777;
  struct ShmBuf{
    sem_t       wsem;
    sem_t       rsem;
    int         count;
    char        buf[BUF_SIZE];
  };
  const char *          name_;
  sem_t *               mutex_;
  struct ShmBuf *       shmp_[2];
  char                  shmname_[2][NAME_MAX], semname_[NAME_MAX];
  unsigned int          flag_;
};

/*
 * MdtmIpcMessage
 */
class MdtmIpcMessage: public MdtmParserInterface {
public:
  MdtmIpcMessage(MdtmIpc* ipc) : ipc_(ipc){
    request_ = msg_buf_.bytestream;
    response_ = msg_buf_.bytestream + MdtmIpc::BUF_SIZE;
  }
  //  virtual int parseit(void* ibuf, int isize, void* obuf, int osize) = 0;
  virtual ~MdtmIpcMessage() {}

  int send() {
      // send message via ipc and wait for response
      if(ipc_->request(request_, MdtmIpc::BUF_SIZE, response_, MdtmIpc::BUF_SIZE) == false) {
          std::cerr << "request invalid input parameter" << std::endl;
          return -1;
      }
      return 0;
  }

  void
  setipc(MdtmIpc* ipc) {
    ipc_ = ipc;
  }

  void* get_message_data_ptr(void) {
    return (void*)msg_buf_.message.request.data;
  }

  void* get_message_response_ptr(void) {
    return (void*)msg_buf_.message.response;
  }

  int set_message_name(const char* name) {
    strncpy(msg_buf_.message.request.header.messagename, name, MAX_NAME);
    return 0;
  }

  static const unsigned int MAX_NAME            = 64;
  static const unsigned int MAX_HEADER          = 1024;
  static const unsigned int MAX_DATA            = MdtmIpc::BUF_SIZE - MAX_HEADER;

protected:
  union {
    char bytestream[2 * MdtmIpc::BUF_SIZE];
    struct{
      struct {
        struct MDTM_MSG_HEADER{
          char        messagename[MAX_NAME];
          char        reserved[MAX_HEADER - MAX_NAME];
        } header;
        char data[MAX_DATA];
      } request;
      char response[MdtmIpc::BUF_SIZE];
    } message;
  } msg_buf_;
  char *request_, *response_;
  MdtmIpc*     ipc_;
};


#endif /* MDTM_IPC_H_ */
