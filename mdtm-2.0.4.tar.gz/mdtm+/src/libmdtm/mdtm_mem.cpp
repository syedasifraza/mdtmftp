/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>
#include <sys/mount.h>
#include <cstring>
#include <string>
#include <iostream>
#include <numa.h>
#include "mdtm_mem.h"

using namespace std;

mdtm_mem::mdtm_mem()
  : MdtmIpcMessage(0),
    class_name_("mdtm_mem"),
    lat_func_(NULL)
{
  // init message
  MdtmIpcMessage::set_message_name(class_name_.c_str());
  cmdline_ = 0; //reinterpret_cast<struct cmd_line_s*>(MdtmIpcMessage::get_message_data_ptr());
  result_ = 0;  //reinterpret_cast<struct result_s*>(MdtmIpcMessage::get_message_response_ptr());

  {
    numanodes_ = numa_num_configured_nodes();
    lats_ = (int*) malloc(sizeof(int) * numanodes_);
  }
}

mdtm_mem::mdtm_mem(MdtmIpc* ipc)
  : MdtmIpcMessage(ipc),
    class_name_("mdtm_mem"),
    lat_func_(NULL)
{
  // init message
  MdtmIpcMessage::set_message_name(class_name_.c_str());
  cmdline_ = reinterpret_cast<struct cmd_line_s*>(MdtmIpcMessage::get_message_data_ptr());
  result_ = reinterpret_cast<struct result_s*>(MdtmIpcMessage::get_message_response_ptr());

  {
    numanodes_ = numa_num_configured_nodes();

//    for(int i = 0; i < nodes; i++ ) {
//        cpuonnode_[i] = get1cpu(i);
//        perfdata_[i] = libperf_initialize(getpid(), get1cpu(i));
//        libperf_enablecount(&perfdata_[i], LIBPERF_COUNT_HW_CACHE_LL_LOADS_MISSES);
//        libperf_enablecount(&perfdata_[i], LIBPERF_COUNT_HW_CACHE_LL_STORES_MISSES);
//    }

    lats_ = (int*) malloc(sizeof(int) * numanodes_);
  }
}

mdtm_mem::~mdtm_mem() {
//  libperf_disablecounter(perfdata_[i], LIBPERF_COUNT_HW_CACHE_LL_LOADS_MISSES);
//  libperf_disablecounter(perfdata_[i], LIBPERF_COUNT_HW_CACHE_LL_STORES_MISSES);
//  libperf_close(perfdata_[i]);
//  libperf_finalize(perfdata_, 0);
}

int
mdtm_mem::getoptnode(pid_t pid) {

  // fill the cmdline_
  cmdline_->cmd = OPTNUMA;
  cmdline_->argv.pid = pid;

  // send to the daemon and wait for response
  if(MdtmIpcMessage::send() < 0)
    return -1;

  // parse response
  if(result_->returnval == 0)
    return result_->argv.numanode;
  else
    return -1;
}

int
mdtm_mem::parseit(void* ibuf, int isize, void* obuf, int osize) {
  int used;

  syslog(LOG_NOTICE, "cmd=%d", cmdline_->cmd);

  memcpy(msg_buf_.bytestream, ibuf, isize);
  result_ = reinterpret_cast<struct result_s*>(obuf);

  switch(cmdline_->cmd) {
  case OPTNUMA:
    {
//      int min = 10000, minnode = -1, sum = 0;
//      for(int i = 0; i < numanodes_; i++) {
//          sum = libperf_readcount(perfdata_[i], LIBPERF_COUNT_HW_CACHE_LL_LOADS_MISSES) +
//              libperf_readcount(perfdata_[i], LIBPERF_COUNT_HW_CACHE_LL_STORES_MISSES);
//          if(sum < min) {
//              min = sum;
//              minnode = i;
//          }
//      }
//      result_->returnval = 0;
//      result_->numanode = minnode;

      int min = 10000, minnode = -1;

      if (lats_) {
          memset(lats_, 0, sizeof(*lats_) * numanodes_);
      }

      if(lat_func_ && lat_func_(lats_) >= 0) {
          for (int i = 0; i < numanodes_; i++) {
              if(lats_ != 0 || lats_[i] < min) {
                  min = lats_[i];
                  minnode = i;
              }
          }

          result_->returnval = 0;
          result_->argv.numanode = minnode;
      }
      else {
          result_->returnval = -1;
          result_->argv.numanode = -1;
      }
    }
    break;
  default:
    result_->returnval = -1;
  }
  used = sizeof(struct result_s);

  return used;
}

void
mdtm_mem::set_lat_fn(int (*lat_fn)(int*)) {
  lat_func_ = lat_fn;
}
