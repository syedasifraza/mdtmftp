/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_SCHEDAFFINITY_H_
#define MDTM_SCHEDAFFINITY_H_

#include <sched.h>
#include <pthread.h>

class mdtm_schedaffinity {
public:
  int ncpu;
private:
  cpu_set_t *mask;
  size_t size;
public:
  mdtm_schedaffinity();
  ~mdtm_schedaffinity();
  int SetAffinity ( int* cpuId, int n, pid_t pid);
  int SetAffinity ( int* cpuId, int n, pthread_t tid );
  int ResetAffinity ();
  int ShowAffinity (pid_t pid);
  int ShowAffinity (pthread_t tid);
};

#endif /* MDTM_SCHEDAFFINITY_H_ */
