/*-
 * Copyright (c) 2009-2012 Michihiro NAKAJIMA
 * Copyright (c) 2003-2007 Tim Kientzle
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR(S) ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h>
//#endif
//#ifdef HAVE_ERRNO_H
#include <errno.h>
//#endif
//#ifdef HAVE_FCNTL_H
#include <fcntl.h>
//#endif
//#ifdef HAVE_STDLIB_H
#include <stdlib.h>
//#endif
//#ifdef HAVE_STRING_H
#include <string.h>
//#endif
#if defined(HAVE_WINCRYPT_H) && !defined(__CYGWIN__)
#include <wincrypt.h>
#endif

#include <unistd.h>
#include "../mdtm_meta.h"
#include "mdtm_meta_private.h"
#include "mdtm_meta_string.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Generic initialization of 'struct archive' objects. */
int
__archive_clean(struct archive *a)
{
  archive_string_conversion_free(a);
  return (ARCHIVE_OK);
}

void
archive_set_error(struct archive *a, int error_number, const char *fmt, ...)
{
        va_list ap;

        a->archive_error_number = error_number;
        if (fmt == NULL) {
                a->error = NULL;
                return;
        }

        archive_string_empty(&(a->error_string));
        va_start(ap, fmt);
        archive_string_vsprintf(&(a->error_string), fmt, ap);
        va_end(ap);
        a->error = a->error_string.s;
}


void
__archive_errx(int retvalue, const char *msg)
{
        static const char *msg1 = "Fatal Internal Error in libarchive: ";
        size_t s;

        s = write(2, msg1, strlen(msg1));
        (void)s; /* UNUSED */
        s = write(2, msg, strlen(msg));
        (void)s; /* UNUSED */
        s = write(2, "\n", 1);
        (void)s; /* UNUSED */
        exit(retvalue);
}

/*
 * Set FD_CLOEXEC flag to a file descriptor if it is not set.
 * We have to set the flag if the platform does not provide O_CLOEXEC
 * or F_DUPFD_CLOEXEC flags.
 *
 * Note: This function is absolutely called after creating a new file
 * descriptor even if the platform seemingly provides O_CLOEXEC or
 * F_DUPFD_CLOEXEC macros because it is possible that the platform
 * merely declares those macros, especially Linux 2.6.18 - 2.6.24 do it.
 */
void
__archive_ensure_cloexec_flag(int fd)
{
#if defined(_WIN32) && !defined(__CYGWIN__)
        (void)fd; /* UNSED */
#else
        int flags;

        if (fd >= 0) {
                flags = fcntl(fd, F_GETFD);
                if (flags != -1 && (flags & FD_CLOEXEC) == 0)
                        fcntl(fd, F_SETFD, flags | FD_CLOEXEC);
        }
#endif
}

const char *
archive_error_string(struct archive *a)
{

        if (a->error != NULL  &&  *a->error != '\0')
                return (a->error);
        else
                return (NULL);
}
#ifdef __cplusplus
}
#endif
