/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <string>
#include <mdtm_parser.h>

//void
//MdtmParser::parse(mdtm_cpuset *mdtm, char *buff){
//  //TODO: reading event queue for coming events
////    syslog (LOG_NOTICE, "Writing to my Syslog.");
//  int * action = (int *)buff;
//  switch(*action) {
//  case MDTM_ACTION_SCHEDULE:
//    break;
//  case MDTM_ACTION_ADDPID:
//    {
//      long proc_pid = atol(buff + 1);
//      mdtm->addpid(proc_pid);
//    }
//    break;
//  case MDTM_ACTION_ADDCPU:
//    {
//      char ncpus = *(buff + 1);
//      char cpuid;
//      for(int i = 0; i < ncpus; i++) {
//          cpuid = *(buff + 2 + i);
//          mdtm->addcpu(cpuid);
//      }
//
//    }
//  default:
//    break;
//  }
//}

int
MdtmParser::parse(void *ibuf, int isize, void *obuf, int osize){
  int used;
  //TODO: reading event queue for coming events
  //    syslog (LOG_NOTICE, "Writing to my Syslog.");

  std::string key = std::string((char *)ibuf);

  ParserHashTable::iterator it = htable.find(key);

  if(it == htable.end())
    return -1;

  MdtmParserInterface* entry = it->second;
  used = entry->parseit(ibuf, isize, obuf, osize);
  return used;
}

int
MdtmParser::enroll(const std::string &name, MdtmParserInterface& instance) {
  htable[name] = &instance;
  return 0;
}

int
MdtmParser::disenroll(std::string name) {
  htable[name] = 0;
  return 0;
}



