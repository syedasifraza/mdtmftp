/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_CPUSET_H_
#define MDTM_CPUSET_H_

#include <string>
#include <bitmask.h>
#include <cpuset.h>
#include "mdtm_ipc.h"

class mdtm_cpuset : public MdtmIpcMessage {
public:
  const std::string     class_name_;
  const std::string     cpusetpath_;
  struct cpuset *       cp;
  struct bitmask *      cpu_mask, *mem_mask;
  unsigned int          cpu_maskbits, mem_maskbits;

public:
  mdtm_cpuset();
  mdtm_cpuset(MdtmIpc* ipc);
  ~mdtm_cpuset();
  int           createpath();
  void          deletepath();
  int           parseit(void* ibuf, int isize, void* obuf, int osize);
  int           addcpu(int cpu);
  int           addnode(int mem);
  int           getmasks(struct bitmask *cpus, struct bitmask *mems);
  int           setmasks(struct bitmask *cpus, struct bitmask *mems);
  int           movetask(pid_t pid);
  int           migratetask(pid_t pid);

private:
  enum Command{
    GETMASKS    = 1,
    SETMASKS,
    MOVETASK,
    MIGTASK
  };
  const std::string           mountpoint;

  int           mount_fs();
  void          setcpus(const struct bitmask *cpus);
  void          setmems(const struct bitmask *mems);
  int           getcpus(struct bitmask *cpus);
  int           getmems(struct bitmask *mems);
  void          modify();

  struct cmd_line_s {
    Command        cmd;
    union {
      struct{
        char  cpus_buf[1024];
        char  mems_buf[1024];
      }getsetmasks;
      pid_t     pid;
    } argv;
  } * cmdline_;

  struct result_s {
    int        returnval;
    char       errcode[64];
    union {
      struct{
        char  cpus_buf[1024];
        char  mems_buf[1024];
      }getsetmasks;
    };
  } * result_;
};



#endif /* MDTM_CPUSET_H_ */
