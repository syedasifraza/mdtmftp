/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <iostream>
#include <sstream>
#include <fstream>
#include <cstring>
#include <string>
#include <vector>
#include <exception>
#include <stdexcept>

#include "include/private/mdtm_config.h"
#include "include/private/mdtm_debug.h"
#include "mdtm_utils.h"

#define MDTM_BIGNUME_1G         (1024ULL*1024ULL*1024ULL)
#define MDTM_BIGNUME_1M         (1024ULL*1024ULL)

mdtmdevice::Map mdtmdevice::typemap = {
    {"Block", 0},
    {"Network", 1},
    {"Virtual", 2}};

const std::string mdtmdevice::type_virtual = "Virtual";
const std::string mdtmdevice::type_block = "Block";
const std::string mdtmdevice::type_network = "Network";

mdtmdevice::mdtmdevice()
{
  namelen = sizeof(this->name)/sizeof(this->name[0]);
  type = -1;
  numa = -1;
}

mdtmdevice::~mdtmdevice()
{
}

char*
mdtmdevice::setname(const char*name)
{
  return strncpy(this->name, name, sizeof(this->name)/sizeof(this->name[0]));
}

int
mdtmdevice::setattr(int attr, const char* cvalue)
{
  int rc = 0;
  std::string str;

  switch(attr) {
  case MDTM_DEV_ATTR_TYPE:
  {
    std::string input = std::string(cvalue);

    str = mdtmdevice::type_block;
    if(caseInSensStringCompare(input, str) == true)
      this->type = 0;

    str = mdtmdevice::type_network;
    if(caseInSensStringCompare(input, str) == true)
      this->type = 1;

    str = mdtmdevice::type_virtual;
    if(caseInSensStringCompare(input, str) == true)
      this->type = 2;
  }
    break;
  case MDTM_DEV_ATTR_NUMA:
    this->numa = atoi(cvalue);
    break;
  default:
    rc = -1;
    break;
  }
  return rc;
}

char*
mdtmdevice::getattr(int attr)
{
  char *buffer = 0;

  switch(attr){
  case MDTM_DEV_ATTR_TYPE:
    for(auto it = typemap.begin();it!=typemap.end();it++) {
        if(it->second == this->type) {
            buffer = new char[128];
            sprintf(buffer, "%s", const_cast<char*>(it->first));
            break;
        }
    }
    break;
  }
  return buffer;
}

int
mdtmdevice::getattr_int(int attr)
{
  int result = -1;

  switch(attr){
  case MDTM_DEV_ATTR_NUMA:
    result = this->numa;
    break;
  }
  return result;
}

char*
mdtmdevice::getname()
{
//  char * buffer = new char[128];
//  strcpy(buffer, this->name);
//  return buffer;
  return this->name;
}

const std::string mdtmconfig::json_config_file = "mdtmconfig.json";
const std::string mdtmconfig::xml_config_file = "mdtmconfig.xml";

mdtmconfig::mdtmconfig() :
    seg_size(0), nthreads(0), doc(NULL), sysconfpath("/etc/mdtm/"), servercfgpath("server.conf"), config_done(false)
{
}

mdtmconfig::~mdtmconfig()
{
//  onlinelist.pop_front()      //TODO: clean up
}

void
mdtmconfig::setconfpath(const char * path)
{
  sysconfpath = std::string(path);
}


int
mdtmconfig::getncpubytype(int type)
{
  int n;

  try {
    switch (type) {
    case 0:
      n = this->storage_cpus.size();
      break;
    case 1:
      n = this->network_cpus.size();
      break;
    case 2:
      n = this->virtual_cpus.size();
      break;
    default:
      throw std::invalid_argument("Unknown type for inquiry CPUs.");
    }
  }
  catch(std::exception &e) {
    throw;
  }

  return n;
}

int
mdtmconfig::getcpusbytype(int *cpus, int size, int type)
{
  int i;

  switch(type) {
  case 0:
    i = 0;
    if ( size < this->storage_cpus.size())
      throw;
    for (auto it = this->storage_cpus.begin(); it != this->storage_cpus.end(); ++it)
            cpus[i++] = *it;
    break;
  case 1:
    i = 0;
    if ( size < this->network_cpus.size())
      throw;
    for (auto it = this->network_cpus.begin(); it != this->network_cpus.end(); ++it)
            cpus[i++] = *it;
    break;
  case 2:
    i = 0;
    if ( size < this->virtual_cpus.size())
      throw;
    for (auto it = this->virtual_cpus.begin(); it != this->virtual_cpus.end(); ++it)
            cpus[i++] = *it;
    break;
  default:
    throw;
    break;
  }
  return 0;
}

const char *
mdtmconfig::getconfigfilepath(void) {
  return this->servercfgpath.c_str();
}

bool
mdtmconfig::readxml() {
  TiXmlNode* node = 0;
  TiXmlElement* todoElement = 0;
  TiXmlElement* itemElement = 0;
  TiXmlElement *devices, *device, *topo;
  char *attstr;
  mdtmdevice *mdev;
  bool  readOk = false;

  try {
      // parse the topology elements
      node = doc->FirstChild( "Topology" );
      if( !node )
        throw  std::runtime_error("Topology missing.");

      topo = node->ToElement();
      if( !topo  )
        throw  std::runtime_error("Topology no elements.");

      for(node = topo->FirstChildElement();
          node;
          node = node->NextSibling())
        {
          if( !node )
            throw  std::runtime_error("Missing node.");

          device = node->ToElement();
          if( !device)
            throw  std::runtime_error("No device.");

          mdev = new mdtmdevice();
          mdev->setname(device->GetText());
          if((char*)device->Attribute( "type") == NULL || (char*)device->Attribute( "numa") == NULL)
              throw std::runtime_error("Invalid device attributes of type or numa.");
          mdev->setattr(mdtmdevice::MDTM_DEV_ATTR_TYPE, device->Attribute( "type"));
          mdev->setattr(mdtmdevice::MDTM_DEV_ATTR_NUMA, device->Attribute( "numa"));
          topomap.insert(Map::value_type(mdev->getname(), *mdev));   //TODO: consider shared pointer
          //      delete mdev;
          //      std::cout << "value= " << mdev->getname() << std::endl;
          //      std::cout << "type= "<<mdev->getattr( mdtmdevice::MDTM_DEV_ATTR_TYPE) << std::endl;
          //      std::cout << "numa= "<<mdev->getattr( mdtmdevice::MDTM_DEV_ATTR_NUMA) << std::endl;
        }

      //  std::cout <<"=== read the topomap ===="<<std::endl;
      //  for(auto it = topomap.begin(); it != topomap.end(); it++){
      //      std::cout << "value= " << it->first << std::endl;
      //      std::cout << "type= "<<it->second->getattr( mdtmdevice::MDTM_DEV_ATTR_TYPE) << std::endl;
      //      std::cout << "numa= "<<it->second->getattr( mdtmdevice::MDTM_DEV_ATTR_NUMA) << std::endl;
      //  }

      // parse the online elements
      TiXmlElement *element;
      node = doc->FirstChild( "Online" );
      if( !node )
        throw  std::runtime_error("No Online items.");

      element = node->ToElement();
      if( !element  )
        throw  std::runtime_error("Online items parsing failed.");

      for(node = element->FirstChildElement();
          node;
          node = node->NextSibling())
        {
          if( !node )
            throw  std::runtime_error("No Online items.");

          device = node->ToElement();
          if( !device)
            throw  std::runtime_error("Invalid Online device.");

          mdev = new mdtmdevice();
          mdev->setname(device->GetText());
          onlinelist.push_back(*mdev);      //TODO: consider shared pointer
          delete mdev;
        }

      // parse threads elements
      node = doc->FirstChild( "Threads" );
      if( !node )
        throw  std::runtime_error("No threads items.");

      element = node->ToElement();
      if( !element  )
        throw  std::runtime_error("Thread item parsing failed.");

      nthreads = atoi(element->Attribute("threads"));
      if(nthreads < 1)
        throw  std::runtime_error("Invalid threads in Threads.");
      for(node = element->FirstChildElement();
          node;
          node = node->NextSibling())
        {
          int n;

          if( !node )
            throw  std::runtime_error("No threads attribute.");

          device = node->ToElement();
          if( !device)
            throw  std::runtime_error("No device for thread attribute.");

          //      std::cout << device->GetText() <<"::"<< (char*)device->Attribute( "threads")<<std::endl;
          if((n = atoi((char*)device->Attribute( "threads"))) < 1) {
              char errmsg[256];
              sprintf(errmsg, "Invalid threads attribute for %s.", device->GetText());
              throw  std::runtime_error(errmsg);
          }
          devthrdmap.insert(dtMap::value_type(device->GetText(), n));
          //      std::cout<<"find result="<<devthrdmap.find(device->GetText())->second<<std::endl;
        }

      // parse File elements
      node = doc->FirstChild( "File" );
      if( !node )
        throw  std::runtime_error("No File items.");

      element = node->ToElement();
      if( !element  )
        throw  std::runtime_error("File items parsing failed.");

      {
        char *      seg;
        int         len = 0, count;
        long long   base = 0, n = 0;

        if(element->Attribute( "segment") == NULL)
          throw  std::runtime_error("File attribute segment missing.");

        seg = (char*)strdup(element->Attribute( "segment"));
        if((len = strlen(seg)) > 0) {
            switch(seg[len-1]) {
            case 'm':
            case 'M':
              base = MDTM_BIGNUME_1M;
              break;
            case 'g':
            case 'G':
              base = MDTM_BIGNUME_1G;
              break;
            default:
              base = 1;
              break;
            }
            seg[len] = '\0';
            if((count = atoi(seg)) < 0)
              count= 0;

            for(int i = 0; i < count; i++) {
                n += base;
            }
        }
        seg_size = n;
        if(seg) free(seg);
      }
      readOk = true;
  }
  catch (std::exception& e)
  {
      mdtm_debug("libmdtm: mdtmconfig: %s\n", e.what());
  }
  return readOk;

//  for(node = element->FirstChildElement();
//      node;
//      node = node->NextSibling())
//    {
//      assert( node );
//      device = node->ToElement();
//      assert( device);
////      std::cout << device->GetText() <<"::"<< (char*)device->Attribute( "threads")<<std::endl;
//      devthrdmap.insert(dtMap::value_type(device->GetText(), atoi((char*)device->Attribute( "threads"))));
////      std::cout<<"find result="<<devthrdmap.find(device->GetText())->second<<std::endl;
//    }

//  std::cout <<"=== read the online list ===="<<std::endl;
//  for(auto it = onlinelist.begin(); it != onlinelist.end(); it++){
//      std::cout << "value= " << it->getname() << std::endl;
//  }
}

#include<stdio.h>
#include<json.h>
#include <limits.h>

bool
mdtmconfig::readjson(const char * path) {
  FILE          *fp;
  char          buffer[PATH_MAX];
  struct        json_object *parsed_json;
  char          *attstr;
  mdtmdevice    *mdev;
  bool          readOk = false;
  int           i;

  // open the json file to read
  try {
    fp = fopen(path, "r");
    if (fp == NULL)
        throw std::runtime_error(std::strerror(errno));
    fread(buffer, PATH_MAX, 1, fp);
    fclose(fp);
  }
  catch (std::exception& e)
  {
      throw std::string(e.what());
  }

  // parse json objects in buffer
  try {

    parsed_json = json_tokener_parse(buffer);
    if(parsed_json == NULL) {
      std::string info = "can not parse JSON file:";
      info = info + std::string(path);
      throw info;
    }

    json_object_object_foreach(parsed_json, key, val) {

      if(!strcmp(key, "topology")) {
        json_object *   nodes;
        json_object *   node;
        json_object *   type;
        json_object *   name;
        json_object *   numa;
        int             n_nodes;

        json_object_object_get_ex(parsed_json, key, &nodes);
        n_nodes = json_object_array_length(nodes);
        for ( i = 0; i < n_nodes; i++) {
          node = json_object_array_get_idx(nodes, i);
          json_object_object_get_ex(node, "type", &type);
          json_object_object_get_ex(node, "name", &name);
          json_object_object_get_ex(node, "numa", &numa);

          mdev = new mdtmdevice();
          mdev->setname(json_object_get_string(name));
          mdev->setattr(mdtmdevice::MDTM_DEV_ATTR_TYPE, json_object_get_string(type));
          mdev->setattr(mdtmdevice::MDTM_DEV_ATTR_NUMA, json_object_get_string(numa));
          topomap.insert(Map::value_type(mdev->getname(), *mdev));
        }
      }
      else if(!strcmp(key, "online")) {
        json_object *   devices;
        json_object *   device;
        int             n_devices;

        json_object_object_get_ex(parsed_json, key, &devices);
        n_devices = json_object_array_length(devices);
        for ( i = 0; i < n_devices; i++ ) {
          device = json_object_array_get_idx(devices, i);

          mdev = new mdtmdevice();
          mdev->setname(json_object_get_string(device));
          onlinelist.push_back(*mdev);      //TODO: consider shared pointer
          delete mdev;
        }
      }
      else if (!strcmp(key, "threads")) {
        json_object *   threads;
        json_object *   thread;
        json_object *   devthreads;
        json_object *   name;
        int             n_threads;

        json_object_object_get_ex(parsed_json, key, &threads);
        n_threads = json_object_array_length(threads);
        for ( i = 0; i < n_threads; i++) {
          thread = json_object_array_get_idx(threads, i);

          json_object_object_get_ex(thread, "threads", &devthreads);
          json_object_object_get_ex(thread, "name", &name);
          devthrdmap.insert(
              dtMap::value_type(strdup(json_object_get_string(name)), json_object_get_int(devthreads)));
        }
      }
      else if (!strcmp(key, "filesegment")) {
        json_object *   segment;
        char *      seg;
        int         len = 0, count;
        long long   base = 0, n = 0;

        json_object_object_get_ex(parsed_json, key, &segment);
        seg = (char *) json_object_get_string(segment);
        if((len = strlen(seg)) > 0) {
          switch(seg[len-1]) {
          case 'm':
          case 'M':
            base = MDTM_BIGNUME_1M;
            break;
          case 'g':
          case 'G':
            base = MDTM_BIGNUME_1G;
            break;
          default:
            base = 1;
            break;
          }
          seg[len] = '\0';
          if((count = atoi(seg)) < 0)
            count= 0;

          for(int i = 0; i < count; i++) {
            n += base;
          }
        }
//        if(seg) free(seg);
        seg_size = n;
      }
      else if (!strcmp(key, "cpus")) {
        json_object *   cpus;
        json_object *   cpu;
        json_object *   storage;
        json_object *   network;
        json_object *   virtualdev;
        int             n;

        json_object_object_get_ex(parsed_json, key, &cpus);

        if(json_object_object_get_ex(cpus, "storage", &storage) == false)
          throw;

        if(json_object_object_get_ex(cpus, "network", &network) == false)
          throw;


        if((n = json_object_array_length(storage)) <= 0)
          throw;
        for ( i = 0; i < n; i++ ) {
          cpu = json_object_array_get_idx(storage, i);
          this->storage_cpus.push_back(json_object_get_int(cpu));
        }

        if((n = json_object_array_length(network)) <= 0)
          throw;
        for ( i = 0; i < n; i++ ) {
          cpu = json_object_array_get_idx(network, i);
          this->network_cpus.push_back(json_object_get_int(cpu));
        }

        if(json_object_object_get_ex(cpus, "virtual", &virtualdev)  == true) {
          if((n = json_object_array_length(virtualdev)) > 0)
            for ( i = 0; i < n; i++ ) {
              cpu = json_object_array_get_idx(virtualdev, i);
              this->virtual_cpus.push_back(json_object_get_int(cpu));
            }
        }
      }
      else if (!strcmp(key, "server")) {

        json_object * configs;
        json_object * config;
        json_object * path;
        int           n;

        if((json_object_object_get_ex(parsed_json, key, &configs) == true) &&
            (n = json_object_array_length(configs)) > 0) {

          if(json_object_object_get_ex(parsed_json, "serverpath", &path) == true) {
            this->servercfgpath = json_object_get_string(path);
          }
          try {
            std::cout << "libmdtm: mdtm_config generates " << this->servercfgpath.c_str() << "." << std::endl;
            std::ofstream out(this->servercfgpath);
            for ( i = 0; i < n; i++) {
              config = json_object_array_get_idx(configs, i);
              std::cout << json_object_get_string(config) << std::endl;
              out << json_object_get_string(config) << "\n";
            }
            out.close();
          }
          catch ( ... ) {
            throw std::string("can not get server configuration!");
          }
        }
      }
    }

    json_object_put(parsed_json);        // release resource
    readOk = true;
  }
  catch (std::exception& e) {
    throw std::string(e.what());
  }
  catch (std::string e) {
    throw;
  }
  return readOk;
}

bool
mdtmconfig::readconfig(const char* path)
{
  bool          loadOkay = false;
  std::string   newpath;
  std::string   syspath;

  // check if configuration file is already read
  if(this->config_done == true)
    return true;
  else
    this->config_done = true;

  // if path is null, look for configuration files in working and system path
  if(path == NULL) {

    // First, try configuration file in JSON
    try {
      loadOkay = this->readjson(mdtmconfig::json_config_file.c_str());
      mdtm_debug("libmdtm: mdtmconfig load %s : %s.\n",
          mdtmconfig::json_config_file.c_str(),
          loadOkay? "succeed" : "fail");
      if(loadOkay)
        return loadOkay;
    }
    catch (std::string e) {
      std::cout << "libmdtm: mdtmconfig load " << mdtmconfig::json_config_file << " : "<< e << std::endl;
    }
    catch (...) {
      std::cout << "libmdtm: mdtmconfig load " << mdtmconfig::json_config_file << " : failed."<< std::endl;
    }

    syspath = this->sysconfpath + mdtmconfig::json_config_file;
    try {
      loadOkay = this->readjson(syspath.c_str());
      mdtm_debug("libmdtm: mdtmconfig load %s: %s.\n", syspath.c_str(), loadOkay?"succeed" : "fail");
      if(loadOkay)
        return loadOkay;
    }
    catch (std::string e) {
      std::cout << "libmdtm: mdtmconfig load " << syspath << " : "<< e << std::endl;
    }
    catch (...) {
      std::cout << "libmdtm: mdtmconfig load " << syspath << " : failed." << std::endl;
    }

    // Then, try configuration file XML
    newpath = mdtmconfig::xml_config_file;
    try {
      doc = new TiXmlDocument(newpath.c_str());
      if( !doc )
        throw std::runtime_error("can not create xml object duo to memory.");

      loadOkay = doc->LoadFile();
      if ( loadOkay == false ) {

        mdtm_debug("libmdtm: mdtmconfig load %s : %s. Try the system path.\n", newpath.c_str(), doc->ErrorDesc());

        newpath = sysconfpath + newpath;
        delete doc;
        doc = new TiXmlDocument(newpath.c_str());
        if(!doc) {
          throw std::runtime_error("can not create xml object duo to memory.");
        }
        loadOkay = doc->LoadFile();
        if(loadOkay == false)
          mdtm_debug("libmdtm: mdtmconfig load %s : %s\n", newpath.c_str(), doc->ErrorDesc());
      }

      if(loadOkay == true) {
        this->nthreads = 0;
        loadOkay = readxml();
        mdtm_debug("libmdtm: mdtmconfig load %s: %s.\n", newpath.c_str(), loadOkay?"succeed" : "fail");
        if(loadOkay)
          return loadOkay;
      }
    }
    catch (std::exception& e)
    {
      std::string info = "Can not read mdtm configuration file ";
      info = info + newpath + ":" + std::string(e.what());
      throw info;
    }
  }
  // if path is specified, use it
  else {
    std::string fn(path);
    std::string ext = fn.substr(fn.find_last_of(".") + 1);

    if(!ext.compare("json")) {
      try {
        loadOkay = this->readjson(path);
        mdtm_debug("libmdtm: mdtmconfig load %s: %s.\n", path, loadOkay?"succeed" : "fail");
        if(loadOkay)
          return loadOkay;
      }
      catch(std::exception &e) {
        std::string info = "Can not read mdtm configuration file ";
        info = info + path + std::string(e.what());
        throw info;
      }
    }
    else if (!ext.compare("xml")) {
      try {
        doc = new TiXmlDocument(path);
        if( !doc )
          throw std::runtime_error("can not create xml object duo to memory.");

        loadOkay = doc->LoadFile();
        if ( loadOkay == false)
          mdtm_debug("libmdtm: mdtmconfig load %s : %s. Try the system path.\n", path, doc->ErrorDesc());
        else {
          nthreads = 0;
          loadOkay = readxml();
          mdtm_debug("libmdtm: mdtmconfig load %s: %s\n", path, loadOkay?"succeed" : "fail");
        }
      }
      catch (std::exception& e)
      {
        mdtm_debug("libmdtm: mdtmconfig load %s: %s\n", path, e.what());
        throw std::string("Can not read mdtm configuration file.");
      }
    }
    else {
      mdtm_debug("libmdtm: mdtmconfig load %s : failed.\n", path);
      throw std::string("Can not read mdtm configuration file.");
    }
  }
  return loadOkay;
}

std::vector<mdtmdevice>
mdtmconfig::topology()
{
  std::vector<mdtmdevice> list;
  for(auto it = topomap.begin(); it != topomap.end(); it++) {
      list.push_back(it->second);
  }
  return list;
}


std::vector<mdtmdevice>
mdtmconfig::online()
{
  return onlinelist;
}

int
mdtmconfig::threads()
{
  return nthreads;
}

int
mdtmconfig::threads(char* devname)
{
  int               n;
  dtMap::iterator   it;

  it = devthrdmap.find(devname);
  if(it != devthrdmap.end())
    n = it->second;
  else
    n = nthreads;
  return n;
}
