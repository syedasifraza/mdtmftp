/*
 * mdtm_pipe.h
 *
 *  Created on: May 24, 2016
 *      Author: liangz
 */

#ifndef SRC_LIBMDTM_MDTM_PIPE_H_
#define SRC_LIBMDTM_MDTM_PIPE_H_


#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  long iden[2];
  int pipefd[2];
} mdtm_pipefd_t;

int
mdtm_pipe_init2(
    int group_count,
    size_t pipesize,
    int nNumas,
    void * nodes);

void *
mdtm_pipe_get2(int numa, unsigned int size, void **arg);

int
mdtm_pipe_put2(int numa, void * pipe);

int
mdtm_pipe_allocated2(int numa);

#ifdef __cplusplus
}
#endif


#endif /* SRC_LIBMDTM_MDTM_PIPE_H_ */
