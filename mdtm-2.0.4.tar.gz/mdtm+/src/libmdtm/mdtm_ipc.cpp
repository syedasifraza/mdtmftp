/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <include/private/mdtm_debug.h>
#include <mdtm_ipc.h>

MdtmIpc::MdtmIpc(const char* ipcname):name_(ipcname) {
  flag_ = MdtmIpc::O_OPENONLY;
  mutex_ = 0;
}

int
MdtmIpc::open(const unsigned int flag) {
  int           fd[2];

  sprintf(shmname_[0],"/%s_request",name_);
  sprintf(shmname_[1],"/%s_response",name_);
  sprintf(semname_,"/%s_mutex",name_);
  flag_ = flag;

  if(flag_ & MdtmIpc::O_CREATE) {
      if(((fd[0] = shm_open(shmname_[0], O_CREAT | O_EXCL | O_RDWR, OBJ_PERMS)) < 0) ||
          ((fd[1] = shm_open(shmname_[1], O_CREAT | O_EXCL | O_RDWR, OBJ_PERMS)) < 0)) {
          perror("shm_open");
          return -1;
      }

      if(ftruncate(fd[0], sizeof(struct ShmBuf)) < 0 ||
          ftruncate(fd[1], sizeof(struct ShmBuf)) < 0) {
          perror("ftruncate failed.");
          return -1;
      }

      /*
       * Now we attach the segment to our data space.
       */
      if ((shmp_[0] = (struct ShmBuf*)mmap(NULL, sizeof(struct ShmBuf), PROT_READ | PROT_WRITE, MAP_SHARED, fd[0], 0)) == MAP_FAILED ||
          (shmp_[1] = (struct ShmBuf*)mmap(NULL, sizeof(struct ShmBuf), PROT_READ | PROT_WRITE, MAP_SHARED, fd[1], 0)) == MAP_FAILED) {
          perror("mmap");
          return -1;
      }

      sem_init(&shmp_[0]->rsem, 1, 0);
      sem_init(&shmp_[0]->wsem, 1, 1);
      sem_init(&shmp_[1]->rsem, 1, 0);
      sem_init(&shmp_[1]->wsem, 1, 1);

      mutex_ = sem_open(semname_, O_CREAT, 0644, 1);
      if(mutex_ == SEM_FAILED) {
          perror("unable to create semaphore");
          sem_unlink(semname_);
          return -1;
      }
  }     // create
  else {
      struct stat   sb[2];

      mutex_ = sem_open(semname_, 0, 0644, 0);
      if(mutex_ == SEM_FAILED) {
//          perror("MdtmIpc: Unable to excecute semaphore");
//          mdtm_debug("MdtmIpc: Unable to excecute semaphore.");
//          sem_close(mutex_);
          return -1;
      }

      fd[0] = shm_open(shmname_[0], O_RDWR, 0);
      fd[1] = shm_open(shmname_[1], O_RDWR, 0);

      // Use object size as length for mmap()
      fstat(fd[0], &sb[0]);
      fstat(fd[1], &sb[1]);
      shmp_[0] = (struct ShmBuf*)mmap(NULL, sb[0].st_size,
                  PROT_READ | PROT_WRITE,
                  MAP_SHARED, fd[0], 0);
      shmp_[1] = (struct ShmBuf*)mmap(NULL, sb[1].st_size,
                  PROT_READ | PROT_WRITE,
                  MAP_SHARED, fd[1], 0);
  }     // openonly
  return 0;
}

int
MdtmIpc::wait(void* buf, int bufsize) {
  int size, s;
  struct timespec ts;

  if (clock_gettime(CLOCK_REALTIME, &ts) == -1) {
          return -1;
  }

  ts.tv_nsec += 1000000UL;      // wait for 1ms

  while ((s = sem_timedwait(&shmp_[0]->rsem, &ts)) == -1 && errno == EINTR)
    continue;       /* Restart if interrupted by handler */

  if (s == -1) {
      if (errno == ETIMEDOUT)
        //timed out
        return 0;
      else
        //error
        return -1;
  } else {
      // succeeded
      memcpy(buf, shmp_[0]->buf, shmp_[0]->count);
      size = shmp_[0]->count;
      sem_post(&shmp_[0]->wsem);
      return size;
  }
}

bool
MdtmIpc::respond(void *data, int size) {
  sem_wait(&shmp_[1]->wsem);
  memcpy(shmp_[1]->buf, data, size);
  shmp_[1]->count = size;
  sem_post(&shmp_[1]->rsem);
  return true;
}

bool
MdtmIpc::request(void* input, int isize, void*output, int osize) {

  if(!input || isize > BUF_SIZE || !output || osize < BUF_SIZE)
    return false;

  sem_wait(mutex_);

  // send out request
  sem_wait(&shmp_[0]->wsem);
  memcpy(shmp_[0]->buf, input, isize);
  shmp_[0]->count = isize;
  sem_post(&shmp_[0]->rsem);

  // get response
  sem_wait(&shmp_[1]->rsem);
  memcpy(output, shmp_[1]->buf, shmp_[1]->count);
  sem_post(&shmp_[1]->wsem);

  sem_post(mutex_);

  return true;
}

void
MdtmIpc::close() {
  if(flag_ & MdtmIpc::O_CREATE) {
      sem_unlink(semname_);
      shm_unlink(shmname_[0]);
      shm_unlink(shmname_[1]);
  }
  else {
  }
}

MdtmIpc::~MdtmIpc() {
}


