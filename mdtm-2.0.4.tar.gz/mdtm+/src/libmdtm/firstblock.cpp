/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>
#include <linux/fs.h>
//typedef uint64_t __u64;
//typedef uint32_t __u32;
#include "fiemap.h"
#include <errno.h>
#include <sys/stat.h>
#include <err.h>

#define FS_IOC_FIEMAP                   _IOWR('f', 11, struct fiemap)

static int use_fibmap = 1;
static int use_fiemap = 1;

uint64_t firstblock(const char *fname)
{
        int ret, fd;
        struct fiemap *fiemap;
        struct fiemap_extent *extent;
        unsigned long block = 0;
        char buf[sizeof(struct fiemap) + sizeof(struct fiemap_extent)];

        if(use_fiemap || use_fibmap) {
            fd = open(fname, O_RDONLY);
            if (fd == -1) {
                fprintf(stderr, "Open failed: %s: %s\n", fname, strerror(errno));
                return 0;
            }

            if (use_fibmap) {
                ret = ioctl(fd, FIBMAP, &block);
                if (ret == 0) {
                    close(fd);
                    return block;
                }
                use_fibmap = 0;
            }

            if(use_fiemap) {
                fiemap = (struct fiemap *)buf;

                fiemap->fm_start = 0;
                fiemap->fm_length = 4096;
                fiemap->fm_flags = 0;
                fiemap->fm_extent_count = 1;

                ret = ioctl(fd, FS_IOC_FIEMAP, fiemap);
                if (ret == -1) {
                    if (errno == EBADR) {
                        fprintf(stderr, "Kernel does not support the flags: 0x%x\n",
                            fiemap->fm_flags);
                        close(fd);
                        return -1;
                    }
                    fprintf(stderr, "Warning: fiemap return code %d: \"%s\"\n", errno,
                        strerror(errno));
                    close(fd);
                    use_fiemap = 0;
                }
                else  {
                    if (fiemap->fm_extent_count == 0 || fiemap->fm_mapped_extents == 0) {
                        close(fd);
                        return 0;
                    }
                    extent = &fiemap->fm_extents[0];
                    close(fd);
                    return extent->fe_physical >> 4;
                }
            }
        }

        // fallback if neither fiemap nor fiemap is turned on
        {
          struct stat st;
          if (lstat(fname, &st) < 0)
            err(1, "stat %s failed", fname);
          return st.st_ino;
        }
}




