/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_IRQ_H_
#define MDTM_IRQ_H_

class mdtm_irq{
public:
  mdtm_irq(){}
  ~mdtm_irq(){}
  int assignirqaffinity(char* devtype);
  void resumeirqaffinity();
  void printirqaffinity(char* devtype);
};



#endif /* MDTM_IRQ_H_ */
