/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_UTILS_H_
#define MDTM_UTILS_H_

#include <vector>

template <class int_type>
class bitarray {
public:
  bitarray() {}
  ~bitarray() {}

  std::vector<int_type>& positions(int_type data);
  void stitch(char *str);
private:
  std::vector<int_type> res;
};

template <class int_type>
std::vector<int_type>& bitarray<int_type>::positions(int_type data)
{
  int n;
//  std::vector<int_type> res;
  res.clear();
  res.reserve(64);
  for (n = 0; data != 0; n++, data &= (data - 1))
    {
      res.push_back(log2(data & ~(data-1)));
    }
//  for(typename std::vector<int_type>::iterator it = res.begin();it != res.end(); ++it)
//    printf("pos=%d\n", *it);
  return res;
}

template <class int_type>
void bitarray<int_type>::stitch(char *str)
{
  char *ptr1, *ptr2;

//  assert(str);

  ptr1=ptr2=str;
  while(*ptr1) {
      if(((char)(*ptr1) == ',') || ((char)(*ptr1) == ' ')) {
        ptr1++; continue;
      }
      else {
          *ptr2++ = *ptr1++;
      }
  }
  *ptr2 = '\0';
  return;
}

#include <string>
bool compareChar(char & c1, char & c2);
bool caseInSensStringCompare(std::string & str1, std::string &str2);


#endif /* MDTM_UTILS_H_ */
