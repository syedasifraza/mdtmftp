/*
 * mdtm_lustre.cpp
 *
 *  Created on: Aug 23, 2016
 *      Author: liangz
 */


#include <config.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <ifaddrs.h>

#include <asm/types.h>
#include <netinet/ether.h>
#include <netinet/in.h>
#include <net/if.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <sys/types.h>

#include <stdlib.h>
#include <unistd.h>
#include <mdtm_lustre.h>

#ifdef __cplusplus
extern "C" {
#endif

#define BUFSIZE 8192

char gateway[255];

struct route_info{
  struct in_addr dstAddr;
  struct in_addr srcAddr;
  struct in_addr gateWay;

  char ifName[IF_NAMESIZE];
};

#include <ctype.h>

static
int
isDigitString(char *a)
{
  int i, len;

  len = strlen(a);

  for(i = 0; i < len; i++)
    if(isdigit(a[i]) == 0)
      break;

  return (i == len)? 1 : 0;
}

static
bool
isValidIpAddress(char *ipAddress)
{
  struct sockaddr_in sa;
  int result = inet_pton(AF_INET, ipAddress, &(sa.sin_addr));
  return result != 0;
}

static
char*
getif(char * addr) {
  struct ifaddrs *addrs, *iap;
  struct sockaddr_in *sa;
  char buf[32];
  char *interface = 0;

  getifaddrs(&addrs);
  for (iap = addrs; iap != NULL; iap = iap->ifa_next) {
      if (iap->ifa_addr && (iap->ifa_flags & IFF_UP) && iap->ifa_addr->sa_family == AF_INET) {
          sa = (struct sockaddr_in *)(iap->ifa_addr);
          inet_ntop(iap->ifa_addr->sa_family, (void *)&(sa->sin_addr), buf, sizeof(buf));
          if (!strcmp(addr, buf)) {
              interface = strdup(iap->ifa_name);
              break;
          }
      }
  }
  freeifaddrs(addrs);
  return interface;
}

static
int readNlSock(int sockFd, char *bufPtr, int seqNum, int pId){

  struct nlmsghdr *nlHdr;
  int readLen = 0, msgLen = 0;

  do{
      /* Recieve response from the kernel */
      if((readLen = recv(sockFd, bufPtr, BUFSIZE - msgLen, 0)) < 0){

          perror("SOCK READ: ");
          return -1;
      }

      nlHdr = (struct nlmsghdr *)bufPtr;

      /* Check if the header is valid */
      if((NLMSG_OK(nlHdr, readLen) == 0) || (nlHdr->nlmsg_type == NLMSG_ERROR))
        {

          perror("Error in recieved packet");
          return -1;
        }

      /* Check if the its the last message */

      if(nlHdr->nlmsg_type == NLMSG_DONE) {
          break;
      }
      else{

          /* Else move the pointer to buffer appropriately */
          bufPtr += readLen;
          msgLen += readLen;
      }

      /* Check if its a multi part message */
      if((nlHdr->nlmsg_flags & NLM_F_MULTI) == 0) {

          /* return if its not */
          break;
      }
  } while((nlHdr->nlmsg_seq != seqNum) || (nlHdr->nlmsg_pid != pId));

  return msgLen;
}

/* For printing the routes. */
#if 0
static
void printRoute(struct route_info *rtInfo)
{

  char tempBuf[512];

  /* Print Destination address */
  if(rtInfo->dstAddr != 0)
    strcpy(tempBuf, (char *)inet_ntoa(rtInfo->dstAddr));
  else
    sprintf(tempBuf,"*.*.*.*\t");
  fprintf(stdout,"%s\t", tempBuf);

  /* Print Gateway address */
  if(rtInfo->gateWay != 0)
    strcpy(tempBuf, (char *)inet_ntoa(rtInfo->gateWay));
  else
    sprintf(tempBuf,"*.*.*.*\t");
  fprintf(stdout,"%s\t", tempBuf);

  /* Print Interface Name*/
  fprintf(stdout,"%s\t", rtInfo->ifName);

  /* Print Source address */
  if(rtInfo->srcAddr != 0)
    strcpy(tempBuf, (char *)inet_ntoa(rtInfo->srcAddr));

  else
    sprintf(tempBuf,"*.*.*.*\t");
  fprintf(stdout,"%s\n", tempBuf);
}
#endif

static
void printGateway()
{
  printf("%s\n", gateway);
}

/* For parsing the route info returned */
static
void parseRoutes(struct nlmsghdr *nlHdr, struct route_info *rtInfo)
{

  struct rtmsg *rtMsg;
  struct rtattr *rtAttr;

  int rtLen;
  char *tempBuf = NULL;

  tempBuf = (char *)malloc(100);
  rtMsg = (struct rtmsg *)NLMSG_DATA(nlHdr);

  /* If the route is not for AF_INET or does not belong to main routing table
  then return. */
  if((rtMsg->rtm_family != AF_INET) || (rtMsg->rtm_table != RT_TABLE_MAIN))

    return;

  /* get the rtattr field */
  rtAttr = (struct rtattr *)RTM_RTA(rtMsg);

  rtLen = RTM_PAYLOAD(nlHdr);
  for(;RTA_OK(rtAttr,rtLen);rtAttr = RTA_NEXT(rtAttr,rtLen)){

      switch(rtAttr->rta_type) {
      case RTA_OIF:
        if_indextoname(*(int *)RTA_DATA(rtAttr), rtInfo->ifName);

        break;
      case RTA_GATEWAY:
        rtInfo->gateWay.s_addr = *(u_int *)RTA_DATA(rtAttr);

        break;
      case RTA_PREFSRC:
        rtInfo->srcAddr.s_addr = *(u_int *)RTA_DATA(rtAttr);

        break;
      case RTA_DST:
        rtInfo->dstAddr.s_addr = *(u_int *)RTA_DATA(rtAttr);

        break;
      }
  }
  //printf("%s\n", (char *)inet_ntoa(rtInfo->dstAddr));
  if (strstr((char *)inet_ntoa(rtInfo->dstAddr), "0.0.0.0"))
      sprintf(gateway, "%s", inet_ntoa(rtInfo->gateWay));
  //printRoute(rtInfo);

  free(tempBuf);
  return;
}

static
char*
getoutif_from_netlink(char * addr)
{
  struct nlmsghdr *nlMsg;
  struct rtmsg *rtMsg;
  struct route_info *rtInfo;
  char msgBuf[BUFSIZE];
  int sock, len, msgSeq = 0;
  char buff[1024];

  /* Create Socket */
  if((sock = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_ROUTE)) < 0)
    perror("Socket Creation: ");

  /* Initialize the buffer */
  memset(msgBuf, 0, BUFSIZE);

  /* point the header and the msg structure pointers into the buffer */
  nlMsg = (struct nlmsghdr *)msgBuf;
  rtMsg = (struct rtmsg *)NLMSG_DATA(nlMsg);

  /* Fill in the nlmsg header*/
  nlMsg->nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg)); // Length of message.

  nlMsg->nlmsg_type = RTM_GETROUTE; // Get the routes from kernel routing table .

  nlMsg->nlmsg_flags = NLM_F_DUMP | NLM_F_REQUEST; // The message is a request for dump.

  nlMsg->nlmsg_seq = msgSeq++; // Sequence of the message packet.
  nlMsg->nlmsg_pid = getpid(); // PID of process sending the request.


  /* Send the request */
  if(send(sock, nlMsg, nlMsg->nlmsg_len, 0) < 0){
      printf("Write To Socket Failed...\n");
      return 0;
  }

  /* Read the response */

  if((len = readNlSock(sock, msgBuf, msgSeq, getpid())) < 0) {
      printf("Read From Socket Failed...\n");
      return 0;
  }
  /* Parse and print the response */
  rtInfo = (struct route_info *)malloc(sizeof(struct route_info));

  /* THIS IS THE NETTSTAT -RL code I commented out the printing here and in parse routes */
  //fprintf(stdout, "Destination\tGateway\tInterface\tSource\n");
  for(;NLMSG_OK(nlMsg,len);nlMsg = NLMSG_NEXT(nlMsg,len)){
      memset(rtInfo, 0, sizeof(struct route_info));
      parseRoutes(nlMsg, rtInfo);
  }

  free(rtInfo);
  close(sock);

  printGateway();

  return 0;
}

#define _PATH_PROCNET_ROUTE             "/proc/net/route"

#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include <ctype.h>

/* Caller must free return string. */

char *proc_gen_fmt(const char *name, int more, FILE * fh,...)
{
    char buf[512], format[512] = "";
    char *title, *head, *hdr;
    va_list ap;

    if (!fgets(buf, (sizeof buf) - 1, fh))
        return NULL;
    strcat(buf, " ");

    va_start(ap, fh);
    title = va_arg(ap, char *);
    for (hdr = buf; hdr;) {
        while (isspace(*hdr) || *hdr == '|')
            hdr++;
        head = hdr;
        hdr = strpbrk(hdr, "| \t\n");
        if (hdr)
            *hdr++ = 0;

        if (!strcmp(title, head)) {
            strcat(format, va_arg(ap, char *));
            title = va_arg(ap, char *);
            if (!title || !head)
                break;
        } else {
            strcat(format, "%*s");      /* XXX */
        }
        strcat(format, " ");
    }
    va_end(ap);

    if (!more && title) {
        fprintf(stderr, "warning: %s does not contain required field %s\n",
                name, title);
        return NULL;
    }
    return strdup(format);
}


#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <resolv.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

char *safe_strncpy(char *dst, const char *src, size_t size)
{
    dst[size-1] = '\0';
    return strncpy(dst,src,size-1);
}

/* cache */
struct addr {
    struct sockaddr_in addr;
    char *name;
    int host;
    struct addr *next;
};

struct service {
    int number;
    char *name;
    struct service *next;
};

static struct addr *INET_nn = NULL;     /* addr-to-name cache           */


/* numeric: & 0x8000: default instead of *,
 *          & 0x4000: host instead of net,
 *          & 0x0fff: don't resolve
 */
static int INET_rresolve(char *name, size_t len, struct sockaddr_in *sin,
                         int numeric, unsigned int netmask)
{
    struct hostent *ent;
    struct netent *np;
    struct addr *pn;
    unsigned long ad, host_ad;
    int host = 0;

    /* Grmpf. -FvK */
    if (sin->sin_family != AF_INET) {
#ifdef DEBUG
        fprintf(stderr, _("rresolve: unsupport address family %d !\n"), sin->sin_family);
#endif
        errno = EAFNOSUPPORT;
        return (-1);
    }
    ad = (unsigned long) sin->sin_addr.s_addr;
#ifdef DEBUG
    fprintf (stderr, "rresolve: %08lx, mask %08x, num %08x \n", ad, netmask, numeric);
#endif
    if (ad == INADDR_ANY) {
        if ((numeric & 0x0FFF) == 0) {
            if (numeric & 0x8000)
                safe_strncpy(name, "default", len);
            else
                safe_strncpy(name, "*", len);
            return (0);
        }
    }
    if (numeric & 0x0FFF) {
        safe_strncpy(name, inet_ntoa(sin->sin_addr), len);
        return (0);
    }

    if ((ad & (~netmask)) != 0 || (numeric & 0x4000))
        host = 1;
#if 0
    INET_nn = NULL;
#endif
    pn = INET_nn;
    while (pn != NULL) {
        if (pn->addr.sin_addr.s_addr == ad && pn->host == host) {
            safe_strncpy(name, pn->name, len);
#ifdef DEBUG
            fprintf (stderr, "rresolve: found %s %08lx in cache\n", (host? "host": "net"), ad);
#endif
            return (0);
        }
        pn = pn->next;
    }

    host_ad = ntohl(ad);
    np = NULL;
    ent = NULL;
    if (host) {
#ifdef DEBUG
        fprintf (stderr, "gethostbyaddr (%08lx)\n", ad);
#endif
        ent = gethostbyaddr((char *) &ad, 4, AF_INET);
        if (ent != NULL)
            safe_strncpy(name, ent->h_name, len);
    } else {
#ifdef DEBUG
        fprintf (stderr, "getnetbyaddr (%08lx)\n", host_ad);
#endif
        np = getnetbyaddr(host_ad, AF_INET);
        if (np != NULL)
            safe_strncpy(name, np->n_name, len);
    }
    if ((ent == NULL) && (np == NULL))
        safe_strncpy(name, inet_ntoa(sin->sin_addr), len);
    pn = (struct addr *) malloc(sizeof(struct addr));
    pn->addr = *sin;
    pn->next = INET_nn;
    pn->host = host;
    pn->name = (char *) malloc(strlen(name) + 1);
    strcpy(pn->name, name);
    INET_nn = pn;

    return (0);
}

/* Display an Internet socket address. */
static char *INET_print(unsigned char *ptr)
{
    return (inet_ntoa((*(struct in_addr *) ptr)));
}

/* Display an Internet socket address. */
static char *INET_sprint(struct sockaddr *sap, int numeric)
{
    static char buff[128];

    if (sap->sa_family == 0xFFFF || sap->sa_family == 0)
        return safe_strncpy(buff, "[NONE SET]", sizeof(buff));

    if (INET_rresolve(buff, sizeof(buff), (struct sockaddr_in *) sap,
                      numeric, 0xffffff00) != 0)
        return (NULL);

    return (buff);
}

char *INET_sprintmask(struct sockaddr *sap, int numeric,
                      unsigned int netmask)
{
    static char buff[128];

    if (sap->sa_family == 0xFFFF || sap->sa_family == 0)
        return safe_strncpy(buff, "[NONE SET]", sizeof(buff));
    if (INET_rresolve(buff, sizeof(buff), (struct sockaddr_in *) sap,
                      numeric, netmask) != 0)
        return (NULL);
    return (buff);
}

static int INET_getsock(char *bufp, struct sockaddr *sap)
{
    char *sp = bufp, *bp;
    unsigned int i;
    unsigned val;
    struct sockaddr_in *sin;

    sin = (struct sockaddr_in *) sap;
    sin->sin_family = AF_INET;
    sin->sin_port = 0;

    val = 0;
    bp = (char *) &val;
    for (i = 0; i < sizeof(sin->sin_addr.s_addr); i++) {
        *sp = toupper(*sp);

        if ((*sp >= 'A') && (*sp <= 'F'))
            bp[i] |= (int) (*sp - 'A') + 10;
        else if ((*sp >= '0') && (*sp <= '9'))
            bp[i] |= (int) (*sp - '0');
        else
            return (-1);

        bp[i] <<= 4;
        sp++;
        *sp = toupper(*sp);

        if ((*sp >= 'A') && (*sp <= 'F'))
            bp[i] |= (int) (*sp - 'A') + 10;
        else if ((*sp >= '0') && (*sp <= '9'))
            bp[i] |= (int) (*sp - '0');
        else
            return (-1);

        sp++;
    }
    sin->sin_addr.s_addr = htonl(val);

    return (sp - bufp);
}

static int INET_input(int type, char *bufp, struct sockaddr *sap)
{
    switch (type) {
    case 1:
    default:
        return (INET_getsock(bufp, sap));
//    case 256:
//        return (INET_resolve(bufp, (struct sockaddr_in *) sap, 1));
//    default:
//        return (INET_resolve(bufp, (struct sockaddr_in *) sap, 0));
    }
}

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <resolv.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include "net-support.h"

static
char*
printf_fib(char * addr)
{

  char buff[1024], iface[16], flags[64];
  char gate_addr[128], net_addr[128];
  char mask_addr[128];
  int num, iflags, metric, refcnt, use, mss, window, irtt;
  FILE *fp = fopen(_PATH_PROCNET_ROUTE, "r");
  char *fmt;

  int ext = 1;
  int numeric = 0;

  if (!fp) {
      perror(_PATH_PROCNET_ROUTE);
      printf("INET (IPv4) not configured in this system.\n");
      return 0;
  }
  printf("Kernel IP routing table\n");

  if (ext == 1)
      printf("Destination     Gateway         Genmask         "
               "Flags Metric Ref    Use Iface\n");
  if (ext == 2)
      printf("Destination     Gateway         Genmask         "
               "Flags   MSS Window  irtt Iface\n");
  if (ext >= 3)
      printf("Destination     Gateway         Genmask         "
               "Flags Metric Ref    Use Iface    "
               "MSS   Window irtt\n");

  irtt = 0;
  window = 0;
  mss = 0;

  fmt = proc_gen_fmt(_PATH_PROCNET_ROUTE, 0, fp,
                     "Iface", "%16s",
                     "Destination", "%128s",
                     "Gateway", "%128s",
                     "Flags", "%X",
                     "RefCnt", "%d",
                     "Use", "%d",
                     "Metric", "%d",
                     "Mask", "%128s",
                     "MTU", "%d",
                     "Window", "%d",
                     "IRTT", "%d",
                     NULL);
  /* "%16s %128s %128s %X %d %d %d %128s %d %d %d\n" */

  if (!fmt)
      return 0;

  while (fgets(buff, 1023, fp)) {
      struct sockaddr snet_target, snet_gateway, snet_mask;
      struct sockaddr_in *sin_netmask;

      num = sscanf(buff, fmt,
                   iface, net_addr, gate_addr,
                   &iflags, &refcnt, &use, &metric, mask_addr,
                   &mss, &window, &irtt);
      if (num < 10 || !(iflags & RTF_UP))
          continue;

      /* Fetch and resolve the target address. */
      (void) INET_input(1, net_addr, &snet_target);

      /* Fetch and resolve the gateway address. */
      (void) INET_input(1, gate_addr, &snet_gateway);

      /* Fetch and resolve the genmask. */
      (void) INET_input(1, mask_addr, &snet_mask);

      sin_netmask = (struct sockaddr_in *)&snet_mask;
      strcpy(net_addr, INET_sprintmask(&snet_target,
                                       (numeric | 0x8000 | (iflags & RTF_HOST? 0x4000: 0)),
                                       sin_netmask->sin_addr.s_addr));
      net_addr[15] = '\0';

      strcpy(gate_addr, INET_sprint(&snet_gateway, numeric | 0x4000));
      gate_addr[15] = '\0';

      strcpy(mask_addr, INET_sprint(&snet_mask, 1));
      mask_addr[15] = '\0';

      /* Decode the flags. */
      flags[0] = '\0';
      if (iflags & RTF_UP)
          strcat(flags, "U");
      if (iflags & RTF_GATEWAY)
          strcat(flags, "G");
#if HAVE_RTF_REJECT
      if (iflags & RTF_REJECT)
          strcpy(flags, "!");
#endif
      if (iflags & RTF_HOST)
          strcat(flags, "H");
      if (iflags & RTF_REINSTATE)
          strcat(flags, "R");
      if (iflags & RTF_DYNAMIC)
          strcat(flags, "D");
      if (iflags & RTF_MODIFIED)
          strcat(flags, "M");
      if (iflags & RTF_DEFAULT)
          strcat(flags, "d");
      if (iflags & RTF_ALLONLINK)
          strcat(flags, "a");
      if (iflags & RTF_ADDRCONF)
          strcat(flags, "c");
      if (iflags & RTF_NONEXTHOP)
          strcat(flags, "o");
      if (iflags & RTF_EXPIRES)
          strcat(flags, "e");
      if (iflags & RTF_CACHE)
          strcat(flags, "c");
      if (iflags & RTF_FLOW)
          strcat(flags, "f");
      if (iflags & RTF_POLICY)
          strcat(flags, "p");
      if (iflags & RTF_LOCAL)
          strcat(flags, "l");
      if (iflags & RTF_MTU)
          strcat(flags, "u");
      if (iflags & RTF_WINDOW)
          strcat(flags, "w");
      if (iflags & RTF_IRTT)
          strcat(flags, "i");
      if (iflags & RTF_NOTCACHED) /* 2.0.36 */
          strcat(flags, "n");

      /* Print the info. */
      if (ext == 1) {
#if HAVE_RTF_REJECT
          if (iflags & RTF_REJECT)
              printf("%-15s -               %-15s %-5s %-6d -  %7d -\n",
                     net_addr, mask_addr, flags, metric, use);
          else
#endif
              printf("%-15s %-15s %-15s %-5s %-6d %-2d %7d %s\n",
                     net_addr, gate_addr, mask_addr, flags,
                     metric, refcnt, use, iface);
      }
      if (ext == 2) {
#if HAVE_RTF_REJECT
          if (iflags & RTF_REJECT)
              printf("%-15s -               %-15s %-5s     - -          - -\n",
                     net_addr, mask_addr, flags);
          else
#endif
              printf("%-15s %-15s %-15s %-5s %5d %-5d %6d %s\n",
                     net_addr, gate_addr, mask_addr, flags,
                     mss, window, irtt, iface);
      }
      if (ext >= 3) {
#if HAVE_RTF_REJECT
          if (iflags & RTF_REJECT)
              printf("%-15s -               %-15s %-5s %-6d -  %7d -        -     -      -\n",
                     net_addr, mask_addr, flags, metric, use);
          else
#endif
              printf("%-15s %-15s %-15s %-5s %-6d %-3d %6d %-6.6s   %-5d %-6d %d\n",
                     net_addr, gate_addr, mask_addr, flags,
                     metric, refcnt, use, iface, mss, window, irtt);
      }
  }

  free(fmt);
  (void) fclose(fp);

  return 0;
}

static
char*
getoutif_from_fib(char * dest_addr)
{

  char buff[1024], iface[16], flags[64], def_iface[16];
  char gate_addr[128], net_addr[128];
  char mask_addr[128];
  int num, iflags, metric, refcnt, use, mss, window, irtt;
  FILE *fp = fopen(_PATH_PROCNET_ROUTE, "r");
  char *fmt;
  struct in_addr        snet_dest;
  int                   dev_found = 0, def_found = 0;

  if (!fp) {
      perror(_PATH_PROCNET_ROUTE);
      printf("INET (IPv4) not configured in this system.\n");
      return 0;
  }

  irtt = 0;
  window = 0;
  mss = 0;

  fmt = proc_gen_fmt(_PATH_PROCNET_ROUTE, 0, fp,
                     "Iface", "%16s",
                     "Destination", "%128s",
                     "Gateway", "%128s",
                     "Flags", "%X",
                     "RefCnt", "%d",
                     "Use", "%d",
                     "Metric", "%d",
                     "Mask", "%128s",
                     "MTU", "%d",
                     "Window", "%d",
                     "IRTT", "%d",
                     NULL);
  /* "%16s %128s %128s %X %d %d %d %128s %d %d %d\n" */

  if (!fmt)
      return 0;

  inet_aton(dest_addr, &snet_dest);

  while (fgets(buff, 1023, fp)) {
      struct sockaddr snet_target, snet_gateway, snet_mask;
      struct sockaddr_in *sin_netmask, *sin_target;

      num = sscanf(buff, fmt,
                   iface, net_addr, gate_addr,
                   &iflags, &refcnt, &use, &metric, mask_addr,
                   &mss, &window, &irtt);
      if (num < 10 || !(iflags & RTF_UP))
          continue;

      /* Fetch and resolve the target address. */
      (void) INET_input(1, net_addr, &snet_target);

      /* Fetch and resolve the gateway address. */
      (void) INET_input(1, gate_addr, &snet_gateway);

      /* Fetch and resolve the genmask. */
      (void) INET_input(1, mask_addr, &snet_mask);

      sin_netmask = (struct sockaddr_in *)&snet_mask;
      sin_target = (struct sockaddr_in *)&snet_target;

      if(sin_target->sin_addr.s_addr == 0) {
        strcpy(def_iface, iface);
        def_found = 1;
      }
      else if ((snet_dest.s_addr & sin_netmask->sin_addr.s_addr) == sin_target->sin_addr.s_addr) {
          dev_found = 1;
          break;
      }
  }

  free(fmt);
  (void) fclose(fp);

  return dev_found ? strdup(iface) : (def_found ? strdup(def_iface) : 0);
}

int
mdtm_lustre_islustre(char *fs) {
  int rc = 0;

  if((strstr(fs, "@") != NULL) ||
      (strstr(fs, ":") != NULL))
    rc = 1;
  return rc;
}

#include <netdb.h>

char *
mdtm_lustre_devname(const char *fs) {
  char          addr[256];
  char *        tmp;

  // parsing hostname or ip from file system name
  strcpy(addr, fs);
  if((tmp = strstr(addr, "@")) == NULL)
    tmp = strstr(addr, ":");
  if(tmp != NULL)
    *tmp = '\0';

  // check the format of address, convert to IP if needed
  if((tmp = strrchr(addr, '.')) == 0 || isDigitString(addr) == 0) {
      // convert hostname to ip
      struct hostent *          he;
      struct sockaddr_in        server;

      he  = gethostbyname(addr);
      if ( he == NULL)
        return 0;

      memcpy(&server.sin_addr, he->h_addr_list[0], he->h_length);
      strcpy(addr, inet_ntoa(server.sin_addr));
  }

  // find the device name for the outgoing network interface
  if(isValidIpAddress(addr)) {
      return getoutif_from_fib(addr);
  }
  return 0;
}

#ifdef __cplusplus
}
#endif



