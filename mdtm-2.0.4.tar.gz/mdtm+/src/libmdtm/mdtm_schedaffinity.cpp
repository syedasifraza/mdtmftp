/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <cstdio>
#include <errno.h>
#include <sched.h>

#include <unistd.h> //processor affinity.
#include <sys/syscall.h> // thread ID.
#include <sys/resource.h> // get/set priority.

#include <pthread.h>

#include "include/private/mdtm_debug.h"
#include "mdtm_schedaffinity.h"

mdtm_schedaffinity::mdtm_schedaffinity() {
  ncpu = sysconf(_SC_NPROCESSORS_ONLN);
  mask = CPU_ALLOC(ncpu);
  size = CPU_ALLOC_SIZE(ncpu);
  CPU_ZERO_S(size, mask);
}
mdtm_schedaffinity::~mdtm_schedaffinity() {
  CPU_FREE(mask);
}
int mdtm_schedaffinity::ShowAffinity (pid_t pid) {
//     cpu_set_t *mask;
//     size_t size;

     // you can use sysconf or __CPU_SETSIZE system macro.
//     int ncpu = sysconf(_SC_NPROCESSORS_ONLN);
//
//     mask = CPU_ALLOC(ncpu);
//     size = CPU_ALLOC_SIZE(ncpu);
//     CPU_ZERO_S(size, mask);
     errno = 0;
     if ( sched_getaffinity(pid, sizeof(mask), mask) == -1 ) {
//     CPU_FREE(mask);
     switch ( errno ) {
     case EPERM: mdtm_debug ( "Error: Insufficient permission.\n" ); break;
     case EFAULT: mdtm_debug ( "Error: Invalid memory address.\n" ); break;
     case ESRCH: mdtm_debug ( "Error: Invalid process ID\n"); break;
     case EINVAL: mdtm_debug ( "Error: Invalid arguments\n"); break;
     }
     return -1;
     }

     mdtm_debug ( "CPU Affinity: \n" );
     for ( int i=0; i < ncpu; i ++ ) {
         if ( CPU_ISSET_S( i, size, mask ) ) {
            mdtm_debug("\tCPU %d is set\n", (i));
         }
     }

//     CPU_FREE(mask);
    return 0;
}

int mdtm_schedaffinity::ShowAffinity (pthread_t tid) {
//     cpu_set_t *mask;
//     size_t size;

     // you can use sysconf or __CPU_SETSIZE system macro.
//     int ncpu = sysconf(_SC_NPROCESSORS_ONLN);
//
//     mask = CPU_ALLOC(ncpu);
//     size = CPU_ALLOC_SIZE(ncpu);
//     CPU_ZERO_S(size, mask);
     errno = 0;
     if ( pthread_getaffinity_np(tid, sizeof(mask), mask) == -1 ) {
//     CPU_FREE(mask);
     switch ( errno ) {
     case EPERM: mdtm_debug ( "Error: Insufficient permission.\n" ); break;
     case EFAULT: mdtm_debug ( "Error: Invalid memory address.\n" ); break;
     case ESRCH: mdtm_debug ( "Error: Invalid process ID\n"); break;
     case EINVAL: mdtm_debug ( "Error: Invalid arguments\n"); break;
     }
     return -1;
     }

//     mdtm_debug ( "CPU Affinity:\n\tPID=%u\tTID=%u\n",getpid(), tid);
//     for ( int i=0; i < ncpu; i ++ ) {
//         if ( CPU_ISSET_S( i, size, mask ) ) {
//            mdtm_debug("\tCPU %d is set\n", (i));
//         }
//     }

//     CPU_FREE(mask);
    return 0;
}

int mdtm_schedaffinity::SetAffinity ( int* cpuId, int n, pid_t pid ) {
//    int ncpu = sysconf(_SC_NPROCESSORS_ONLN);
//    cpu_set_t *mask = CPU_ALLOC(ncpu);
//    size_t size = CPU_ALLOC_SIZE(ncpu);
    CPU_ZERO_S(size, mask);
    for(int i = 0; i < n; i++)
      CPU_SET_S(cpuId[i], size, mask);
    if ( sched_setaffinity(pid, size, mask) == -1 ) {
//       CPU_FREE(mask);
       switch ( errno ) {
       case EPERM: mdtm_debug ( "Error: Insufficient permission.\n" ); break;
       case EFAULT: mdtm_debug ( "Error: Invalid memory address.\n" ); break;
       case ESRCH: mdtm_debug ( "Error: Invalid process ID\n" ); break;
       case EINVAL: mdtm_debug ( "Error: Invalid arguments\n" ); break;
       }
       return -1;
    }

//    CPU_FREE(mask);
    return 0;
}

int mdtm_schedaffinity::SetAffinity ( int* cpuId, int n, pthread_t tid ) {
//    int ncpu = sysconf(_SC_NPROCESSORS_ONLN);
//    cpu_set_t *mask = CPU_ALLOC(ncpu);
//    size_t size = CPU_ALLOC_SIZE(ncpu);
    CPU_ZERO_S(size, mask);
    for(int i = 0; i < n; i++)
      CPU_SET_S(cpuId[i], size, mask);
    if ( pthread_setaffinity_np(tid, size, mask) == -1 ) {
//       CPU_FREE(mask);
       switch ( errno ) {
       case EPERM: mdtm_debug ( "Error: Insufficient permission.\n" ); break;
       case EFAULT: mdtm_debug ( "Error: Invalid memory address.\n" ); break;
       case ESRCH: mdtm_debug ( "Error: Invalid process ID\n" ); break;
       case EINVAL: mdtm_debug ( "Error: Invalid arguments\n" ); break;
       }
       return -1;
    }

//    CPU_FREE(mask);
    return 0;
}

int mdtm_schedaffinity::ResetAffinity () {
    int ncpu = sysconf(_SC_NPROCESSORS_ONLN);
    cpu_set_t *mask = CPU_ALLOC(ncpu);
    size_t size = CPU_ALLOC_SIZE(ncpu);

    CPU_ZERO_S(size, mask);
    for ( int i=0; i < ncpu; i++ ) {
        CPU_SET_S(i, size, mask);
    }

    if ( sched_setaffinity(0, size, mask) == -1 ) {
//        CPU_FREE(mask);
        switch ( errno ) {
        case EPERM: mdtm_debug ( "Error: Insufficient permission.\n" ); break;
        case EFAULT: mdtm_debug ( "Error: Invalid memory address.\n" ); break;
        case ESRCH: mdtm_debug ( "Error: Invalid process ID\n" ); break;
        case EINVAL: mdtm_debug ( "Error: Invalid arguments\n" ); break;
        default: mdtm_debug ( "Error: Unexpected Error code %d\n", errno ); break;
        }
        return -1;
    }

//    CPU_FREE(mask);
    return 0;
}



// To set CPU affinity of a any thread, call  SetAffinity() from thread function.

// e.g. you can set affinity for main thread/process as follows:

//int main(void) {
//
//    //get number of processors on the box.
//    int ncpu = sysconf(_SC_NPROCESSORS_ONLN);
//    ShowAffinity ();
//    mdtm_debug ( "\nRestricting to only middle one : %d \n", ncpu/2 );
//    SetAffinity ( (ncpu-1) / 2 );
//    ShowAffinity ();
//
//    return 0;
//}


