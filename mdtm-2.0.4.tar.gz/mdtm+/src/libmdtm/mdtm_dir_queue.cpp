/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include "mdtm_dir_queue.h"

mdtm_dir_queue::
mdtm_dir_queue(const char *pathname) : total_size(0), nblocks(0) {
  walk(pathname);
};

mdtm_dir_queue::
~mdtm_dir_queue() {
  dir_list.clear();
  file_list.clear();
  zero_list.clear();
  link_list.clear();
}

bool
mdtm_dir_queue::
add_file(const libdir::dentry& de) {
  return true; /* Don't read file (add_file_data) */
}

bool
mdtm_dir_queue::
add_file(std::string filename, size_t size) {
  libdir::dentry de;
  de.set_is_file();
  de.set_stat(size);
  de.set_position(total_size);
  de.set_name(filename);
//  de.set_parent(".");
  nblocks += de.splitname("", 100, 512);
  total_size += de.size();
  file_list.push_back(de);
  return true;
}

void
mdtm_dir_queue::
add_file_data(const libdir::dentry& de) {
  de.stat();
  nblocks += de.splitname(getroot(), 100, 512);
  file_list.push_back(de);
}

void
mdtm_dir_queue::
add_zero_file(const libdir::dentry& de) {
  de.stat();
  nblocks += de.splitname(getroot(), 100, 512);
  zero_list.push_back(de);
}

void
mdtm_dir_queue::
add_link_file(const libdir::dentry& de) {
  de.stat();
  nblocks += de.splitname(getroot(), 100, 512);
  link_list.push_back(de);
}

bool
mdtm_dir_queue::
add_fifo(const libdir::dentry& de) {
  de.stat();
  nblocks += de.splitname(getroot(), 100, 512);
  fifo_list.push_back(de);
  return true;
}

bool
mdtm_dir_queue::
add_fifo(std::string filename, size_t size) {
  libdir::dentry de;
  de.set_is_fifo();
  de.set_stat(size);
  de.set_position(total_size);
  de.set_name(filename);
//  de.set_parent(".");
  nblocks += de.splitname("", 100, 512);
  total_size += de.size();
  file_list.push_back(de);
  return true;
}

bool
mdtm_dir_queue::
add_directory(const libdir::dentry& de) {
  de.stat();
  nblocks += de.splitname(getroot(), 100, 512);
  dir_list.push_back(de);
  return true;
}

bool
mdtm_dir_queue::
add_directory(std::string dirname) {
  libdir::dentry de;

  de.set_is_dir();
  de.set_name(dirname);
//  de.set_parent(".");
  nblocks += de.splitname("", 100, 512);
  dir_list.push_back(de);
  return true;
}

libdir::dentry
mdtm_dir_queue::
remove_directory() {
  libdir::dentry de;
  if(!dir_list.empty()){
      de  = dir_list.front();
      dir_list.pop_front();
      return de;
  }
  else
    throw "empty dir_list";
}

libdir::dentry
mdtm_dir_queue::
remove_file() {
  libdir::dentry de;
  if(!file_list.empty()){
      de  = file_list.front();
      file_list.pop_front();
      return de;
  }
  else if(!fifo_list.empty()) {
      de  = fifo_list.front();
      fifo_list.pop_front();
      return de;
  }
    throw "empty file_list";

}

libdir::dentry
mdtm_dir_queue::
peek_file() {
  libdir::dentry de;
  if(!file_list.empty()){
      de  = file_list.front();
      return de;
  }
  else if(!fifo_list.empty()) {
      de = fifo_list.front();
      return de;
  }
  else
    throw "empty file_list";

}

#include <stdio.h>
#include <string.h>
#include <linux/limits.h>
bool
mdtm_dir_queue::
add_sortedpaths(
    char **     path_array,
    size_t *    size_array,
    int         array_size)
{
  char  tmpcstr[PATH_MAX+1], *c;

  try {
      sorted_paths.clear();

      for ( int i = 0; i < array_size; i++) {
          strcpy(tmpcstr, path_array[i]);
          if(tmpcstr[strlen(tmpcstr)-1] != '/') {
            this->add_file(std::string(tmpcstr), size_array[i]);
            c = strrchr(tmpcstr, '/');
            *(c+1) = 0;
          }

          while(strcmp(tmpcstr, "/")) {
        	  tmpcstr[strlen(tmpcstr)-1] = 0;
        	  this->sorted_paths.insert(std::string(tmpcstr));
        	  //            tmpcstr[strlen(tmpcstr)-1] = 0;
        	  c = strrchr(tmpcstr, '/');
        	  *(c+1) = 0;
          }
      }

      for ( auto it = this->sorted_paths.begin(); it != this->sorted_paths.end(); it++)
        this->add_directory(*it);
  }
  catch (int e) {
      return false;
  }

  return true;
}

long
mdtm_dir_queue::
blocks()
{
	return nblocks;
}




