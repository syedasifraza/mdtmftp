/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_SCHED_SPT_H_
#define MDTM_SCHED_SPT_H_

#include "include/mdtm/mdtm_tree.h"
#include "mdtm_schedaffinity.h"
#include "mdtm_ipc.h"

typedef struct {
  unsigned              index;
  mdtm_node_t *         ptr;
  unsigned              cost;
  mdtm_node_t**         buf;
} cpu_cost_t;

typedef struct {
 unsigned numboundthreads;
}mdtm_cpudesc_t;

class mdtm_sched_spt : public MdtmIpcMessage {
public:
  const  std::string    class_name_;
  static const unsigned cost_max = (unsigned)-1;
  static const int numa_dist_factor = 10;
  static const int node_dist_factor = 1;
  static const int max_numa_nodes = 16;
  const mdtm_node_t* mdtmtree;
private:
  mdtm_node_t* spt;
  mdtm_schedaffinity *affinity;
  mdtm_cpudesc_t *cpudesc;
public:
  mdtm_sched_spt(const mdtm_node_t* mdtm_tree)
  : mdtmtree(mdtm_tree),
    spt(0),
    MdtmIpcMessage(0)
  {
    // init message
    MdtmIpcMessage::set_message_name(class_name_.c_str());
    cmdline_ = NULL;//reinterpret_cast<struct cmd_line_s*>(MdtmIpcMessage::get_message_data_ptr());
    result_ = NULL;//reinterpret_cast<struct result_s*>(MdtmIpcMessage::get_message_response_ptr());

    // init member varibles
    mdtm_create_spt();
    affinity = new mdtm_schedaffinity();
    cpudesc = (mdtm_cpudesc_t*)malloc(sizeof(mdtm_cpudesc_t) * affinity->ncpu);
    memset(cpudesc, 0, sizeof(mdtm_cpudesc_t) * affinity->ncpu);
  }

  mdtm_sched_spt(const mdtm_node_t* mdtm_tree, MdtmIpc* ipc)
  : mdtmtree(mdtm_tree),
    spt(0),
    MdtmIpcMessage(ipc)
  {
    // init message
    MdtmIpcMessage::set_message_name(class_name_.c_str());
    cmdline_ = reinterpret_cast<struct cmd_line_s*>(MdtmIpcMessage::get_message_data_ptr());
    result_ = reinterpret_cast<struct result_s*>(MdtmIpcMessage::get_message_response_ptr());

    // init member varibles
    mdtm_create_spt();
    affinity = new mdtm_schedaffinity();
    cpudesc = (mdtm_cpudesc_t*)malloc(sizeof(mdtm_cpudesc_t) * affinity->ncpu);
    memset(cpudesc, 0, sizeof(mdtm_cpudesc_t) * affinity->ncpu);
  }
  ~mdtm_sched_spt(){ free(cpudesc); delete  affinity;}
  int mdtm_sched_cpu(char* srcdevice, char*dstdevice);
  int mdtm_sched_cpu(char* srcdevice, pid_t pid);
  int mdtm_sched_cpu(char* srcdevice, pthread_t tid);
  int mdtm_sched_cpu_r(char* srcdevice, pthread_t tid);
  int mdtm_sched_cpu_l(char* srcdevice);
  int mdtm_sched_cpu(int numa, pid_t pid);
  int mdtm_sched_cpu(int numa, pthread_t tid);
  int mdtm_sched_cpu_on_numa(char* srcdevice, pid_t pid, int numaid);
  int mdtm_sched_cpu_on_numa(char* srcdevice, pthread_t tid, int numaid);
  int mdtm_place_cpu(int targetcpu, pthread_t tid);
  int mdtm_place_cpu(int targetcpu, pid_t pid);
  void mdtm_print_path(char * src, char*dst);
  int  parseit(void* ibuf, int isize, void* obuf, int osize);

private:
  int mdtm_dijkstra(const mdtm_node_t *spt, char *device, const cpu_cost_t *cpucosts);
  void mdtm_getmincost(const mdtm_node_t* tree, mdtm_node_t ** minnode, unsigned *mincost);
  unsigned mdtm_getnodewithmincost(mdtm_node_t **node);
  unsigned mdtm_dijkstra(mdtm_node_t *cpu, const char* device);
  void mdtm_updateneighborcosts(mdtm_node_t *node);
  int mdtm_calc_costs(const char *device, cpu_cost_t *cpucosts);
  void mdtm_resetcostnflag(mdtm_node_t* tree);
  bool mdtm_get_path(mdtm_node_t*src, mdtm_node_t*dst, mdtm_node_t** path, int* depth, int *maxdepth);
  void mdtm_print_path(mdtm_node_t * src, mdtm_node_t*dst);
  void mdtm_print_affinitymask(pthread_t pid);
  int  mdtm_create_spt(void);
  void mdtm_connect_numas(void);
  static int mdtm_cost(float dist, int factor);
  int mdtm_destroy_spt();
  int roundrobin(int *cpus, int count) ;
private:
  enum Command{
    SCHED    = 1
  };

  struct cmd_line_s {
    Command        cmd;
    union {
      struct{
        char  cpus_buf[1024];
        char  mems_buf[1024];
      }getsetmasks;
      char    device[256];
    } argv;
  } * cmdline_;

  struct result_s {
    int        returnval;
    char       errcode[64];
    union {
      struct{
        char  cpus_buf[1024];
        char  mems_buf[1024];
      }getsetmasks;
      int     cpu;
    } data;
  } * result_;
};

#endif /* MDTM_SCHED_SPT_H_ */
