/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <config.h>
#include <iostream>
#include <assert.h>
#include <iterator>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <numaif.h>
#include <numa.h>
#include <linux/limits.h>
#include <malloc.h>
#include <cstdio>
#include <fstream>
#include <string>
#include <sstream>
#include <string>
#include <cstring>
#include <exception>
#include <stdexcept>
#include <hwloc.h>

#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "include/mdtm/mdtm_tree.h"
#include "include/mdtm.h"
#include "include/private/mdtm_tree_intern.h"
#include "include/private/mdtm_debug.h"
#include "include/private/mdtm_config.h"
#include "mdtm_sched_spt.h"
#include "mdtm_dir_queue.h"
#include "mdtm_meta.h"
#include "mdtm_ipc.h"
#include "mdtm_parser.h"
#include "mdtm_cpuset.h"
#include "mdtm_mem.h"
#include "numatop.h"
#include "mdtm_lvm.h"
#include "mdtm_filefrag.h"
#include "mdtm_df.h"
#include "mdtm_pipe.h"
#include "mdtm_lustre.h"

//#define MDTM_DEFAULT_NUMAS              16

//#define MEMORY_MMAP
//#define MEMORY_MEMALIGN
#define MEMORY_MEMALIGN_BIND
//#define MEMORY_MALLOC

//TODO: use fcntl.h after 3.12
//#define F_SETPIPE_SZ 1031
//#define F_GETPIPE_SZ 1032

struct mdtm_io_s {
  unsigned devicenumber;
  unsigned numanode;
};

#if 0
typedef struct {
  long iden[2];
  int pipefd[2];
} mdtm_pipefd_t;

typedef struct {
  mdtm_pipefd_t *pipes;
  int total;
  int used;
  pthread_mutex_t lock;
} mdtm_pipe_pool_t;

typedef struct {
  int numa_id;
  int group_count;
  mdtm_node_t   *numanode;
  int  cpu;
  mdtm_pipefd_t *pipes;
  size_t        pipesize;
  bool   result;
}pipe_thread_data_t;
#endif

typedef struct {
  int           numa_id;
  mdtm_node_t   *numanode;
  int           cpu;
  void          *mem;
  size_t        size;
  int           result;
}mem_thread_data_t;

static mdtmconfig                       g_mdtm_config;
static mdtm_optmode_t                   g_mdtm_opmode = MDTM_OPMODE_DEFAULT;
static MdtmParserInterface *            g_cpuset = NULL;
static MdtmParserInterface *            g_mem = NULL;
static MdtmParser *                     g_parser = NULL;
static MdtmIpc *                        g_ipc = NULL;
static struct mdtm_device_s*            g_devices = 0;
static int                              g_ndevices = 0;
static mdtm_sched_spt *                 g_sched = 0;
//static mdtm_pipe_pool_t *               g_mdtm_pipe_pools = 0;
//static int                              global_group_count = 0;
static int                              g_mdtm_pipe_initialized = 0;

static mdtm_node_t *                    mdtm_topology_tree = 0;
static const char*                      mdtm_version_string = 0;
static size_t                           g_page_size;

#define SWAB_ALIGN_OFFSET 2
#define INPUT_BLOCK_SLOP (2 * SWAB_ALIGN_OFFSET + 2 * g_page_size - 1)
/* The page size on this host.  */

#ifdef __cplusplus
extern "C" {
#endif

void mdtm_get_sys_info();

static
void
mdtm_server_fini(void);

static
void
mdtm_client_fini(void);

static
int
mdtm_server_init(void) {
//  mdtm_irq *                    irq;
  try {
      // create ipc instance
      g_ipc = new MdtmIpc("mdtm");
      if(g_ipc->open(MdtmIpc::O_CREATE) < 0)
        throw std::runtime_error(std::string("Cannot open IPC."));

      // initialize parser
      g_parser = new MdtmParser();

      // scheduler
      g_sched = new mdtm_sched_spt(mdtm_topology_tree, g_ipc);
      g_parser->enroll(static_cast<mdtm_sched_spt *>(g_sched)->class_name_, *g_sched);

      // zone
      g_cpuset = new mdtm_cpuset(g_ipc);
      if(static_cast<mdtm_cpuset*>(g_cpuset)->createpath() < 0)
        throw std::runtime_error(std::string("Cannot create CPUSET path."));
      g_parser->enroll(static_cast<mdtm_cpuset*>(g_cpuset)->class_name_, *g_cpuset);
      g_ndevices = mdtm_config_getpcidevices(&g_devices);
      for(int i = 0; i < g_ndevices; i++) {
          static_cast<mdtm_cpuset*>(g_cpuset)->addnode(g_devices[i].numaid);
      }

      // memory
      g_mem = new mdtm_mem(g_ipc);
      g_parser->enroll(static_cast<mdtm_mem*>(g_mem)->class_name_, *g_mem);
      static_cast<mdtm_mem*>(g_mem)->set_lat_fn(numatop_node_lat);

      //  irq = new mdtm_irq();
      //  irq->assignirqaffinity("eth3-");
      //  irq->printirqaffinity("eth3-");
      //  irq->resumeirqaffinity();

  } catch(const std::exception &e) {
      g_mdtm_opmode = MDTM_OPMODE_DEFAULT;
      mdtm_server_fini();
      std::cerr<< "libmdtm: an exception is caught:"<<e.what()<<std::endl;
      return -1;
  } catch(...) {
      g_mdtm_opmode = MDTM_OPMODE_DEFAULT;
      mdtm_server_fini();
      std::cerr<< "libmdtm: default exception."<<std::endl;
      return -1;
  }

  return 0;
}

static
void
mdtm_server_fini(void) {
  if(g_devices)
    free(g_devices);

  if(g_mem) { delete g_mem; g_mem = NULL; }

  //  delete irq;
  //...

  if(g_cpuset) {
      static_cast<mdtm_cpuset*>(g_cpuset)->deletepath();
      delete g_cpuset;
      g_cpuset = NULL;
  }

  if(g_sched) { delete g_sched; g_sched = NULL; }

  if(g_parser) { delete g_parser; g_parser = NULL; }

  if(g_ipc) {
      g_ipc->close();
      delete g_ipc;
      g_ipc = NULL;
  }
}

static
int
mdtm_server_poll() {
  char                  inbuf[MdtmIpc::BUF_SIZE], outbuf[MdtmIpc::BUF_SIZE];
  int                   inbufsize, outbufsize, used;

  if(!g_sched || !g_parser)
    return -1;

  if((used = g_ipc->wait((void*)inbuf, inbufsize)) > 0) {
      used = g_parser->parse(inbuf, used, outbuf, outbufsize);    //Run our Process
      g_ipc->respond(outbuf, used);
  }
  return 0;
}

static
int
mdtm_client_init(void) {
//  mdtm_irq *                    irq;

  try {
      // create ipc instance
      g_ipc = new MdtmIpc("mdtm");
      if(g_ipc->open(MdtmIpc::O_OPENONLY) < 0)
        return -1;

      // initialize parser
      g_parser = new MdtmParser();

      // create objects and register with parser
      g_sched = new mdtm_sched_spt(mdtm_topology_tree, g_ipc);
      g_parser->enroll(static_cast<mdtm_sched_spt *>(g_sched)->class_name_, *g_sched);

      g_cpuset = new mdtm_cpuset(g_ipc);
      g_parser->enroll(static_cast<mdtm_cpuset*>(g_cpuset)->class_name_, *g_cpuset);

      g_mem = new mdtm_mem(g_ipc);
      g_parser->enroll(static_cast<mdtm_mem*>(g_mem)->class_name_, *g_mem);

  } catch(const std::exception &e) {
      g_mdtm_opmode = MDTM_OPMODE_DEFAULT;
      mdtm_client_fini();
      std::cerr<< "An exception is caught:"<<e.what()<<std::endl;
      return -1;
  } catch(...) {
      g_mdtm_opmode = MDTM_OPMODE_DEFAULT;
      mdtm_client_fini();
      std::cerr<< "default exception."<<std::endl;
      return -1;
  }

  return 0;
}

static
void
mdtm_client_fini(void) {
  //  delete irq;
  if(g_mem) { delete g_mem; g_mem = NULL; }
  if(g_cpuset) { delete g_cpuset; g_cpuset = NULL; }
  if(g_sched) { delete g_sched; g_sched = NULL;}
  if(g_parser) { delete g_parser; g_parser = NULL; }
  if(g_ipc) {
      g_ipc->close();
      delete g_ipc;
      g_ipc = NULL;
  }
}

static
int
mdtm_default_init(void) {
  int rc = -1;
  try {
      g_sched = new mdtm_sched_spt(mdtm_topology_tree);
      rc = 0;
  } catch(const std::exception &e) {
      std::cerr<<"An exception is caught when instantiating mdtm_sched_spt:" << e.what()<<std::endl;
      g_mdtm_opmode = MDTM_OPMODE_DEFAULT;
  }
  return rc;
}

static
void
mdtm_default_fini(void) {
  //  delete irq;
  if(g_sched) { delete g_sched; g_sched = NULL; }
}

/*
 * Public Functions
 */

const char*
mdtm_show_version()
{
  if(!mdtm_version_string) {
      char* buff = (char*)malloc(128*sizeof(char));
      snprintf(buff, 128, "mdtm library version: %s\thwloc version: %x\n", MDTM_VERSION_STRING, hwloc_get_api_version());
      mdtm_version_string = buff;
  }
  return mdtm_version_string;
}

int
mdtm_poll(void) {
  return mdtm_server_poll();
}

int
mdtm_init(mdtm_optmode_t op_mode)
{
  int   rc = 0;

  if(mdtm_topology_tree)
    // return if mdtm_init is already done
    return 0;

  if(mdtm_config_init(NULL) == -1)
    return -1;

  if ((rc = mdtm_create_sys_info(&mdtm_topology_tree,&g_mdtm_config)) < 0)
    return rc;

#ifdef HAVE_LVM2APP_H
    mdtm_lvm_init();
#endif

  switch(op_mode) {
  case MDTM_OPMODE_CLIENT:
    if((rc = mdtm_client_init()) < 0) {
      rc = mdtm_default_init();
      mdtm_debug("libmdtm: mdtm_client_init rolls back to mdtm_default_init().\n");
    }
    break;
  case MDTM_OPMODE_SERVER:
    if((rc = mdtm_server_init()) < 0) {
//      rc = mdtm_default_init();
      mdtm_debug("libmdtm: mdtm_server_init() unsuccessful.\n");
    }
    break;
  case MDTM_OPMODE_DEFAULT:
  default:
    if((rc = mdtm_default_init()) < 0) {
      mdtm_debug("libmdtm: mdtm_defau_init() unsuccessful.\n");
    }
    break;
  }

  if(rc < 0) {
      mdtm_delete_sys_info(mdtm_topology_tree);
      g_mdtm_opmode = MDTM_OPMODE_UNKNOWN;
  }
  else {
      g_mdtm_opmode = (op_mode==MDTM_OPMODE_UNKNOWN)? MDTM_OPMODE_DEFAULT : op_mode;
      g_page_size = getpagesize();
  }

  return rc;
}

void
mdtm_deinit()
{
  switch(g_mdtm_opmode) {
  case MDTM_OPMODE_SERVER:
    mdtm_server_fini();
    break;
  case MDTM_OPMODE_CLIENT:
    mdtm_client_fini();
    break;
  case MDTM_OPMODE_DEFAULT:
  default:
    mdtm_default_fini();
    break;
  }

#ifdef HAVE_LVM2APP_H
  mdtm_lvm_fini();
#endif

  if(mdtm_topology_tree)
    mdtm_delete_sys_info(mdtm_topology_tree);

  return;
}

int
mdtm_zone_getmask(struct bitmask *cpus, struct bitmask *mems)
{
  if(g_mdtm_opmode != MDTM_OPMODE_CLIENT)
    return -2;

  return g_cpuset? static_cast<mdtm_cpuset *>(g_cpuset)->getmasks(cpus, mems) : -1;
}

int
mdtm_zone_setmask(struct bitmask *cpus, struct bitmask *mems)
{
  if(g_mdtm_opmode != MDTM_OPMODE_CLIENT)
    return -2;

  return g_cpuset? static_cast<mdtm_cpuset *>(g_cpuset)->setmasks(cpus, mems) : -1;
}

int
mdtm_zone_movetask(pid_t pid)
{
  if(g_mdtm_opmode != MDTM_OPMODE_CLIENT)
    return -2;

  return g_cpuset ? static_cast<mdtm_cpuset *>(g_cpuset)->movetask(pid) : -1;
}

int
mdtm_zone_migratetask(pid_t pid)
{
  if(g_mdtm_opmode != MDTM_OPMODE_CLIENT)
    return -2;

  return g_cpuset ? static_cast<mdtm_cpuset *>(g_cpuset)->migratetask(pid) : -1;
}

int
mdtm_getcpuaffinity(char* devicename, mdtm_cpuset_t **cpuset)
{
  assert(mdtm_topology_tree);
  assert(cpuset);

  const mdtm_node_t *m = mdtm_getnodebyname(
      (const mdtm_node_t *) mdtm_topology_tree, (const char*) devicename);
  if (m)
    {
      unsigned *indexes;
      int num = mdtm_online_cpuset(m, &indexes);
      struct cpu_descript_s *desc = (struct cpu_descript_s *) malloc(
          sizeof(struct cpu_descript_s) * num);
      for (int i = 0; i < num; i++)
        {
          desc[i].index = indexes[i];
          desc[i].load = 10;    //TODO: load of cpu
        }
      free(indexes);
      *cpuset = (mdtm_cpuset_t*) malloc(sizeof(mdtm_cpuset_t));
      (*cpuset)->numofcpu = num;
      (*cpuset)->cpus = desc;
      return 0;
    }
  return -1;
}


struct mdtm_FileMap *mdtm_findfilemap (const char *pathname)
{
  struct stat buf;
  int ret;
  int fd;
  int major, minor;
  int numaidx;
  char devicename[16];
  int filesegments = 1;        //TODO: hardcode

  assert(pathname != NULL);

  {
    FILE * fp ;
    std::string cmd = "/bin/df ";
    cmd += pathname;
    if((fp= popen(cmd.c_str(), "r")) == NULL) {
        // error processing and exit
    }


    std::string s="";
    while( !feof( fp ) && !ferror( fp ))
        {
            char buf[128];

//            while (fgets(buf, sizeof (buf), fp))
//              s+= buf;
            fgets(buf, sizeof (buf), fp);
            fgets(buf, sizeof (buf), fp);
            s+= buf;
            std::cerr << s <<std::endl;
            {
              std::string ss;
            std::istringstream iss(s);
            iss >> ss;
            std::cerr << ss << std::endl;
            }
            break;
        }
    pclose(fp);


  }

  fd = open (pathname, O_RDONLY);
  if (fd < 0) {perror ("open");}

  ret = fstat (fd, &buf);
  if (ret < 0) {
      perror ("fstat");
      return 0;
  }
  major = (buf.st_dev >> 8) & 0xff;
  minor = (buf.st_dev) & 0xff;

  //TODO: only support SCSI at this time
  assert(major == 8);
  switch(major) {
  case 8:
    snprintf(devicename, 16, "sd%c",'a'+minor%16);
    break;
  default:
    break;
  }

  numaidx = mdtm_getnumaaffinity(mdtm_topology_tree, devicename);

  std::cerr << "file name: " << pathname << " located on " << devicename << " major=" << major << " minor=" << minor << " Numa index=" << numaidx << std::endl;

  struct mdtm_FileMap *map = (struct mdtm_FileMap *)malloc(sizeof(struct mdtm_FileMap) + filesegments * (sizeof(mdtm_FileSeg_t) + sizeof(struct mdtm_io_s)));
  map->pathname = strdup(pathname);
  map->seg_num = filesegments;     //TODO: hardcoded
  map->fileseg = (mdtm_FileSeg_t*)((char*)map + sizeof(struct mdtm_FileMap));
  map->fileseg->local_node = numaidx;
  map->fileseg->offset = 0;     //TODO: hardcoded
  map->fileseg->size = buf.st_size;
  map->fileseg->storage_dev = (struct mdtm_io_s*)((char*)map->fileseg + sizeof(mdtm_FileSeg_t));
  map->fileseg->storage_dev->devicenumber = buf.st_dev;

  return map;
}

void
mdtm_printpath(char* srcdev, char* dstdev, void *tree)
{
  mdtm_node_t * t = (mdtm_node_t*)tree;
  if(!tree) {
      t = mdtm_topology_tree;
  }
  assert(t);

//  mdtm_sched_spt *g_sched = new mdtm_sched_spt(t);
  g_sched->mdtm_print_path(srcdev, dstdev);
  return;
}

void
mdtm_printschedresult(char* srcdev, char* dstdev, void *tree)
{
  mdtm_node_t * t = (mdtm_node_t*)tree;
  if(!tree) {
      t = mdtm_topology_tree;
  }
  assert(t);

//  mdtm_sched_spt *g_sched = new mdtm_sched_spt(t);

  if(g_sched->mdtm_sched_cpu(srcdev, dstdev) < 0)
    mdtm_debug("Failed ---Invaid Parameter");

  return;
}

static
int
mdtm_place_per_single_device(mdtm_thread_desc_t* desc, int targetcpu) {
    int cpu = -1;

    if(desc == NULL)
        return -1;

    switch(g_mdtm_opmode) {
    case MDTM_OPMODE_CLIENT:
        // TODO: client mode

//        if(desc->flags & MDTM_CPUBIND_PROC) {
//            if( (cpu = g_sched->mdtm_sched_cpu_r(desc->devices[0], desc->id.pid)) < 0)
//                mdtm_debug("libmdtm: %s Failed ---Invaid Parameter",__FUNCTION__);
//        }
//        else if(desc->flags & MDTM_CPUBIND_THREAD){
//            if((cpu = g_sched->mdtm_sched_cpu_r(desc->devices[0], desc->id.tid)) < 0)
//                mdtm_debug("%s Failed ---Invaid Parameter",__FUNCTION__);
//        }
//        else {
//            mdtm_debug("libmdtm: %s Failed ---Invaid Parameter",__FUNCTION__);
//        }

        mdtm_debug("libmdtm @%s: the client mode is not implemented.",__FUNCTION__);
        break;
    case MDTM_OPMODE_SERVER:
    case MDTM_OPMODE_DEFAULT:
    default:
        if(desc->flags & MDTM_CPUBIND_PROC) {
            if( (cpu = g_sched->mdtm_place_cpu(targetcpu, desc->id.pid)) < 0)
                mdtm_debug("libmdtm: %s failed place pid %llu on cpu %d",__FUNCTION__, desc->id.pid, targetcpu);
        }
        else if(desc->flags & MDTM_CPUBIND_THREAD){
            if((cpu = g_sched->mdtm_place_cpu(targetcpu, desc->id.tid)) < 0)
                mdtm_debug("libmdtm: %s failed place tid %llu on cpu %d",__FUNCTION__, desc->id.tid, targetcpu);
        }
        else {
            mdtm_debug("libmdtm: %s failed: Invaid Parameter",__FUNCTION__);
        }
        break;
    }
    desc->boundcpu = cpu;
    desc->numaindex = -1;     // TODO: find the numa node index for target cpu

    return cpu;
}

int
mdtm_sched_per_single_device(mdtm_thread_desc_t* desc, void *tree) {
  int cpu = -1;
  mdtm_node_t * t = (mdtm_node_t*)tree;

  if(!desc || !tree)
    return -1;

  if(!tree) {
      t = mdtm_topology_tree;
  }
  assert(t);

//  mdtm_sched_spt *g_sched = new mdtm_sched_spt(t);
#if 0
  if(desc->numaindex >= 0) {
      // schedule on NUMA index
      if(desc->flags & MDTM_CPUBIND_PROC) {
          if(g_sched->mdtm_sched_cpu(desc->numaindex, desc->pid) < 0)
            std::cout<< "Failed ---Invaid Parameter"<<std::endl;
      }
      else {
          if(g_sched->mdtm_sched_cpu(desc->numaindex, desc->tid) < 0)
            std::cout<< "Failed ---Invaid Parameter"<<std::endl;
      }
  }
  else
#endif 
  {
      // schedule on device name
      //TODO: chedk the valid thread or proc
      switch(g_mdtm_opmode) {
      case MDTM_OPMODE_CLIENT:
        if(desc->flags & MDTM_CPUBIND_PROC) {
            if( (cpu = g_sched->mdtm_sched_cpu_r(desc->devices[0], desc->id.pid)) < 0)
              mdtm_debug("%s Failed ---Invaid Parameter",__FUNCTION__);
        }
        else if(desc->flags & MDTM_CPUBIND_THREAD){
            if((cpu = g_sched->mdtm_sched_cpu_r(desc->devices[0], desc->id.tid)) < 0)
              mdtm_debug("%s Failed ---Invaid Parameter",__FUNCTION__);
        }
        else {
            mdtm_debug("%s Failed ---Invaid Parameter",__FUNCTION__);
        }
        break;
      case MDTM_OPMODE_SERVER:
      case MDTM_OPMODE_DEFAULT:
      default:
        if(desc->flags & MDTM_CPUBIND_PROC) {
            if( (cpu = g_sched->mdtm_sched_cpu(desc->devices[0], desc->id.pid)) < 0)
              mdtm_debug("%s Failed ---Invaid Parameter",__FUNCTION__);
        }
        else if(desc->flags & MDTM_CPUBIND_THREAD){
            if((cpu = g_sched->mdtm_sched_cpu(desc->devices[0], desc->id.tid)) < 0)
              mdtm_debug("%s Failed ---Invaid Parameter",__FUNCTION__);
        }
        else {
            mdtm_debug("%s Failed ---Invaid Parameter",__FUNCTION__);
        }
        break;
      }
      desc->boundcpu = cpu;
      desc->numaindex = mdtm_getnumaaffinity(mdtm_topology_tree, desc->devices[0]);
  }

  return cpu;
}

int
mdtm_sched_per_single_device_on_numa(mdtm_thread_desc_t* desc, int numa) {
  int cpu = -1;

  if(desc->flags & MDTM_CPUBIND_PROC) {
      if((cpu = g_sched->mdtm_sched_cpu_on_numa(desc->devices[0], desc->id.pid, numa)) < 0)
        mdtm_debug("[libmdtm] %s failed: mdtm_sched_cpu_on_numa %d.\n",__FUNCTION__, numa);
      else
        desc->boundcpu = cpu;
  }
  else if (desc->flags & MDTM_CPUBIND_THREAD){
      if((cpu = g_sched->mdtm_sched_cpu_on_numa(desc->devices[0], desc->id.tid, numa)) < 0)
        mdtm_debug("[libmdtm] %s failed: mdtm_sched_cpu_on_numa %d.\n",__FUNCTION__, numa);
      else
        desc->boundcpu = cpu;
  }
  else
    mdtm_debug("[libmdtm] %s failed: invaid parameter %x\n",__FUNCTION__, desc->flags);

  return cpu;
}

int
mdtm_schedule_threads(mdtm_thread_desc_t *thread_descs, int numofdescs)
{
  int i;
  char* dev;

  if(!mdtm_topology_tree) {
	  mdtm_debug("[libmdtm] %s: error: mdtm_topology_tree is null.\n");
	  return -1;
  }

  for (i = 0; i < numofdescs; i++) {
      if((dev = thread_descs[i].devices[0])) {
          const mdtm_node_t *m = mdtm_getdevicenodebyname((const char*) dev);
          if (m && (mdtm_device_isconfig(m) == false)){
              //schedule the thread if hosting device is in the topology tree
        	  if(mdtm_sched_per_single_device(&thread_descs[i], mdtm_topology_tree) < 0)
        		  return -1;
          }
          else if(m){
              //schedule the thread if hosting device is manually file configured
              if(mdtm_sched_per_single_device_on_numa(&thread_descs[i], m->ref_numaid) < 0)
            	  return -1;
              thread_descs[i].numaindex = m->ref_numaid;
          }
          else {
              // reprot error is the device not found
              mdtm_debug("%s: Warning: device not found.\n", dev);
              continue;
          }
          mdtm_debug ( "%s: device=%s\tcpu=%d\n",__FUNCTION__, dev,  thread_descs[i].boundcpu);
      }
      else if(thread_descs[i].devices[1]){
      }
      else
        continue;
  }
  return 0;
}

/*
 * place threads to the given set of cpus
 */
int
mdtm_place_threads(mdtm_thread_desc_t *thread_descs, int numofdescs, int *cpus, int numofcpus)
{
  int i;
  char* dev;

  if(!thread_descs || !cpus) {
      mdtm_debug("[libmdtm] %s: error: invalid arguments.\n", __FUNCTION__);
      return -1;
  }

  for (i = 0; i < numofdescs; i++) {
      if((dev = thread_descs[i].devices[0])) {
          const mdtm_node_t *m = mdtm_getdevicenodebyname((const char*) dev);
          if (m && (mdtm_device_isconfig(m) == false))
          {
              //place the thread if hosting device is in the topology tree
              if(mdtm_place_per_single_device(&thread_descs[i], cpus[i]) < 0)
              {
                  mdtm_debug("libmdtm: @%s Error: thread of device %s not placed on cpu %d.\n", __FUNCTION__, dev, cpus[i]);
                  return -1;
              }
          }
          else if(m)
          {
              //place the thread if hosting device is manually file configured
              if(mdtm_place_per_single_device(&thread_descs[i], cpus[i]) < 0)
              {
                  mdtm_debug("libmdtm: @%s Error: thread of device %s not placed on cpu %d.\n", __FUNCTION__, dev, cpus[i]);
                  return -1;
              }
//              thread_descs[i].numaindex = m->ref_numaid;
          }
          else
          {
              // reprot error is the device not found
              mdtm_debug("libmdtm: %s: Warning: device %s not found.\n", __FUNCTION__, dev);
              continue;
          }
          mdtm_debug ( "libmdtm: %s: device=%s\tcpu=%d\n",__FUNCTION__, dev,  thread_descs[i].boundcpu);
      }
      else if(thread_descs[i].devices[1]) {
          mdtm_debug ( "libmdtm: %s: not implemented for secondary device.\n",__FUNCTION__);
      }
      else
      {
          mdtm_debug ( "libmdtm: %s: no valid device for the IO thread.\n",__FUNCTION__);
          continue;
      }
  }
  return 0;
}

int
mdtm_getpcidevices(struct mdtm_device_s** devices)
{
  return mdtm_getdevicesbytype(mdtm_topology_tree, 0, devices);
}

int
mdtm_numa_nodes(void)
{
  return numa_num_configured_nodes();
}

#if 0

static
void*
mdtm_thread_alloc_pipe ( void *ptr )
{
  pipe_thread_data_t *data = (pipe_thread_data_t *)ptr;
  int i, rc;
  cpu_set_t cpuset;
  int cpuId = data->cpu;
  pthread_t threadid;

  //bind the current thread to the core
  CPU_ZERO(&cpuset);
  CPU_SET(cpuId, &cpuset);
  threadid = pthread_self();
  if ( pthread_setaffinity_np(threadid, sizeof(cpu_set_t), &cpuset) == -1 ) {
      switch ( errno ) {
      case EPERM: mdtm_debug ( "Error: Insufficient permission.\n" ); break;
      case EFAULT: mdtm_debug ( "Error: Invalid memory address.\n" ); break;
      case ESRCH: mdtm_debug ( "Error: Invalid process ID\n" ); break;
      case EINVAL: mdtm_debug ( "Error: Invalid arguments\n" ); break;
      }
  }

  rc = pthread_getaffinity_np(threadid, sizeof(cpu_set_t), &cpuset);
  assert(rc == 0);

//  for (i = 0; i < CPU_SETSIZE; i++)
//    if (CPU_ISSET(i, &cpuset))
//      mdtm_debug("Thread %u: target to CPU %d, bind to    CPU %d\n", threadid, cpuId, i);

  // create pipes
//  data->pipes = (mdtm_pipefd_t*)malloc(sizeof(mdtm_pipefd_t) * data->group_count);
  for(i = 0; i < data->group_count; i++) {
      rc = pipe2(data->pipes[i].pipefd, O_DIRECT);
      if(rc < 0) break;
      rc = fcntl(data->pipes[i].pipefd[1], F_SETPIPE_SZ, data->pipesize);
      if(rc < 0) break;
  }
  if(rc < 0) {
      mdtm_debug("libmdtm: Pipe creation failed: %s @%s:%s\n",strerror(errno), __FILE__,__FUNCTION__);
      return NULL;
  }

  //set buffer size
#ifdef GLIBC_NEW
  for (i = 0; i < data->group_count; i++) {
      fcntl(data->pipes[i].pipefd[0], F_SETPIPE_SZ, pipesize);
      fcntl(data->pipes[i].pipefd[1], F_SETPIPE_SZ, pipesize);
  }
#endif

  data->result = true;

  return NULL;
}

/* \brief Create a pipe pool on each NUMA node.
 *
 * group_count: the size of pipepool to be created on each NUMA node
 * pipesize:    the size of pipe buffer
 */
int
mdtm_pipe_init(int group_count, size_t pipesize)
{
  int rc, i, nNumas = 0, num_numa_nodes = 0;
  mdtm_node_t** numa_nodes;
  pthread_t threadids[MDTM_DEFAULT_NUMAS], *p_threadids = threadids;         /* thread variables */
  pipe_thread_data_t data[MDTM_DEFAULT_NUMAS], *p_data = data;
  bool      default_threadids_data = true;
  /* structs to be passed to threads */
  unsigned *cpus = 0;

  global_group_count = group_count;

  if(!mdtm_topology_tree) {
    return -1;
  }

  if(g_mdtm_pipe_pools)
    //already existing
    return 0;

  //get info about NUMA nodes
  if((nNumas = mdtm_numa_nodes()) <= 0 ||
      (numa_nodes = (mdtm_node_t **)calloc(nNumas, sizeof(mdtm_node_t*))) == NULL ||
      (mdtm_getnodesbytype(mdtm_topology_tree, "NUMANode", numa_nodes, &num_numa_nodes) != 0) ||
      (num_numa_nodes != nNumas))
  {
      if(numa_nodes) free(numa_nodes);
      return -1;
  }

  if(nNumas > MDTM_DEFAULT_NUMAS) {
      if((p_threadids = (pthread_t*)calloc(nNumas, sizeof(pthread_t))) == 0 ||
         (p_data = (pipe_thread_data_t*)calloc(nNumas, sizeof(pipe_thread_data_t))) == 0)
        {
          if(numa_nodes) free(numa_nodes);
          return -1;
        }
      default_threadids_data = false;
  }

  // create a pipe pool for each NUMA node
  g_mdtm_pipe_pools = (mdtm_pipe_pool_t*)calloc(nNumas, sizeof(mdtm_pipe_pool_t));
  if(g_mdtm_pipe_pools ==NULL)
    return -1;

  for(i = 0; i < nNumas; i++) {
      g_mdtm_pipe_pools[i].pipes =
          (mdtm_pipefd_t*)calloc(group_count, sizeof(mdtm_pipefd_t));

      if((g_mdtm_pipe_pools[i].pipes == NULL) ||
         (pthread_mutex_init(&g_mdtm_pipe_pools[i].lock, NULL) != 0) ||
         (mdtm_online_cpuset(numa_nodes[i], &cpus) <= 0))
        break;

      g_mdtm_pipe_pools[i].total = group_count;
      g_mdtm_pipe_pools[i].used = 0;

      p_data[i].result = false;
      p_data[i].numa_id = i;
      p_data[i].pipes =  g_mdtm_pipe_pools[i].pipes;
      p_data[i].group_count = group_count;
      p_data[i].numanode = numa_nodes[i];
      p_data[i].cpu = cpus[0];
      p_data[i].pipesize = pipesize;
  }

  if(i <  nNumas) {
      // if failed, then clean up
      if(cpus)
        free(cpus);

      for(; i >= 0; i--) {
          if(g_mdtm_pipe_pools[i].pipes)
            free(g_mdtm_pipe_pools[i].pipes);
          pthread_mutex_destroy(&g_mdtm_pipe_pools[i].lock);
      }

      if(g_mdtm_pipe_pools) {
        free(g_mdtm_pipe_pools);
        g_mdtm_pipe_pools = NULL;
      }

      if(numa_nodes)
        free(numa_nodes);

      return -1;
  }

  //create pipes on each NUMA node
  for(i = 0; i < nNumas; i++) {
      rc = pthread_create(&p_threadids[i], NULL, mdtm_thread_alloc_pipe, (void *) &p_data[i]);
      if(rc != 0)
          break;
  }
  for(; i > 0 ; i--)
    pthread_join(p_threadids[i-1], NULL);

  if(default_threadids_data == false) {
      free(p_threadids);
      free(p_data);
  }

  // check the results of pipes creating
  for(i = 0; i < nNumas && p_data[i].result==true; i++);

  if(i < nNumas) {
      // if failed, clean up
      mdtm_pipe_destroy();
      return -1;
  }

  return 0;
}

int
mdtm_pipe_destroy()
{
  int i, j;

  if(g_mdtm_pipe_pools) {
      for(i = 0; i < mdtm_numa_nodes(); i++) {
          pthread_mutex_lock(&g_mdtm_pipe_pools[i].lock);
          for(j = 0; j < g_mdtm_pipe_pools[i].total; j++) {
              close(g_mdtm_pipe_pools[i].pipes[j].pipefd[0]);
              close(g_mdtm_pipe_pools[i].pipes[j].pipefd[1]);
          }
          free(g_mdtm_pipe_pools[i].pipes);
          pthread_mutex_unlock(&g_mdtm_pipe_pools[i].lock);
      }
      free(g_mdtm_pipe_pools);
      g_mdtm_pipe_pools = NULL;
  }
  return 0;
}

int
mdtm_pipe_get(int numa,  unsigned int ask, void** arg)
{
  mdtm_pipefd_t** pipes = (mdtm_pipefd_t**)arg;
  int available = 0, allocated = 0;

  assert(g_mdtm_pipe_pools);

  //TODO: add mutex

  *pipes = g_mdtm_pipe_pools[numa].pipes + g_mdtm_pipe_pools[numa].used;
  available = g_mdtm_pipe_pools[numa].total - g_mdtm_pipe_pools[numa].used;
  allocated = (ask < available)? ask : available;
  g_mdtm_pipe_pools[numa].used += allocated;
  return allocated;
}

int
mdtm_pipe_drain(int pipefd, int size, int flag)
{
  static int fd = 0;
  int rc;

  if(flag & MDTM_PIPEDRAIN_CLOSE) {
    if(!fd) close(fd);
    return 0;
  }

  if(!fd)
    fd = open("/dev/null", O_WRONLY);

  rc = splice(pipefd, NULL,
      fd, NULL,
      (size_t)size,
      SPLICE_F_MOVE|SPLICE_F_MORE);

  return rc;
}

int
mdtm_pipe_check(void *p) {
  mdtm_pipefd_t *       mpipe = (mdtm_pipefd_t*) p;
  return (mpipe && mpipe->pipefd[0] && mpipe->pipefd[1])? 0 : -1;
}
#else


/* \brief Create a pipe pool on each NUMA node.
 *
 * group_count: the size of pipepool to be created on each NUMA node
 * pipesize:    the size of pipe buffer
 */
int
mdtm_pipe_init(int group_count, size_t pipesize)
{
  int rc, i, nNumas = 0, num_numa_nodes = 0;
  mdtm_node_t** numa_nodes = NULL;

  if(g_mdtm_pipe_initialized)
    //already existing
    return 0;

  if(!mdtm_topology_tree)
      return -1;

  //get info about NUMA nodes
  if((nNumas = mdtm_numa_nodes()) <= 0 ||
      (numa_nodes = (mdtm_node_t **)calloc(nNumas, sizeof(mdtm_node_t*))) == NULL ||
      (mdtm_getnodesbytype(mdtm_topology_tree, "NUMANode", numa_nodes, &num_numa_nodes) != 0) ||
      (num_numa_nodes != nNumas))
  {
      if(numa_nodes) free(numa_nodes);
      return -1;
  }

  rc = mdtm_pipe_init2(group_count, pipesize, nNumas, numa_nodes);
  if ( rc >= 0 )
    g_mdtm_pipe_initialized = 1;

  if(numa_nodes)
    free(numa_nodes);

  return rc;
}

/* \brief Check if mdtm module is initialized
 *
 * Note: It is not safe to call from different threads
 */
int
mdtm_is_inited(void)
{
  return mdtm_topology_tree != 0;
}

/* \brief Get a pipe from the pipe pool for the specific NUMA node.
 *
 * numa:        the NUMA index of whitch the pipe pool to be used
 * size:        not used
 * pipe:        pointer to the pipes returned
 */
void *
mdtm_pipe_get(int numa,  unsigned int size, void **pipe)
{
  return mdtm_pipe_get2(numa, size, pipe);
}

/* \brief Put a pipe to the pipe pool for the specifi NUMA node.
 *
 * numa:        the NUMA index of whitch the pipe pool to be used
 * pipe:        pointer to the pipes returned
 */
int
mdtm_pipe_put(int numa, void* pipe)
{
  return mdtm_pipe_put2(numa, pipe);
}

int
mdtm_pipe_allocated(int numa)
{
	return mdtm_pipe_allocated2(numa);
}

#endif

//struct globus_memory_s
//{
//    int                                         total_size;
//    int                                         node_size;
//    int                                         nodes_used;
//    int                                         node_count;
//    int                                         node_count_per_malloc;
//
//    globus_bool_t                               destroyed;
//    globus_mutex_t                              lock;
//
//    globus_byte_t *                             first;
//    globus_byte_t **                            free_ptrs;
//    int                                         free_ptrs_size;
//    int                                         free_ptrs_offset;
//};
//
//int
//mdtm_local_memory_init(
//    void* mem_info,
//    int node_size,
//    int node_count,
//    mdtm_location_ref_t *loc_ref,
//    int ref_num)
//{
//  &monitor->mem, block_size, optimal_count, loc_ref, sizeof(loc_ref)/sizeof(mdtm_location_ref_t))
//}



/* Return PTR, aligned upward to the next multiple of ALIGNMENT.
   ALIGNMENT must be nonzero.  The caller must arrange for ((char *)
   PTR) through ((char *) PTR + ALIGNMENT - 1) to be addressable
   locations.  */
static inline void *
ptr_align (void const *ptr, size_t alignment)
{
  char const *p0 = (char*)ptr;
  char const *p1 = (char*)(p0 + alignment - 1);
  return (void *) (p1 - (size_t) p1 % alignment);
}

static void*
alloc_ibuf (size_t input_blocksize)
{
  void *ibuf;
  char *real_buf = (char*)malloc (input_blocksize + INPUT_BLOCK_SLOP);
  if (!real_buf)
//    error (EXIT_FAILURE, 0,
//           _("memory exhausted by input buffer of size %zu bytes (%s)"),
//           input_blocksize, human_size (input_blocksize));
    return 0;

  real_buf += SWAB_ALIGN_OFFSET;        /* allow space for swab */

  ibuf = ptr_align (real_buf, g_page_size);
  return ibuf;
}

/* \brief allocate memory on specified numa RAM
 *
 */
static void*
mdtm_thread_alloc_mem ( void *ptr )
{
  mem_thread_data_t *data = (mem_thread_data_t *)ptr;
  cpu_set_t cpuset;
  int cpuId = data->cpu;
  pthread_t threadid;
  char *anon;
  size_t size;
  int i, rc;

  //bind the current thread to the given cpu core
  CPU_ZERO(&cpuset);
  CPU_SET(cpuId, &cpuset);
  threadid = pthread_self();
  if ( pthread_setaffinity_np(threadid, sizeof(cpu_set_t), &cpuset) == -1 ) {
      mdtm_debug("Binding thread to CPU failed.\n");
      switch ( errno ) {
      case EPERM: mdtm_debug ( "Error: Insufficient permission.\n" ); break;
      case EFAULT: mdtm_debug ( "Error: Invalid memory address.\n" ); break;
      case ESRCH: mdtm_debug ( "Error: Invalid process ID\n" ); break;
      case EINVAL: mdtm_debug ( "Error: Invalid arguments\n" ); break;
      }
      data->result = -1;
      return NULL;
  }

  // allocate and pin memory
  size = data->size;

#ifdef MEMORY_MMAP
  anon = (char*)mmap(NULL, size, PROT_READ|PROT_WRITE, MAP_ANON|MAP_SHARED, -1, 0);
  if (anon == MAP_FAILED) {
    data->result = -2;
    mdtm_debug("mmap failed: %s. size=%d\n", strerror(errno),size);
    return NULL;
  }

  if (mlock((void*)anon, size) < 0) {
      data->result = -3;
      mdtm_debug("mlock failed: %s.\n", strerror(errno));
      munmap((void*)anon, size);
      return NULL;
  }

  //write dummy value to each page to assure reserve physical memory
  //ref:http://www.informit.com/articles/article.aspx?p=23618&seqNum=9
  {
    size_t i;
    size_t g_page_size = getpagesize ();
    for (i = 0; i < size; i += g_page_size)
      anon[i] = 0;
  }
#endif

#ifdef MEMORY_MEMALIGN
  {
    size_t alignment = 4096;

    anon = (char*)memalign(alignment * 2, size + alignment);
    if (anon == NULL) {
      data->result = -2;
      mdtm_debug("memalign failed: %s. size=%d\n", strerror(errno), size);
      return NULL;
    }

    if (mlock((void*)anon, size) < 0) {
        data->result = -3;
        mdtm_debug("mlock failed: %s.\n", strerror(errno));
        free((void*)anon);
        return NULL;
    }

    //write dummy value to each page to assure reserve physical memory
    //ref:http://www.informit.com/articles/article.aspx?p=23618&seqNum=9
    {
      size_t i;
      size_t g_page_size = getpagesize ();
      for (i = 0; i < size; i += g_page_size)
        anon[i] = 0;
    }
    mdtm_debug("DBG@%s:%d: MEMALIGN succeed!\n", __FILE__, __LINE__);
  }
#endif

#ifdef MEMORY_MEMALIGN_BIND
  {
    size_t alignment = 4096;

    // allocate aligned memory
    rc = posix_memalign((void **)&anon, alignment * 2, size + alignment);
    if (rc != 0) {
      data->result = -2;
      mdtm_debug("posix_memalign failed to allocate %d bytes: return=%d\n", size, rc);
      return NULL;
    }

    // gurantee the page containing that memory stay in the RAM
    if (mlock((void*)anon, size) < 0) {
        data->result = -3;
        mdtm_debug("mlock failed: %s. Please run with sudo privileges.\n", strerror(errno));
        free((void*)anon);
        return NULL;
    }

    // bind memory
    {
#define MAXNODE 4096

      int ret;
      int len;
      int policy = -1;
      char *p;
      unsigned long mask[MAXNODE] = { 0 };
      unsigned long retmask[MAXNODE] = { 0 };

      p = anon;
      len = size;
      mask[0] = 1<<data->numa_id;
//      mdtm_debug("DBG@%s:%d: numa_id=%d!\n", __FILE__, __LINE__,data->numa_id);
      ret = mbind(p, len, MPOL_BIND, mask, MAXNODE, 0);
      if (ret < 0)
    	  mdtm_debug("mbind err: %d %s\n", ret, strerror(errno));
      ret = get_mempolicy(&policy, retmask, MAXNODE, p, MPOL_F_ADDR);
      if (ret < 0)
    	  mdtm_debug("get_mempolicy err: %d %d\n", ret, errno);

//      if (policy == MPOL_BIND)
//        mdtm_debug("DBG@%s:%d: MBIND succeed!\n", __FILE__, __LINE__);
//      else
//        printf("ERROR: policy is %d\n", policy);
    }

    //write dummy value to each page to assure reserve physical memory
    //ref:http://www.informit.com/articles/article.aspx?p=23618&seqNum=9
    {
      size_t i;
      size_t g_page_size = getpagesize ();
      for (i = 0; i < size; i += g_page_size)
        anon[i] = 0;
    }
  }
#endif

#ifdef MEMORY_MALLOC
  {
    anon = (char*)alloc_ibuf(size);
    if(!anon)
      mdtm_debug("DBG@%s:%d: MALLOC Failed!\n", __FILE__, __LINE__);
    else
      mdtm_debug("DBG@%s:%d: MALLOC succeed!\n", __FILE__, __LINE__);

  }
#endif

  data->mem = (void*)anon;
  data->result = 0;

  return NULL;
}

/* \brief
 * Allocate location aware memory
 * numa:        numa node index
 * size:        size of memory to allocate
 * On success this function return the address. On error, NULL is returned.
 */
void*
mdtm_loc_malloc(unsigned numa, size_t size)
{
  int i;
  pthread_t threadid;
  mem_thread_data_t data;         /* structs to be passed to threads */
  unsigned *cpus;
  mdtm_node_t **numa_nodes, *target;
  int num_numa_nodes = 0;
  int numa_opt;

  if(!mdtm_topology_tree) {
    return NULL;
  }

  // find the numa node
  if((numa_opt = static_cast<mdtm_mem *>(g_mem)->getoptnode(getpid())) < 0)
    numa_opt = numa;

  if(numa_opt < 0)
    return malloc(size);

  if((numa_nodes = (mdtm_node_t **)malloc(sizeof(mdtm_node_t*)*16)) == NULL)
      return NULL;
  mdtm_getnodesbytype(mdtm_topology_tree, "NUMANode", numa_nodes, &num_numa_nodes);
  for(i = 0; i < num_numa_nodes; i++) {
      if(numa_nodes[i]->logical_index == numa_opt)
        break;
  }
  if(i < num_numa_nodes)
    target = numa_nodes[i];
  else {
      // numa node not found
      free(numa_nodes);
      return NULL;
  }

  // find 1st online cpu on numa node
  if(mdtm_online_cpuset(target, &cpus) <= 0) {
      free(numa_nodes);
      return NULL;
  }
  data.cpu = cpus[0]; free(cpus);
  data.size = size;

  // allocate memory locked on numa RAM
  pthread_create(&threadid, NULL, mdtm_thread_alloc_mem, (void *) &data);
  pthread_join(threadid, NULL);

  return (data.result == 0)?data.mem : NULL;
}

/* \brief
 * Allocate location aware memory. version 2
 * numa:        numa node index
 * addr:        pointer to the memory address
 * size:        size of memory to allocate
 * On success this function return 0. On error, -1 is returned.
 */
int
mdtm_loc_malloc2(unsigned numa, void** addr, size_t size)
{
  int i;
  pthread_t threadid;
  mem_thread_data_t data;         /* structs to be passed to threads */
  unsigned *cpus;
  mdtm_node_t **numa_nodes, *target;
  int num_numa_nodes=0;
  int numa_opt;

  if(!addr)
    return -1;

  if(!mdtm_topology_tree) {
      return -1;
  }

  if(!g_mem ||
     (numa_opt = static_cast<mdtm_mem *>(g_mem)->getoptnode(getpid())) < 0)
    numa_opt = numa;

  if(numa_opt < 0) {
      *addr = malloc(size);
      return *addr ? 0 : -1;
  }

  // find the numa node
  if((numa_nodes = (mdtm_node_t **)malloc(sizeof(mdtm_node_t*)*16)) == NULL)
    return -1;
  mdtm_getnodesbytype(mdtm_topology_tree, "NUMANode", numa_nodes, &num_numa_nodes);
  for(i = 0; i < num_numa_nodes; i++) {
      if(numa_nodes[i]->logical_index == numa_opt)
        break;
  }
  if(i < num_numa_nodes)
    target = numa_nodes[i];
  else {
      // numa node not found
      free(numa_nodes);
      return -1;
  }

  // find 1st online cpu on numa node
  if(mdtm_online_cpuset(target, &cpus) <= 0) {
      free(numa_nodes);
      return -1;
  }
  data.cpu = cpus[0];
  data.size = size;
  data.numa_id = numa_opt;
  free(cpus);
  free(numa_nodes);

  // allocate memory locked on numa RAM
  pthread_create(&threadid, NULL, mdtm_thread_alloc_mem, (void *) &data);
  pthread_join(threadid, NULL);
  *addr = data.mem;
  return data.result;
}


/* \brief
 * release location aware memory
 */
void
mdtm_loc_mfree(void* mem, int size)
{
  munlock(mem, size);
  munmap(mem, size);
}

long long
mdtm_numa_nodesize(int node, long long* free)
{
  return numa_node_size64(node, free);
}

int
mdtm_cpuset_get(struct bitmask *cpus, struct bitmask *mems)
{
  if(g_mdtm_opmode == MDTM_OPMODE_CLIENT) {

  }
  return 0;
}
int
mdtm_cpuset_set(struct bitmask *cpus, struct bitmask *mems)
{
  if(g_mdtm_opmode == MDTM_OPMODE_CLIENT) {

  }
  return 0;
}
int
mdtm_cpuset_getpids(const struct cpuset_pidlist *pl)
{
  if(g_mdtm_opmode == MDTM_OPMODE_CLIENT) {

  }
  return 0;
}
int
mdtm_cpuset_addpid(pid_t pid)
{
  if(g_mdtm_opmode == MDTM_OPMODE_CLIENT) {

  }
  return 0;
}

/**
 * Return the nominal name of the device
 *
 * \param inputname     device name, e.g. /dev/sda1
 *
 * \return              the nominal, e.g sda
 */
static
char*
mdtm_nominal_devname(const char* inputname) {
  int len, i, found;
  char *tmp, *in, *out;

  // find the basename from the inputname
  in = strdup(inputname);
  tmp = strrchr(in, '/');
  if(tmp == NULL)
    return tmp;
  tmp += 1;
  len = strlen(tmp);
  for(i = 0; i < len; i++) {
      if((tmp[i] >= '0' && tmp[i] <= '9') ||
          (tmp[i] >= 'A' && tmp[i] <= 'Z') ||
          (tmp[i] >= 'a' && tmp[i] <= 'z'))
        continue;
      else {
          tmp[i] = '\0';
          break;
      }
  }

  // parse the devname based on types
  found = 0;
  if(!found && !strncmp(tmp, "md", 2))
    // md: devname in form of md[n]
    found = 1;

  if(!found && !strncmp(tmp, "sd", 2)) {
    // sd: sda1 => sda
    for(--i; i >= 0; i--) {
        if(tmp[i] >= '0' && tmp[i] <= '9') {
            tmp[i] = '\0';
            continue;
        }
        else
          break;
    }
    found = 1;
  }

  if(!found && !strncmp(tmp, "nvme", 4)) {
    // nvme: nvme0n1p1 => nvme0n1
    for(--i; i >= 0; i--) {
        if(tmp[i] == 'p' || tmp[i] == 'P') {
            tmp[i] = '\0';
            break;
        }
    }
    found = 1;
  }

  if(!found) {
      // default: remove the trailing digital numbers
      for(--i; i >= 0; i--) {
          if(tmp[i] >= '0' && tmp[i] <= '9') {
              tmp[i] = '\0';
              continue;
          }
          else
            break;
      }
  }

  out = strdup(tmp);
  free(in);
  return out;
}

static
int
mdtm_lvm_parse(
    const char*         fs,
    mdtm_lv_seg_t**     segments,
    const char*         pathname)
{
  char *              lv_name;
  mdtm_fileext_t *    fileexts;
  int                 nfileexts;
  mdtm_lv_seg_t *     allsegs;
  int                 allsegs_count = 0, allsegs_max = 16;
  int                 i, j, nsegs;

#ifndef HAVE_LVM2APP_H
      // Oops, does not have access to LVM, return failure.
  	  mdtm_debug("libmdtm: error: mdtm_lvm_parse() cannot proceed. "
  			  "Check if lvm package is installed.\n");
      return MDTM_ERR_NOTSUPPORT;
#endif

  // get its full name in format of vgxx-lvxx
  lv_name = mdtm_lvm_getlvname(fs);
  if(lv_name == NULL) {
  	  mdtm_debug("libmdtm: error: mdtm_lvm_getlvname() failed duo to memory.\n");
      return MDTM_ERR_NOMEM;
  }

  // get the file extents
  if((nfileexts = mdtm_filefrag_get(pathname, &fileexts)) <= 0) {
	  if (nfileexts < 0) {
		  // if no extents from mdtm_filefrag_get(), estimate one
		  mdtm_lv_seg_t *segs = NULL;
		  nsegs = mdtm_lvm_get_physical_devices(
				  lv_name,
				  0,1000,	// estimated range
				  &segs);
		  if (nsegs > 0) {
			  if((allsegs = (mdtm_lv_seg_t*)calloc(allsegs_max, sizeof(*allsegs))) == NULL) {
				  free(lv_name);
				  return MDTM_ERR_NOMEM;
			  }
			  allsegs[0].m_start = 0;
			  allsegs[0].m_end = 1000;
			  allsegs[0].dev = mdtm_nominal_devname(segs[0].dev);
			  *segments = allsegs;
			  nfileexts = 1;
		  }
	  }
	  free(lv_name);
	  return (nfileexts >= 0)? nfileexts : MDTM_ERR_NOEXTENT;
  }

  // find the physical device each file extent locates
  if((allsegs = (mdtm_lv_seg_t*)calloc(allsegs_max, sizeof(*allsegs))) == NULL) {
      free(fileexts);
      return MDTM_ERR_NOMEM;
  }

  for(i = 0; i < nfileexts; i++) {
      mdtm_lv_seg_t *segs = NULL;
      nsegs = mdtm_lvm_get_physical_devices(
          lv_name,
          fileexts[i].start, fileexts[i].end,
          &segs);
      if(nsegs < 0) {
          allsegs_count = -1;
          break;
      }

      if((allsegs_max - allsegs_count) < nsegs) {
          do {
              allsegs_max = allsegs_max << 1;
          }while((allsegs_max - allsegs_count) < nsegs);
          allsegs = (mdtm_lv_seg_t*)realloc(allsegs, allsegs_max * sizeof(*allsegs));
      }

      for(j = 0; j < nsegs; j++) {
          allsegs[allsegs_count].m_start = segs[j].m_start;
          allsegs[allsegs_count].m_end = segs[j].m_end;
          allsegs[allsegs_count].dev = mdtm_nominal_devname(segs[j].dev);
          allsegs_count++;
          if(segs[j].dev) free(segs[j].dev);
      }
      if(segs != NULL)
        free(segs);
  }

  free(fileexts);
  free(lv_name);

  *segments = allsegs;
  return allsegs_count;
}

static
int
mdtm_lustre_parse(
    const char*         fs,
    mdtm_lv_seg_t**     segments)
{
  char *                devname;
  mdtm_lv_seg_t *       allsegs;
  int                   allsegs_count = 0, allsegs_max = 16;

  if((devname = mdtm_lustre_devname(fs)) == 0) {
      return 0;
  }

  if((allsegs = (mdtm_lv_seg_t*)calloc(1, sizeof(*allsegs))) == NULL) {
      return -1;
  }
  allsegs[allsegs_count].dev = devname;
  allsegs[allsegs_count].m_start = 0;
  allsegs[allsegs_count].m_end = 0;
  *segments = allsegs;
  allsegs_count++;
  return allsegs_count;
}

#define         DEVSCSI_STR             "/dev/sd"
#define         DEVSCSI_STR_LEN         (strlen(DEVSCSI_STR) - 1)
#define         DEVIDE_STR              "/dev/hd"
#define         DEVIDE_STR_LEN          (strlen(DEVIDE_STR) - 1)
#define         DEVRAID_STR             "/dev/md"
#define         DEVRAID_STR_LEN         (strlen(DEVRAID_STR) - 1)
#define         DEVWILD_STR             "/dev/"
#define         DEVWILD_STR_LEN         (strlen(DEVWILD_STR) - 1)

static
int
mdtm_is_dev (const char*         fs)
{
  // typical device like sd*, hd*, md* and etc.
  if(!strncmp(fs, DEVSCSI_STR, DEVSCSI_STR_LEN))
    return 1;

  if(!strncmp(fs, DEVIDE_STR, DEVIDE_STR_LEN))
    return 1;

  if(!strncmp(fs, DEVRAID_STR, DEVRAID_STR_LEN))
    return 1;

  if(!strncmp(fs, DEVWILD_STR, DEVWILD_STR_LEN))
    return 1;

  return 0;
}

static
int
mdtm_dev_parse(
    const char*         fs,
    mdtm_lv_seg_t**     segments)
{
  char *                devname;
  mdtm_lv_seg_t *       allsegs;
  int                   allsegs_count = 0, allsegs_max = 16;

  if((devname = mdtm_nominal_devname(fs)) == 0) {
      return 0;
  }

  if((allsegs = (mdtm_lv_seg_t*)calloc(1, sizeof(*allsegs))) == NULL) {
      return -1;
  }
  allsegs[allsegs_count].dev = devname;
  allsegs[allsegs_count].m_start = 0;
  allsegs[allsegs_count].m_end = 0;
  *segments = allsegs;
  allsegs_count++;
  return allsegs_count;
}

static
int
mdtm_other_parse(
    const char*         fs,
    mdtm_lv_seg_t**     segments)
{
  mdtm_lv_seg_t *       allsegs;
  int                   allsegs_count = 0, allsegs_max = 16;

  if(!fs || !segments) {
      return 0;
  }

  if((allsegs = (mdtm_lv_seg_t*)calloc(1, sizeof(*allsegs))) == NULL) {
      return -1;
  }
  allsegs[allsegs_count].dev = strdup(fs);
  allsegs[allsegs_count].m_start = 0;
  allsegs[allsegs_count].m_end = 0;
  *segments = allsegs;
  allsegs_count++;
  return allsegs_count;
}

int
mdtm_map_file(char* path, char* buff, int buf_len)
{
  char linebuf[256];
  int linebuf_len = 256;
  int found = 0;
  FILE *mapfile;
  char device[256],location[256],sd[16];

  if(!buff || buf_len <= 0 || !path)
    return MDTM_ERR_INVADL;

  if(!(mapfile = fopen("/etc/mtab", "r")))
    return MDTM_ERR_NOENT;

  while(fgets(linebuf, linebuf_len, mapfile) != NULL) {
      if(sscanf(linebuf,"%s %s", device, location) <= 0)
        continue;

      // if path start with the location string, then we found it.
      if((strstr(path, location) == path) && strcmp(location, "/")) {
          sscanf(device,"/dev/%s", sd);
          if(sd[strlen(sd)-1] >= '1' && sd[strlen(sd)-1] <= '9')
            sd[strlen(sd)-1] = 0;
          strcpy(buff, sd);
          found = 1;
          break;
      }
  }
  fclose(mapfile);
  return (found == 1)? MDTM_SUCCESS : MDTM_FAILURE;
}

int
mdtm_map_file2(const char* filepath, char** filesystem, mdtm_lv_seg_t** segments)
{
    char *              fs = 0;
    char                *tmpstr, *slash;
    int                 rc = -1;

    if(!filepath || !segments)
      return -1;

    // find the file system for the file path
    tmpstr = strdup(filepath);
    while(mdtm_df_file(tmpstr, &fs) == -1) {
        slash = strrchr(tmpstr, '/');
        if(slash)
          *slash = '\0';
        else
          break;
    }
    if(!fs) {
        free(tmpstr);
        return MDTM_ERR_INVADL;
    }
    if(filesystem)
      *filesystem = strdup(fs);
    // end of find file system

    // parsing file system for device name
    if(mdtm_lvm_islv(fs))  {
        // logic volume
        rc = mdtm_lvm_parse(fs, segments, tmpstr);
    }
    else if(mdtm_is_dev(fs)){
        // typical device like sd*, hd*, md* and etc.
        rc = mdtm_dev_parse(fs, segments);
    }
    else if(mdtm_lustre_islustre(fs)) {
        // lustre
        rc = mdtm_lustre_parse(fs, segments);
    }
    else {
        // unknown storage devices
        rc = mdtm_other_parse(fs, segments);
    }
    free(tmpstr);
    free(fs);
    return rc;
}

void
mdtm_map_file_free(mdtm_lv_seg_t* segments, int n)
{
  if(segments) {
      for(int i = 0; i < n; i++)
        if(segments[i].dev)
          free(segments[i].dev);
      free(segments);
  }
}

/* \brief Return the name of file system for the given file path
 *
 *      @param  filepath    	[IN] the path to file
 *      @param  filesystem    	[OUT] the path to file
 *      @return            	On success, it returns the NUMA index. Or <0 if failed.
 */
int
mdtm_map_getfilesystem(const char* filepath, char** filesystem)
{
    char *              fs = 0;
    char                *tmpstr, *slash;

    if(!filepath || !filesystem)
      return -1;

    // find the file system for the file path
    tmpstr = strdup(filepath);
    while(mdtm_df_file(tmpstr, &fs) == -1) {
        slash = strrchr(tmpstr, '/');
        if(slash)
          *slash = '\0';
        else
          break;
    }
    if(!fs) {
        free(tmpstr);
        return MDTM_ERR_INVADL;
    }
    if(filesystem)
      *filesystem = strdup(fs);

    free(tmpstr);
    free(fs);

    return 0;
}

/* \brief Find the index of NUMA containing the file
 *      It return the NUMA index where the device containing the file locates
 *
 *      @param  path    the full path to the file
 *      @return         On success, it returns the NUMA index. Or <0 if failed.
 */
int
mdtm_find_numa_of_file(char *path)
{
  char dev[64];
  int devlen = 64;
  int numa;
  int rc;
  const mdtm_node_t *m;

  if(!path)
    return -1;

  // mapping the path to dev
  {
      mdtm_lv_seg_t* segments;
      if((rc = mdtm_map_file2((const char*)path, 0, &segments)) <= 0)
        return rc;
      strcpy(dev, segments[0].dev);
      mdtm_map_file_free(segments, rc);
  }

  m = mdtm_getdevicenodebyname((const char*) dev);

  // return numa id of from configure file
  if (m && mdtm_device_isconfig(m) == true){
      numa = m->ref_numaid;
      return numa;
  }

  // return numa id from the topology tree
  numa = mdtm_getnumaaffinity(mdtm_topology_tree, dev);
  return numa;
}

/* \brief Find the index of NUMA containing the device
 *      It return the NUMA index where the device containing the file locates
 *
 *      @param  devname    the full path to the file
 *      @return            On success, it returns the NUMA index. Or <0 if failed.
 */
int
mdtm_find_numa_of_dev(char *devname)
{
  int                   numa;
  const mdtm_node_t *   m;

  if(!devname)
    return -1;

  m = mdtm_getdevicenodebyname((const char*) devname);

  // return numa id of from configure file
  if (m && mdtm_device_isconfig(m) == true){
      numa = m->ref_numaid;
      return numa;
  }

  // return numa id from the topology tree
  numa = mdtm_getnumaaffinity(mdtm_topology_tree, (const char*)devname);
  return numa;
}

static
void
mdtm_config_freepcidevices(struct mdtm_device_s* devices, int n);

int
mdtm_config_init(const char * path)
{
  return (g_mdtm_config.readconfig(path) == false) ? -1 : 0;
}

long long
mdtm_config_get_maxfilesize()
{
  return g_mdtm_config.segsize();
}

int
mdtm_config_get_netif(char*devname, int len)
{
  struct mdtm_device_s* devices = 0;
  int nDevices = 0;
  int found = 0, i;

  if(!devname || len <= 0)
    return -1;

  nDevices = mdtm_config_getpcidevices(&devices);
  for(i = 0; i < nDevices; i++) {
      if(((devices[i].classid == MDTM_DEVICE_CLASS_NETWORK) &&
          !strcmp(devices[i].attr.network.operstate, "up"))) {
          found = 1;
          break;
      }
  }
  if(found != 1) {
      mdtm_debug("[libmdtm] Warning: No network device is found up running.\n");
      return -1;
  }

  strncpy(devname, devices[i].name, len);

  mdtm_config_freepcidevices(devices, nDevices);
  return 0;
}

int
mdtm_config_get_threadsperdevice(char *devname)
{
  return g_mdtm_config.threads(devname);
}

int
mdtm_config_getpcidevices(struct mdtm_device_s** devices)
{
  int                           i, nconfig;
  struct mdtm_device_s *        d;

  // read online devices from the configure file
  std::vector<mdtmdevice> mdevlist = g_mdtm_config.online();
  if((nconfig = mdevlist.size() ) <= 0)
    return 0;

  // check if online devices are in topology tree and return device info if yes
  if((d = (struct mdtm_device_s*) calloc(nconfig, sizeof(mdtm_device_s))) == 0)
    return 0;
  i = 0;
  for(auto it = mdevlist.begin(); it != mdevlist.end(); it++,i++) {
      if(mdtm_getdevicebyname(mdtm_topology_tree, it->getname(), &d[i]) < 0) {
          mdtm_debug(
              "[libmdtm] Warning: %s is configured online but not found in the topology tree.\n",
              it->getname());
      }
  }
  if( i > 0 ) {
      *devices = d;
      return i;
  }
  else {
      free(d);
      return 0;
  }
}

int
mdtm_config_get_ncpu(int *nstorage, int *nnetwork, int *nvirtual)
{
  int result = -1;

  if(!nstorage || !nnetwork || !nvirtual)
    return result;

  try {
    *nstorage = g_mdtm_config.getncpubytype(0);
    *nnetwork = g_mdtm_config.getncpubytype(1);
    *nvirtual = g_mdtm_config.getncpubytype(2);
    result = 0;
  }
  catch (std::exception &e) {
    mdtm_debug("libmdtm: mdtmconfig get cpu number for each type of devices failed: %s\n", e.what());
  }

  return result;
}

int
mdtm_config_get_cpus(int *storages, int s, int *networks, int n, int *virtuals, int v)
{
  int   result = -1;
  int   num;

  if(!storages || !networks || !virtuals)
    return result;

  try {
    num = g_mdtm_config.getcpusbytype(storages, s, 0);
    num = g_mdtm_config.getcpusbytype(networks, n, 1);
    num = g_mdtm_config.getcpusbytype(virtuals, v, 2);
    result = 0;
  }
  catch(std::exception &e){
    mdtm_debug("libmdtm: mdtmconfig get cpu array for each type of devices failed: %s\n", e.what());
  }

  return result;
}

const char *
mdtm_config_getconfigfilepath(void)
{
  return strdup(g_mdtm_config.getconfigfilepath());
}

static
void
mdtm_config_freepcidevices(struct mdtm_device_s* devices, int n)
{
  if(!devices || n <=0 )
    return;

  for ( int i = 0; i < n; i++) {
      if(devices[i].classid == MDTM_DEVICE_CLASS_NETWORK &&
          devices[i].attr.network.operstate != 0)
        free(devices[i].attr.network.operstate);
      if(devices[i].name)
        free(devices[i].name);
  }
  free(devices);
  return;
}


// generic data structure map
struct pointer_cmp {
bool operator () (const void *a,const void *b) const
{
  return a < b;
}

};
typedef std::map<void *, void*, pointer_cmp> PointerMap;

PointerMap mapList[128];
int maplistIndex = 0;

int
mdtm_map_create()
{
  return maplistIndex++;
}

void*
mdtm_map_insert(int handle, void*key, void *eventq)
{
//  PointerMap *map = (PointerMap*)g_eventq_table;
  PointerMap *map = &mapList[handle];
  std::pair<std::map<void*,void*>::iterator,bool> ret;
  ret = map->insert(std::pair<void*, void*>(key, eventq));
  return eventq;
}

void*
mdtm_map_remove(int handle, void *key)
{
  PointerMap::iterator it;
//  PointerMap *map = (PointerMap*)g_eventq_table;
  PointerMap *map = &mapList[handle];

  it = map->find(key);
//  map->erase(it);
  return it->second;
}

//
//      directory queue operations
//
void*
mdtm_dir_queue_create(const char* pathname)
{
  mdtm_dir_queue *dirq = NULL;

  if(!pathname)
    dirq = new mdtm_dir_queue();
  else
    dirq = new mdtm_dir_queue(pathname);

  return dirq;
}

void
mdtm_dir_queue_destroy(void *q)
{
  delete((mdtm_dir_queue *)q);
}

const char*
mdtm_dir_queue_dequeue(void* q)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  try
  {
      de = dirq->remove_file();
  }
  catch(const char* msg){
//      std::cout << msg <<std::endl;
    return NULL;
  }
  return (de.fq()).c_str();
}

char*
mdtm_dir_queue_dequeue2(void* q, char *filepath)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  try
  {
      de = dirq->remove_file();
  }
  catch(const char* msg){
//      std::cout << msg <<std::endl;
    return NULL;
  }
  return strcpy(filepath, (de.fq()).c_str());
}

char*
mdtm_dir_queue_peek(void* q, char *filepath)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  try
  {
      de = dirq->peek_file();
  }
  catch(const char* msg){
//      std::cout << msg <<std::endl;
    return NULL;
  }
  return strcpy(filepath, (de.fq()).c_str());
}

void
mdtm_dir_queue_iter(void* q)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;

  for(auto it = dirq->begin(); it!= dirq->end(); it++){
      de = *it;
      printf("file=%s size=%zu position=%zu\n",
             de.fq().c_str(), de.size(), de.position());
  }
  for(auto it = dirq->begin2(); it!= dirq->end2(); it++){
      de = *it;
    printf("dir=%s\n", de.fq().c_str());
  }
}

long long
mdtm_dir_queue_maxfilesize(void* q)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  size_t 	max_size = 0, tmp;

  if(!q)
	  return -1;

  for(auto it = dirq->begin(); it!= dirq->end(); it++){
      de = *it;
      tmp = de.size();
      max_size = (max_size > tmp)? max_size : tmp;
  }
  return (long long)max_size;
}

int
mdtm_dir_queue_chown_dir(void* q, char* username)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  struct passwd *pwd;

  pwd = getpwnam(username);   /* Try getting UID for username */
  if (pwd == NULL) {
      perror("getpwnam");
      return -1;
  }

  for(auto it = dirq->begin2(); it!= dirq->end2(); it++){
      de = *it;
      if(chown(de.fq().c_str(), pwd->pw_uid, pwd->pw_gid) < 0)
        mdtm_debug("libmdtm: %s %s %s\n", __FUNCTION__,
            de.fq().c_str(),
            strerror(errno));
  }
  return 0;
}

/* mdtm_dir_queue_find()
 *
 * Return the directory queue entry for the queue offset in bytes.
 */
int
mdtm_dir_queue_find(void* q, long long offset, mdtm_file_entry_t *entry)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  auto prev_it = dirq->begin();
  bool found=false;

  assert(entry);

  for(auto it = dirq->begin(); it!= dirq->end(); it++){
      de = *it;
      if(de.position() > offset) {
          found = true;
          break;
      }
      else if(de.position() == offset) {
          found = true;
          prev_it = it;
          break;
      }
      else if ((de.position() < offset)){
          if (de.position() + de.size() > offset) {
              found = true;
              prev_it = it;
          }
      }
      prev_it = it;
  }
  if(found == true) {
      de = *prev_it;
      strcpy(entry->path, de.fq().c_str());
      entry->offset = offset - de.position();
      entry->size = de.size();
      return 0;
  }
  else
    return de.position();
}

static
mdtm_dir_queue::const_iterator
mdtm_find(
    mdtm_dir_queue::const_iterator start,
    mdtm_dir_queue::const_iterator end,
    long long offset)
{
  mdtm_dir_queue::const_iterator it = start;
  if(start == end)
    return start;
  else {
      std::advance(it, std::distance(it, end)/2);
      if(it->position() > offset)
        return mdtm_find(start, it, offset);
      else if((it->position() <= offset) && ((it->position() + it->size()) > offset))
          return it;
      else
        return mdtm_find(it, end, offset);
  }
}

/* mdtm_dir_queue_find2()
 *
 * Return the directory queue entry for the queue offset in bytes.
 * This function use the binary search for better performance than sequential
 * method.
 */
int
mdtm_dir_queue_find2(
    void* q,
    long long offset,
    mdtm_file_entry_t *entry)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  auto prev_it = dirq->begin();
  bool found=false;

  assert(entry);

  prev_it = mdtm_find(dirq->begin(), dirq->end(), offset);
//  if(found == true)
    {
      de = *prev_it;
      strcpy(entry->path, de.fq().c_str());
      entry->offset = offset - de.position();
      entry->size = de.size();
      return 0;
  }
//  else
//    return de.position();
}

/* mdtm_dir_queue_find3()
 *
 * Return the directory queue entry for the queue offset in bytes.
 * This function used a modified sequential search to take advantage of
 * the almost-sorted arrival pattern which archives the optimal performance.
 */
int
mdtm_dir_queue_find3(void* q, long long offset, mdtm_file_entry_t *entry)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  auto prev_it = dirq->cur_it;
  bool found=false;

  assert(entry);
  assert(offset >= 0);

  while(prev_it->position() > offset)
    prev_it--;

  for(auto it = prev_it; it!= dirq->end(); it++){
      de = *it;
      if(de.position() > offset) {
          found = true;
          break;
      }
      else if(de.position() == offset) {
          found = true;
          prev_it = it;
          break;
      }
      else {
          if (de.position() + de.size() > offset) {
              found = true;
              prev_it = it;
              break;
          }
          else
            prev_it = it;
      }
  }
  if(found == true) {
      dirq->cur_it = prev_it;
      de = *prev_it;
      strcpy(entry->path, de.fq().c_str());
      entry->offset = offset - de.position();
      assert(entry->offset >= 0);
      entry->size = de.size();
      return 0;
  }
  else
    return -1;
}

/* mdtm_dir_queue_compare()
 * Return the directory queue entry for the queue offset in bytes.
 */
int
mdtm_dir_queue_compare(void* srcq, void* dstq)
{
  libdir::dentry de;
  mdtm_dir_queue *src_dirq = (mdtm_dir_queue *)srcq;
  mdtm_dir_queue *dst_dirq = (mdtm_dir_queue *)dstq;
  mdtm_file_entry_t entry;

//  assert(entry);

  printf("Original============================\n");
  mdtm_dir_queue_iter(src_dirq);


  printf("Recovered============================\n");
  mdtm_dir_queue_iter(dst_dirq);

//  for(auto it = src_dirq->begin(); it!= src_dirq->end(); it++){
//      de = *it;
//      if(mdtm_dir_queue_find(src_dirq, de.position(), &entry) != 0) {
//          printf("not found in destination: %s\n", de.fq(), de.position());
//      }
////      else
////        printf("%s\n", entry.path);//de.fq().c_str());//de.fq());
//  }
  return 0;
}

void
mdtm_dir_queue_create_meta(void* q, const char* meta)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;

  struct archive *a;
  struct archive_entry *entry;
  struct stat     statinfo;
  int r;
  int i;
  const char *metaname = meta;

  a = archive_write_new();
  archive_write_set_format_gnutar(a);
  archive_write_open_filename(a, metaname);
  //  archive_read_open_memory(a, (void *)(uintptr_t) data, sizeof(data));

  // add directories
  for(auto it = dirq->begin2(); it!= dirq->end2(); it++){
      de = *it;
//      if (lstat(de.fq().c_str(), &statinfo) != 0){
//          printf("error: %s: %s\n",de.fq().c_str(), strerror(errno));
//          return;
//      }

      entry = archive_entry_new();
//      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
      archive_entry_set_size(entry, 0); // Note 3
      archive_entry_set_filetype(entry, AE_IFDIR);
      //      archive_entry_set_perm(entry, 0777);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          //              errmsg(": ");
          //              errmsg(archive_error_string(a));
          //              needcr = 1;
          printf("error: %s: %s\n",__FILE__,__FUNCTION__);
      }
      if (r == ARCHIVE_FATAL)
        exit(1);
      if (r > ARCHIVE_FAILED) {
      }
      archive_entry_free(entry);
  }

  // add files
  for(auto it = dirq->begin(); it!= dirq->end(); it++) {
      de = *it;
      if (lstat(de.fq().c_str(), &statinfo) != 0){
          printf("error: %s: %s\n",de.fq().c_str(), strerror(errno));
          return;
      }

      entry = archive_entry_new();
      //      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
      archive_entry_set_size(entry, statinfo.st_size); // Note 3
      archive_entry_set_filetype(entry, AE_IFREG);
      //      archive_entry_set_perm(entry, 0777);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          //              errmsg(": ");
          //              errmsg(archive_error_string(a));
          //              needcr = 1;
          printf("error: %s: %s\n",__FILE__,__FUNCTION__);
      }
      if (r == ARCHIVE_FATAL)
        exit(1);
      if (r > ARCHIVE_FAILED) {
      }
      archive_entry_free(entry);
  }

  archive_write_close(a);
  archive_write_free(a);
  return;

}

void
mdtm_dir_queue_parse_meta(void* q, const char* meta)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;

  struct archive *a;
  struct archive *ext;
  struct archive_entry *entry;
  struct stat     statinfo;
  int r;
  int i;
  const char *metaname = meta;

  a = archive_read_new();
  assert(ARCHIVE_OK == archive_read_support_format_tar(a));

  ext = archive_write_disk_new();

  if (metaname != NULL && strcmp(metaname, "-") == 0)
    metaname = NULL;
  if ((r = archive_read_open_filename(a, metaname, 10240))) {
      mdtm_debug("[libmdtm] %s:%d: Archive read open failed: %s\n",__FILE__,__LINE__,metaname);
      archive_read_close(a);
      archive_read_free(a);
      return;
  }
  for (;;) {
      r = archive_read_next_header(a, &entry);
      if (r == ARCHIVE_EOF)
        break;
      if (r != ARCHIVE_OK) {
          mdtm_debug("[libmdtm] %s:%d: Archive read failed: %s\n",__FILE__,__LINE__,metaname);
          break;
      }
//      if (verbose && do_extract)
//        msg("x ");
//      if (verbose || !do_extract)
//        msg(archive_entry_pathname(entry));

//      printf("path=%s, type=%s size=%d\n",
//          archive_entry_pathname(entry),
//          archive_entry_filetype(entry) == AE_IFREG ? "AE_IFREG" : "AE_IFDIR",
//              archive_entry_size(entry));

      if(archive_entry_filetype(entry) == AE_IFREG) {
          dirq->add_file(archive_entry_pathname(entry),archive_entry_size(entry));
      }
      else
      if(archive_entry_filetype(entry) == AE_IFDIR) {
        r = archive_write_header(ext, entry);
        if (r != ARCHIVE_OK){
          mdtm_debug("[libmdtm] Director writing error:%s\n",archive_entry_pathname(entry));
          break;
        }
      }

//      if (do_extract) {
//          r = archive_write_header(ext, entry);
//          printf("%s:Ready to read header from %s\n",__FUNCTION__,filename);
//
//          if (r != ARCHIVE_OK)
//            errmsg(archive_error_string(a));
//          else
//            copy_data(a, ext);
//      }
//      if (verbose || !do_extract)
//        msg("\n");
//      archive_read_data_skip(a);
  }
  archive_read_close(a);
  archive_read_free(a);

//  mdtm_dir_queue_iter(dirq);
  return;
}

int
mdtm_dir_queue_empty(void* q)
{
  if(!q) return -1;
  return ((mdtm_dir_queue *)q)->file_empty()? 1 : 0;
}

int
mdtm_dir_queue_empty_dir(void* q)
{
  if(!q) return -1;
  return ((mdtm_dir_queue *)q)->dir_empty()? 1 : 0;
}

/* \brief
 * Create the meta data in the buffer from the input directory queue
 *
 * @param q             the input queue containing a directory of files and folders.
 * @param buff          the out buffer containing meta data.
 * @param buf_ize       the buffer size in bytes.
 */
long long
mdtm_dir_queue_create_meta2(void* q, void* buff, size_t buffSize)
{
  libdir::dentry                de;
  mdtm_dir_queue *              dirq;
  size_t                        used;

  struct archive *a;
  struct archive_entry *        entry;
  struct stat                   statinfo;
  char *                        path;
  int                           r;

  dirq = (mdtm_dir_queue *)q;

  if((a = archive_write_new()) == NULL)
      return -1;

  // set the size of copy buffer
  archive_write_set_bytes_per_block(a, buffSize);

  if( archive_write_set_format_gnutar(a) != ARCHIVE_OK) {
	  archive_write_free(a);
	  return -1;
  }

  if(ARCHIVE_OK != archive_write_open_memory(a, buff, buffSize, &used))
	  goto error_mem;

  // add directories
  for(auto it = dirq->begin2(); it!= dirq->end2(); it++) {
      de = *it;

      entry = archive_entry_new();
      if(entry == NULL)
        goto error_mem;

//      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
      archive_entry_set_size(entry, 0); // Note 3
      archive_entry_set_filetype(entry, AE_IFDIR);
      //      archive_entry_set_perm(entry, 0777);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: %s %s: archive_write_header() failed.\n",__FILE__,__FUNCTION__);
          archive_entry_free(entry);
          goto error_mem;
      }
      archive_entry_free(entry);
  }

  // add zero-byte-long files
  for(auto it = dirq->begin3(); it!= dirq->end3(); it++) {
      de = *it;
      if (lstat(de.fq().c_str(), &statinfo) != 0) {
          mdtm_debug("libmdtm: lstat failed: %s: %s\n",de.fq().c_str(), strerror(errno));
          goto error_mem;
      }

      entry = archive_entry_new();
      if(entry == NULL)
    	  goto error_mem;

      //      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
//      archive_entry_set_size(entry, 0); // Note 3
      archive_entry_set_filetype(entry, AE_IFREG);
      archive_entry_copy_stat(entry, &statinfo);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: archive_write_header() failed: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
          archive_entry_free(entry);
          goto error_mem;
      }
      archive_entry_free(entry);
  }

  // add link files
  for(auto it = dirq->begin4(); it!= dirq->end4(); it++) {
      de = *it;
      path = strdup(de.fq().c_str());

      if (lstat(path, &statinfo) != 0){
          mdtm_debug("libmdtm: lstat failed: %s: %s\n",path, strerror(errno));
          goto error_mem;
      }

      entry = archive_entry_new();
      if(entry == NULL)
        goto error_mem;

      {
        //      archive_entry_set_mode(entry, statinfo.st_mode);
        archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
        //      archive_entry_set_size(entry, statinfo.st_size); // Note 3
        //      archive_entry_set_filetype(entry, AE_IFLNK);
        archive_entry_copy_stat(entry, &statinfo);
        archive_entry_set_filetype(entry, AE_IFLNK);

        if (S_ISLNK(statinfo.st_mode)) {
            size_t linkbuffer_len = statinfo.st_size + 1;
            char *linkbuffer;
            int lnklen;

            linkbuffer = (char*) malloc(linkbuffer_len);
            if (linkbuffer == NULL) {
//                archive_set_error(&a->archive, ENOMEM,
//                    "Couldn't read link data");
                mdtm_debug("libmdtm: memory failed: %s: %d\n",__FUNCTION__, __LINE__);
                archive_entry_free(entry);
            	goto error_mem;
            }
//            if (a->tree != NULL) {
//#ifdef HAVE_READLINKAT
//                lnklen = readlinkat(a->tree_current_dir_fd(a->tree),
//                    path, linkbuffer, linkbuffer_len);
//#else
//                if (a->tree_enter_working_dir(a->tree) != 0) {
//                    archive_set_error(&a->archive, errno,
//                        "Couldn't read link data");
//                    free(linkbuffer);
//                    return (ARCHIVE_FAILED);
//                }
//                lnklen = readlink(path, linkbuffer, linkbuffer_len);
//#endif /* HAVE_READLINKAT */
//            } else
            lnklen = readlink(path, linkbuffer, linkbuffer_len);
            if (lnklen < 0) {
//                archive_set_error(&a->archive, errno,
//                    "Couldn't read link data");
                free(linkbuffer);
                mdtm_debug("libmdtm: readlink failed: %s: %d %s\n",__FUNCTION__, __LINE__, strerror(errno));
                archive_entry_free(entry);
            	goto error_mem;
            }
            linkbuffer[lnklen] = 0;
            archive_entry_set_symlink(entry, linkbuffer);
            free(linkbuffer);
        }
      }


      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: archive_write_header() failed: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
          archive_entry_free(entry);
          goto error_mem;
      }

      archive_entry_free(entry);
      free(path);
  }

  // add fifo files
  for(auto it = dirq->begin_fifo(); it!= dirq->end_fifo(); it++) {
      de = *it;
      if (lstat(de.fq().c_str(), &statinfo) != 0){
          mdtm_debug("libmdtm: lstat failed: %s: %s\n",de.fq().c_str(), strerror(errno));
          goto error_mem;
      }

      entry = archive_entry_new();
      if(entry == NULL)
        goto error_mem;

      //      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
//      archive_entry_set_size(entry, statinfo.st_size);
      archive_entry_set_size(entry, MDTM_STREAM_PIPE_SIZE);
      archive_entry_set_filetype(entry, AE_IFIFO);
      //      archive_entry_set_perm(entry, 0777);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: archive_write_header() failed: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
          archive_entry_free(entry);
          goto error_mem;
      }
      archive_entry_free(entry);
  }

  // add files
  for(auto it = dirq->begin(); it!= dirq->end(); it++) {
      de = *it;
      if (lstat(de.fq().c_str(), &statinfo) != 0){
          mdtm_debug("libmdtm: lstat failed: %s: %s\n",de.fq().c_str(), strerror(errno));
          goto error_mem;
      }

      entry = archive_entry_new();
      if(entry == NULL)
        goto error_mem;

      //      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
      archive_entry_set_size(entry, statinfo.st_size); // Note 3
      archive_entry_set_filetype(entry, AE_IFREG);
      //      archive_entry_set_perm(entry, 0777);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: archive_write_header() failed: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
          archive_entry_free(entry);
          goto error_mem;
      }
      archive_entry_free(entry);
  }

  r = archive_write_close(a);
  if (r < ARCHIVE_OK) {
      mdtm_debug("libmdtm: error: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
      archive_write_free(a);
      return -1;
  }

  archive_write_free(a);
  return used;

 error_mem:
    archive_write_close(a);
    archive_write_free(a);
    return -1;
}

/* \brief
 * Create the meta data in the buffer from the input directory queue
 *
 * @param q             the input queue containing a directory of files and folders.
 * @param buff          the out buffer containing meta data.
 * @param buf_ize       the buffer size in bytes.
 */
long long
mdtm_dir_queue_create_meta3(void* q, void* buff, size_t buffSize)
{
  libdir::dentry                de;
  mdtm_dir_queue *              dirq;
  size_t                        used;

  struct archive *a;
  struct archive_entry *        entry;
  struct stat                   statinfo;
  char *                        path;
  int                           r;

  dirq = (mdtm_dir_queue *)q;

  if((a = archive_write_new()) == NULL)
    return -1;

  // set the size of copy buffer
  archive_write_set_bytes_per_block(a, buffSize);

  if( archive_write_set_format_gnutar(a) != ARCHIVE_OK) {
	  archive_write_free(a);
	  return -1;
  }

  if(ARCHIVE_OK != archive_write_open_memory(a, buff, buffSize, &used))
	  goto error_mem;

  // add directories
  for(auto it = dirq->begin2(); it!= dirq->end2(); it++) {
      de = *it;

      entry = archive_entry_new();
      if(entry == NULL)
        goto error_mem;

//      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq().c_str());
//      archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
      archive_entry_set_size(entry, 0); // Note 3
      archive_entry_set_filetype(entry, AE_IFDIR);
      //      archive_entry_set_perm(entry, 0777);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: %s %s: archive_write_header() failed.\n",__FILE__,__FUNCTION__);
          archive_entry_free(entry);
          goto error_mem;
      }
      archive_entry_free(entry);
  }

  // add zero-byte-long files
  for(auto it = dirq->begin3(); it!= dirq->end3(); it++) {
      de = *it;
//      if (lstat(de.fq().c_str(), &statinfo) != 0) {
//          mdtm_debug("libmdtm: lstat failed: %s: %s\n",de.fq().c_str(), strerror(errno));
//          goto error_mem;
//      }

      entry = archive_entry_new();
      if(entry == NULL)
        goto error_mem;

      //      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
//      archive_entry_set_size(entry, 0); // Note 3
      archive_entry_set_filetype(entry, AE_IFREG);
      archive_entry_copy_stat(entry, &statinfo);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: archive_write_header() failed: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
          archive_entry_free(entry);
          goto error_mem;
      }
      archive_entry_free(entry);
  }

  // add link files
  for(auto it = dirq->begin4(); it!= dirq->end4(); it++) {
      de = *it;
      path = strdup(de.fq().c_str());

//      if (lstat(path, &statinfo) != 0){
//          mdtm_debug("libmdtm: lstat failed: %s: %s\n",path, strerror(errno));
//          goto error_mem;
//      }

      entry = archive_entry_new();
      if(entry == NULL)
        goto error_mem;

      {
        //      archive_entry_set_mode(entry, statinfo.st_mode);
        archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
        //      archive_entry_set_size(entry, statinfo.st_size); // Note 3
        //      archive_entry_set_filetype(entry, AE_IFLNK);
        archive_entry_copy_stat(entry, &statinfo);
        archive_entry_set_filetype(entry, AE_IFLNK);

        if (S_ISLNK(statinfo.st_mode)) {
            size_t linkbuffer_len = statinfo.st_size + 1;
            char *linkbuffer;
            int lnklen;

            linkbuffer = (char*) malloc(linkbuffer_len);
            if (linkbuffer == NULL) {
//                archive_set_error(&a->archive, ENOMEM,
//                    "Couldn't read link data");
                mdtm_debug("libmdtm: memory failed: %s: %d\n",__FUNCTION__, __LINE__);
                archive_entry_free(entry);
            	goto error_mem;
            }

            lnklen = readlink(path, linkbuffer, linkbuffer_len);
            if (lnklen < 0) {
//                archive_set_error(&a->archive, errno,
//                    "Couldn't read link data");
                free(linkbuffer);
                mdtm_debug("libmdtm: readlink failed: %s: %d %s\n",__FUNCTION__, __LINE__, strerror(errno));
                archive_entry_free(entry);
            	goto error_mem;
            }
            linkbuffer[lnklen] = 0;
            archive_entry_set_symlink(entry, linkbuffer);
            free(linkbuffer);
        }
      }


      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: archive_write_header() failed: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
          archive_entry_free(entry);
          goto error_mem;
      }

      archive_entry_free(entry);
      free(path);
  }

  // add fifo files
  for(auto it = dirq->begin_fifo(); it!= dirq->end_fifo(); it++) {
      de = *it;
//      if (lstat(de.fq().c_str(), &statinfo) != 0){
//          mdtm_debug("libmdtm: lstat failed: %s: %s\n",de.fq().c_str(), strerror(errno));
//          goto error_mem;
//      }

      entry = archive_entry_new();
      if(entry == NULL)
        goto error_mem;

      //      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq2(dirq->getroot()).c_str());
//      archive_entry_set_size(entry, statinfo.st_size);
      archive_entry_set_size(entry, MDTM_STREAM_PIPE_SIZE);
      archive_entry_set_filetype(entry, AE_IFIFO);
      //      archive_entry_set_perm(entry, 0777);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: archive_write_header() failed: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
          archive_entry_free(entry);
          goto error_mem;
      }
      archive_entry_free(entry);
  }

  // add files
  for(auto it = dirq->begin(); it!= dirq->end(); it++) {
      de = *it;
//      if (lstat(de.fq().c_str(), &statinfo) != 0){
//          mdtm_debug("libmdtm: lstat failed: %s: %s\n",de.fq().c_str(), strerror(errno));
//          goto error_mem;
//      }

      entry = archive_entry_new();
      if(entry == NULL)
        goto error_mem;

      //      archive_entry_set_mode(entry, statinfo.st_mode);
      archive_entry_set_pathname(entry, de.fq().c_str());
      archive_entry_set_size(entry, de.size()); // Note 3
      archive_entry_set_filetype(entry, AE_IFREG);
      //      archive_entry_set_perm(entry, 0777);

      r = archive_write_header(a, entry);
      if (r < ARCHIVE_OK) {
          mdtm_debug("libmdtm: archive_write_header() failed: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
          archive_entry_free(entry);
          goto error_mem;
      }
      archive_entry_free(entry);
  }

  r = archive_write_close(a);
  if (r < ARCHIVE_OK) {
      mdtm_debug("libmdtm: error: %s: %s: %s\n",__FILE__,__FUNCTION__,archive_error_string(a));
      archive_write_free(a);
      return -1;
  }

  archive_write_free(a);
  return used;

error_mem:
  archive_write_close(a);
  archive_write_free(a);
  return -1;
}

/* \brief
 * Parse the meta data in the buffer and save to the output directory queue.
 * It also write parsed directories to disks.
 *
 * @param q             the output queue containing the parsed files.
 * @param buff          the buffer containing meta data.
 * @param buf_ize       the buffer size in bytes.
 * @param target_root   the root path for the extract files. It is the
 *                      current working directory if NULL.
 */
void
mdtm_dir_queue_parse_meta2(
    void* q,
    const char* buff,
    size_t buf_size,
    char* target_root)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;

  struct archive *a;
  struct archive *ext;
  struct archive_entry *entry;
  struct stat     statinfo;
  int             r;
  size_t          entry_size;
  int             entry_type;
  char            newPath[PATH_MAX + 1];

  dirq->setroot(target_root);
  a = archive_read_new();
  if(!a) {
      mdtm_debug("[libmdtm] %s:%d: Archive read new failed.\n",__FILE__,__LINE__);
      return;
  }

  // support gnu format
  if(ARCHIVE_OK != archive_read_support_format_tar(a)) {
      mdtm_debug("[libmdtm] %s:%d: Archive format not support.\n",__FILE__,__LINE__);
      archive_read_free(a);
      return;
  }

  if(ARCHIVE_OK != archive_read_open_memory(a, (void*)buff, buf_size)) {
      mdtm_debug("[libmdtm] %s:%d: Archive read open failed.\n",__FILE__,__LINE__);
      archive_read_free(a);
      return;
  }

  ext = archive_write_disk_new();

  for (;;) {
      r = archive_read_next_header(a, &entry);
      if (r == ARCHIVE_EOF)
        break;
      if (r != ARCHIVE_OK) {
          mdtm_debug("[libmdtm] %s:%d: Archive read failed: buff=%p\n",__FILE__,__LINE__,buff);
          goto parse_error;
      }

      entry_type = archive_entry_filetype(entry);
      entry_size = archive_entry_size(entry);
      if(entry_type == AE_IFREG && entry_size > 0) {
          snprintf( newPath, PATH_MAX, "%s%s", target_root, archive_entry_pathname(entry) );
          dirq->add_file(std::string(newPath), entry_size);
      }
      else if(entry_type == AE_IFIFO) {
          snprintf( newPath, PATH_MAX, "%s%s", target_root, archive_entry_pathname(entry) );
          dirq->add_fifo(std::string(newPath), MDTM_STREAM_PIPE_SIZE); //entry_size);
      }
      else {
          const char* path = archive_entry_pathname( entry );

          snprintf( newPath, PATH_MAX, "%s%s", target_root, path );
          archive_entry_set_pathname( entry, newPath );
          r = archive_write_header(ext, entry);
          if (r != ARCHIVE_OK) {
            mdtm_debug("Header writing error:%s\n",archive_entry_pathname(entry));
            goto parse_error;
          }
          if(entry_type == AE_IFREG){
              r = archive_write_finish_entry(ext);
              if (r != ARCHIVE_OK) {
                mdtm_debug("File writing error:%s\n",archive_entry_pathname(entry));
                goto parse_error;
              }
          }
          if(entry_type == AE_IFLNK){
//              copy_data(a, ext);
//              r = archive_write_finish_entry(ext);
//              if (r != ARCHIVE_OK)
//                printf("File writing error:%s\n",archive_entry_pathname(entry));
          }
          if(entry_type == AE_IFDIR) {
              dirq->add_directory(std::string(archive_entry_pathname(entry)));
          }
      }
  } // for(;;)

  dirq->cur_it = dirq->begin();

parse_error:
  archive_read_close(a);
  archive_read_free(a);
  return;
}

/* \brief
 * Parse the meta data in the bufferand and save to the output directory queue.
 * It does NOT write to disks.
 *
 * @param q             the output queue containing the parsed files.
 * @param buff          the buffer containing meta data.
 * @param buf_ize       the buffer size in bytes.
 * @param target_root   the root path for the extract files. It is the
 *                      current working directory if NULL.
 */
void
mdtm_dir_queue_parse_meta_only(
    void* q,
    const char* buff,
    size_t buf_size,
    char* target_root)
{
  libdir::dentry de;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;

  struct archive *a;
  struct archive_entry *entry;
  struct stat     statinfo;
  int             r;
  size_t          entry_size;
  int             entry_type;
  char            newPath[PATH_MAX + 1];

  dirq->setroot(target_root);

  a = archive_read_new();
  if(!a) {
      mdtm_debug("[libmdtm] %s:%d: Archive read new failed.\n",__FILE__,__LINE__);
      return;
  }

  // support gnu format
  if(ARCHIVE_OK != archive_read_support_format_tar(a)) {
      mdtm_debug("[libmdtm] %s:%d: Archive format not support.\n",__FILE__,__LINE__);
      archive_read_free(a);
      return;
  }

  if(ARCHIVE_OK != archive_read_open_memory(a, (void*)buff, buf_size)) {
      mdtm_debug("[libmdtm] %s:%d: Archive read open failed.\n",__FILE__,__LINE__);
      archive_read_free(a);
      return;
  }

  for (;;) {
      r = archive_read_next_header(a, &entry);
      if (r == ARCHIVE_EOF)
        break;
      if (r != ARCHIVE_OK) {
          mdtm_debug("%s:%d: Archive read failed: buff=%p\n",__FILE__,__LINE__,buff);
          goto parse_error;
      }

      entry_type = archive_entry_filetype(entry);
      entry_size = archive_entry_size(entry);
      if(entry_type == AE_IFREG && entry_size > 0) {
          snprintf( newPath, PATH_MAX, "%s%s", target_root, archive_entry_pathname(entry) );
          dirq->add_file(std::string(newPath), entry_size);
      }
      else if(entry_type == AE_IFIFO) {
          snprintf( newPath, PATH_MAX, "%s%s", target_root, archive_entry_pathname(entry) );
          dirq->add_fifo(std::string(newPath), MDTM_STREAM_PIPE_SIZE); //entry_size);
      }
      else {
          const char* path = archive_entry_pathname( entry );

          snprintf( newPath, PATH_MAX, "%s%s", target_root, path );
          archive_entry_set_pathname( entry, newPath );
          if(entry_type == AE_IFREG){
          }
          if(entry_type == AE_IFLNK){
          }
          if(entry_type == AE_IFDIR) {
              dirq->add_directory(std::string(archive_entry_pathname(entry)));
          }
      }
  } // for(;;)

  dirq->cur_it = dirq->begin();

parse_error:
  archive_read_close(a);
  archive_read_free(a);
  return;
}

void*
mdtm_dir_queue_clone(void* srcq) {
  int result = -1;
  mdtm_dir_queue *src = (mdtm_dir_queue *)srcq, *dst;

  assert(srcq);
  dst = new mdtm_dir_queue(*src);
  dst->cur_it = dst->begin();
  return dst;
}

// number of entry in the directory queue
int
mdtm_dir_queue_size(void* q, unsigned char flag) {
  int result = -1;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  int count = 0;

  assert(dirq);

  if(flag & MDTM_DIR_QUEUE_SIZE_FILE)
    for(auto it = dirq->begin(); it!= dirq->end(); it++){
        count++;
    }

  if(flag & MDTM_DIR_QUEUE_SIZE_DIR)
    for(auto it = dirq->begin2(); it!= dirq->end2(); it++){
        count++;
    }

  if(flag & MDTM_DIR_QUEUE_SIZE_FIFO)
    for(auto it = dirq->begin_fifo(); it!= dirq->end_fifo(); it++){
        count++;
    }
  return count;
}

long
mdtm_dir_queue_blocks(void* q, unsigned char flag) {

  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;

  if(dirq == 0)
	  return -1;

  return dirq->blocks();
}

int
mdtm_dir_queue_addfile(
    void *q,
    char *path,
    size_t size) {
  int result = -1;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;
  dirq->add_file(std::string(path), size);
  return 0;
}

int
mdtm_dir_queue_addpaths(
    void *      q,
    char **     path_array,
    size_t *    size_array,
    int         array_size)
{
  int result = -1;
  int i, n;
  mdtm_dir_queue *dirq = (mdtm_dir_queue *)q;

  if(!q || !path_array || !size_array || array_size <= 0)
    return -1;

  dirq->add_sortedpaths(path_array,size_array,array_size);

  return 0;
}

int
mdtm_blockdevice_sectorsize(const char* filepath)
{
  size_t                sector_sz = -1;
  char *                file_sys = NULL;
  mdtm_lv_seg_t *       segments;
  int                   fd, rc;

  if( (rc = mdtm_map_file2(filepath, &file_sys, &segments) > 0)) {
      if((fd = open(file_sys, O_RDONLY | O_NONBLOCK)) > 0) {
          if(ioctl(fd, BLKSSZGET, &sector_sz) >= 0)
            fprintf(stderr, "file_sys=%s sector_sz=%zu\n", file_sys, sector_sz);
          else
            sector_sz = -1;
      }
      mdtm_map_file_free(segments, rc);
  }

  return (int)sector_sz;
}

#ifdef __cplusplus
}
#endif

