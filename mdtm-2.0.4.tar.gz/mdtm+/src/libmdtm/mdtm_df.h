/*
 * mdtm_df.h
 *
 *  Created on: Jan 22, 2016
 *      Author: liangz
 */

#ifndef SRC_LIBMDTM_MDTM_DF_H_
#define SRC_LIBMDTM_MDTM_DF_H_

#ifdef __cplusplus
extern "C" {
#endif
/**
 * Return the name of device on which the file is on
 *
 * \param  path         the full path of file
 * \param  devname      the pointer to the name string of device,
 *                      e.g. /dev/mapper/vg_denali-lv_home
 *
 * \return              If success, the number of device found and its name
 *                      is in *devname. Otherwise -1;
 */
int
mdtm_df_file(const char* path, char **devname);

#ifdef __cplusplus
}
#endif

#endif /* SRC_LIBMDTM_MDTM_DF_H_ */
