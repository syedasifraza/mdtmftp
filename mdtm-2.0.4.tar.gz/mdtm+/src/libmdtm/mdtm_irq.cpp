/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <memory.h>
#include <math.h>
#include <dirent.h>
#include <assert.h>
#include <stdint.h>

#include <vector>
#include <string>
#include <syslog.h>
#include <iostream>
#include <vector>
#include <ctime>       /* time */
#include <cstdlib>

#include <mdtm_utils.h>
#include <mdtm_irq.h>

// path to directories
#define PATH_PROC_INTERRUPTS         "/proc/interrupts"
#define PATH_IRQ_AFFINITY_BACKUP     "backup"

void
mdtm_irq::printirqaffinity(char* devtype){
  char path[128];
  FILE *fp;
  size_t len = 0;
  char *line = NULL;
  ssize_t readbytes;
  std::vector<int> irqnums;
  std::vector<std::string> irqqueues;
  char queuename[64];
  int temp, irq;

  fp = fopen("/proc/interrupts","r");
  if(!fp)
    perror("fopen");
  while((readbytes = getline(&line, &len, fp)) != -1) {
      if(strstr(line, devtype)){
          sscanf(line, "%d:", &temp);
          irqnums.push_back(temp);
//          puts(line);
          sscanf(strstr(line, devtype),"%s ",queuename);
          irqqueues.push_back(queuename);
      }
  }
  fclose(fp);


  printf("Device\t\tirq\taffinity mask\n");
  printf("==============================================\n");
  std::vector<std::string>::iterator itq = irqqueues.begin();
  for(std::vector<int>::iterator it = irqnums.begin(); it != irqnums.end(); ++it) {
      snprintf(path, sizeof(path), "/proc/irq/%d/smp_affinity", *it);
      fp = fopen(path,"r");
      if(!fp)
        perror("fopen");

      irq = *it;

      readbytes = getline(&line, &len, fp);
//      printf("%d\t%s\t%s", irq, *itq, line);
      printf("%s\t%d\t%s", (*itq).c_str(), irq, line);

      ++itq;

      fclose(fp);
  }

  free(line);

}


int mdtm_irq::assignirqaffinity(char* devtype) {
  char path[128];
  FILE *fp;
  size_t len = 0;
  char *line = NULL;
  ssize_t readbytes;
  std::vector<int> irqnums;
  int temp;
  bitarray<uint64_t> *ba = new bitarray<uint64_t>();
  int irq;
  char cmdline[256], cmdline2[256];
  uint64_t data;

  assert(devtype);

  /* initialize random seed: */
  srand ((unsigned)time(0));

  // create backup folder
  snprintf(cmdline, sizeof(cmdline), "mkdir -p %s",PATH_IRQ_AFFINITY_BACKUP);
  system(cmdline);

  // retrieve the irq numbers for "eth" devices
  //  snprintf(path,strlen(PATH_PROC_INTERRUPTS) + 1, "%s", PATH_PROC_INTERRUPTS);
  //  printf("%s\n",path);
  fp = fopen("/proc/interrupts","r");
  if(!fp)
    perror("fopen");
  while((readbytes = getline(&line, &len, fp)) != -1) {
      if(strstr(line, devtype)){
          sscanf(line, "%d:", &temp);
          irqnums.push_back(temp);
//          puts(line);
      }
  }
  fclose(fp);

  // check irq affinity and assign only one to every irq if multiple available
  for(std::vector<int>::iterator it = irqnums.begin(); it != irqnums.end(); ++it) {
      snprintf(path, sizeof(path), "/proc/irq/%d/smp_affinity", *it);
      fp = fopen(path,"r");
      if(!fp)
        perror("fopen");

//      printf("irq=%d\n", *it);
      irq = *it;

      readbytes = getline(&line, &len, fp);
      fclose(fp);

      if(readbytes != -1) {
          ba->stitch(line);
          data = strtoull(line, NULL, 16);
//          printf("affinity=%016llx\n",data);
          std::vector<uint64_t> &res = ba->positions(data);

//          for(std::vector<uint64_t>::iterator it = res.begin();it != res.end(); ++it)
//            printf("pos=%u\n", *it);

          if(res.size() > 1) {
              uint64_t tt = 1;
              int index = rand() % res.size();
//              printf("size=%d, rand=%d, %d, new value = %llx\n",res.size(), index, res[index], tt<<res[index]);
              snprintf(cmdline, sizeof(cmdline), "echo %llx > /proc/irq/%d/smp_affinity",tt<<res[index], irq);
//              printf("cmd=%s\n",cmdline);
              snprintf(cmdline2, sizeof(cmdline2), "mkdir -p %s/%d;cat /proc/irq/%d/smp_affinity > %s/%d/smp_affinity", PATH_IRQ_AFFINITY_BACKUP, irq, irq, PATH_IRQ_AFFINITY_BACKUP, irq);
              system(cmdline2);
              system(cmdline);
          }
      }
  }

  free(ba);
  free(line);

  return 0;
}

void mdtm_irq::resumeirqaffinity() {
  DIR *fd_proc;
  struct dirent *dirp;
  int fd_stat, cur_pid, cnt;
  char buf[1000], pdir[50], statfile[50], procname[50];
  int pid;

  sprintf (pdir, PATH_IRQ_AFFINITY_BACKUP);

  if (!(fd_proc = opendir (pdir)))
  {
  printf( "Unable to open dir = %s, errno \n", pdir);
  return;
  }
  while ((dirp = readdir (fd_proc)) != NULL)
  {
      if(!strcmp(dirp->d_name, ".") || !strcmp(dirp->d_name, ".."))
        continue;

//      printf(" %s, \n",dirp->d_name);
      snprintf(buf, sizeof(buf), "cat %s/%s/smp_affinity > /proc/irq/%s/smp_affinity\n", PATH_IRQ_AFFINITY_BACKUP, dirp->d_name, dirp->d_name);
//      printf("cmd =%s", buf);
      system(buf);
  }
  return;
}


