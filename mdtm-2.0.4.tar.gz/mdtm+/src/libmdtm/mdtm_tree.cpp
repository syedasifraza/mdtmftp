/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <error.h>
#include <string.h>
#include <vector>

#include <hwloc.h>
#include "include/mdtm.h"
#include "include/mdtm/mdtm_tree.h"
#include "include/private/mdtm_tree_intern.h"
#include "include/private/mdtm_debug.h"
#include "include/private/mdtm_config.h"

//TODO: implementing sington pattern
static int lstopo_show_taskset = 0;
static mdtm_node_t* first_device = 0, *first_numa = 0;
static mdtm_node_t *first_numa0 = 0;
static int g_nDevices = 0, g_nNumas = 0, g_nNumas0 = 0;         //TODO: to work on the sington pattern
static hwloc_topology_t topology;
static unsigned long topology_refcount = 0;

#ifdef __cplusplus
extern "C" {
#endif

#define indent(output, i) \
                   fprintf (output, "%*s", (int) i, "");

mdtm_node_t*
mdtm_alloc_node(
		hwloc_topology_t topology,
		hwloc_obj_t l,
		int logical,
		int verbose_mode)
{
  char type[32], *attr, phys[32] = "";
  unsigned idx = logical ? l->logical_index : l->os_index;
  const char *indexprefix = logical ? " L#" : " P#";
  mdtm_node_t * newNode = NULL;

  if (!(newNode = (mdtm_node_t*) malloc(sizeof(mdtm_node_t)))) {
	  return NULL;
  }
  memset(newNode, 0, sizeof(mdtm_node_t));
  newNode->numChildren = l->arity;

  //  if (lstop_show_cpuset < 2)
  {
    int len;

    // retrieve object type and name
    if (l->type == HWLOC_OBJ_MISC && l->name)
      newNode->name = strdup(l->name);
    else {
        hwloc_obj_type_snprintf(type, sizeof(type), l, verbose_mode - 1);
        newNode->type = strdup(type);
        if ((l->type == HWLOC_OBJ_OS_DEVICE) && l->name
            && l->type != HWLOC_OBJ_MISC)
        {
            //pull out more information about the device
            char path[64] = {0};
            char value[16] = {0};
            FILE *file;

            if(!strcmp(type, "Network") || !strcmp(type, "Net")) {
                // operation state: up or down
                snprintf(path, sizeof(path), "/sys/class/net/%s/operstate", l->name);
                file = fopen(path, "r");
                if (file) {
                    fread(value, sizeof(value), 1, file);
                    fclose(file);
                    newNode->attr2.network.operstate = (char*)((value[0] == 'u')? "up" : "down");
                }
                else
                  mdtm_debug("libmdtm: Sysfs file not found: %s\n", path);

                // speed
                newNode->attr2.network.speed = 0;
                if(!strcmp(newNode->attr2.network.operstate, "up")) {
                    snprintf(path, sizeof(path), "/sys/class/net/%s/speed", l->name);
                    file = fopen(path, "r");
                    if (file) {
                        fread(value, sizeof(value), 1, file);
                        fclose(file);
                        newNode->attr2.network.speed = strtoul(value, NULL, 0);
                    }
                    else
                    	mdtm_debug("libmdtm: Sysfs file not found: %s\n", path);
                }
                else {
                    newNode->attr2.network.speed = 0;
                }

                // type
                snprintf(path, sizeof(path), "/sys/class/net/%s/type", l->name);
                file = fopen(path, "r");
                if (file) {
                    fread(value, sizeof(value), 1, file);
                    fclose(file);
                    newNode->attr2.network.type = strtoull(value, NULL, 0);
                }
                else
                    mdtm_debug("libmdtm: Sysfs file not found: %s\n", path);
            }

            if(!strcmp(type, "Block")) {
                // devid
                snprintf(path, sizeof(path), "/sys/class/block/%s/dev", l->name);
                file = fopen(path, "r");
                if (file) {
                    int major = 0, minor = 0, rc;
                    rc = fread((void*)value, sizeof(value), 1, file);
                    if(rc > 0 || feof(file)) {
                        sscanf((const char*)value, "%d:%d",&major,&minor);
                        newNode->attr2.storage.devid = major<<8 | minor;
                    }
                    else
                      mdtm_debug("Sysfs file read failed. %s\n", path);
                    fclose(file);
                }
                else
                    mdtm_debug("libmdtm: Sysfs file not found: %s\n", path);

                // size
                snprintf(path, sizeof(path), "/sys/class/block/%s/size", l->name);
                file = fopen(path, "r");
                if (file) {
                    fread(value, sizeof(value), 1, file);
                    fclose(file);
                    newNode->attr2.storage.size = strtoul(value, NULL, 0);
                }
                else
                    mdtm_debug("libmdtm: Sysfs file not found: %s\n", path);

                // rotational
                snprintf(path, sizeof(path), "/sys/class/block/%s/queue/rotational", l->name);
                file = fopen(path, "r");
                if (file) {
                    fread(value, sizeof(value), 1, file);
                    fclose(file);
                    newNode->attr2.storage.type = strtoul(value, NULL, 0);
                }
                else
                    mdtm_debug("libmdtm: Sysfs file not found: %s\n", path);
            }
            //end of pull out more information

            // hook up to the device link list
            newNode->name = strdup(l->name);
            if (!first_device)
              {
                first_device = newNode;
                first_device->prev = first_device->next = first_device;
                g_nDevices++;
              }
            else
              {
                mdtm_node_t *last_device = first_device->prev;
                newNode->prev = last_device;
                newNode->next = first_device;
                last_device->next = newNode;
                first_device->prev = newNode;
                g_nDevices++;
              }
            // end of hook up to the device linklist
        }

        // hook up to the numa link list
        if(l->type == HWLOC_OBJ_NODE) {
        	if (!first_numa) {
        		first_numa = newNode;
        		first_numa->prev = first_numa->next = first_numa;
        		g_nNumas++;
        	}
        	else {
        		mdtm_node_t *last_numa = first_numa->prev;
        		newNode->prev = last_numa;
        		newNode->next = first_numa;
        		last_numa->next = newNode;
        		first_numa->prev = newNode;
        		g_nNumas++;
        	}
        }
        // end of hook up to the numa link list
      }

    // retrieve object logical index
    newNode->logical_index = l->logical_index;
    newNode->os_index = l->os_index;

    // retrieve  object attribute
    len = hwloc_obj_attr_snprintf(NULL, 0, l, " ", verbose_mode - 1);
    attr = (char*) malloc(len + 1);
    *attr = '\0';
    hwloc_obj_attr_snprintf(attr, len + 1, l, " ", verbose_mode - 1);
    newNode->attr = strdup(attr);
    free(attr);
  }

  newNode->online_cpuset= l->online_cpuset;
  if (!l->cpuset) {
	  //      mdtm_debug("NOTICE: cpuset is zero! ");
	  //      hwloc_obj_type_snprintf(type, sizeof(type), l, verbose_mode - 1);
	  //      mdtm_debug("type=%s ", type);
	  //      if(l->name)mdtm_debug("name = %s",l->name);
	  //      mdtm_debug("\n");
	  return newNode;
  }
  else {
	  char *cpusetstr;
	  if (lstopo_show_taskset)
		  hwloc_bitmap_taskset_asprintf(&cpusetstr, l->cpuset);
	  else
		  hwloc_bitmap_asprintf(&cpusetstr, l->cpuset);
	  newNode->cpuset = strdup(cpusetstr);
	  free(cpusetstr);
  }

  return newNode;
}

static
int
mdtm_set_node_attr(mdtm_node_t *newNode, char *type, char *name)
{
  char path[64] = {0};
  char value[16] = {0};
  FILE *file;

  // network device
  if(!strcmp(type, "Network") || !strcmp(type, "Net")) {
      // operation state: up or down
      snprintf(path, sizeof(path), "/sys/class/net/%s/operstate", name);
      file = fopen(path, "r");
      if (file) {
          fread(value, sizeof(value), 1, file);
          fclose(file);
          newNode->attr2.network.operstate = (char*)((value[0] == 'u')? "up" : "down");
      }
      else {
    	  newNode->attr2.network.operstate = (char*) "unknown";
    	  fprintf(stderr, "[libmdtm] can not open %s : %s\n", path, strerror(errno));
    	  goto attr_error;
      }

      // speed
      newNode->attr2.network.speed = 0;
      if(!strcmp(newNode->attr2.network.operstate, "up")) {
          snprintf(path, sizeof(path), "/sys/class/net/%s/speed", name);
          file = fopen(path, "r");
          if (file) {
              fread(value, sizeof(value), 1, file);
              fclose(file);
              newNode->attr2.network.speed = strtoul(value, NULL, 0);
          }
          else {
        	  newNode->attr2.network.speed = 0;
        	  fprintf(stderr, "[libmdtm] can not open %s : %s\n", path, strerror(errno));
        	  goto attr_error;
          }
      }
      else {
          newNode->attr2.network.speed = 0;
      }

      // type
      snprintf(path, sizeof(path), "/sys/class/net/%s/type", name);
      file = fopen(path, "r");
      if (file) {
          fread(value, sizeof(value), 1, file);
          fclose(file);
          newNode->attr2.network.type = strtoull(value, NULL, 0);
      }
      else {
    	  newNode->attr2.network.type = 0;
    	  fprintf(stderr, "[libmdtm] can not open %s : %s\n", path, strerror(errno));
    	  goto attr_error;
      }
  }

  // block device
  if(!strcmp(type, "Block")) {
      // devid
      snprintf(path, sizeof(path), "/sys/class/block/%s/dev", name);
      file = fopen(path, "r");
      if (file) {
          int major, minor;
          fread(value, sizeof(value), 1, file);
          fclose(file);
          sscanf(value, "%d:%d",&major,&minor);
          newNode->attr2.storage.devid = major<<8 | minor;
      }
      else {
    	  newNode->attr2.storage.devid = 0;
    	  fprintf(stderr, "[libmdtm] can not open %s : %s\n", path, strerror(errno));
    	  goto attr_error;
      }

      // size
      snprintf(path, sizeof(path), "/sys/class/block/%s/size", name);
      file = fopen(path, "r");
      if (file) {
          fread(value, sizeof(value), 1, file);
          fclose(file);
          newNode->attr2.storage.size = strtoul(value, NULL, 0);
      }
      else {
    	  newNode->attr2.storage.size = 0;
    	  fprintf(stderr, "[libmdtm] can not open %s : %s\n", path, strerror(errno));
    	  goto attr_error;
      }

      // rotational: optional
      snprintf(path, sizeof(path), "/sys/class/block/%s/queue/rotational", name);
      file = fopen(path, "r");
      if (file) {
          fread(value, sizeof(value), 1, file);
          fclose(file);
          newNode->attr2.storage.type = strtoul(value, NULL, 0);
      }
      else {
    	  newNode->attr2.storage.type = 0;
    	  fprintf(stderr, "[libmdtm] can not open %s : %s\n", path, strerror(errno));
      }
  }

  return 0;

attr_error:
  return -1;

}

/* \brief Create node on the device list based on the configure file
 * @return      0 if success, -1 if failed.
 */
int
mdtm_insert_from_config(mdtm_node_t     *sysinfo_tree,
                        void            *data)
{
  mdtm_node_t * newNode = NULL;
  std::vector<mdtmdevice> devlist;
  mdtmconfig *cfg = (mdtmconfig*)data;

  if(data == 0)
	  return 0;

  devlist = cfg->topology();
  for(auto it = devlist.begin(); it != devlist.end(); it++){
      if (!(newNode = (mdtm_node_t*) malloc(sizeof(mdtm_node_t))))
        {
          return -1;
        }

      memset(newNode, 0, sizeof(mdtm_node_t));
      newNode->isconfig = 1;
      newNode->type = it->getattr(mdtmdevice::MDTM_DEV_ATTR_TYPE);
      newNode->name = strdup(it->getname());
      newNode->ref_numaid = it->getattr_int(mdtmdevice::MDTM_DEV_ATTR_NUMA);
      if (mdtm_set_node_attr(newNode, newNode->type, newNode->name) < 0) {
    	  free(newNode->name);
    	  free(newNode);
    	  continue;
      }

      // hook up to the device link list
      if (!first_device)
        {
          first_device = newNode;
          first_device->prev = first_device->next = first_device;
          g_nDevices++;
        }
      else
        {
          mdtm_node_t *last_device = first_device->prev;
          newNode->prev = last_device;
          newNode->next = first_device;
          last_device->next = newNode;
          first_device->prev = newNode;
          g_nDevices++;
        }
  }
  return 0;
}


/* Recursively output topology in a console fashion */
void
mdtm_insert_from_hwloc(mdtm_node_t **tree, const mdtm_node_t *owner, hwloc_topology_t topology,
    hwloc_obj_t l, hwloc_obj_t parent, int i, int logical,
    int verbose_mode)
{
  // Create a new node
  *tree = mdtm_alloc_node(topology, l, logical, verbose_mode);
  if(*tree == NULL)
	  return;
  (*tree)->parent = (mdtm_node_t*)owner;
  if(l->type == HWLOC_OBJ_PU) return;
  if (l->arity) // || (!i && !l->arity))
  {
	  for (unsigned x = 0; x < l->arity; x++)
		  if (l->children[x]->type != HWLOC_OBJ_PU )
		  {
			  mdtm_insert_from_hwloc(&((*tree)->children[x]), *tree, topology,
					  l->children[x], l, i, logical, verbose_mode);
		  }
  }

  return;
}

void
mdtm_duplicate_node(const mdtm_node_t* oldone, mdtm_node_t **newone) {

  mdtm_node_t * newNode =0;

  newNode = (mdtm_node_t*) malloc(sizeof(mdtm_node_t));
  if(!newNode)
    {
      //assert();
      return;
    }
  memset(newNode, 0, sizeof(mdtm_node_t));

  newNode->numChildren = oldone->numChildren;
  if(oldone->type) newNode->type = strdup(oldone->type);
  if(oldone->name) newNode->name = strdup(oldone->name);

  // retrieve object logical index
  newNode->logical_index = oldone->logical_index;
  newNode->os_index = oldone->os_index;

  // retrieve  object attribute
  if(oldone->attr) newNode->attr = strdup(oldone->attr);

  newNode->online_cpuset= oldone->online_cpuset;
  if(oldone->cpuset) newNode->cpuset = strdup(oldone->cpuset);

  if(oldone->type && !strcmp(oldone->type,"NUMANode")) {
//      mdtm_debug("old NUMA=%p, new NUMA node=%p\n", oldone, newNode);
      if (!first_numa0)
        {
          first_numa0 = newNode;
          first_numa0->prev = first_numa0->next = first_numa0;
          g_nNumas0++;
        }
      else
        {
          mdtm_node_t *last_numa = first_numa0->prev;
          newNode->prev = last_numa;
          newNode->next = first_numa0;
          last_numa->next = newNode;
          first_numa0->prev = newNode;
          g_nNumas0++;
        }
  }

  *newone = newNode;

  return;
}


//TODO: better to move to sched_spt.cpp
void
mdtm_duplicate_tree(const mdtm_node_t *oldtree, mdtm_node_t **newtree, mdtm_node_t *parent) {
  const mdtm_node_t *oldnode = oldtree;
  mdtm_node_t *newnode = 0;

  mdtm_duplicate_node(oldnode, &newnode);
  newnode->parent = parent;

  if(!parent) // || (parent && parent->type && !strcmp(parent->type, "Machine")))
    newnode->parentcost = (unsigned) -1;
  else
    newnode->parentcost = 1;
  newnode->cost = (unsigned)-1;
  *newtree = newnode;

  if(!strcmp(newnode->type, "Core")) return;



  // creating links to children nodes
  for(int i = 0; i < oldtree->numChildren; i++) {
      mdtm_duplicate_tree(oldtree->children[i], &(newnode->children[i]), newnode);
      newnode->childrencost[i]  = 1;
  }

  return;
}

void
mdtm_tree_print_preorder(mdtm_node_t * tree, int level)
{
  if (tree)
    {
      indent(stdout, 2*level);
      if (tree->type)
        mdtm_debug("%s\t", tree->type);
      mdtm_debug("L#%d\t", tree->logical_index);
      if (tree->name)
        mdtm_debug("%s\t", tree->name);
      if((tree->attr) && (tree->type) && strcmp(tree->type,"Machine"))
        mdtm_debug("%s", tree->attr);
      mdtm_debug("\n");
      for (int i = 0; i < tree->numChildren; i++)
        {
          mdtm_tree_print_preorder(tree->children[i],level+1);
        }
    }
}

int
mdtm_online_cpuset(const mdtm_node_t* node, unsigned** ids)
{
  unsigned *temp, count = 0;
  unsigned cpu;
  //const mdtm_node_t *node = disk_node;

  if (!node)
    return 0;

  while (node && (!node->cpuset))
    node = node->parent;

  assert(node);

  temp = (unsigned*) malloc(sizeof(unsigned) * 256);     //TODO: magic number
  if(hwloc_bitmap_weight(node->online_cpuset) == -1)
    return 0;
  hwloc_bitmap_foreach_begin(cpu, node->online_cpuset)
    temp[count++] = cpu;
  hwloc_bitmap_foreach_end();

  *ids = temp;
  return count;
}

// TODO:
void
mdtm_destroy_tree(mdtm_node_t *tree)
{
  //TODO: release resources
//  free(first_device);
//  free(first_numa);
  free(tree);
  first_device = 0; g_nDevices = 0;
  first_numa = 0; g_nNumas= 0;
  tree = 0;
  return;
}

const mdtm_node_t*
mdtm_getnodebyname(const mdtm_node_t *tree, const char* name)
{
  const mdtm_node_t* node = 0;
  if (tree->name && !strcmp(tree->name, name))
    {
      return tree;
    }
  if(tree->type && !strcmp(tree->type, "Core")) return 0;
  for (int i = 0; i < tree->numChildren; i++)
    {
      node = mdtm_getnodebyname(tree->children[i], name);
      if (node)
        return node;
    }

  return 0;
}

int
mdtm_getdevicebyname(const mdtm_node_t *tree,
                     const char *name,
                     struct mdtm_device_s *device)
{
  struct mdtm_node_s *pDevice = first_device;
  int   numa = 0;

  for (int i = 0; i < g_nDevices; i++){
      if(!strcmp(pDevice->name, name)){
          device->name = strdup(pDevice->name);
          if (!strcmp(pDevice->type, "Network") || !strcmp(pDevice->type, "Net")) {
              device->classid = MDTM_DEVICE_CLASS_NETWORK;
              device->attr.network.operstate = strdup(pDevice->attr2.network.operstate);
              device->attr.network.speed = pDevice->attr2.network.speed;
              device->attr.network.type = pDevice->attr2.network.type;
              numa = mdtm_getnumaaffinity(tree,device->name);
              device->numaid = (numa >= 0)? numa : 0;
          }
          if(!strcmp(pDevice->type, "Block")) {
              device->classid = MDTM_DEVICE_CLASS_STORAGE;
              device->attr.storage.devid = pDevice->attr2.storage.devid;
              device->attr.storage.size = pDevice->attr2.storage.size;
              device->attr.storage.type = pDevice->attr2.storage.type;
              numa = pDevice->isconfig? pDevice->ref_numaid : mdtm_getnumaaffinity(tree,device->name);
              device->numaid = (numa >= 0)? numa : 0;
          }
          if(!strcmp(pDevice->type, "Virtual")) {
              device->classid = MDTM_DEVICE_CLASS_VIRTUAL;
//              device->attr.storage.devid = pDevice->attr2.storage.devid;
//              device->attr.storage.size = pDevice->attr2.storage.size;
//              device->attr.storage.type = pDevice->attr2.storage.type;
              numa = pDevice->isconfig? pDevice->ref_numaid : mdtm_getnumaaffinity(tree,device->name);
              device->numaid  = (numa >= 0)? numa : 0;
          }
          return 0;
      }
      pDevice = pDevice->next;
  }
  return -1;
}

int
mdtm_getdevicesbytype(const mdtm_node_t* tree, const char* type,
    struct mdtm_device_s** devices)
{
  struct mdtm_device_s *d;
  struct mdtm_node_s *pDevice = first_device;
  int count = 0;

  if (g_nDevices <= 0)
    return 0;

  d = (mdtm_device_s*) malloc(sizeof(mdtm_device_s) * g_nDevices); //TODO: fix the magic number
  for (int i = 0; i < g_nDevices; i++)
    {
      if (!type || !strcmp(pDevice->type, type))
        {
          d[count].name = strdup(pDevice->name);
          if (!strcmp(pDevice->type, "Network") || !strcmp(pDevice->type, "Net")) {
              d[count].classid = MDTM_DEVICE_CLASS_NETWORK;
              d[count].attr.network.operstate = strdup(pDevice->attr2.network.operstate);
              d[count].attr.network.speed = pDevice->attr2.network.speed;
              d[count].attr.network.type = pDevice->attr2.network.type;
              d[count].numaid = mdtm_getnumaaffinity(tree,d[count].name);
          }
          if(!strcmp(pDevice->type, "Block")) {
              d[count].classid = MDTM_DEVICE_CLASS_STORAGE;
              d[count].attr.storage.devid = pDevice->attr2.storage.devid;
              d[count].attr.storage.size = pDevice->attr2.storage.size;
              d[count].attr.storage.type = pDevice->attr2.storage.type;
              d[count].numaid = pDevice->isconfig? pDevice->ref_numaid : mdtm_getnumaaffinity(tree,d[count].name);
          }
          count++;
        }
      pDevice = pDevice->next;
    }
  *devices = d;
  return count;
}

int
mdtm_getnodesbytype(const mdtm_node_t* tree, const char* type,
    mdtm_node_t** nodes, int *n)
{

  if(!tree) return 0;

  if (tree->type)
    {
      if (!strcmp(tree->type, type))
        {
          (nodes)[*n] = (mdtm_node_t*) tree;
          (*n)++;
          return 0;
        }
    }

  for (int i = 0; i < tree->numChildren; i++)
    {
      mdtm_getnodesbytype(tree->children[i], type, nodes, n);
    }

  return 0;
}

int
mdtm_getdevicesaffinity(const mdtm_node_t* node,
    struct mdtm_device_s* devices, int *n)
{
  int rc = 0;

  if (!node) {
    return -1;
  }

  if (!strcmp(node->type, "Network") || !strcmp(node->type, "Net") || !strcmp(node->type, "Block"))
    {
      devices[(*n)].name = strdup(node->name);
      //if(!strcmp(node->type, "Network") || !strcmp(node->type, "Net"))devices[*n].attr.mac_addr = strdup(node->attr);
//      if (!type || !strcmp(pDevice->type, type))
        {
//          devices[*n].name = strdup(node->name);
          if (!strcmp(node->type, "Network") || !strcmp(node->type, "Net")) {
              devices[*n].classid = MDTM_DEVICE_CLASS_NETWORK;
              devices[*n].attr.network.operstate = strdup(node->attr2.network.operstate);
              devices[*n].attr.network.speed = node->attr2.network.speed;
              devices[*n].attr.network.type = node->attr2.network.type;
              devices[*n].numaid = mdtm_getnumaaffinity(node,node->name);
          }
          if(!strcmp(node->type, "BLOCK")) {
              devices[*n].classid = MDTM_DEVICE_CLASS_STORAGE;
              devices[*n].attr.storage.devid = node->attr2.storage.devid;
              devices[*n].attr.storage.size = node->attr2.storage.size;
              devices[*n].attr.storage.type = node->attr2.storage.type;
              devices[*n].numaid = mdtm_getnumaaffinity(node,node->name);
          }
        }
      (*n)++;
    }

  for (int i = 0; i < node->numChildren; i++)
    {
      rc = mdtm_getdevicesaffinity(node->children[i], devices, n);
    }
  return rc;
}

int
mdtm_getdevicesaffinity2(const mdtm_node_t*node,
    struct mdtm_device_s **devices, int *n)
{
        //TODO: magic number
        *devices = (struct mdtm_device_s*)malloc(sizeof(struct mdtm_device_s)*64);
        memset(*devices, 0, sizeof(struct mdtm_device_s)*64);
        return mdtm_getdevicesaffinity(node, *devices, n);
}

//void
//mdtm_getnumaaffinity1(unsigned cpu)
//{
//  int temp[10];
//  int count = 0;
//  mdtm_node_t *node;
//  hwloc_bitmap_foreach_begin(cpu, node->online_cpuset)
//    temp[count++] = cpu;
//  hwloc_bitmap_foreach_end();
//}

int
mdtm_getnumaaffinity(const mdtm_node_t *tree, const char *device)
{
  const mdtm_node_t * node;
  node = mdtm_getnodebyname(tree, device);

  while(node && strcmp(node->type, "NUMANode")) {
      node = node->parent;
  }

  if(!node)
    return -1;
  else
    return node->logical_index;
}

int
mdtm_getmaxnumberofdevices()
{
  return g_nDevices;
}


static __hwloc_inline void
hwloc_utils_print_distance_matrix(hwloc_topology_t topology, hwloc_obj_t root, unsigned nbobjs, unsigned reldepth, float *matrix, int logical)
{
  hwloc_obj_t objj, obji;
  unsigned i, j;

  /* column header */
  mdtm_debug("  index");
  for(j=0, objj=NULL; j<nbobjs; j++) {
    objj = hwloc_get_next_obj_inside_cpuset_by_depth(topology, root->cpuset, root->depth+reldepth, objj);
    mdtm_debug(" % 5d",
           (int) (logical ? objj->logical_index : objj->os_index));
  }
  mdtm_debug("\n");

  /* each line */
  for(i=0, obji=NULL; i<nbobjs; i++) {
    obji = hwloc_get_next_obj_inside_cpuset_by_depth(topology, root->cpuset, root->depth+reldepth, obji);
    /* row header */
    mdtm_debug("  % 5d",
             (int) (logical ? obji->logical_index : obji->os_index));

    /* row values */
    for(j=0, objj=NULL; j<nbobjs; j++) {
      objj = hwloc_get_next_obj_inside_cpuset_by_depth(topology, root->cpuset, root->depth+reldepth, objj);
      for(j=0; j<nbobjs; j++)
        mdtm_debug(" %2.3f", matrix[i*nbobjs+j]);
      mdtm_debug("\n");
    }
  }
}

//TODO: check if there exist the case that distance_count > 1
//unsigned
//mdtm_getnumadistance(float **matrix) {
//    int logical = 1;
//    unsigned nbobjs, j, i=0;
//    //TODO: assuming there is only one root node and numa distance matrix
//    //nbobjs = hwloc_get_nbobjs_by_depth(topology, 0);
//    //for(j=0; j<nbobjs; j++)
//    {
//      //hwloc_obj_t obj = hwloc_get_obj_by_depth(topology, 0, j);
//      hwloc_obj_t obj = hwloc_get_obj_by_depth(topology, 0, 0);
//      unsigned k;
//      char roottypestring[32];
//      hwloc_obj_type_snprintf (roottypestring, sizeof(roottypestring), obj, 0);
//      for(k=0; k<obj->distances_count; k++)
//      {
//        struct hwloc_distances_s *distances = obj->distances[k];
//        if (!distances->latency)
//          continue;
////        mdtm_debug("Latency matrix between %u %ss (depth %u) by %s indexes (below %s%s%u):\n",
////               distances->nbobjs,
////               hwloc_obj_type_string(hwloc_get_depth_type(topology, i+distances->relative_depth)),
////               i+distances->relative_depth,
////               logical ? "logical" : "physical",
////               roottypestring,
////               logical ? " L#" :  " P#",
////               logical ? obj->logical_index : obj->os_index);
////        hwloc_utils_print_distance_matrix(topology, obj, distances->nbobjs, distances->relative_depth, distances->latency, logical);
//        *matrix = distances->latency;
//        return distances->nbobjs;
//      }
//    }
//}
unsigned
mdtm_getnumadistance(float **matrix) {
    int logical = 1;
    unsigned nbobjs, nmobjs = 0, j, i=0;
    //TODO: assuming there is only one root node and numa distance matrix

    hwloc_obj_t obj = hwloc_get_obj_by_type(topology, HWLOC_OBJ_NODE, 0);
    if(obj == 0)
        return 0;

    assert((obj->depth - 1) >= 0);
    nbobjs = hwloc_get_nbobjs_by_depth(topology, obj->depth - 1);
    assert(nbobjs < 2);
    for(j=0; j<nbobjs; j++)
    {
      hwloc_obj_t obj = hwloc_get_obj_by_depth(topology, 0, j);
      //hwloc_obj_t obj = hwloc_get_obj_by_depth(topology, 0, 0);
      unsigned k;
      char roottypestring[32];
      hwloc_obj_type_snprintf (roottypestring, sizeof(roottypestring), obj, 0);
      assert(obj->distances_count < 2);
      for(k=0; k<obj->distances_count; k++)
      {
        struct hwloc_distances_s *distances = obj->distances[k];
        if (!distances->latency)
          continue;
//        mdtm_debug("Latency matrix between %u %ss (depth %u) by %s indexes (below %s%s%u):\n",
//               distances->nbobjs,
//               hwloc_obj_type_string(hwloc_get_depth_type(topology, i+distances->relative_depth)),
//               i+distances->relative_depth,
//               logical ? "logical" : "physical",
//               roottypestring,
//               logical ? " L#" :  " P#",
//               logical ? obj->logical_index : obj->os_index);
//        hwloc_utils_print_distance_matrix(topology, obj, distances->nbobjs, distances->relative_depth, distances->latency, logical);
        *matrix = distances->latency;
        nmobjs =  distances->nbobjs;
      }
    }
    return nmobjs;
}

void
mdtm_find_disk_near(const char* cpuset, const mdtm_node_t *tree)
{
}

void
mdtm_find_nic_near(const char* cpuset, const mdtm_node_t *tree)
{
}

int
mdtm_create_sys_info(mdtm_node_t        **sysinfo_tree,
                     void               *data)
{
  unsigned long flags = HWLOC_TOPOLOGY_FLAG_IO_DEVICES |
                        HWLOC_TOPOLOGY_FLAG_IO_BRIDGES |
                        HWLOC_TOPOLOGY_FLAG_ICACHES;
  int rc = -1;

  if(!topology && topology_refcount == 0) {
      if ((rc = hwloc_topology_init(&topology)) < 0) {
          perror("hwloc_topology_init failed.");
          return rc;
      }
      hwloc_topology_set_flags(topology, flags);
      hwloc_topology_ignore_type(topology, HWLOC_OBJ_CACHE);
      if ((rc = hwloc_topology_load(topology)) < 0) {//TODO: release resources
          perror("hwloc_topology_load failed.");
          return rc;
      }
      topology_refcount ++;
  }

  mdtm_insert_from_hwloc(sysinfo_tree,
                         NULL,
                         topology,
                         hwloc_get_root_obj(topology),
                         hwloc_get_root_obj(topology),
                         0,
                         1,
                         0);

  mdtm_insert_from_config(*sysinfo_tree, data);

  //TODO: investigate the coupleing of topolgy
  //hwloc_topology_destroy(topology);
  return 0;
}

void
mdtm_delete_sys_info(mdtm_node_t *tree)
{
  mdtm_destroy_tree(tree);
//  if(--topology_refcount <= 0)
//    hwloc_topology_destroy(topology);
//  mdtm_debug("I am ok %p\n", topology);
}

int
mdtm_getdevices(const mdtm_node_t **first)
{
  assert(first);
  *first = first_device;
  return g_nDevices;
}

const
mdtm_node_t *
mdtm_getdevicenodebyname(const char *name)
{
  mdtm_node_t *node = first_device;

  while(node) {
      if(!strcmp(node->name, name))
        break;
      node = node->next;
  }

  return (const mdtm_node_t *)node;
}

const char*
mdtm_nodename(const mdtm_node_t *node)
{
  assert(node);
  return node->name;
}

mdtm_node_t*
mdtm_nextnode(const mdtm_node_t*node)
{
  return node->next;
}

bool
mdtm_isdevice(const mdtm_node_t*node)
{
  if(node &&
     ((!strcmp(node->type,"Block") || !strcmp(node->type,"Network") || !strcmp(node->type,"Net"))))
     return true;
  return false;
}

bool
mdtm_device_isconfig(const mdtm_node_t *node)
{
  return node->isconfig == 1;
}

const char*
mdtm_devicename(mdtm_device_s * dev, int i)
{
  assert(dev);
  return dev[i].name;
}

//const char*
//mdtm_deviceattr(mdtm_device_s *devices, int i)
//{
//  //TODO: more attrs than mac_addr??
//  if(devices[i].attr.mac_addr)
//              return devices[i].attr.mac_addr;
//  return 0;
//}

/* \brief return the topology tree node having the given numa index
 *
 */
mdtm_node_t* mdtm_getnumanode(int numaindex)
{
  mdtm_node_t* node = first_numa;
  int flag_found = 0;

  while(node != 0) {
      if(node->logical_index == numaindex) {
          flag_found = 1;
          break;
      }
      node = first_numa->next;
  }

  return (flag_found? node : 0);
}

#ifdef __cplusplus
}
#endif
