/*
 * mdtm_df.cpp
 *
 *  Created on: Jan 21, 2016
 *      Author: liangz
 */

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

#include <sys/stat.h>
#include <sys/sysmacros.h>

#include <stdbool.h>
#include <sys/types.h>


#ifdef __cplusplus
extern "C" {
#endif

/*
 *  GNU/Linux, 4.3BSD, SunOS, HP-UX, Dynix, Irix
 *
 */

#define         STREQ(a, b)             (strcmp (a, b) == 0)
#define         STREQ_LEN(a, b, n)      (strncmp (a, b, n) == 0)

/* A mount table entry. */
struct mount_entry
{
  char *me_devname;             /* Device node name, including "/dev/". */
  char *me_mountdir;            /* Mount point directory name. */
  char *me_mntroot;             /* Directory on filesystem of device used */
  /* as root for the (bind) mount. */
  char *me_type;                /* "nfs", "4.2", etc. */
  dev_t me_dev;                 /* Device number of me_mountdir. */
  unsigned int me_dummy : 1;    /* Nonzero for dummy file systems. */
  unsigned int me_remote : 1;   /* Nonzero for remote fileystems. */
  unsigned int me_type_malloced : 1; /* Nonzero if me_type was malloced. */
  struct mount_entry *me_next;
};

static struct mount_entry *     global_mount_list = NULL;

/* Desired exit status.  */
static int exit_status;


struct mount_entry *read_file_system_list (bool need_fs_type);
void free_mount_entry (struct mount_entry *entry);

static
struct mount_entry *
mdtm_read_fs_list(bool need_fs_type) {
  struct mount_entry *mount_list;
  struct mount_entry *me;
  struct mount_entry **mtail = &mount_list;
  (void) need_fs_type;
  FILE *fp;
  char const *mountinfo = "/proc/self/mountinfo";

  fp = fopen (mountinfo, "r");
  if (fp != NULL) {
      char *line = NULL;
      size_t buf_size = 0;

      while (getline (&line, &buf_size, fp) != -1) {
          unsigned int devmaj, devmin;
          int target_s, target_e, type_s, type_e;
          int source_s, source_e, mntroot_s, mntroot_e;
          char test;
          char *dash;
          int rc;

          rc = sscanf(line, "%*u "        /* id - discarded  */
              "%*u "        /* parent - discarded */
              "%u:%u "      /* dev major:minor  */
              "%n%*s%n "    /* mountroot */
              "%n%*s%n"     /* target, start and end  */
              "%c",         /* more data...  */
              &devmaj, &devmin,
              &mntroot_s, &mntroot_e,
              &target_s, &target_e,
              &test);

          if (rc != 3 && rc != 7)  /* 7 if %n included in count.  */
            continue;

          /* skip optional fields, terminated by " - "  */
          dash = strstr (line + target_e, " - ");
          if (! dash)
            continue;

          rc = sscanf(dash, " - "
              "%n%*s%n "    /* FS type, start and end  */
              "%n%*s%n "    /* source, start and end  */
              "%c",         /* more data...  */
              &type_s, &type_e,
              &source_s, &source_e,
              &test);
          if (rc != 1 && rc != 5)  /* 5 if %n included in count.  */
            continue;

          /* manipulate the sub-strings in place.  */
          line[mntroot_e] = '\0';
          line[target_e] = '\0';
          dash[type_e] = '\0';
          dash[source_e] = '\0';
//          unescape_tab (dash + source_s);
//          unescape_tab (line + target_s);
//          unescape_tab (line + mntroot_s);

          me = (struct mount_entry *)malloc (sizeof *me);

          me->me_devname = strdup (dash + source_s);
          me->me_mountdir = strdup (line + target_s);
          me->me_mntroot = strdup (line + mntroot_s);
          me->me_type = strdup (dash + type_s);
          me->me_type_malloced = 1;
          me->me_dev = makedev (devmaj, devmin);
          /* we pass "false" for the "Bind" option as that's only
              significant when the Fs_type is "none" which will not be
              the case when parsing "/proc/self/mountinfo", and only
              applies for static /etc/mtab files.  */
//          me->me_dummy = ME_DUMMY (me->me_devname, me->me_type, false);
//          me->me_remote = ME_REMOTE (me->me_devname, me->me_type);

          /* Add to the linked list. */
          *mtail = me;
          mtail = &me->me_next;
      }

      free (line);

      if (ferror (fp))
        {
          int saved_errno = errno;
          fclose (fp);
          errno = saved_errno;
          goto free_then_fail;
        }

      if (fclose (fp) == EOF)
        goto free_then_fail;
  }

  *mtail = NULL;
  return mount_list;

free_then_fail:
  {
    int saved_errno = errno;
    *mtail = NULL;

    while (mount_list)
      {
        me = mount_list->me_next;
        free_mount_entry (mount_list);
        mount_list = me;
      }

    errno = saved_errno;
    return NULL;
  }
}

/* Free a mount entry as returned from read_file_system_list ().  */
void free_mount_entry (struct mount_entry *me)
{
  free (me->me_devname);
  free (me->me_mountdir);
  free (me->me_mntroot);
  if (me->me_type_malloced)
    free (me->me_type);
  free (me);
}

/* Figure out which device file or directory POINT is mounted on
   and show its disk usage.
   STATP must be the result of 'stat (POINT, STATP)'.  */
static
struct mount_entry const*
get_point (const char *point, const struct stat *statp)
{
  struct stat disk_stats;
  struct mount_entry *me;
  struct mount_entry const *best_match = NULL;

  /* Calculate the real absolute file name for POINT, and use that to find
     the mount point.  This avoids statting unavailable mount points,
     which can hang df.  */
  char *resolved = canonicalize_file_name (point);
  if (resolved && resolved[0] == '/')
    {
      size_t resolved_len = strlen (resolved);
      size_t best_match_len = 0;

      for (me = global_mount_list; me; me = me->me_next)
      if (!STREQ (me->me_type, "lofs")
          && (!best_match /*|| best_match->me_dummy || !me->me_dummy*/))
        {
          size_t len = strlen (me->me_mountdir);
          if (best_match_len <= len && len <= resolved_len
              && (len == 1 /* root file system */
                  || ((len == resolved_len || resolved[len] == '/')
                      && STREQ_LEN (me->me_mountdir, resolved, len))))
            {
              best_match = me;
              best_match_len = len;
            }
        }
    }
  free (resolved);
  if (best_match
      && (stat (best_match->me_mountdir, &disk_stats) != 0
          || disk_stats.st_dev != statp->st_dev))
    best_match = NULL;

  if (! best_match)
    for (me = global_mount_list; me; me = me->me_next)
      {
        if (me->me_dev == (dev_t) -1)
          {
            if (stat (me->me_mountdir, &disk_stats) == 0)
              me->me_dev = disk_stats.st_dev;
            else
              {
                /* Report only I/O errors.  Other errors might be
                   caused by shadowed mount points, which means POINT
                   can't possibly be on this file system.  */
                if (errno == EIO)
                  {
//                    error (0, errno, "%s", quote (me->me_mountdir));
                    exit_status = EXIT_FAILURE;
                  }

                /* So we won't try and fail repeatedly. */
                me->me_dev = (dev_t) -2;
              }
          }

        if (statp->st_dev == me->me_dev
            && !STREQ (me->me_type, "lofs")
            && (!best_match /*|| best_match->me_dummy || !me->me_dummy*/))
          {
            /* Skip bogus mtab entries.  */
            if (stat (me->me_mountdir, &disk_stats) != 0
                || disk_stats.st_dev != me->me_dev)
              me->me_dev = (dev_t) -2;
            else
              best_match = me;
          }
      }

  return best_match;
}

/* Determine what kind of node NAME is and show the disk usage
   for it.  STATP is the results of 'stat' on NAME.  */

static
struct mount_entry const *
get_entry (char const *name, struct stat const *statp)
{
//  if (direct_statfs)
//    {
//      char *resolved = canonicalize_file_name (name);
//      if (resolved)
//        {
//          get_dev (NULL, resolved, NULL, NULL, false, false, NULL, false);
//          free (resolved);
//          return;
//        }
//    }

//  if ((S_ISBLK (statp->st_mode) || S_ISCHR (statp->st_mode))
//      && get_disk (name))
//    return;

  return get_point (name, statp);
}

int
mdtm_df_file(const char* path, char **devname) {
  struct mount_entry *  mount_list;
  struct mount_entry const *me = 0;
  struct stat stats;
  int fd;
  int rc = 0;

  if( !path || !devname)
    return -1;

  *devname = 0;

  /* Prefer to open with O_NOCTTY and use fstat, but fall back
               on using "stat", in case the file is unreadable.  */
  fd = open (path, O_RDONLY | O_NOCTTY);
  if ((fd < 0 || fstat (fd, &stats))
      && stat (path, &stats))
    rc = -1;

  if (0 <= fd)
    close (fd);

  if(rc == -1)
    return -1;

  if(global_mount_list == NULL)
    if((global_mount_list =
        mdtm_read_fs_list(0)) == NULL) {
        close(fd);
        return -1;
    }

  me = get_entry (path, &stats);
  if(me)
    *devname = strdup(me->me_devname);

  return me? 1 : 0;
}

#ifdef __cplusplus
}
#endif



