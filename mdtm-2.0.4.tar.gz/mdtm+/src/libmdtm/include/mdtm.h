/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

/*
 * mdtm - multicore-aware data transfer middleware routines
 *
 *      link with -lmdtm
 *
 * mdtm_show_version() - Version of the library.
 *
 * ==== Create and delete mdtm internal data structures: topo, spt... ====
 * mdtm_init(op_mode) - Create mdtm module with op_mode mode
 * mdtm_deinit() - Delete mdtm module
 * mdtm_is_inited() - Check if mdtm module inintialized
 *
 * ==== Query current system topology ====
 * mdtm_getcpuaffinity(devicename, mdtm_cpuset) - Get the set of CPUs local to the device
 * mdtm_getpcidevices(devices) - Get the list of devices in current system
 * mdtm_numa_nodes() - Get the number of NUMA nodes in current system
 * mdtm_numa_nodesize(node, total, free) - Get the total and free memory size of given NUMA node
 *
 * ==== Create and delete file map ====
 * mdtm_findfilemap(pathname) - Create map for the file in the path
 * mdtm_destroyfilemap(filemap) - Delete the file map
 *
 * ==== Schedule threads and display results ====
 * mdtm_schedule_threads(thread_descs, numofdescs) - Schedule threads in thread_descs
 * mdtm_sched_per_single_device(thread_desc, tree) - Schedule one thread based on its first local device
 * mdtm_printpath(char* srcdev, char* dstdev, void *tree)
 * mdtm_printschedresult(char* srcdev, char* dstdev, void *tree);
 * mdtm_place_threads(thread_descs, numofdescs, cpus, numofcpus) - Place threads on CPU cores
 *
 * ==== Create, retrieve and delete pipes ====
 * mdtm_pipe_init(count, size) - Create count of pipes with size on each NUMA
 * mdtm_pipe_get(numa_idx, ask, pipe) - Allocate a pipe with size on NUMA numa_idx
 * mdtm_pipe_put(numa_idx, pipe) - Release pipe on NUMA numa_idx
 * mdtm_pipe_allocated(numa_idx) - Return the pipes already allocated
 * mdtm_pipe_drain(pipefd, size, flag) - Drain pipe buffer
 * mdtm_pipe_check(mdtmpipefd*) - Check the validation of pipe
 * mdtm_pipe_destroy() - Delete pipes
 *
 * ==== Allocate, free and query numa-aware memory ====
 * mdtm_local_memory_init(mem_info, node_isze, node_count, loca_ref, ref_num) - Initialize local memory
 * mdtm_loc_malloc(numa, size) - Allocate memory with size from node numa
 * mdtm_loc_malloc2(numa, addr, size) - Allocate memory with size from node numa
 * mdtm_loc_mfree(mem, size) - Free memory.
 *
 * ==== Query, change and add task to MDTM Zones ====
 * mdtm_zone_getmask(cpus, mems) - Get cpu and mem bitmasks for current MDTM Zone
 * mdtm_zone_setmask(cpus, mems) - Set MDTM Zone to cpus and mems bitmasks
 * mdtm_zone_movetask(pid_t pid) - Move the task to the MDTM Zone.
 * mdtm_zone_migratetask(pid_t pid) - Move task and its memory to the MDTM Zone
 *
 * ==== Utilities: file location ====
 * mdtm_map_file(path, devname, devname_len) - Find the device on which the file in path is stored
 * mdtm_map_file2(path, filesystem, segments) - Find the file system and device where the file is stored
 * mdtm_map_file_free(segments) - Release the resources used by segments and etc. for mapping
 * mdtm_map_getfilesystem(path) - Find the file system of the given file
 * mdtm_find_numa_of_file(path) - Find the NUMA node local to the storage device containing the file in path
 * mdtm_find_numa_of_dev(path) - Find the NUMA node local to the storage device containing the file in path
 *
 * ==== Parsing the configuration file =====
 * mdtm_config_init() - Read the configuration file to initialize internal data
 * mdtm_config_get_maxfilesize() - Get the maximum size of file to be segmented to transfer
 * mdtm_config_get_netif(char*devname, int len) - Get the network interface
 * mdtm_config_get_threadsperdevice(devname) - Get the number of threads to be allocated for device
 * mdtm_config_getpcidevices(devices) - Get online device info
 * mdtm_config_get_ncpu - Get CPU numbers for each device type
 * mdtm_config_get_cpus - Get CPU index for each device type
 * mdtm_config_getconfigfilepath - Get the path to server configuration file
 *
 * ==== Create, insert and remove item to the internal map data structure =====
 * mdtm_map_create() - Bounce up the number of entries in the internal map
 * mdtm_map_insert(handle, key, eventq) - Insert the key and evenq pair to the map
 * mdtm_map_remove(handle, key) - Remove the entry with the given key
 *
 * ==== Create, convert, find, clone and exam data structure dir_queue ====
 * mdtm_dir_queue_create(pathname) - Create a list, dir_queue, of all files and directories under pathname
 * mdtm_dir_queue_destroy(queue) - Destroy the dir_queue object
 * mdtm_dir_queue_dequeue(queue) - Remove the first file entry in the dir_queue
 * mdtm_dir_queue_dequeue2(queue) - Remove the first file entry in the dir_queue
 * mdtm_dir_queue_peek(queue, path) - Peek the first file entry in the dir_queue
 * mdtm_dir_queue_iter(queue) - Iterate and print out the dir_queue
 * mdtm_dir_queue_maxfilesize - Return the maximum size of files in dir_queue
 * mdtm_dir_queue_chown_dir(queue, username) -  Change the owner of the directories in the dir_queue
 * mdtm_dir_queue_find(queue, offset, entry) - Search for entry around the offset in the dir_queue
 * mdtm_dir_queue_find2(queue, offset, entry) - Search for entry around the offset in the dir_queue
 * mdtm_dir_queue_find3(queue, offset, entry) - Search for entry around the offset in the dir_queue
 * mdtm_dir_queue_create_meta(queue, meta) - Create meta data from the dir_queue
 * mdtm_dir_queue_create_meta2(queue, meta) - Create meta data from the dir_queue
 * mdtm_dir_queue_create_meta3(queue, meta) - Create meta data from the dir_queue
 * mdtm_dir_queue_parse_meta(queue, meta) - Parse the meta to the dir_queue and write to disk
 * mdtm_dir_queue_parse_meta2(queue, meta) - Parse the meta to the dir_queue and write to disk
 * mdtm_dir_queue_parse_meta_only(queue, meta) - Parse the meta to the dir_queue only
 * mdtm_dir_queue_empty(queue) - Check if the dir_queue is empty of regular files and fifo
 * mdtm_dir_queue_empty_dir(queue) - Check if the dir_queue is empty of directory entries
 * mdtm_dir_queue_clone(queue) - Clone the given dir_queue
 * mdtm_dir_queue_size(queue, opts) - Return the size of dir_queue
 * mdtm_dir_queue_blocks(queue, opts) - Return block number for names in dir_queue
 * mdtm_dir_queue_compare(source, destination) - Compare two dir_queues
 * mdtm_dir_queue_addfile(queue, file) - Add file to the dir_queue
 * mdtm_dir_queue_addpaths(queue, path_array,..) - Add paths in the array to the dir_queue
 *
 */
#ifndef MDTM_H_
#define MDTM_H_

#include <sched.h>
#include <pthread.h>
#include <sys/types.h>

#include "bitmask.h"
#include "cpuset.h"

#ifdef __cplusplus
extern "C"
{
#endif

/* MDTM function return code */
#define MDTM_SUCCESS            (0)
#define MDTM_FAILURE            (-1)
#define MDTM_ERR_BASE           (-1)
#define MDTM_ERR_INVADL         (MDTM_ERR_BASE - 1)
#define MDTM_ERR_NOMEM          (MDTM_ERR_BASE - 2)
#define MDTM_ERR_NOENT          (MDTM_ERR_BASE - 3)
#define MDTM_ERR_NOTSUPPORT     (MDTM_ERR_BASE - 4)
#define MDTM_ERR_NOEXTENT       (MDTM_ERR_BASE - 5)

/* MDTM Operating Mode */
typedef enum {
  MDTM_OPMODE_UNKNOWN = -1,
  MDTM_OPMODE_DEFAULT = 0,
  MDTM_OPMODE_CLIENT,
  MDTM_OPMODE_SERVER
} mdtm_optmode_t;

struct cpu_descript_s
{
  int index;
  int load;
};

typedef struct mdtm_cpuset_s
{
  int numofcpu;
  struct cpu_descript_s *cpus;
} mdtm_cpuset_t;

struct mdtm_io_s;

/** \brief mdtm file segment structure */
typedef struct mdtm_FileSeg {

    /** \Start point of this segment */
    long long offset;

    /** \Size of this segment */
    long long size;

    /** \Local numa node this seg will be read/write from/to */
    int local_node;

    /** \Storage device this seg will be read/write from/to */
    struct mdtm_io_s *storage_dev;

} mdtm_FileSeg_t;

/** \brief mdtm file map structure */
struct mdtm_FileMap {

   /** \The absolute pathname of the target file*/
    char *pathname;//   [MDTM_MAX_PATHNAME];

    /** \Number of segments in the linked list*/
    int seg_num;

    /** \All segments belong to the target file*/
    mdtm_FileSeg_t *fileseg;
};

#define MDTM_THREAD_TYPE_IO     (0)
#define MDTM_THREAD_TYPE_MAN    (1)
#define MDTM_THREAD_MAX_DEVICE  (8)     //max. hosting devices for io thread
#define MDTM_CPUBIND_PROC       (0x01)
#define MDTM_CPUBIND_THREAD     (0x02)
typedef struct {
  unsigned char flags;                          // [IN] indicate "id" is tid or pid
  int           type;                           // [IN] device type: MDTM_DEVICE_CLASS_NETWORK...
  union {
    pid_t pid;
    pthread_t tid;
  } id;                                         // [IN] thread id to schedule
  char* devices[MDTM_THREAD_MAX_DEVICE];        // [IN] device name to schedule
  int   numaindex;                              // [OUT] #numa scheduled for thread
  unsigned boundcpu;                            // [OUT] #core scheduled for thread
}mdtm_thread_desc_t;

#define MDTM_DEVICE_CLASS_NETWORK       0x01
#define MDTM_DEVICE_CLASS_STORAGE       0x02
#define MDTM_DEVICE_CLASS_VIRTUAL       0x10

#define MDTM_STREAM
#define MDTM_STREAM_PIPE_SIZE           (0x0100000000000000UL - 1)

struct mdtm_device_s
{
  char *name;
  unsigned classid;
  unsigned numaid;

  union props_u {
    struct {
      unsigned long speed;      // speed
      unsigned type;            // 1: ethernet 32:ib
      char *operstate;          // up or down
    } network;
    struct {
      unsigned devid;           //dev_t
      unsigned type;            //rotational: 1--HDD other--SSD
      unsigned long long size;       // 512-byte blocks
    }storage;
  }attr;
};

typedef struct {
  unsigned type;
  union {
    char* name;
    int   handle;
  } id;
} mdtm_location_ref_t;

typedef struct {
  unsigned char *       buffer;                 // data buffer
  long long             offset;                 // file offset
  size_t                size;                   // file size in bytes
  char                  path[256];              // file full path
  size_t                buffer_len;             // data buffer length
} mdtm_file_entry_t;

typedef struct _LV_SEG_ {
  uint64_t      m_start;
  uint64_t      m_end;
  char*         dev;
} mdtm_lv_seg_t;

#define MDTM_DIR_QUEUE_SIZE_FILE        0x01
#define MDTM_DIR_QUEUE_SIZE_DIR         0x02
#define MDTM_DIR_QUEUE_SIZE_FIFO        0x03

#define MDTM_META_ENTRY_SIZE            512

#define MDTM_PIPEDRAIN_CLOSE            0x01
#define MDTM_PIPEDRAIN_DRAIN            0x02

#define MDTM_DEFAULT_NUMAS              16


/**
 *  \brief Return the version of MDTM library.
 *
 *  It returns the MDTM library version as well as those of supporting libraries.
 *
 *  @param None
 *  @return The pointer to the version string.
 */
const char*
mdtm_show_version();

/**
 *  \brief Initialization of the MDTM module.
 *
 *  This function initializes MDTM objects and thus should be the first function to call
 *  before any other MDTM functions.
 *
 *  In practice, MDTM module could serve user applications in two ways: MDTM functions
 *  complete services in the same process as the user application or they relay the
 *  requested services to a running back-end daemon which completes and return results.
 *  Therefore this function needs the caller to pass in the operation mode parameter,
 *  MDTM_OPMODE_NONE, MDTM_OPMODE_SERVER or MDTM_OPMODE_CLIENT, which identifies how
 *  MDTM functions deal with caller's service requests.
 *
 *  MDTM_OPMODE_DEFAULT: no client/daemon: services completed in the current process
 *  MDTM_OPMODE_CLIENT: for user applications: relay service requests to daemon
 *  MDTM_OPMODE_SERVER: for daemons: receive and complete service requests from clients
 *
 *  @param op_mode      one of the operating modes: MDTM_OPMODE_DEFAULT, MDTM_OPMODE_CLIENT
 *                      and MDTM_OPMODE_SERVER
 *
 *  @return If successful, return 0; otherwise return a negative number.
 */
int
mdtm_init(mdtm_optmode_t op_mode);

/**
 *  \brief De-initialization of the MDTM module.
 *
 *  It releases all resources occupied by MDTM module.
 *
 *  @param None
 *  @return None.
 */
void
mdtm_deinit(void);

int
mdtm_is_inited(void);

/**
 *  \brief Poll the IPC task queue
 *
 *  This function will block until there is a ready task in the queue or an internal
 *  timeout (default 1ms). It is exclusively used by the mdtm daemon.
 */
int
mdtm_poll(void);

/**
 *  \brief Return CPUs in affinity of the given device.
 *
 *  This function return a list of CPUs that are in affinity of the given device.
 *
 *  @param devicename   device name in string.
 *  @param cpuset       pointer to a list of the CPUs
 *
 *  @return If failed, return a negative number.
 */
int
mdtm_getcpuaffinity(char* devicename, mdtm_cpuset_t **cpuset);

/**
 *  \brief Return the list of devices in the system.
 *
 *  This function return a list of devices detected or configured in the system.
 *
 *  @param devicename   device name in string.
 *  @param cpuset       pointer to a list of the CPUs
 *
 *  @return If failed, return a negative number.
 */
int
mdtm_getpcidevices(struct mdtm_device_s** devices);

/**
 * \brief Return the number of NUMA nodes in the current system
 */
int
mdtm_numa_nodes(void);

/**
 * \brief Return the memory size of NUMA node in the current system
 */
long long
mdtm_numa_nodesize(int node, long long *freep);


/** \brief Find the file distribution according the file name
 *
 *  It decomposes the file into single/multiple segement(s) according to the storage device(s) it will be read/write from/to
 *
 *  @param      pathname  The  absolute pathname of the target file. Its length is no more than MDTM_MAX_PATHNAME.
 *  @return     struct mdtm_FileMap *: success      NULL: failed
 */
struct mdtm_FileMap *mdtm_findfilemap (const char *pathname);

/** \brief Release associated resources to mdtm_FileMap object
 *
 */
void
mdtm_destroyfilemap(struct mdtm_FileMap *map);

/** \brief Schedule and pin user threads on CPU cores.
 *
 *  MDTM schedules the provided set of threads on CPU cores with predefined scheduling policy,
 *  especially the locality. Those threads are to be pinned to selected cores.
 *
 *  thread_descs is an array of thread descriptors which contain info about the threads to be
 *  scheduled and the scheduling results as well. The thread descriptor is defined as,
 *
 *  typedef struct {
 *          unsigned char flags;
 *          int           type;
 *          union {
 *              pid_t pid;
 *              pthread_t tid;
 *          } id;
 *          char* devices[MDTM_THREAD_MAX_DEVICE];
 *          int   numaindex;
 *          unsigned boundcpu;
 *  }mdtm_thread_desc_t;
 *
 *  where "id" and "devices" are input parameters, which are the thread id and device name to schedule; "numaindex"
 *  and "boundcpu" are output parameters which contain the #numa and #core to which the thread is bound to.
 *
 *
 *  @param thread_descs      The set of thread descriptors.
 *  @param numofdescs        The number of the set.
 *  @return
 **/
int
mdtm_schedule_threads(mdtm_thread_desc_t *thread_descs, int numofdescs);

/** \brief Schedule and pin user threads on CPU cores.
 *
 *  MDTM places the provided set of threads on given CPU cores. There exists one-to-one mapping relationship
 *  between the threads and cpu cores. Those threads are to be pinned to those cores.
 *
 *  This function provides an alternate to the schedule_threads() to let the user to choose the cpu cores to
 *  run the threads rather than the scheduler to make the choice.
 *
 *  thread_descs is an array of thread descriptors which contain info about the threads to be
 *  scheduled and the scheduling results as well. The thread descriptor is defined as,
 *
 *  typedef struct {
 *          unsigned char flags;
 *          int           type;
 *          union {
 *              pid_t pid;
 *              pthread_t tid;
 *          } id;
 *          char* devices[MDTM_THREAD_MAX_DEVICE];
 *          int   numaindex;
 *          unsigned boundcpu;
 *  }mdtm_thread_desc_t;
 *
 *  where "id" and "devices" are input parameters, which are the thread id and device name to schedule; "numaindex"
 *  and "boundcpu" are output parameters which contain the #numa and #core to which the thread is bound to.
 *
 *
 *  @param thread_descs      The set of thread descriptors.
 *  @param numofdescs        The number of the set.
 *  @param cpus              The set of cpu cores.
 *  @param numofcpus         The number of the cpu cores
 *  @return
 **/
int
mdtm_place_threads(mdtm_thread_desc_t *thread_descs, int numofdescs, int *cpus, int numofcpus);

/** \brief Schedule and pin the given user thread on one CPU core.
 *
 *  MDTM schedules the given thread on a CPU core with predefined scheduling policy,
 *  especially the locality. That thread is to be pinned to selected core. See
 *  mdtm_schedule_threads() comments for more information.
 *
 *
 *  @param desc              description of thread to be scheduled.
 *  @param numofdescs        topology tree.
 *  @return                  #cpu if succeeds, negative if fails
 **/
int
mdtm_sched_per_single_device(mdtm_thread_desc_t* desc, void *tree);

/** \brief Schedule and pin the given user thread on one cpu core from numa.
 *
 ** MDTM schedules the given thread on a CPU core with predefined scheduling policy,
 ** especially the locality. That thread is to be pinned to selected core.
 **
 **
 ** @param desc              description of thread to be scheduled.
 ** @param numa              #numa the destination cpu core locates.
 ** @return                  #cpu if succeeds, negative if fails
 **/
int
mdtm_sched_per_single_device_on_numa(mdtm_thread_desc_t* desc, int numa);

void
mdtm_printpath(char* srcdev, char* dstdev, void *tree);

void
mdtm_printschedresult(char* srcdev, char* dstdev, void *tree);

int
mdtm_pipe_init(int optimal_count, size_t pipesize);

void *
mdtm_pipe_get(int numa_idx, unsigned int unused, void **pipe);

/** \brief Return the number of allocated pipes on given NUMA node.
 *
 *  Retrieve and return the number of allocated pipe on the given NUMA node.
 *  If numa_idx is less than 0, it return all pipes on the system.
 *
 *  @numa_idx              	 the index of NUMA node.
 *  @return                  if success, the pipes allocated; if failed -1.
 **/
int
mdtm_pipe_allocated(int numa_idx);

int
mdtm_pipe_put(int numa_idx, void* pipe);

int
mdtm_pipe_drain(int pipefd, int size, int flag);

int
mdtm_pipe_check(void *mpipe);

int
mdtm_pipe_destroy();

int
mdtm_local_memory_init(
    void* mem_info,
    int node_size,
    int node_count,
    mdtm_location_ref_t *loc_ref,
    int ref_num);

/*  \brief Allocate location aware memory.
 *  It allocates size of memory and locks it to the specified NUMA node.
 *  @param             numa        numa node index
 *  @param             size        size of memory to allocate
 *  @return            On success this function return the address. On error, NULL is returned.
 */
void*
mdtm_loc_malloc(unsigned numa, size_t size);

/* \brief
 * Allocate location aware memory. version 2
 * numa:        numa node index
 * addr:        pointer to the memory address
 * size:        size of memory to allocate
 * On success this function return 0. On error, -1 is returned.
 */
int
mdtm_loc_malloc2(unsigned numa, void**addr, size_t size);

/* \brief
 * release location aware memory
 */
void
mdtm_loc_mfree(void* mem, int size);

/* \brief
 *  Get and set cpu bitmask, mem bitmask and pid list for current MDTM cpuset
 */
int
mdtm_cpuset_get(struct bitmask *cpus, struct bitmask *mems);
int
mdtm_cpuset_set(struct bitmask *cpus, struct bitmask *mems);
int
mdtm_cpuset_getpids(const struct cpuset_pidlist *pl);
int
mdtm_cpuset_addpid(pid_t pid);

/* \brief Find the disk on which the file is located
 *
 *      This function return the disk name for the given file.
 *
 *      @param  path    the file's full path
 *      @param  buff    the pointer to the buffer to contain the disk name
 *      @param  buf_len the size of the buff
 *      @return On success, it returns MDTM_SUCCESS, otherwise the MDTM_FAILURE or
 *              error code.
 */
int
mdtm_map_file(char* path, char* devname, int devname_len);

/* \brief Find the disks on which the file in given path and its extents are located
 *
 *      This function checks the path recursively to find the associated file system.
 *      If it is LVM, then further dig out the related device for each segments. If
 *      it is a non-LVM, return the found device.
 *
 *      @param  path            the file's full path    [IN]
 *      @param  filesystem      the pointer to the file system name     [OUT]
 *      @param  segments        the pointer to the buffer to contain the disk name      [OUT]
 *
 *      @return On success, it returns the number of segments and the devices in
 *              segments; otherwise -1.
 */
int
mdtm_map_file2(const char* path, char** filesystem, mdtm_lv_seg_t** segments);

void
mdtm_map_file_free(mdtm_lv_seg_t* segments, int n);

/* \brief Return the name of file system for the given file path
 *
 *      @param  filepath    	[IN] the path to file
 *      @param  filesystem    	[OUT] the path to file
 *      @return            	On success, it returns the NUMA index. Or <0 if failed.
 */
int
mdtm_map_getfilesystem(const char* filepath, char** filesystem);

/* \brief       Find the device on which the file is saved
 *
 * It analyzes the file path and resovles the OS device name on which the file is saved
 *
 * @param       path            The full path of file
 *
 * @return      On success, it returns uma node index. On error, -1 is returned.
 */
int
mdtm_find_numa_of_file(char *path);

/* \brief Find the index of NUMA containing the device
 *      It return the NUMA index where the device containing the file locates
 *
 *      @param  devname    the full path to the file
 *      @return            On success, it returns the NUMA index. Or <0 if failed.
 */
int
mdtm_find_numa_of_dev(char *devname);

/* \brief Initialize mdtm parameters from the configuration file
 *      It opens the mdtm configuration file and reads the mdtm parameters.
 *      If the path is NULL, try mdtmconfig.json and mdtmconfig.xml in the working
 *      directory and then the system directory /etc/mdtm.
 *
 *      @param  path        the full path to the configuration file
 *      @return             On success, it returns 0. Or <0 if failed.
 */
int
mdtm_config_init(const char * path);

long long
mdtm_config_get_maxfilesize();

int
mdtm_config_get_netif(char*devname, int len);

int
mdtm_config_get_threadsperdevice(char* devname);

/* \brief       Return info of online devices from configuration file
 *
 *              This function check and return information of  online device
 *              specified in the configuration file.
 *
 * @param       devices            pointer to the device information array
 *
 * @return      it returns the number of online devices found in system
 *              topology tree.
 */
int
mdtm_config_getpcidevices(struct mdtm_device_s** devices);

int
mdtm_config_get_ncpu(int *nstorage, int *nnetwork, int *nvirtual);

int
mdtm_config_get_cpus(int *storages, int s, int *networks, int n, int*viruals, int v);

const char *
mdtm_config_getconfigfilepath(void);

int
mdtm_map_create();

void*
mdtm_map_insert(int handle, void*key, void *eventq);

void*
mdtm_map_remove(int handle, void *key);

/* \brief       Create a list, dir_queue, of all files and directories under pathname
 *
 * It traverses the given path and returns a list of files and directories sorted by
 * their physical location on the disk
 *
 * @param       pathname    The name of new owner
 *
 * @return      On success, it returns a dir_queue object. On error, NULL is returned.
 */
void*
mdtm_dir_queue_create(const char* pathname);

/* \brief       Destroy the list, dir_queue, releasing resources
 *
 * It releases the resources used by dir_queue object.
 *
 * @param       q    the object of dir_queue
 *
 * @return
 */
void
mdtm_dir_queue_destroy(void *q);

/* \brief       Remove the first file entry of dir_queue and return its full path name
 *
 * It removes the first file entry of dir_queue and return its full path name.
 *
 * @param       q    the object of dir_queue
 *
 * @return      the full path name of file
 */
const char*
mdtm_dir_queue_dequeue(void* q);

char*
mdtm_dir_queue_dequeue2(void* q, char *filepath);

/* \brief       Check the first file entry in the directory queue
 *
 * It checks the directory queue and return the reference to the first element
 *
 * @param       q            Pointer to the directory queue
 *
 * @return      On success, it returns the file name of the first entry. On error, NULL is returned.
 */
char*
mdtm_dir_queue_peek(void* q, char *filepath);

/* \brief       Print out entry information in the directory queue
 *
 * It checks the directory queue and return the information
 *
 * @param       q            Pointer to the directory queue
 *
 * @return
 */
void
mdtm_dir_queue_iter(void* q);

/* \brief       Return the max. size of files in queue
 *
 * It checks the directory queue and return the maximum size of files in queue
 *
 * @param       q            Pointer to the directory queue
 *
 * @return      On success, it returns the maximum size. On error, -1 is returned.
 */
long long
mdtm_dir_queue_maxfilesize(void* q);

/* \brief       Change the owner of directories in the directory queue
 *
 * It iterates through the directory queue and change the ownership of each directory to the given
 * username
 *
 * @param       q            Pointer to the directory queue
 * @param       useraname    The name of new owner
 *
 * @return      On success, it returns 0. On error, -1 is returned.
 */
int
mdtm_dir_queue_chown_dir(void* q, char* username);

/* \brief       Search for entry around the offset in the dir_queue
 *
 * Return the directory queue entry for the queue offset in bytes.
 * mdtm_dir_queue_find3 used a modified sequential search to take advantage of
 * the almost-sorted arrival pattern which archives the optimal performance.
 */
int
mdtm_dir_queue_find(
    void* q,
    long long offset,
    mdtm_file_entry_t *entry);

int
mdtm_dir_queue_find2(
    void* q,
    long long offset,
    mdtm_file_entry_t *entry);

int
mdtm_dir_queue_find3(
    void* q,
    long long offset,
    mdtm_file_entry_t *entry);

/* \brief       Create meta data from the dir_queue
 *
 * These group of functions travers the directory queue and create meta data in GNU format.
 *
 * mdtm_dir_queue_create_meta() - obsolete
 * mdtm_dir_queue_create_meta2() - it saves paths excluding precedent of the root.
 *                                 i.e. /home/linux/x ==> linux/x; it also
 *                                 requires the paths are accessible.
 * mdtm_dir_queue_create_meta3() - it saves paths including its parent.
 *                                 i.e. /home/linux/x; it dose NOT
 *                                 requires the paths are accessible.
 *
 * @param       q            Pointer to the directory queue
 * @param       meta         Pointer to the meta data
 *
 * @return
 */
void
mdtm_dir_queue_create_meta(void* q, const char* meta);

long long
mdtm_dir_queue_create_meta2(
    void* q,
    void* buff,
    size_t buffSize);

long long
mdtm_dir_queue_create_meta3(
    void* q,
    void* buff,
    size_t buffSize);


/* \brief       Parse meta data to dir_queue
 *
 * The group of functions parse meta data in GNU format and save to the directory queue.
 *
 * mdtm_dir_queue_parse_meta() - obsolet.
 * mdtm_dir_queue_parse_meta2() - writes the directory to disk.
 * mdtm_dir_queue_parse_meta_only() - only parse meta without writing to disk.
 *
 * @param       q            Pointer to the directory queue
 * @param       meta         Pointer to the meta data
 * @param       target_root  Pointer to the root
 *
 * @return
 */
//FIXME: add return value
void
mdtm_dir_queue_parse_meta(void* q, const char* meta);

void
mdtm_dir_queue_parse_meta2(
    void* q,
    const char* buff,
    size_t buf_size,
    char* target_root);

void
mdtm_dir_queue_parse_meta_only(
    void* q,
    const char* buff,
    size_t buf_size,
    char* target_root);

/* \brief       Check if the directory queue is empty of regular files and fifo
 *
 * It checks the directory queue and return the result
 *
 * @param       q            Pointer to the directory queue
 *
 * @return      On success, it returns 1 (empty) or 0 (not empty). On error, -1 is returned.
 */
int
mdtm_dir_queue_empty(void* q);

/* \brief       Check if the directory queue is empty of directory entries
 *
 * It checks the directory queue and return the result
 *
 * @param       q            Pointer to the directory queue
 *
 * @return      On success, it returns 1 (empty) or 0 (not empty). On error, -1 is returned.
 */
int
mdtm_dir_queue_empty_dir(void* q);

/* \brief       Duplicate the directory queue
 *
 * It clones the given directory queue and return it
 *
 * @param       srcq         Pointer to the directory queue
 *
 * @return      On success, it returns the pointer to the new directory. On error, NULL is returned.
 */
void*
mdtm_dir_queue_clone(void* srcq);

/* \brief       Check the size of the directory queue
 *
 * It returns the number of entries in directory queue.
 *
 * @param       q         Pointer to the directory queue
 * @param       opts      Flag to control what entries would be count
 *
 * @return      On success, it returns the number of the  directory queue entries. On error, 0 is returned.
 */
int
mdtm_dir_queue_size(void* q, unsigned char opts);

/* \brief       Check the number of blocks containing all names in the directory queue
 *
 * It returns the number of blocks to contain all names in directory queue.
 *
 * @param       q         Pointer to the directory queue
 * @param       opts      [NOT USED] Flag to control what entries would be count.
 *
 * @return      On success, it returns the number of blocks. On error, 0 is returned.
 */
long
mdtm_dir_queue_blocks(void* q, unsigned char opts);

/* \brief       Compare two directory queues
 *
 * It compares two directory queues.
 *
 * @param       srcq      Pointer to the directory queue
 * @param       dstq      Pointer to the directory queue
 *
 * @return      If same, it returns 1. otherwise, 0 is returned.
 *
 * NOTE: Not finished. Do not use it.
 */
int
mdtm_dir_queue_compare(void* srcq, void* dstq);

/* \brief       Add file to the dir_queue
 *
 * It adds the path to directory queue.
 *
 * @param       q      Pointer to the directory queue
 * @param       path   Full path of file
 * @size        size   File size
 *
 * @return      If success, it returns 0. otherwise, -1 is returned.
 */
int
mdtm_dir_queue_addfile(
    void *      q,
    char *      path,
    size_t      size);

/* \brief       Add paths to the dir_queue
 *
 * It add the paths in the array to the directory queue.
 *
 * @param       q      Pointer to the directory queue
 * @param       path   Full path of file
 * @size        size   File size
 *
 * @return      If success, it returns 0. otherwise, -1 is returned.
 */
int
mdtm_dir_queue_addpaths(
    void *      q,
    char **     path_array,
    size_t *    size_array,
    int         array_size);

/* \brief       Get the cpus and memory nodes in the current MDTM zone
 *
 * It returns the cpu cores and memory nodes from MDTM zone in bitmask.
 *
 * @param       cpus      bitmask for the cpu cores
 * @param       mems      bitmask for the memory nodes
 *
 * @return      If succeed, it returns 0. otherwise, negative is returned.
 *
 */
int
mdtm_zone_getmask(struct bitmask *cpus, struct bitmask *mems);

/* \brief       Set the cpus and memory nodes in the current MDTM zone
 *
 * It sets the cpu cores and memory nodes from MDTM zone.
 *
 * @param       cpus      bitmask for the cpu cores
 * @param       mems      bitmask for the memory nodes
 *
 * @return      If succeed, it returns 0. otherwise, negative is returned.
 *
 */
int
mdtm_zone_setmask(struct bitmask *cpus, struct bitmask *mems);

/* \brief       Move given process to the current MDTM zone
 *
 * It moves given process to the MDTM zone.
 *
 * @param       pid       process id to move
 *
 * @return      If succeed, it returns 0. otherwise, negative is returned.
 *
 */
int
mdtm_zone_movetask(pid_t pid);

/* \brief       Migrate given process to the current MDTM zone
 *
 * It migrate given process to the MDTM zone.
 *
 * @param       pid       process id to move
 *
 * @return      If succeed, it returns 0. otherwise, negative is returned.
 *
 */
int
mdtm_zone_migratetask(pid_t pid);

/* \brief       Return the sector size of the
 *
 * It migrate given process to the MDTM zone.
 *
 * @param       pid       process id to move
 *
 * @return      If succeed, it returns 0. otherwise, negative is returned.
 *
 */
int
mdtm_blockdevice_sectorsize(const char* filepath);


#ifdef __cplusplus
}
#endif

#endif /* MDTM_H_ */
