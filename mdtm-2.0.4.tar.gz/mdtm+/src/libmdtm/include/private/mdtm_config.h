/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_CONFIG_H_
#define MDTM_CONFIG_H_

#include <vector>
#include <map>
#include <string>
//#include <string.h>
#include "../tinyxml/tinyxml.h"

class mdtmdevice
{
public:
  mdtmdevice();
  virtual   ~mdtmdevice();
  char*     setname(const char*);
  char*     getname();
  int       setattr(int attr, const char* cvalue);
  char*     getattr(int attr);
  int       getattr_int(int attr);
public:
  static const int MDTM_DEV_ATTR_TYPE = 0;
  static const int MDTM_DEV_ATTR_NUMA = 1;
  static const std::string MDTM_CONFIG_DEFAULT_PATH;
  static const std::string type_virtual;
  static const std::string type_block;
  static const std::string type_network;
protected:
  char  name[64];
  int   namelen;
  int   type;
  int   numa;
  struct char_cmp {
    bool operator () (const char *a,const char *b) const
    {
      return strcmp(a,b)<0;
    }
  };
  typedef std::map<const char *, int, char_cmp> Map;
  static Map   typemap;
};

class mdtmconfig
{
public:
  mdtmconfig();
  virtual ~mdtmconfig();
  bool                          readconfig(const char* path);
  std::vector<mdtmdevice>       topology();
  std::vector<mdtmdevice>       online();
  int                           threads();
  int                           threads(char*);
  long long                     segsize() { return seg_size; }
  void                          setconfpath(const char *);
  int                           getncpubytype(int);
  int                           getcpusbytype(int *, int, int);
  const char *                  getconfigfilepath(void);

  static const std::string      json_config_file;
  static const std::string      xml_config_file;

protected:
  TiXmlDocument                         *doc;
  int                                   nthreads;

  struct char_cmp {
    bool operator () (const char *a,const char *b) const
    {
      return strcmp(a,b)<0;
    }
  };

  typedef std::map<const char *, mdtmdevice, char_cmp> Map;
  Map topomap;

  typedef std::map<const char *, int, char_cmp> dtMap;
  dtMap   devthrdmap;

  std::vector<mdtmdevice>   onlinelist;
  long long                 seg_size;

  std::vector<int>          storage_cpus;
  std::vector<int>          network_cpus;
  std::vector<int>          virtual_cpus;

  std::string               servercfgpath;

private:
  std::string sysconfpath;
  bool readxml();
  bool readjson(const char * path = "mdtmconfig.json");
  bool config_done;
};


#endif /* MDTM_CONFIG_H_ */
