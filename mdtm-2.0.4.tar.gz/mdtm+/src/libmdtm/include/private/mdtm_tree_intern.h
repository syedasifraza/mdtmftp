/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_TREE_INTERN_H_
#define MDTM_TREE_INTERN_H_

#include "../mdtm/mdtm_tree.h"

struct mdtm_node_s
{
  char *name;
  char *type;
  char *attr;
  char *cpuset;
  unsigned logical_index;
  unsigned os_index;
  hwloc_cpuset_t online_cpuset;
  struct mdtm_node_s *parent;
  unsigned parentcost;
  struct mdtm_node_s *children[32];
  unsigned childrencost[32];
  int numChildren;
  struct mdtm_node_s *siblings[32];
  unsigned siblingscost[32];
  int numSiblings;
  struct mdtm_node_s *next;
  struct mdtm_node_s *prev;
  unsigned cost;
  unsigned setflag;
  union {
    struct {
      unsigned long speed;
      unsigned type;
      char *operstate;
    }network;
    struct {
      unsigned devid;   //dev_t
      int capacity;
      unsigned type;
      unsigned long size;
    }storage;
  }attr2;
  unsigned isconfig; //indicate if it is created from configure file rather than from the hwloc topology tree
  unsigned ref_numaid;
};

#endif /* MDTM_TREE_INTERN_H_ */
