/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_TREE_H_
#define MDTM_TREE_H_

#include <hwloc.h>

struct mdtm_device_s;
struct mdtm_node_s;
typedef struct mdtm_node_s mdtm_node_t;

#ifdef __cplusplus
extern "C" {
#endif

void
mdtm_tree_print_preorder(mdtm_node_t *tree, int level);

void
mdtm_insert_from_hwloc(mdtm_node_t **tree,
                      const mdtm_node_t * owner,
                      hwloc_topology_t topology,
                      hwloc_obj_t l,
                      hwloc_obj_t parent,
                      int i,
                      int logical,
                      int verbose_mode);

void
mdtm_duplicate_tree(const mdtm_node_t *oldtree,
                    mdtm_node_t **newtree,
                    mdtm_node_t *parent);

int
mdtm_create_sys_info(mdtm_node_t        **tree,
                     void               *data);

void
mdtm_delete_sys_info(mdtm_node_t *tree);

int
mdtm_online_cpuset(const mdtm_node_t* node, unsigned** ids);

const
mdtm_node_t*
mdtm_getnodebyname(const mdtm_node_t *tree, const char* name);

int
mdtm_getdevicesbytype(const mdtm_node_t* tree,
                      const char* type,
                      struct mdtm_device_s** devices);

int
mdtm_getnodesbytype(const mdtm_node_t* tree,
                    const char* type,
                    mdtm_node_t** nodes, int *n);

int
mdtm_getdevicesaffinity(const mdtm_node_t* node,
                        struct mdtm_device_s* devices,
                        int *n);

int
mdtm_getdevicesaffinity2(const mdtm_node_t*node,
                         struct mdtm_device_s **devices,
                         int *n);

int
mdtm_getnumaaffinity(const mdtm_node_t* tree, const char *device);

int
mdtm_getmaxnumberofdevices();

int
mdtm_getdevices(const mdtm_node_t **first);

const
mdtm_node_t *
mdtm_getdevicenodebyname(const char *name);

int
mdtm_getdevicebyname(const mdtm_node_t *tree,
                     const char *name,
                     struct mdtm_device_s *device);

const
char*
mdtm_nodename(const mdtm_node_t *node);

mdtm_node_t*
mdtm_nextnode(const mdtm_node_t*);

bool
mdtm_isdevice(const mdtm_node_t*node);

bool
mdtm_device_isconfig(const mdtm_node_t *node);

const
char*
mdtm_devicename(mdtm_device_s * dev,int i);

unsigned
mdtm_getnumadistance(float **matrix);

const
char*
mdtm_deviceattr(mdtm_device_s *devices, int i);

/* \brief return the topology tree node having the given numa index
 *
 */
mdtm_node_t* mdtm_getnumanode(int numaindex);

#ifdef __cplusplus
}
#endif

#endif /* MDTM_TREE_H_ */
