/*
 * mdtm_lvm.cpp
 *
 *  Created on: Jan 25, 2016
 *      Author: liangz
 */

#include <config.h>
#include <string.h>
#include <errno.h>
#include <mdtm_lvm.h>

#ifdef HAVE_LVM2APP_H
#include "lvm2app.h"
#endif


#ifdef __cplusplus
extern "C" {
#endif

#define         DEVMAPPER_STR           "/dev/mapper"
#define         DEVMAPPER_STR_LEN       (strlen(DEVMAPPER_STR) - 1)

#ifdef HAVE_LVM2APP_H

static lvm_t            global_lvm = 0;
static pthread_mutex_t  global_lvm_lock;


static void _process_vg(lvm_t lvm, vg_t vg)
{
       struct dm_list *lvs, *pvs;
       struct lvm_pv_list *pvl;
       struct lvm_lv_list *lvl;

       if (!vg) {
               fprintf(stderr, "Error opening volume group");
               return;
       }
       printf("vg_name: %s, vg_uuid: %s\n", lvm_vg_get_name(vg),
              lvm_vg_get_uuid(vg));
       pvs = lvm_vg_list_pvs(vg);
       if (!pvs && lvm_errno(lvm)) {
               fprintf(stderr, "lvm_vg_list_pvs() failed\n");
               return;
       } else if (!pvs) {
               fprintf(stdout, "- No PVs, error!\n");
               return;
       }
       dm_list_iterate_items(pvl, pvs) {
               printf("- pv_name: %s, pv_uuid: %s\n",
                       lvm_pv_get_name(pvl->pv), lvm_pv_get_uuid(pvl->pv));
       }
       lvs = lvm_vg_list_lvs(vg);
       if (!lvs && lvm_errno(lvm)) {
               fprintf(stderr, "lvm_vg_list_lvs() failed\n");
               return;
       } else if (!lvs) {
               fprintf(stdout, "- No LVs\n");
               return;
       }
       dm_list_iterate_items(lvl, lvs) {
               printf("- lv_name: %s, lv_uuid: %s\n",
                       lvm_lv_get_name(lvl->lv), lvm_lv_get_uuid(lvl->lv));
               printf("- lv_name: %s, lv_attr: %s, lv_size: %lu64\n",
                       lvm_lv_get_name(lvl->lv), lvm_lv_get_name(lvl->lv), lvm_lv_get_size(lvl->lv));
               printf("- lv_name: %s, list_size: %d\n",
                   lvm_lv_get_name(lvl->lv), dm_list_size(lvm_lv_list_lvsegs(lvl->lv)));
               {
                 lvm_property_value v;
                 char prop_name[] = "devices";
                 struct dm_list * dms;
                 lvseg_list_t* list;
                 dms = dm_list_first(lvm_lv_list_lvsegs(lvl->lv));
                 list = (lvseg_list_t*)dms;


                 v = lvm_lvseg_get_property(list->lvseg, prop_name);

                 if (v.is_string)
                   printf(", value = %s\n", v.value.string);
                 if (v.is_integer)
                   printf(", value = %lu64\n", v.value.integer);
               }
       }
}

int mdtm_lvm_display()
{
       lvm_t lvm;
       vg_t vg;
       struct dm_list *vgnames;
       struct lvm_str_list *strl;

       lvm = lvm_init(NULL);
       if (!lvm) {
               fprintf(stderr, "lvm_init() failed\n");
               goto bad;
       }

       printf("Library version: %s\n", lvm_library_get_version());
       vgnames = lvm_list_vg_names(lvm);
       if (!vgnames) {
               fprintf(stderr, "lvm_list_vg_names() failed\n");
               goto bad;
       }
       dm_list_iterate_items(strl, vgnames) {
               printf("Opening volume group %s\n", strl->str);
               vg = lvm_vg_open(lvm, strl->str, "r", 0);
               _process_vg(lvm, vg);
               lvm_vg_close(vg);
       }
       lvm_quit(lvm);
       exit(0);
bad:
       if (lvm)
               lvm_quit(lvm);
       exit(-1);
}

/*
 * Padding an extra dash for every dash found in the input string
 */
static
char *
mdtm_lvm_util_paddash(const char * input)
{
  char * output;
  int   i, j;

  if (input == 0)
    return 0;

  if ((output = (char *) malloc(strlen(input) * 2)) == 0)
    return 0;

  for ( i = 0, j = 0; i < strlen(input); i++) {
      if(input[i] == '-') {
          output[j++] = '-';
          output[j++] = '-';
      }
      else
        output[j++] = input[i];
  }
  output[j] = '\0';
  return output;
}

/*
 * Return the vg and lv names for the input name
 *
 * name         file system name string (from df) like "/dev/mapper/centos_sc--demo--03-root"
 * vg_name      group name, e.g. "/dev/mapper/centos_sc-demo-03". NOTE: ONLY ONE DASH
 * lv_name      lv name, e.g. "root"
 *
 * return       1 if found, 0 if not found, -1 if error
 */
static
int
mdtm_lvm_getnames(char* name, char** vg_name, char** lv_name) {
  char *                c;
  int                   found = 0;
  struct dm_list *      list;
  lvm_str_list_t *      cur_elem = 0;
  lvm_str_list_t *      pre_elem = 0;

  if((list = lvm_list_vg_names(global_lvm)) == 0)
    return -1;          // can not allocate memory

  if(dm_list_empty(list))
    return 0;           // did not find any group

  for(cur_elem = (lvm_str_list_t*) dm_list_first(list);
      cur_elem != 0;) {
        if(strchr(cur_elem->str, '-')) {
            /* if vg name contains '-', it would be shown as '--' in the name derived
             * from df. So vg name needs padding to comparing with name.
             */
            char *      temp;

            temp = mdtm_lvm_util_paddash((const char*)cur_elem->str);
            if(temp == 0)
              continue;

            if((c = strstr(name, temp))) {
                *vg_name = strdup(cur_elem->str);
                *lv_name = strdup(name + strlen (temp) + 1);
                found = 1;
                break;
            }
        }
        else
          if((c = strstr(name, cur_elem->str))) {
              *vg_name = strdup(cur_elem->str);
              *lv_name = strdup(name + strlen (cur_elem->str) + 1);
              found = 1;
              break;
          }

        pre_elem = cur_elem;
        cur_elem = (lvm_str_list_t*) dm_list_next(list,(const struct dm_list *)pre_elem);
  }
  return found;
}

struct lvm_lv_list *
mdtm_lvm_find_lv(lvm_t lvm, char* vg_name, char* lv_name) {
  vg_t vg;
  struct dm_list *lvs;
  struct lvm_lv_list *lvl;
  int found = 0;

  vg = lvm_vg_open(lvm, vg_name, "r", 0);

  lvs = lvm_vg_list_lvs(vg);
  if (!lvs && lvm_errno(lvm)) {
          fprintf(stderr, "lvm_vg_list_lvs() failed\n");
          return 0;
  } else if (!lvs) {
          fprintf(stdout, "- No LVs\n");
          return 0;
  }
  dm_list_iterate_items(lvl, lvs) {
//          printf("lv_name: %s, lv_uuid: %s\n",
//                  lvm_lv_get_name(lvl->lv), lvm_lv_get_uuid(lvl->lv));

          if(!strcmp(lvm_lv_get_name(lvl->lv), lv_name)) {
              found = 1;
              break;
          }
  }

  lvm_vg_close(vg);

  return found? lvl : 0;
}

struct lvm_lv_list *
mdtm_lvm_find_lv2(lvm_t lvm, vg_t vg, char* lv_name) {
//  vg_t vg;
  struct dm_list *lvs;
  struct lvm_lv_list *lvl;
  int found = 0;

//  vg = lvm_vg_open(lvm, vg_name, "r", 0);

  lvs = lvm_vg_list_lvs(vg);
  if (!lvs && lvm_errno(lvm)) {
          fprintf(stderr, "lvm_vg_list_lvs() failed\n");
          return 0;
  } else if (!lvs) {
          fprintf(stdout, "- No LVs\n");
          return 0;
  }
  dm_list_iterate_items(lvl, lvs) {
//          printf("lv_name: %s, lv_uuid: %s\n",
//                  lvm_lv_get_name(lvl->lv), lvm_lv_get_uuid(lvl->lv));

          if(!strcmp(lvm_lv_get_name(lvl->lv), lv_name)) {
              found = 1;
              break;
          }
  }

//  lvm_vg_close(vg);

  return found? lvl : 0;
}

struct lvm_lv_list *
mdtm_lvm_getlv_from_name(char* name) {
  struct lvm_lv_list * lvl;
  char *vg_name, *lv_name;

  if(mdtm_lvm_getnames(name, &vg_name, &lv_name) <= 0)
    return 0;

  lvl= mdtm_lvm_find_lv(global_lvm, vg_name, lv_name);

  free(vg_name);
  free(lv_name);

  return lvl;
}

//typedef struct _LV_SEG_ {
//  uint64_t      m_start;
//  uint64_t      m_end;
//  char*         dev;
//} mdtm_lv_seg_t;

int
mdtm_lvm_get_lv_segment(
    struct lvm_lv_list * lvl,
    uint64_t start,
    uint64_t end,
    mdtm_lv_seg_t ** psegs)
{
  struct dm_list *              dml;
  struct dm_list *              elem;
  lvseg_list_t *                list;
  lvm_property_value            v;
  const struct dm_list *        dv;
  uint64_t                      seg_start, seg_end;
  mdtm_lv_seg_t *               segs;
  int                           nsegs, count = 0;

  dml = lvm_lv_list_lvsegs(lvl->lv);
  nsegs = dm_list_size(dml);

  segs = (mdtm_lv_seg_t *)calloc(nsegs, sizeof(*segs));

  dm_list_iterate(dv, dml) {
    list = (lvseg_list_t*)dv;

    v = lvm_lvseg_get_property(list->lvseg, "seg_start");
    if (!v.is_valid || !v.is_integer)
      return 0;
    seg_start = v.value.integer;

    v = lvm_lvseg_get_property(list->lvseg, "seg_size");
    if (!v.is_valid || !v.is_integer)
      return 0;
    seg_end = seg_start + v.value.integer - 1;

    v = lvm_lvseg_get_property(list->lvseg, "devices");
    if (!v.is_valid || !v.is_string)
      return 0;

    if((start > seg_end) || (end < seg_start))
        continue;
    else if(end <= seg_end) {
        segs[count].m_start = start;
        segs[count].m_end = end;
        segs[count].dev = strdup(v.value.string);
        count++;
        break;
    }
    else if(end > seg_end) {
        segs[count].m_start = start;
        segs[count].m_end = seg_end;
        segs[count].dev = strdup(v.value.string);
        count++;
        start = seg_end + 1;
    }
  }

  if(count > 0)
    *psegs = segs;
  else
    free(segs);

  return count;
}

//******* Public API Functions ************

int
mdtm_lvm_init()
{
  if(global_lvm)
    return 0;

  global_lvm = lvm_init(NULL);
  if (!global_lvm) {
      fprintf(stderr, "lvm_init() failed\n");
      return -1;
  }
  if(pthread_mutex_init(&global_lvm_lock, NULL) != 0) {
      lvm_quit(global_lvm);
      global_lvm = NULL;
      return -1;
  }
  return 0;
}

void
mdtm_lvm_fini()
{
  if(global_lvm) {
    lvm_quit(global_lvm);
    global_lvm = NULL;
    pthread_mutex_destroy(&global_lvm_lock);
  }
}

char*
mdtm_lvm_getlibversion() {
  return strdup(lvm_library_get_version());
}

int
mdtm_lvm_get_physical_devices(
    char* lvfullname,
    uint64_t start,
    uint64_t end,
    mdtm_lv_seg_t **psegs)
{
  struct lvm_lv_list * lvl;
  int nsegs = 0;

  char *vg_name, *lv_name;
  vg_t vg;

  if(!lvfullname || (!global_lvm && (mdtm_lvm_init() < 0)))
    return 0;

  if(mdtm_lvm_getnames(lvfullname, &vg_name, &lv_name) <= 0)
    return 0;

  pthread_mutex_lock(&global_lvm_lock);

  if((vg = lvm_vg_open(global_lvm, vg_name, "r", 0)) == NULL) {
      fprintf(stderr, "lvm_vg_open failed:%s\n", strerror(errno));
      pthread_mutex_unlock(&global_lvm_lock);
      return -1;
  }

  lvl = mdtm_lvm_find_lv2(global_lvm, vg, lv_name);
  nsegs = mdtm_lvm_get_lv_segment(lvl, start, end, psegs);

  if(lvm_vg_close(vg) != 0)
    fprintf(stderr, "lvm_vg_close failed:%s\n", strerror(errno));

  pthread_mutex_unlock(&global_lvm_lock);

  free(vg_name);
  free(lv_name);

  return nsegs;
}

#else
int
mdtm_lvm_display() {
  return 0;
}

int
mdtm_lvm_init() {
  return 0;
}

void
mdtm_lvm_fini() {
  return;
}

char*
mdtm_lvm_getlibversion() {
  return NULL;
}

int
mdtm_lvm_get_physical_devices(
    char* lvfullname,
    uint64_t start,
    uint64_t end,
    mdtm_lv_seg_t **psegs) {
  return 0;
}

#endif  // end of HAVE_LVM2APP_H

int
mdtm_lvm_islv(char *fs) {
  return !strncmp(fs, DEVMAPPER_STR, DEVMAPPER_STR_LEN);
}

char*
mdtm_lvm_getlvname(const char *fs) {
  char buf[256], *name = NULL;

  if(sscanf(fs, "/dev/mapper/%s", buf) == 1)
    name = strdup(buf);
  return name;
}

#ifdef __cplusplus
}
#endif

