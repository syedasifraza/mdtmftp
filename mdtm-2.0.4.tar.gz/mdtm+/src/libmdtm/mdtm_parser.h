/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef MDTM_PARSER_H_
#define MDTM_PARSER_H_

#include <unordered_map>
#include <string>

class MdtmParserInterface {
public:
  virtual int parseit(void* ibuf, int isize, void* obuf, int osize) = 0;
  virtual ~MdtmParserInterface() {}
};

class MdtmParser {
public:
  MdtmParser(){}
  ~MdtmParser(){}
  int enroll(const std::string& name, MdtmParserInterface& instance);
  int disenroll(std::string name);
  int parse(void *ibuf, int isize, void *obuf, int osize);

private:
  typedef std::unordered_map<std::string, MdtmParserInterface *> ParserHashTable;
  ParserHashTable     htable;
};



#endif /* MDTM_PARSER_H_ */
