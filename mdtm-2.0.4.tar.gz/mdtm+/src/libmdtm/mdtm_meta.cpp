/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/times.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/sysmacros.h>

#include "mdtm_meta.h"
#include "meta/mdtm_meta_private.h"
#include "meta/mdtm_meta_write_private.h"
#include "meta/mdtm_meta_string.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef UINT64_MAX
#define UINT64_MAX (~(uint64_t)0)
#endif

#ifndef INT64_MAX
#define INT64_MAX ((int64_t)(UINT64_MAX >> 1))
#endif

#ifndef INT64_MIN
#define INT64_MIN ((int64_t)(~INT64_MAX))
#endif

#define ARCHIVE_FORMAT_TAR                      0x30000
#define ARCHIVE_FORMAT_TAR_USTAR                (ARCHIVE_FORMAT_TAR | 1)
#define ARCHIVE_FORMAT_TAR_GNUTAR               (ARCHIVE_FORMAT_TAR | 4)

/*
 * Permission bits.
 */
#define ARCHIVE_ENTRY_ACL_EXECUTE             0x00000001
#define ARCHIVE_ENTRY_ACL_WRITE               0x00000002
#define ARCHIVE_ENTRY_ACL_READ                0x00000004
#define ARCHIVE_ENTRY_ACL_READ_DATA           0x00000008
#define ARCHIVE_ENTRY_ACL_LIST_DIRECTORY      0x00000008
#define ARCHIVE_ENTRY_ACL_WRITE_DATA          0x00000010
#define ARCHIVE_ENTRY_ACL_ADD_FILE            0x00000010
#define ARCHIVE_ENTRY_ACL_APPEND_DATA         0x00000020
#define ARCHIVE_ENTRY_ACL_ADD_SUBDIRECTORY    0x00000020
#define ARCHIVE_ENTRY_ACL_READ_NAMED_ATTRS    0x00000040
#define ARCHIVE_ENTRY_ACL_WRITE_NAMED_ATTRS   0x00000080
#define ARCHIVE_ENTRY_ACL_DELETE_CHILD        0x00000100
#define ARCHIVE_ENTRY_ACL_READ_ATTRIBUTES     0x00000200
#define ARCHIVE_ENTRY_ACL_WRITE_ATTRIBUTES    0x00000400
#define ARCHIVE_ENTRY_ACL_DELETE              0x00000800
#define ARCHIVE_ENTRY_ACL_READ_ACL            0x00001000
#define ARCHIVE_ENTRY_ACL_WRITE_ACL           0x00002000
#define ARCHIVE_ENTRY_ACL_WRITE_OWNER         0x00004000
#define ARCHIVE_ENTRY_ACL_SYNCHRONIZE         0x00008000

#define ARCHIVE_ENTRY_ACL_PERMS_POSIX1E                 \
        (ARCHIVE_ENTRY_ACL_EXECUTE                      \
            | ARCHIVE_ENTRY_ACL_WRITE                   \
            | ARCHIVE_ENTRY_ACL_READ)

#define ARCHIVE_ENTRY_ACL_PERMS_NFS4                    \
        (ARCHIVE_ENTRY_ACL_EXECUTE                      \
            | ARCHIVE_ENTRY_ACL_READ_DATA               \
            | ARCHIVE_ENTRY_ACL_LIST_DIRECTORY          \
            | ARCHIVE_ENTRY_ACL_WRITE_DATA              \
            | ARCHIVE_ENTRY_ACL_ADD_FILE                \
            | ARCHIVE_ENTRY_ACL_APPEND_DATA             \
            | ARCHIVE_ENTRY_ACL_ADD_SUBDIRECTORY        \
            | ARCHIVE_ENTRY_ACL_READ_NAMED_ATTRS        \
            | ARCHIVE_ENTRY_ACL_WRITE_NAMED_ATTRS       \
            | ARCHIVE_ENTRY_ACL_DELETE_CHILD            \
            | ARCHIVE_ENTRY_ACL_READ_ATTRIBUTES         \
            | ARCHIVE_ENTRY_ACL_WRITE_ATTRIBUTES        \
            | ARCHIVE_ENTRY_ACL_DELETE                  \
            | ARCHIVE_ENTRY_ACL_READ_ACL                \
            | ARCHIVE_ENTRY_ACL_WRITE_ACL               \
            | ARCHIVE_ENTRY_ACL_WRITE_OWNER             \
            | ARCHIVE_ENTRY_ACL_SYNCHRONIZE)

/*
 * Inheritance values (NFS4 ACLs only); included in permset.
 */
#define ARCHIVE_ENTRY_ACL_ENTRY_FILE_INHERIT                0x02000000
#define ARCHIVE_ENTRY_ACL_ENTRY_DIRECTORY_INHERIT           0x04000000
#define ARCHIVE_ENTRY_ACL_ENTRY_NO_PROPAGATE_INHERIT        0x08000000
#define ARCHIVE_ENTRY_ACL_ENTRY_INHERIT_ONLY                0x10000000
#define ARCHIVE_ENTRY_ACL_ENTRY_SUCCESSFUL_ACCESS           0x20000000
#define ARCHIVE_ENTRY_ACL_ENTRY_FAILED_ACCESS               0x40000000

#define ARCHIVE_ENTRY_ACL_INHERITANCE_NFS4                      \
        (ARCHIVE_ENTRY_ACL_ENTRY_FILE_INHERIT                   \
            | ARCHIVE_ENTRY_ACL_ENTRY_DIRECTORY_INHERIT         \
            | ARCHIVE_ENTRY_ACL_ENTRY_NO_PROPAGATE_INHERIT      \
            | ARCHIVE_ENTRY_ACL_ENTRY_INHERIT_ONLY              \
            | ARCHIVE_ENTRY_ACL_ENTRY_SUCCESSFUL_ACCESS         \
            | ARCHIVE_ENTRY_ACL_ENTRY_FAILED_ACCESS)

/* We need to be able to specify combinations of these. */
#define ARCHIVE_ENTRY_ACL_TYPE_ACCESS   256  /* POSIX.1e only */
#define ARCHIVE_ENTRY_ACL_TYPE_DEFAULT  512  /* POSIX.1e only */
#define ARCHIVE_ENTRY_ACL_TYPE_ALLOW    1024 /* NFS4 only */
#define ARCHIVE_ENTRY_ACL_TYPE_DENY     2048 /* NFS4 only */
#define ARCHIVE_ENTRY_ACL_TYPE_AUDIT    4096 /* NFS4 only */
#define ARCHIVE_ENTRY_ACL_TYPE_ALARM    8192 /* NFS4 only */
#define ARCHIVE_ENTRY_ACL_TYPE_POSIX1E  (ARCHIVE_ENTRY_ACL_TYPE_ACCESS \
            | ARCHIVE_ENTRY_ACL_TYPE_DEFAULT)
#define ARCHIVE_ENTRY_ACL_TYPE_NFS4     (ARCHIVE_ENTRY_ACL_TYPE_ALLOW \
            | ARCHIVE_ENTRY_ACL_TYPE_DENY \
            | ARCHIVE_ENTRY_ACL_TYPE_AUDIT \
            | ARCHIVE_ENTRY_ACL_TYPE_ALARM)

/* Tag values mimic POSIX.1e */
#define ARCHIVE_ENTRY_ACL_USER          10001   /* Specified user. */
#define ARCHIVE_ENTRY_ACL_USER_OBJ      10002   /* User who owns the file. */
#define ARCHIVE_ENTRY_ACL_GROUP         10003   /* Specified group. */
#define ARCHIVE_ENTRY_ACL_GROUP_OBJ     10004   /* Group who owns the file. */
#define ARCHIVE_ENTRY_ACL_MASK          10005   /* Modify group access (POSIX.1e only) */
#define ARCHIVE_ENTRY_ACL_OTHER         10006   /* Public (POSIX.1e only) */
#define ARCHIVE_ENTRY_ACL_EVERYONE      10107   /* Everyone (NFS4 only) */

struct archive_acl_entry {
        struct archive_acl_entry *next;
        int     type;                   /* E.g., access or default */
        int     tag;                    /* E.g., user/group/other/mask */
        int     permset;                /* r/w/x bits */
        int     id;                     /* uid/gid for user/group */
        struct archive_mstring name;            /* uname/gname */
};

struct archive_acl {
        mode_t          mode;
        struct archive_acl_entry        *acl_head;
        struct archive_acl_entry        *acl_p;
        int              acl_state;     /* See acl_next for details. */
        wchar_t         *acl_text_w;
        char            *acl_text;
        int              acl_types;
};

static struct archive_acl_entry *
acl_new_entry(struct archive_acl *acl,
    int type, int permset, int tag, int id)
{
        struct archive_acl_entry *ap, *aq;

        /* Type argument must be a valid NFS4 or POSIX.1e type.
         * The type must agree with anything already set and
         * the permset must be compatible. */
        if (type & ARCHIVE_ENTRY_ACL_TYPE_NFS4) {
                if (acl->acl_types & ~ARCHIVE_ENTRY_ACL_TYPE_NFS4) {
                        return (NULL);
                }
                if (permset &
                    ~(ARCHIVE_ENTRY_ACL_PERMS_NFS4
                        | ARCHIVE_ENTRY_ACL_INHERITANCE_NFS4)) {
                        return (NULL);
                }
        } else  if (type & ARCHIVE_ENTRY_ACL_TYPE_POSIX1E) {
                if (acl->acl_types & ~ARCHIVE_ENTRY_ACL_TYPE_POSIX1E) {
                        return (NULL);
                }
                if (permset & ~ARCHIVE_ENTRY_ACL_PERMS_POSIX1E) {
                        return (NULL);
                }
        } else {
                return (NULL);
        }

        /* Verify the tag is valid and compatible with NFS4 or POSIX.1e. */
        switch (tag) {
        case ARCHIVE_ENTRY_ACL_USER:
        case ARCHIVE_ENTRY_ACL_USER_OBJ:
        case ARCHIVE_ENTRY_ACL_GROUP:
        case ARCHIVE_ENTRY_ACL_GROUP_OBJ:
                /* Tags valid in both NFS4 and POSIX.1e */
                break;
        case ARCHIVE_ENTRY_ACL_MASK:
        case ARCHIVE_ENTRY_ACL_OTHER:
                /* Tags valid only in POSIX.1e. */
                if (type & ~ARCHIVE_ENTRY_ACL_TYPE_POSIX1E) {
                        return (NULL);
                }
                break;
        case ARCHIVE_ENTRY_ACL_EVERYONE:
                /* Tags valid only in NFS4. */
                if (type & ~ARCHIVE_ENTRY_ACL_TYPE_NFS4) {
                        return (NULL);
                }
                break;
        default:
                /* No other values are valid. */
                return (NULL);
        }

        if (acl->acl_text_w != NULL) {
                free(acl->acl_text_w);
                acl->acl_text_w = NULL;
        }
        if (acl->acl_text != NULL) {
                free(acl->acl_text);
                acl->acl_text = NULL;
        }

        /* If there's a matching entry already in the list, overwrite it. */
        ap = acl->acl_head;
        aq = NULL;
        while (ap != NULL) {
                if (ap->type == type && ap->tag == tag && ap->id == id) {
                        ap->permset = permset;
                        return (ap);
                }
                aq = ap;
                ap = ap->next;
        }

        /* Add a new entry to the end of the list. */
        ap = (struct archive_acl_entry *)malloc(sizeof(*ap));
        if (ap == NULL)
                return (NULL);
        memset(ap, 0, sizeof(*ap));
        if (aq == NULL)
                acl->acl_head = ap;
        else
                aq->next = ap;
        ap->type = type;
        ap->tag = tag;
        ap->id = id;
        ap->permset = permset;
        acl->acl_types |= type;
        return (ap);
}

void
archive_acl_clear(struct archive_acl *acl)
{
        struct archive_acl_entry *ap;

        while (acl->acl_head != NULL) {
                ap = acl->acl_head->next;
                archive_mstring_clean(&acl->acl_head->name);
                free(acl->acl_head);
                acl->acl_head = ap;
        }
        if (acl->acl_text_w != NULL) {
                free(acl->acl_text_w);
                acl->acl_text_w = NULL;
        }
        if (acl->acl_text != NULL) {
                free(acl->acl_text);
                acl->acl_text = NULL;
        }
        acl->acl_p = NULL;
        acl->acl_state = 0; /* Not counting. */
}

void
archive_acl_copy(struct archive_acl *dest, struct archive_acl *src)
{
        struct archive_acl_entry *ap, *ap2;

        archive_acl_clear(dest);

        dest->mode = src->mode;
        ap = src->acl_head;
        while (ap != NULL) {
                ap2 = acl_new_entry(dest,
                    ap->type, ap->permset, ap->tag, ap->id);
                if (ap2 != NULL)
                        archive_mstring_copy(&ap2->name, &ap->name);
                ap = ap->next;
        }
}

#if !defined(HAVE_MAJOR) && !defined(major)
/* Replacement for major/minor/makedev. */
#define major(x) ((int)(0x00ff & ((x) >> 8)))
#define minor(x) ((int)(0xffff00ff & (x)))
#define makedev(maj,min) ((0xff00 & ((maj)<<8)) | (0xffff00ff & (min)))
#endif

struct archive_entry {
        struct archive *archive;

        /*
         * Note that ae_stat.st_mode & AE_IFMT  can be  0!
         *
         * This occurs when the actual file type of the object is not
         * in the archive.  For example, 'tar' archives store
         * hardlinks without marking the type of the underlying
         * object.
         */

        /*
         * We have a "struct aest" for holding file metadata rather than just
         * a "struct stat" because on some platforms the "struct stat" has
         * fields which are too narrow to hold the range of possible values;
         * we don't want to lose information if we read an archive and write
         * out another (e.g., in "tar -cf new.tar @old.tar").
         *
         * The "stat" pointer points to some form of platform-specific struct
         * stat; it is declared as a void * rather than a struct stat * as
         * some platforms have multiple varieties of stat structures.
         */
        void *stat;
        int  stat_valid; /* Set to 0 whenever a field in aest changes. */

        struct aest {
                int64_t         aest_atime;
                uint32_t        aest_atime_nsec;
                int64_t         aest_ctime;
                uint32_t        aest_ctime_nsec;
                int64_t         aest_mtime;
                uint32_t        aest_mtime_nsec;
                int64_t         aest_birthtime;
                uint32_t        aest_birthtime_nsec;
                int64_t         aest_gid;
                int64_t         aest_ino;
                uint32_t        aest_nlink;
                uint64_t        aest_size;
                int64_t         aest_uid;
                /*
                 * Because converting between device codes and
                 * major/minor values is platform-specific and
                 * inherently a bit risky, we only do that conversion
                 * lazily.  That way, we will do a better job of
                 * preserving information in those cases where no
                 * conversion is actually required.
                 */
                int             aest_dev_is_broken_down;
                dev_t           aest_dev;
                dev_t           aest_devmajor;
                dev_t           aest_devminor;
                int             aest_rdev_is_broken_down;
                dev_t           aest_rdev;
                dev_t           aest_rdevmajor;
                dev_t           aest_rdevminor;
        } ae_stat;

        int ae_set; /* bitmap of fields that are currently set */
#define AE_SET_HARDLINK 1
#define AE_SET_SYMLINK  2
#define AE_SET_ATIME    4
#define AE_SET_CTIME    8
#define AE_SET_MTIME    16
#define AE_SET_BIRTHTIME 32
#define AE_SET_SIZE     64
#define AE_SET_INO      128
#define AE_SET_DEV      256

        /*
         * Use aes here so that we get transparent mbs<->wcs conversions.
         */
        struct archive_mstring ae_fflags_text;  /* Text fflags per fflagstostr(3) */
        unsigned long ae_fflags_set;            /* Bitmap fflags */
        unsigned long ae_fflags_clear;
        struct archive_mstring ae_gname;                /* Name of owning group */
        struct archive_mstring ae_hardlink;     /* Name of target for hardlink */
        struct archive_mstring ae_pathname;     /* Name of entry */
        struct archive_mstring ae_symlink;              /* symlink contents */
        struct archive_mstring ae_uname;                /* Name of owner */

        /* Not used within libarchive; useful for some clients. */
        struct archive_mstring ae_sourcepath;   /* Path this entry is sourced from. */

        void *mac_metadata;
        size_t mac_metadata_size;

        /* ACL support. */
        struct archive_acl    acl;

//        /* extattr support. */
//        struct ae_xattr *xattr_head;
//        struct ae_xattr *xattr_p;
//
//        /* sparse support. */
//        struct ae_sparse *sparse_head;
//        struct ae_sparse *sparse_tail;
//        struct ae_sparse *sparse_p;

        /* Miscellaneous. */
        char             strmode[12];
};



struct archive_entry *
archive_entry_new2(struct archive *a)
{
        struct archive_entry *entry;

        entry = (struct archive_entry *)malloc(sizeof(*entry));
        if (entry == NULL)
                return (NULL);
        memset(entry, 0, sizeof(*entry));
        entry->archive = a;
        return (entry);
}

struct archive_entry *
archive_entry_new(void)
{
        return archive_entry_new2(NULL);
}

struct archive_entry *
archive_entry_clear(struct archive_entry *entry)
{
        if (entry == NULL)
                return (NULL);
        archive_mstring_clean(&entry->ae_fflags_text);
        archive_mstring_clean(&entry->ae_gname);
        archive_mstring_clean(&entry->ae_hardlink);
        archive_mstring_clean(&entry->ae_pathname);
        archive_mstring_clean(&entry->ae_sourcepath);
        archive_mstring_clean(&entry->ae_symlink);
        archive_mstring_clean(&entry->ae_uname);
//        archive_entry_copy_mac_metadata(entry, NULL, 0);
        archive_acl_clear(&entry->acl);
//        archive_entry_xattr_clear(entry);
//        archive_entry_sparse_clear(entry);
        free(entry->stat);
        memset(entry, 0, sizeof(*entry));
        return entry;
}

struct archive_entry *
archive_entry_clone(struct archive_entry *entry)
{
        struct archive_entry *entry2;
        struct ae_xattr *xp;
        struct ae_sparse *sp;
        size_t s;
        const void *p;

        /* Allocate new structure and copy over all of the fields. */
        /* TODO: Should we copy the archive over?  Or require a new archive
         * as an argument? */
        entry2 = archive_entry_new2(entry->archive);
        if (entry2 == NULL)
                return (NULL);
        entry2->ae_stat = entry->ae_stat;
        entry2->ae_fflags_set = entry->ae_fflags_set;
        entry2->ae_fflags_clear = entry->ae_fflags_clear;

        /* TODO: XXX If clone can have a different archive, what do we do here if
         * character sets are different? XXX */
        archive_mstring_copy(&entry2->ae_fflags_text, &entry->ae_fflags_text);
        archive_mstring_copy(&entry2->ae_gname, &entry->ae_gname);
        archive_mstring_copy(&entry2->ae_hardlink, &entry->ae_hardlink);
        archive_mstring_copy(&entry2->ae_pathname, &entry->ae_pathname);
        archive_mstring_copy(&entry2->ae_sourcepath, &entry->ae_sourcepath);
        archive_mstring_copy(&entry2->ae_symlink, &entry->ae_symlink);
        entry2->ae_set = entry->ae_set;
        archive_mstring_copy(&entry2->ae_uname, &entry->ae_uname);

        /* Copy ACL data over. */
        archive_acl_copy(&entry2->acl, &entry->acl);

        /* Copy Mac OS metadata. */
//        p = archive_entry_mac_metadata(entry, &s);
//        archive_entry_copy_mac_metadata(entry2, p, s);

//        /* Copy xattr data over. */
//        xp = entry->xattr_head;
//        while (xp != NULL) {
//                archive_entry_xattr_add_entry(entry2,
//                    xp->name, xp->value, xp->size);
//                xp = xp->next;
//        }
//
//        /* Copy sparse data over. */
//        sp = entry->sparse_head;
//        while (sp != NULL) {
//                archive_entry_sparse_add_entry(entry2,
//                    sp->offset, sp->length);
//                sp = sp->next;
//        }

        return (entry2);
}

void
archive_entry_free(struct archive_entry *entry)
{
        archive_entry_clear(entry);
        free(entry);
}

//void
//archive_entry_set_pathname(struct archive_entry *entry, const char *name)
//{
//        archive_mstring_copy_mbs(&entry->ae_pathname, name);
//}
//
//void
//archive_entry_set_filetype(struct archive_entry *entry, unsigned int type)
//{
//        entry->stat_valid = 0;
//        entry->acl.mode &= ~AE_IFMT;
//        entry->acl.mode |= AE_IFMT & type;
//}

__LA_MODE_T
archive_entry_mode(struct archive_entry *entry)
{
        return (entry->acl.mode);
}

__LA_MODE_T
archive_entry_filetype(struct archive_entry *entry)
{
        return (AE_IFMT & entry->acl.mode);
}

const char *
archive_entry_pathname(struct archive_entry *entry)
{
        const char *p;
        if (archive_mstring_get_mbs(
            entry->archive, &entry->ae_pathname, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

const wchar_t *
archive_entry_pathname_w(struct archive_entry *entry)
{
        const wchar_t *p;
        if (archive_mstring_get_wcs(
            entry->archive, &entry->ae_pathname, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

int
_archive_entry_pathname_l(struct archive_entry *entry,
    const char **p, size_t *len, struct archive_string_conv *sc)
{
        return (archive_mstring_get_mbs_l(&entry->ae_pathname, p, len, sc));
}
#define archive_entry_pathname_l        _archive_entry_pathname_l

void
archive_entry_copy_pathname(struct archive_entry *entry, const char *name)
{
        archive_mstring_copy_mbs(&entry->ae_pathname, name);
}

mode_t
archive_entry_perm(struct archive_entry *entry)
{
        return (~AE_IFMT & entry->acl.mode);
}


dev_t
archive_entry_rdev(struct archive_entry *entry)
{
//        if (entry->ae_stat.aest_rdev_is_broken_down)
//                return ae_makedev(entry->ae_stat.aest_rdevmajor,
//                    entry->ae_stat.aest_rdevminor);
//        else
                return (entry->ae_stat.aest_rdev);
}

dev_t
archive_entry_rdevmajor(struct archive_entry *entry)
{
        if (entry->ae_stat.aest_rdev_is_broken_down)
                return (entry->ae_stat.aest_rdevmajor);
        else
                return major(entry->ae_stat.aest_rdev);
}

dev_t
archive_entry_rdevminor(struct archive_entry *entry)
{
        if (entry->ae_stat.aest_rdev_is_broken_down)
                return (entry->ae_stat.aest_rdevminor);
        else
                return minor(entry->ae_stat.aest_rdev);
}

int64_t
archive_entry_size(struct archive_entry *entry)
{
        return (entry->ae_stat.aest_size);
}

int
archive_entry_size_is_set(struct archive_entry *entry)
{
        return (entry->ae_set & AE_SET_SIZE);
}

const char *
archive_entry_sourcepath(struct archive_entry *entry)
{
        const char *p;
        if (archive_mstring_get_mbs(
            entry->archive, &entry->ae_sourcepath, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

const wchar_t *
archive_entry_sourcepath_w(struct archive_entry *entry)
{
        const wchar_t *p;
        if (archive_mstring_get_wcs(
            entry->archive, &entry->ae_sourcepath, &p) == 0)
                return (p);
        return (NULL);
}

const char *
archive_entry_symlink(struct archive_entry *entry)
{
        const char *p;
        if ((entry->ae_set & AE_SET_SYMLINK) == 0)
                return (NULL);
        if (archive_mstring_get_mbs(
            entry->archive, &entry->ae_symlink, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

const wchar_t *
archive_entry_symlink_w(struct archive_entry *entry)
{
        const wchar_t *p;
        if ((entry->ae_set & AE_SET_SYMLINK) == 0)
                return (NULL);
        if (archive_mstring_get_wcs(
            entry->archive, &entry->ae_symlink, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

int
_archive_entry_symlink_l(struct archive_entry *entry,
    const char **p, size_t *len, struct archive_string_conv *sc)
{
        if ((entry->ae_set & AE_SET_SYMLINK) == 0) {
                *p = NULL;
                *len = 0;
                return (0);
        }
        return (archive_mstring_get_mbs_l( &entry->ae_symlink, p, len, sc));
}

const char *
archive_entry_hardlink(struct archive_entry *entry)
{
        const char *p;
        if ((entry->ae_set & AE_SET_HARDLINK) == 0)
                return (NULL);
        if (archive_mstring_get_mbs(
            entry->archive, &entry->ae_hardlink, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

int
_archive_entry_hardlink_l(struct archive_entry *entry,
    const char **p, size_t *len, struct archive_string_conv *sc)
{
        if ((entry->ae_set & AE_SET_HARDLINK) == 0) {
                *p = NULL;
                *len = 0;
                return (0);
        }
        return (archive_mstring_get_mbs_l(&entry->ae_hardlink, p, len, sc));
}

int64_t
archive_entry_uid(struct archive_entry *entry)
{
        return (entry->ae_stat.aest_uid);
}

const char *
archive_entry_uname(struct archive_entry *entry)
{
        const char *p;
        if (archive_mstring_get_mbs(entry->archive, &entry->ae_uname, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

const wchar_t *
archive_entry_uname_w(struct archive_entry *entry)
{
        const wchar_t *p;
        if (archive_mstring_get_wcs(entry->archive, &entry->ae_uname, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

int
_archive_entry_uname_l(struct archive_entry *entry,
    const char **p, size_t *len, struct archive_string_conv *sc)
{
        return (archive_mstring_get_mbs_l(&entry->ae_uname, p, len, sc));
}

/*
 * Functions to set archive_entry properties.
 */

void
archive_entry_set_filetype(struct archive_entry *entry, unsigned int type)
{
        entry->stat_valid = 0;
        entry->acl.mode &= ~AE_IFMT;
        entry->acl.mode |= AE_IFMT & type;
}

void
archive_entry_set_size(struct archive_entry *entry, int64_t s)
{
        entry->stat_valid = 0;
        entry->ae_stat.aest_size = s;
        entry->ae_set |= AE_SET_SIZE;
}

void
archive_entry_unset_size(struct archive_entry *entry)
{
        archive_entry_set_size(entry, 0);
        entry->ae_set &= ~AE_SET_SIZE;
}

void
archive_entry_copy_sourcepath(struct archive_entry *entry, const char *path)
{
        archive_mstring_copy_mbs(&entry->ae_sourcepath, path);
}

int64_t
archive_entry_gid(struct archive_entry *entry)
{
        return (entry->ae_stat.aest_gid);
}

const char *
archive_entry_gname(struct archive_entry *entry)
{
        const char *p;
        if (archive_mstring_get_mbs(entry->archive, &entry->ae_gname, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

const wchar_t *
archive_entry_gname_w(struct archive_entry *entry)
{
        const wchar_t *p;
        if (archive_mstring_get_wcs(entry->archive, &entry->ae_gname, &p) == 0)
                return (p);
        if (errno == ENOMEM)
                __archive_errx(1, "No memory");
        return (NULL);
}

int
_archive_entry_gname_l(struct archive_entry *entry,
    const char **p, size_t *len, struct archive_string_conv *sc)
{
        return (archive_mstring_get_mbs_l(&entry->ae_gname, p, len, sc));
}

void
archive_entry_set_symlink(struct archive_entry *entry, const char *linkname)
{
        archive_mstring_copy_mbs(&entry->ae_symlink, linkname);
        if (linkname != NULL)
                entry->ae_set |= AE_SET_SYMLINK;
        else
                entry->ae_set &= ~AE_SET_SYMLINK;
}

void
archive_entry_copy_symlink(struct archive_entry *entry, const char *linkname)
{
        archive_mstring_copy_mbs(&entry->ae_symlink, linkname);
        if (linkname != NULL)
                entry->ae_set |= AE_SET_SYMLINK;
        else
                entry->ae_set &= ~AE_SET_SYMLINK;
}

int
_archive_entry_copy_symlink_l(struct archive_entry *entry,
    const char *linkname, size_t len, struct archive_string_conv *sc)
{
        int r;

        r = archive_mstring_copy_mbs_len_l(&entry->ae_symlink,
            linkname, len, sc);
        if (linkname != NULL && r == 0)
                entry->ae_set |= AE_SET_SYMLINK;
        else
                entry->ae_set &= ~AE_SET_SYMLINK;
        return (r);
}

void
archive_entry_set_dev(struct archive_entry *entry, dev_t d)
{
        entry->stat_valid = 0;
        entry->ae_set |= AE_SET_DEV;
        entry->ae_stat.aest_dev_is_broken_down = 0;
        entry->ae_stat.aest_dev = d;
}

void
archive_entry_set_ino(struct archive_entry *entry, int64_t ino)
{
        entry->stat_valid = 0;
        entry->ae_set |= AE_SET_INO;
        entry->ae_stat.aest_ino = ino;
}

void
archive_entry_set_pathname(struct archive_entry *entry, const char *name)
{
        archive_mstring_copy_mbs(&entry->ae_pathname, name);
}

#define archive_entry_copy_pathname_l   _archive_entry_copy_pathname_l
int
_archive_entry_copy_pathname_l(struct archive_entry *entry,
    const char *name, size_t len, struct archive_string_conv *sc)
{
        return (archive_mstring_copy_mbs_len_l(&entry->ae_pathname,
            name, len, sc));
}

void
archive_entry_set_mode(struct archive_entry *entry, mode_t m)
{
        entry->stat_valid = 0;
        entry->acl.mode = m;
}

void
archive_entry_copy_stat(struct archive_entry *entry, const struct stat *st)
{
//#if HAVE_STRUCT_STAT_ST_MTIMESPEC_TV_NSEC
//        archive_entry_set_atime(entry, st->st_atime, st->st_atimespec.tv_nsec);
//        archive_entry_set_ctime(entry, st->st_ctime, st->st_ctimespec.tv_nsec);
//        archive_entry_set_mtime(entry, st->st_mtime, st->st_mtimespec.tv_nsec);
//#elif HAVE_STRUCT_STAT_ST_MTIM_TV_NSEC
//        archive_entry_set_atime(entry, st->st_atime, st->st_atim.tv_nsec);
//        archive_entry_set_ctime(entry, st->st_ctime, st->st_ctim.tv_nsec);
//        archive_entry_set_mtime(entry, st->st_mtime, st->st_mtim.tv_nsec);
//#elif HAVE_STRUCT_STAT_ST_MTIME_N
//        archive_entry_set_atime(entry, st->st_atime, st->st_atime_n);
//        archive_entry_set_ctime(entry, st->st_ctime, st->st_ctime_n);
//        archive_entry_set_mtime(entry, st->st_mtime, st->st_mtime_n);
//#elif HAVE_STRUCT_STAT_ST_UMTIME
//        archive_entry_set_atime(entry, st->st_atime, st->st_uatime * 1000);
//        archive_entry_set_ctime(entry, st->st_ctime, st->st_uctime * 1000);
//        archive_entry_set_mtime(entry, st->st_mtime, st->st_umtime * 1000);
//#elif HAVE_STRUCT_STAT_ST_MTIME_USEC
//        archive_entry_set_atime(entry, st->st_atime, st->st_atime_usec * 1000);
//        archive_entry_set_ctime(entry, st->st_ctime, st->st_ctime_usec * 1000);
//        archive_entry_set_mtime(entry, st->st_mtime, st->st_mtime_usec * 1000);
//#else
//        archive_entry_set_atime(entry, st->st_atime, 0);
//        archive_entry_set_ctime(entry, st->st_ctime, 0);
//        archive_entry_set_mtime(entry, st->st_mtime, 0);
//#endif
//#if HAVE_STRUCT_STAT_ST_BIRTHTIMESPEC_TV_NSEC
//        archive_entry_set_birthtime(entry, st->st_birthtime, st->st_birthtimespec.tv_nsec);
//#elif HAVE_STRUCT_STAT_ST_BIRTHTIME
//        archive_entry_set_birthtime(entry, st->st_birthtime, 0);
//#else
//        archive_entry_unset_birthtime(entry);
//#endif
//        archive_entry_set_dev(entry, st->st_dev);
//        archive_entry_set_gid(entry, st->st_gid);
//        archive_entry_set_uid(entry, st->st_uid);
//        archive_entry_set_ino(entry, st->st_ino);
//        archive_entry_set_nlink(entry, st->st_nlink);
//        archive_entry_set_rdev(entry, st->st_rdev);
        archive_entry_set_size(entry, st->st_size);
        archive_entry_set_mode(entry, st->st_mode);
}


void
archive_entry_set_uname(struct archive_entry *entry, const char *name)
{
        archive_mstring_copy_mbs(&entry->ae_uname, name);
}

void
archive_entry_set_gname(struct archive_entry *entry, const char *name)
{
        archive_mstring_copy_mbs(&entry->ae_gname, name);
}


time_t
archive_entry_mtime(struct archive_entry *entry)
{
        return (entry->ae_stat.aest_mtime);
}

////////////////////////////////////////////////////////////////////////
//
//      archive_read
//
////////////////////////////////////////////////////////////////////////
struct archive_read;
struct archive_read_filter_bidder;
struct archive_read_filter;

/*
 * How bidding works for filters:
 *   * The bid manager initializes the client-provided reader as the
 *     first filter.
 *   * It invokes the bidder for each registered filter with the
 *     current head filter.
 *   * The bidders can use archive_read_filter_ahead() to peek ahead
 *     at the incoming data to compose their bids.
 *   * The bid manager creates a new filter structure for the winning
 *     bidder and gives the winning bidder a chance to initialize it.
 *   * The new filter becomes the new top filter and we repeat the
 *     process.
 * This ends only when no bidder provides a non-zero bid.  Then
 * we perform a similar dance with the registered format handlers.
 */
struct archive_read_filter_bidder {
        /* Configuration data for the bidder. */
        void *data;
        /* Name of the filter */
        const char *name;
        /* Taste the upstream filter to see if we handle this. */
        int (*bid)(struct archive_read_filter_bidder *,
            struct archive_read_filter *);
        /* Initialize a newly-created filter. */
        int (*init)(struct archive_read_filter *);
        /* Set an option for the filter bidder. */
        int (*options)(struct archive_read_filter_bidder *,
            const char *key, const char *value);
        /* Release the bidder's configuration data. */
        int (*free)(struct archive_read_filter_bidder *);
};

/*
 * This structure is allocated within the archive_read core
 * and initialized by archive_read and the init() method of the
 * corresponding bidder above.
 */
struct archive_read_filter {
        int64_t position;
        /* Essentially all filters will need these values, so
         * just declare them here. */
        struct archive_read_filter_bidder *bidder; /* My bidder. */
        struct archive_read_filter *upstream; /* Who I read from. */
        struct archive_read *archive; /* Associated archive. */
        /* Open a block for reading */
        int (*open)(struct archive_read_filter *self);
        /* Return next block. */
        ssize_t (*read)(struct archive_read_filter *, const void **);
        /* Skip forward this many bytes. */
        int64_t (*skip)(struct archive_read_filter *self, int64_t request);
        /* Seek to an absolute location. */
        int64_t (*seek)(struct archive_read_filter *self, int64_t offset, int whence);
        /* Close (just this filter) and free(self). */
        int (*close)(struct archive_read_filter *self);
        /* Function that handles switching from reading one block to the next/prev */
        int (*sswitch)(struct archive_read_filter *self, unsigned int iindex);
        /* My private data. */
        void *data;

        const char      *name;
        int              code;

        /* Used by reblocking logic. */
        char            *buffer;
        size_t           buffer_size;
        char            *next;          /* Current read location. */
        size_t           avail;         /* Bytes in my buffer. */
        const void      *client_buff;   /* Client buffer information. */
        size_t           client_total;
        const char      *client_next;
        size_t           client_avail;
        char             end_of_file;
        char             closed;
        char             fatal;
};

/*
 * The client looks a lot like a filter, so we just wrap it here.
 *
 * TODO: Make archive_read_filter and archive_read_client identical so
 * that users of the library can easily register their own
 * transformation filters.  This will probably break the API/ABI and
 * so should be deferred at least until libarchive 3.0.
 */
struct archive_read_data_node {
        int64_t begin_position;
        int64_t total_size;
        void *data;
};
struct archive_read_client {
        archive_open_callback   *opener;
        archive_read_callback   *reader;
        archive_skip_callback   *skipper;
        archive_seek_callback   *seeker;
        archive_close_callback  *closer;
        archive_switch_callback *switcher;
        unsigned int nodes;
        unsigned int cursor;
        int64_t position;
        struct archive_read_data_node *dataset;
};

struct archive_read {
        struct archive  archive;

        struct archive_entry    *entry;

        /* Dev/ino of the archive being read/written. */
        int               skip_file_set;
        int64_t           skip_file_dev;
        int64_t           skip_file_ino;

        /*
         * Used by archive_read_data() to track blocks and copy
         * data to client buffers, filling gaps with zero bytes.
         */
        const char       *read_data_block;
        int64_t           read_data_offset;
        int64_t           read_data_output_offset;
        size_t            read_data_remaining;

        /*
         * Used by formats/filters to determine the amount of data
         * requested from a call to archive_read_data(). This is only
         * useful when the format/filter has seek support.
         */
        char              read_data_is_posix_read;
        size_t            read_data_requested;

        /* Callbacks to open/read/write/close client archive streams. */
        struct archive_read_client client;

        /* Registered filter bidders. */
        struct archive_read_filter_bidder bidders[14];

        /* Last filter in chain */
        struct archive_read_filter *filter;

        /* Whether to bypass filter bidding process */
        int bypass_filter_bidding;

        /* File offset of beginning of most recently-read header. */
        int64_t           header_position;

        /* Nodes and offsets of compressed data block */
        unsigned int data_start_node;
        unsigned int data_end_node;

        /*
         * Format detection is mostly the same as compression
         * detection, with one significant difference: The bidders
         * use the read_ahead calls above to examine the stream rather
         * than having the supervisor hand them a block of data to
         * examine.
         */

        struct archive_format_descriptor {
                void     *data;
                const char *name;
                int     (*bid)(struct archive_read *, int best_bid);
                int     (*options)(struct archive_read *, const char *key,
                    const char *value);
                int     (*read_header)(struct archive_read *, struct archive_entry *);
                int     (*read_data)(struct archive_read *, const void **, size_t *, int64_t *);
                int     (*read_data_skip)(struct archive_read *);
                int64_t (*seek_data)(struct archive_read *, int64_t, int);
                int     (*cleanup)(struct archive_read *);
        }       formats[16];
        struct archive_format_descriptor        *format; /* Active format. */

        /*
         * Various information needed by archive_extract.
         */
        struct extract           *extract;
        int                     (*cleanup_archive_extract)(struct archive_read *);
};

int     __archive_read_register_format(struct archive_read *a,
            void *format_data,
            const char *name,
            int (*bid)(struct archive_read *, int),
            int (*options)(struct archive_read *, const char *, const char *),
            int (*read_header)(struct archive_read *, struct archive_entry *),
            int (*read_data)(struct archive_read *, const void **, size_t *, int64_t *),
            int (*read_data_skip)(struct archive_read *),
            int64_t (*seek_data)(struct archive_read *, int64_t, int),
            int (*cleanup)(struct archive_read *));

int __archive_read_get_bidder(struct archive_read *a,
    struct archive_read_filter_bidder **bidder);

const void *__archive_read_ahead(struct archive_read *, size_t, ssize_t *);
const void *__archive_read_filter_ahead(struct archive_read_filter *,
    size_t, ssize_t *);
int64_t __archive_read_seek(struct archive_read*, int64_t, int);
int64_t __archive_read_filter_seek(struct archive_read_filter *, int64_t, int);
int64_t __archive_read_consume(struct archive_read *, int64_t);
int64_t __archive_read_filter_consume(struct archive_read_filter *, int64_t);
int __archive_read_program(struct archive_read_filter *, const char *);
void __archive_read_free_filters(struct archive_read *);
int  __archive_read_close_filters(struct archive_read *);


#define minimum(a, b) (a < b ? a : b)

static int      choose_filters(struct archive_read *);
static int      choose_format(struct archive_read *);
static struct archive_vtable *archive_read_vtable(void);
static int64_t  _archive_filter_bytes(struct archive *, int);
static int      _archive_filter_code(struct archive *, int);
static const char *_archive_filter_name(struct archive *, int);
static int  _archive_filter_count(struct archive *);
static int      _archive_read_close(struct archive *);
static int      _archive_read_data_block(struct archive *,
                    const void **, size_t *, int64_t *);
static int      _archive_read_free(struct archive *);
static int      _archive_read_next_header(struct archive *,
                    struct archive_entry **);
static int      _archive_read_next_header2(struct archive *,
                    struct archive_entry *);
static int64_t  advance_file_pointer(struct archive_read_filter *, int64_t);

static struct archive_vtable *
archive_read_vtable(void)
{
        static struct archive_vtable av;
        static int inited = 0;

        if (!inited) {
//                av.archive_filter_bytes = _archive_filter_bytes;
//                av.archive_filter_code = _archive_filter_code;
//                av.archive_filter_name = _archive_filter_name;
//                av.archive_filter_count = _archive_filter_count;
                av.archive_read_data_block = _archive_read_data_block;
                av.archive_read_next_header = _archive_read_next_header;
                av.archive_read_next_header2 = _archive_read_next_header2;
                av.archive_free = _archive_read_free;
                av.archive_close = _archive_read_close;
                inited = 1;
        }
        return (&av);
}

/*
 * Allocate, initialize and return a struct archive object.
 */
struct archive *
archive_read_new(void)
{
        struct archive_read *a;

        a = (struct archive_read *)malloc(sizeof(*a));
        if (a == NULL)
                return (NULL);
        memset(a, 0, sizeof(*a));
        a->archive.magic = ARCHIVE_READ_MAGIC;

        a->archive.state = ARCHIVE_STATE_NEW;
        a->entry = archive_entry_new2(&a->archive);
        a->archive.vtable = archive_read_vtable();

        return (&a->archive);
}

int
archive_read_next_header(struct archive *a, struct archive_entry **entry)
{
        return ((a->vtable->archive_read_next_header)(a, entry));
}

int
archive_read_next_header2(struct archive *a, struct archive_entry *entry)
{
        return ((a->vtable->archive_read_next_header2)(a, entry));
}

int
archive_read_close(struct archive *a)
{
        return ((a->vtable->archive_close)(a));
}

int
archive_read_free(struct archive *a)
{
        if (a == NULL)
                return (ARCHIVE_OK);
        return ((a->vtable->archive_free)(a));
}

int
archive_read_data_block(struct archive *a,
    const void **buff, size_t *s, int64_t *o)
{
        return ((a->vtable->archive_read_data_block)(a, buff, s, o));
}

/*
 * Record the do-not-extract-to file. This belongs in archive_read_extract.c.
 */
void
archive_read_extract_set_skip_file(struct archive *_a, int64_t d, int64_t i)
{
        struct archive_read *a = (struct archive_read *)_a;

//        if (ARCHIVE_OK != __archive_check_magic(_a, ARCHIVE_READ_MAGIC,
//                ARCHIVE_STATE_ANY, "archive_read_extract_set_skip_file"))
//                return;
        a->skip_file_set = 1;
        a->skip_file_dev = d;
        a->skip_file_ino = i;
}

static ssize_t
client_read_proxy(struct archive_read_filter *self, const void **buff)
{
        ssize_t r;
        r = (self->archive->client.reader)(&self->archive->archive,
            self->data, buff);
        return (r);
}

static int64_t
client_skip_proxy(struct archive_read_filter *self, int64_t request)
{
        if (request < 0)
                __archive_errx(1, "Negative skip requested.");
        if (request == 0)
                return 0;

        if (self->archive->client.skipper != NULL) {
                /* Seek requests over 1GiB are broken down into
                 * multiple seeks.  This avoids overflows when the
                 * requests get passed through 32-bit arguments. */
                int64_t skip_limit = (int64_t)1 << 30;
                int64_t total = 0;
                for (;;) {
                        int64_t get, ask = request;
                        if (ask > skip_limit)
                                ask = skip_limit;
                        get = (self->archive->client.skipper)
                                (&self->archive->archive, self->data, ask);
                        if (get == 0)
                                return (total);
                        request -= get;
                        total += get;
                }
        } else if (self->archive->client.seeker != NULL
                && request > 64 * 1024) {
                /* If the client provided a seeker but not a skipper,
                 * we can use the seeker to skip forward.
                 *
                 * Note: This isn't always a good idea.  The client
                 * skipper is allowed to skip by less than requested
                 * if it needs to maintain block alignment.  The
                 * seeker is not allowed to play such games, so using
                 * the seeker here may be a performance loss compared
                 * to just reading and discarding.  That's why we
                 * only do this for skips of over 64k.
                 */
                int64_t before = self->position;
                int64_t after = (self->archive->client.seeker)
                    (&self->archive->archive, self->data, request, SEEK_CUR);
                if (after != before + request)
                        return ARCHIVE_FATAL;
                return after - before;
        }
        return 0;
}

static int64_t
client_seek_proxy(struct archive_read_filter *self, int64_t offset, int whence)
{
        /* DO NOT use the skipper here!  If we transparently handled
         * forward seek here by using the skipper, that will break
         * other libarchive code that assumes a successful forward
         * seek means it can also seek backwards.
         */
        if (self->archive->client.seeker == NULL)
                return (ARCHIVE_FAILED);
        return (self->archive->client.seeker)(&self->archive->archive,
            self->data, offset, whence);
}

static int
client_close_proxy(struct archive_read_filter *self)
{
        int r = ARCHIVE_OK, r2;
        unsigned int i;

        if (self->archive->client.closer == NULL)
                return (r);
        for (i = 0; i < self->archive->client.nodes; i++)
        {
                r2 = (self->archive->client.closer)
                        ((struct archive *)self->archive,
                                self->archive->client.dataset[i].data);
                if (r > r2)
                        r = r2;
        }
        return (r);
}

static int
client_open_proxy(struct archive_read_filter *self)
{
  int r = ARCHIVE_OK;
        if (self->archive->client.opener != NULL)
                r = (self->archive->client.opener)(
                    (struct archive *)self->archive, self->data);
        return (r);
}

static int
client_switch_proxy(struct archive_read_filter *self, unsigned int iindex)
{
//  int r1 = ARCHIVE_OK, r2 = ARCHIVE_OK;
//        void *data2 = NULL;
//
//        /* Don't do anything if already in the specified data node */
//        if (self->archive->client.cursor == iindex)
//                return (ARCHIVE_OK);
//
//        self->archive->client.cursor = iindex;
//        data2 = self->archive->client.dataset[self->archive->client.cursor].data;
//        if (self->archive->client.switcher != NULL)
//        {
//                r1 = r2 = (self->archive->client.switcher)
//                        ((struct archive *)self->archive, self->data, data2);
//                self->data = data2;
//        }
//        else
//        {
//                /* Attempt to call close and open instead */
//                if (self->archive->client.closer != NULL)
//                        r1 = (self->archive->client.closer)
//                                ((struct archive *)self->archive, self->data);
//                self->data = data2;
//                if (self->archive->client.opener != NULL)
//                        r2 = (self->archive->client.opener)
//                                ((struct archive *)self->archive, self->data);
//        }
//        return (r1 < r2) ? r1 : r2;
  return (ARCHIVE_OK);
}
/*
 * Open the archive
 */
//int
//archive_read_open(struct archive *a, void *client_data,
//    archive_open_callback *client_opener, archive_read_callback *client_reader,
//    archive_close_callback *client_closer)
//{
//        /* Old archive_read_open() is just a thin shell around
//         * archive_read_open1. */
//        archive_read_set_open_callback(a, client_opener);
//        archive_read_set_read_callback(a, client_reader);
//        archive_read_set_close_callback(a, client_closer);
//        archive_read_set_callback_data(a, client_data);
//        return archive_read_open1(a);
//}
//
//
//int
//archive_read_open2(struct archive *a, void *client_data,
//    archive_open_callback *client_opener,
//    archive_read_callback *client_reader,
//    archive_skip_callback *client_skipper,
//    archive_close_callback *client_closer)
//{
//        /* Old archive_read_open2() is just a thin shell around
//         * archive_read_open1. */
//        archive_read_set_callback_data(a, client_data);
//        archive_read_set_open_callback(a, client_opener);
//        archive_read_set_read_callback(a, client_reader);
//        archive_read_set_skip_callback(a, client_skipper);
//        archive_read_set_close_callback(a, client_closer);
//        return archive_read_open1(a);
//}



int
archive_read_set_open_callback(struct archive *_a,
    archive_open_callback *client_opener)
{
        struct archive_read *a = (struct archive_read *)_a;
//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "archive_read_set_open_callback");
        a->client.opener = client_opener;
        return ARCHIVE_OK;
}

int
archive_read_set_read_callback(struct archive *_a,
    archive_read_callback *client_reader)
{
        struct archive_read *a = (struct archive_read *)_a;
//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "archive_read_set_read_callback");
        a->client.reader = client_reader;
        return ARCHIVE_OK;
}

int
archive_read_set_skip_callback(struct archive *_a,
    archive_skip_callback *client_skipper)
{
        struct archive_read *a = (struct archive_read *)_a;
//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "archive_read_set_skip_callback");
        a->client.skipper = client_skipper;
        return ARCHIVE_OK;
}

int
archive_read_set_seek_callback(struct archive *_a,
    archive_seek_callback *client_seeker)
{
        struct archive_read *a = (struct archive_read *)_a;
//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "archive_read_set_seek_callback");
        a->client.seeker = client_seeker;
        return ARCHIVE_OK;
}

int
archive_read_set_close_callback(struct archive *_a,
    archive_close_callback *client_closer)
{
        struct archive_read *a = (struct archive_read *)_a;
//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "archive_read_set_close_callback");
        a->client.closer = client_closer;
        return ARCHIVE_OK;
}

int
archive_read_set_switch_callback(struct archive *_a,
    archive_switch_callback *client_switcher)
{
        struct archive_read *a = (struct archive_read *)_a;
//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "archive_read_set_switch_callback");
        a->client.switcher = client_switcher;
        return ARCHIVE_OK;
}

int
archive_read_set_callback_data(struct archive *_a, void *client_data)
{
        return archive_read_set_callback_data2(_a, client_data, 0);
}

int
archive_read_set_callback_data2(struct archive *_a, void *client_data,
    unsigned int iindex)
{
        struct archive_read *a = (struct archive_read *)_a;
//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "archive_read_set_callback_data2");

        if (a->client.nodes == 0)
        {
                a->client.dataset = (struct archive_read_data_node *)
                    calloc(1, sizeof(*a->client.dataset));
                if (a->client.dataset == NULL)
                {
                        archive_set_error(&a->archive, ENOMEM,
                                "No memory.");
                        return ARCHIVE_FATAL;
                }
                a->client.nodes = 1;
        }

        if (iindex > a->client.nodes - 1)
        {
                archive_set_error(&a->archive, EINVAL,
                        "Invalid index specified.");
                return ARCHIVE_FATAL;
        }
        a->client.dataset[iindex].data = client_data;
        a->client.dataset[iindex].begin_position = -1;
        a->client.dataset[iindex].total_size = -1;
        return ARCHIVE_OK;
}

int
archive_read_append_callback_data(struct archive *_a, void *client_data)
{
        struct archive_read *a = (struct archive_read *)_a;
        return archive_read_add_callback_data(_a, client_data, a->client.nodes);
}



int
archive_read_add_callback_data(struct archive *_a, void *client_data,
    unsigned int iindex)
{
        struct archive_read *a = (struct archive_read *)_a;
        void *p;
        unsigned int i;

//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "archive_read_add_callback_data");
        if (iindex > a->client.nodes) {
//                archive_set_error(&a->archive, EINVAL,
//                        "Invalid index specified.");
                return ARCHIVE_FATAL;
        }
        p = realloc(a->client.dataset, sizeof(*a->client.dataset)
                * (++(a->client.nodes)));
        if (p == NULL) {
//                archive_set_error(&a->archive, ENOMEM,
//                        "No memory.");
                return ARCHIVE_FATAL;
        }
        a->client.dataset = (struct archive_read_data_node *)p;
        for (i = a->client.nodes - 1; i > iindex && i > 0; i--) {
                a->client.dataset[i].data = a->client.dataset[i-1].data;
                a->client.dataset[i].begin_position = -1;
                a->client.dataset[i].total_size = -1;
        }
        a->client.dataset[iindex].data = client_data;
        a->client.dataset[iindex].begin_position = -1;
        a->client.dataset[iindex].total_size = -1;
        return ARCHIVE_OK;
}

int
archive_read_open1(struct archive *_a)
{
        struct archive_read *a = (struct archive_read *)_a;
        struct archive_read_filter *filter, *tmp;
        int slot, e;
        unsigned int i;

//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "archive_read_open");
//        archive_clear_error(&a->archive);

        if (a->client.reader == NULL) {
                archive_set_error(&a->archive, EINVAL,
                    "No reader function provided to archive_read_open");
                a->archive.state = ARCHIVE_STATE_FATAL;
                return (ARCHIVE_FATAL);
        }

        /* Open data source. */
        if (a->client.opener != NULL) {
                e = (a->client.opener)(&a->archive, a->client.dataset[0].data);
                if (e != 0) {
                        /* If the open failed, call the closer to clean up. */
                        if (a->client.closer) {
                                for (i = 0; i < a->client.nodes; i++)
                                        (a->client.closer)(&a->archive,
                                            a->client.dataset[i].data);
                        }
                        return (e);
                }
        }

        filter = (struct archive_read_filter *)calloc(1, sizeof(*filter));
        if (filter == NULL)
                return (ARCHIVE_FATAL);
        filter->bidder = NULL;
        filter->upstream = NULL;
        filter->archive = a;
        filter->data = a->client.dataset[0].data;
        filter->open = client_open_proxy;
        filter->read = client_read_proxy;
        filter->skip = client_skip_proxy;
        filter->seek = client_seek_proxy;
        filter->close = client_close_proxy;
        filter->sswitch = client_switch_proxy;
        filter->name = "none";
        filter->code = ARCHIVE_FILTER_NONE;

        a->client.dataset[0].begin_position = 0;
        if (!a->filter || !a->bypass_filter_bidding)
        {
                a->filter = filter;
                /* Build out the input pipeline. */
                e = choose_filters(a);
                if (e < ARCHIVE_WARN) {
                        a->archive.state = ARCHIVE_STATE_FATAL;
                        return (ARCHIVE_FATAL);
                }
        }
        else
        {
                /* Need to add "NONE" type filter at the end of the filter chain */
                tmp = a->filter;
                while (tmp->upstream)
                        tmp = tmp->upstream;
                tmp->upstream = filter;
        }

        if (!a->format)
        {
                slot = choose_format(a);
                if (slot < 0) {
                        __archive_read_close_filters(a);
                        a->archive.state = ARCHIVE_STATE_FATAL;
                        return (ARCHIVE_FATAL);
                }
                a->format = &(a->formats[slot]);
        }

        a->archive.state = ARCHIVE_STATE_HEADER;

        /* Ensure libarchive starts from the first node in a multivolume set */
        client_switch_proxy(a->filter, 0);
        return (e);
}


/*
 * Allow each registered stream transform to bid on whether
 * it wants to handle this stream.  Repeat until we've finished
 * building the pipeline.
 */
static int
choose_filters(struct archive_read *a)
{
        int number_bidders, i, bid, best_bid;
        struct archive_read_filter_bidder *bidder, *best_bidder;
        struct archive_read_filter *filter;
        ssize_t avail;
        int r;

        for (;;) {
                number_bidders = sizeof(a->bidders) / sizeof(a->bidders[0]);

                best_bid = 0;
                best_bidder = NULL;

                bidder = a->bidders;
                for (i = 0; i < number_bidders; i++, bidder++) {
                        if (bidder->bid != NULL) {
                                bid = (bidder->bid)(bidder, a->filter);
                                if (bid > best_bid) {
                                        best_bid = bid;
                                        best_bidder = bidder;
                                }
                        }
                }

                /* If no bidder, we're done. */
                if (best_bidder == NULL) {
                        /* Verify the filter by asking it for some data. */
                        __archive_read_filter_ahead(a->filter, 1, &avail);
                        if (avail < 0) {
                                __archive_read_close_filters(a);
                                __archive_read_free_filters(a);
                                return (ARCHIVE_FATAL);
                        }
                        a->archive.compression_name = a->filter->name;
                        a->archive.compression_code = a->filter->code;
                        return (ARCHIVE_OK);
                }

                filter
                    = (struct archive_read_filter *)calloc(1, sizeof(*filter));
                if (filter == NULL)
                        return (ARCHIVE_FATAL);
                filter->bidder = best_bidder;
                filter->archive = a;
                filter->upstream = a->filter;
                a->filter = filter;
                r = (best_bidder->init)(a->filter);
                if (r != ARCHIVE_OK) {
                        __archive_read_close_filters(a);
                        __archive_read_free_filters(a);
                        return (ARCHIVE_FATAL);
                }
        }
}

/*
 * Read header of next entry.
 */
static int
_archive_read_next_header2(struct archive *_a, struct archive_entry *entry)
{
        struct archive_read *a = (struct archive_read *)_a;
        int r1 = ARCHIVE_OK, r2;

//        archive_check_magic(_a, ARCHIVE_READ_MAGIC,
//            ARCHIVE_STATE_HEADER | ARCHIVE_STATE_DATA,
//            "archive_read_next_header");

        archive_entry_clear(entry);
//        archive_clear_error(&a->archive);

        /*
         * If client didn't consume entire data, skip any remainder
         * (This is especially important for GNU incremental directories.)
         */
        if (a->archive.state == ARCHIVE_STATE_DATA) {
                r1 = archive_read_data_skip(&a->archive);
                if (r1 == ARCHIVE_EOF)
                        archive_set_error(&a->archive, EIO,
                            "Premature end-of-file.");
                if (r1 == ARCHIVE_EOF || r1 == ARCHIVE_FATAL) {
                        a->archive.state = ARCHIVE_STATE_FATAL;
                        return (ARCHIVE_FATAL);
                }
        }

        /* Record start-of-header offset in uncompressed stream. */
        a->header_position = a->filter->position;

        ++_a->file_count;
        r2 = (a->format->read_header)(a, entry);

        /*
         * EOF and FATAL are persistent at this layer.  By
         * modifying the state, we guarantee that future calls to
         * read a header or read data will fail.
         */
        switch (r2) {
        case ARCHIVE_EOF:
                a->archive.state = ARCHIVE_STATE_EOF;
                --_a->file_count;/* Revert a file counter. */
                break;
        case ARCHIVE_OK:
//                a->archive.state = ARCHIVE_STATE_DATA;
                a->archive.state = ARCHIVE_STATE_HEADER;
                break;
        case ARCHIVE_WARN:
//                a->archive.state = ARCHIVE_STATE_DATA;
                a->archive.state = ARCHIVE_STATE_HEADER;
                break;
        case ARCHIVE_RETRY:
                break;
        case ARCHIVE_FATAL:
                a->archive.state = ARCHIVE_STATE_FATAL;
                break;
        }

        a->read_data_output_offset = 0;
        a->read_data_remaining = 0;
        a->read_data_is_posix_read = 0;
        a->read_data_requested = 0;
        a->data_start_node = a->client.cursor;
        /* EOF always wins; otherwise return the worst error. */
        return (r2 < r1 || r2 == ARCHIVE_EOF) ? r2 : r1;
}

int
_archive_read_next_header(struct archive *_a, struct archive_entry **entryp)
{
        int ret;
        struct archive_read *a = (struct archive_read *)_a;
        *entryp = NULL;
        ret = _archive_read_next_header2(_a, a->entry);
        *entryp = a->entry;
        return ret;
}



/*
 * Advance the file pointer by the amount requested.
 * Returns the amount actually advanced, which may be less than the
 * request if EOF is encountered first.
 * Returns a negative value if there's an I/O error.
 */
static int64_t
advance_file_pointer(struct archive_read_filter *filter, int64_t request)
{
        int64_t bytes_skipped, total_bytes_skipped = 0;
        ssize_t bytes_read;
        size_t min;

        if (filter->fatal)
                return (-1);

        /* Use up the copy buffer first. */
        if (filter->avail > 0) {
                min = (size_t)minimum(request, (int64_t)filter->avail);
                filter->next += min;
                filter->avail -= min;
                request -= min;
                filter->position += min;
                total_bytes_skipped += min;
        }

        /* Then use up the client buffer. */
        if (filter->client_avail > 0) {
                min = (size_t)minimum(request, (int64_t)filter->client_avail);
                filter->client_next += min;
                filter->client_avail -= min;
                request -= min;
                filter->position += min;
                total_bytes_skipped += min;
        }
        if (request == 0)
                return (total_bytes_skipped);

        /* If there's an optimized skip function, use it. */
        if (filter->skip != NULL) {
                bytes_skipped = (filter->skip)(filter, request);
                if (bytes_skipped < 0) {        /* error */
                        filter->fatal = 1;
                        return (bytes_skipped);
                }
                filter->position += bytes_skipped;
                total_bytes_skipped += bytes_skipped;
                request -= bytes_skipped;
                if (request == 0)
                        return (total_bytes_skipped);
        }

        /* Use ordinary reads as necessary to complete the request. */
        for (;;) {
                bytes_read = (filter->read)(filter, &filter->client_buff);
                if (bytes_read < 0) {
                        filter->client_buff = NULL;
                        filter->fatal = 1;
                        return (bytes_read);
                }

                if (bytes_read == 0) {
                        if (filter->archive->client.cursor !=
                              filter->archive->client.nodes - 1) {
                                if (client_switch_proxy(filter,
                                    filter->archive->client.cursor + 1)
                                    == ARCHIVE_OK)
                                        continue;
                        }
                        filter->client_buff = NULL;
                        filter->end_of_file = 1;
                        return (total_bytes_skipped);
                }

                if (bytes_read >= request) {
                        filter->client_next =
                            ((const char *)filter->client_buff) + request;
                        filter->client_avail = (size_t)(bytes_read - request);
                        filter->client_total = bytes_read;
                        total_bytes_skipped += request;
                        filter->position += request;
                        return (total_bytes_skipped);
                }

                filter->position += bytes_read;
                total_bytes_skipped += bytes_read;
                request -= bytes_read;
        }
}

/**
 * Returns ARCHIVE_FAILED if seeking isn't supported.
 */
int64_t
__archive_read_seek(struct archive_read *a, int64_t offset, int whence)
{
        return __archive_read_filter_seek(a->filter, offset, whence);
}

int64_t
__archive_read_filter_seek(struct archive_read_filter *filter, int64_t offset,
    int whence)
{
        struct archive_read_client *client;
        int64_t r;
        unsigned int cursor;

        if (filter->closed || filter->fatal)
                return (ARCHIVE_FATAL);
        if (filter->seek == NULL)
                return (ARCHIVE_FAILED);

        client = &(filter->archive->client);
        switch (whence) {
        case SEEK_CUR:
                /* Adjust the offset and use SEEK_SET instead */
                offset += filter->position;
        case SEEK_SET:
                cursor = 0;
                while (1)
                {
                        if (client->dataset[cursor].begin_position < 0 ||
                            client->dataset[cursor].total_size < 0 ||
                            client->dataset[cursor].begin_position +
                              client->dataset[cursor].total_size - 1 > offset ||
                            cursor + 1 >= client->nodes)
                                break;
                        r = client->dataset[cursor].begin_position +
                                client->dataset[cursor].total_size;
                        client->dataset[++cursor].begin_position = r;
                }
                while (1) {
                        r = client_switch_proxy(filter, cursor);
                        if (r != ARCHIVE_OK)
                                return r;
                        if ((r = client_seek_proxy(filter, 0, SEEK_END)) < 0)
                                return r;
                        client->dataset[cursor].total_size = r;
                        if (client->dataset[cursor].begin_position +
                            client->dataset[cursor].total_size - 1 > offset ||
                            cursor + 1 >= client->nodes)
                                break;
                        r = client->dataset[cursor].begin_position +
                                client->dataset[cursor].total_size;
                        client->dataset[++cursor].begin_position = r;
                }
                offset -= client->dataset[cursor].begin_position;
                if (offset < 0)
                        offset = 0;
                else if (offset > client->dataset[cursor].total_size - 1)
                        offset = client->dataset[cursor].total_size - 1;
                if ((r = client_seek_proxy(filter, offset, SEEK_SET)) < 0)
                        return r;
                break;

        case SEEK_END:
                cursor = 0;
                while (1) {
                        if (client->dataset[cursor].begin_position < 0 ||
                            client->dataset[cursor].total_size < 0 ||
                            cursor + 1 >= client->nodes)
                                break;
                        r = client->dataset[cursor].begin_position +
                                client->dataset[cursor].total_size;
                        client->dataset[++cursor].begin_position = r;
                }
                while (1) {
                        r = client_switch_proxy(filter, cursor);
                        if (r != ARCHIVE_OK)
                                return r;
                        if ((r = client_seek_proxy(filter, 0, SEEK_END)) < 0)
                                return r;
                        client->dataset[cursor].total_size = r;
                        r = client->dataset[cursor].begin_position +
                                client->dataset[cursor].total_size;
                        if (cursor + 1 >= client->nodes)
                                break;
                        client->dataset[++cursor].begin_position = r;
                }
                while (1) {
                        if (r + offset >=
                            client->dataset[cursor].begin_position)
                                break;
                        offset += client->dataset[cursor].total_size;
                        if (cursor == 0)
                                break;
                        cursor--;
                        r = client->dataset[cursor].begin_position +
                                client->dataset[cursor].total_size;
                }
                offset = (r + offset) - client->dataset[cursor].begin_position;
                if ((r = client_switch_proxy(filter, cursor)) != ARCHIVE_OK)
                        return r;
                r = client_seek_proxy(filter, offset, SEEK_SET);
                if (r < ARCHIVE_OK)
                        return r;
                break;

        default:
                return (ARCHIVE_FATAL);
        }
        r += client->dataset[cursor].begin_position;

        if (r >= 0) {
                /*
                 * Ouch.  Clearing the buffer like this hurts, especially
                 * at bid time.  A lot of our efficiency at bid time comes
                 * from having bidders reuse the data we've already read.
                 *
                 * TODO: If the seek request is in data we already
                 * have, then don't call the seek callback.
                 *
                 * TODO: Zip seeks to end-of-file at bid time.  If
                 * other formats also start doing this, we may need to
                 * find a way for clients to fudge the seek offset to
                 * a block boundary.
                 *
                 * Hmmm... If whence was SEEK_END, we know the file
                 * size is (r - offset).  Can we use that to simplify
                 * the TODO items above?
                 */
                filter->avail = filter->client_avail = 0;
                filter->next = filter->buffer;
                filter->position = r;
                filter->end_of_file = 0;
        }
        return r;
}

/*
 * Allow each registered format to bid on whether it wants to handle
 * the next entry.  Return index of winning bidder.
 */
static int
choose_format(struct archive_read *a)
{
        int slots;
        int i;
        int bid, best_bid;
        int best_bid_slot;

        slots = sizeof(a->formats) / sizeof(a->formats[0]);
        best_bid = -1;
        best_bid_slot = -1;

        /* Set up a->format for convenience of bidders. */
        a->format = &(a->formats[0]);
        for (i = 0; i < slots; i++, a->format++) {
                if (a->format->bid) {
                        bid = (a->format->bid)(a, best_bid);
                        if (bid == ARCHIVE_FATAL)
                                return (ARCHIVE_FATAL);
                        if (a->filter->position != 0)
                                __archive_read_seek(a, 0, SEEK_SET);
                        if ((bid > best_bid) || (best_bid_slot < 0)) {
                                best_bid = bid;
                                best_bid_slot = i;
                        }
                }
        }

        /*
         * There were no bidders; this is a serious programmer error
         * and demands a quick and definitive abort.
         */
        if (best_bid_slot < 0) {
                archive_set_error(&a->archive, ARCHIVE_ERRNO_FILE_FORMAT,
                    "No formats registered");
                return (ARCHIVE_FATAL);
        }

        /*
         * There were bidders, but no non-zero bids; this means we
         * can't support this stream.
         */
        if (best_bid < 1) {
                archive_set_error(&a->archive, ARCHIVE_ERRNO_FILE_FORMAT,
                    "Unrecognized archive format");
                return (ARCHIVE_FATAL);
        }

        return (best_bid_slot);
}

/*
 * Skip over all remaining data in this entry.
 */
int
archive_read_data_skip(struct archive *_a)
{
        struct archive_read *a = (struct archive_read *)_a;
        int r;
        const void *buff;
        size_t size;
        int64_t offset;

//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_DATA,
//            "archive_read_data_skip");

        if (a->format->read_data_skip != NULL)
                r = (a->format->read_data_skip)(a);
        else {
                while ((r = archive_read_data_block(&a->archive,
                            &buff, &size, &offset))
                    == ARCHIVE_OK)
                        ;
        }

        if (r == ARCHIVE_EOF)
                r = ARCHIVE_OK;

        a->archive.state = ARCHIVE_STATE_HEADER;
        return (r);
}



/*
 * Read the next block of entry data from the archive.
 * This is a zero-copy interface; the client receives a pointer,
 * size, and file offset of the next available block of data.
 *
 * Returns ARCHIVE_OK if the operation is successful, ARCHIVE_EOF if
 * the end of entry is encountered.
 */
static int
_archive_read_data_block(struct archive *_a,
    const void **buff, size_t *size, int64_t *offset)
{
        struct archive_read *a = (struct archive_read *)_a;
//        archive_check_magic(_a, ARCHIVE_READ_MAGIC, ARCHIVE_STATE_DATA,
//            "archive_read_data_block");

        if (a->format->read_data == NULL) {
//                archive_set_error(&a->archive, ARCHIVE_ERRNO_PROGRAMMER,
//                    "Internal error: "
//                    "No format_read_data_block function registered");
                return (ARCHIVE_FATAL);
        }

        return (a->format->read_data)(a, buff, size, offset);
}



int
__archive_read_close_filters(struct archive_read *a)
{
        struct archive_read_filter *f = a->filter;
        int r = ARCHIVE_OK;
        /* Close each filter in the pipeline. */
        while (f != NULL) {
                struct archive_read_filter *t = f->upstream;
                if (!f->closed && f->close != NULL) {
                        int r1 = (f->close)(f);
                        f->closed = 1;
                        if (r1 < r)
                                r = r1;
                }
                free(f->buffer);
                f->buffer = NULL;
                f = t;
        }
        return r;
}

void
__archive_read_free_filters(struct archive_read *a)
{
        while (a->filter != NULL) {
                struct archive_read_filter *t = a->filter->upstream;
                free(a->filter);
                a->filter = t;
        }
}

/*
 * Close the file and all I/O.
 */
static int
_archive_read_close(struct archive *_a)
{
        struct archive_read *a = (struct archive_read *)_a;
        int r = ARCHIVE_OK, r1 = ARCHIVE_OK;

//        archive_check_magic(&a->archive, ARCHIVE_READ_MAGIC,
//            ARCHIVE_STATE_ANY | ARCHIVE_STATE_FATAL, "archive_read_close");
        if (a->archive.state == ARCHIVE_STATE_CLOSED)
                return (ARCHIVE_OK);
//        archive_clear_error(&a->archive);
        a->archive.state = ARCHIVE_STATE_CLOSED;

        /* TODO: Clean up the formatters. */

        /* Release the filter objects. */
        r1 = __archive_read_close_filters(a);
        if (r1 < r)
                r = r1;

        return (r);
}

/*
 * Release memory and other resources.
 */
static int
_archive_read_free(struct archive *_a)
{
        struct archive_read *a = (struct archive_read *)_a;
        int i, n;
        int slots;
        int r = ARCHIVE_OK;

        if (_a == NULL)
                return (ARCHIVE_OK);
//        archive_check_magic(_a, ARCHIVE_READ_MAGIC,
//            ARCHIVE_STATE_ANY | ARCHIVE_STATE_FATAL, "archive_read_free");
        if (a->archive.state != ARCHIVE_STATE_CLOSED
            && a->archive.state != ARCHIVE_STATE_FATAL)
                r = archive_read_close(&a->archive);

        /* Call cleanup functions registered by optional components. */
        if (a->cleanup_archive_extract != NULL)
                r = (a->cleanup_archive_extract)(a);

        /* Cleanup format-specific data. */
        slots = sizeof(a->formats) / sizeof(a->formats[0]);
        for (i = 0; i < slots; i++) {
                a->format = &(a->formats[i]);
                if (a->formats[i].cleanup)
                        (a->formats[i].cleanup)(a);
        }

        /* Free the filters */
        __archive_read_free_filters(a);

        /* Release the bidder objects. */
        n = sizeof(a->bidders)/sizeof(a->bidders[0]);
        for (i = 0; i < n; i++) {
                if (a->bidders[i].free != NULL) {
                        int r1 = (a->bidders[i].free)(&a->bidders[i]);
                        if (r1 < r)
                                r = r1;
                }
        }

        archive_string_free(&a->archive.error_string);
        if (a->entry)
                archive_entry_free(a->entry);
        a->archive.magic = 0;
        __archive_clean(&a->archive);
        free(a->client.dataset);
        free(a);
        return (r);
}

/*
 * Used internally by read format handlers to register their bid and
 * initialization functions.
 */
int
__archive_read_register_format(struct archive_read *a,
    void *format_data,
    const char *name,
    int (*bid)(struct archive_read *, int),
    int (*options)(struct archive_read *, const char *, const char *),
    int (*read_header)(struct archive_read *, struct archive_entry *),
    int (*read_data)(struct archive_read *, const void **, size_t *, int64_t *),
    int (*read_data_skip)(struct archive_read *),
    int64_t (*seek_data)(struct archive_read *, int64_t, int),
    int (*cleanup)(struct archive_read *))
{
        int i, number_slots;

//        archive_check_magic(&a->archive,
//            ARCHIVE_READ_MAGIC, ARCHIVE_STATE_NEW,
//            "__archive_read_register_format");

        number_slots = sizeof(a->formats) / sizeof(a->formats[0]);

        for (i = 0; i < number_slots; i++) {
                if (a->formats[i].bid == bid)
                        return (ARCHIVE_WARN); /* We've already installed */
                if (a->formats[i].bid == NULL) {
                        a->formats[i].bid = bid;
                        a->formats[i].options = options;
                        a->formats[i].read_header = read_header;
                        a->formats[i].read_data = read_data;
                        a->formats[i].read_data_skip = read_data_skip;
                        a->formats[i].seek_data = seek_data;
                        a->formats[i].cleanup = cleanup;
                        a->formats[i].data = format_data;
                        a->formats[i].name = name;
                        return (ARCHIVE_OK);
                }
        }

        archive_set_error(&a->archive, ENOMEM,
            "Not enough slots for format registration");
        return (ARCHIVE_FATAL);
}

const void *
__archive_read_ahead(struct archive_read *a, size_t min, ssize_t *avail)
{
        return (__archive_read_filter_ahead(a->filter, min, avail));
}

const void *
__archive_read_filter_ahead(struct archive_read_filter *filter,
    size_t min, ssize_t *avail)
{
        ssize_t bytes_read;
        size_t tocopy;

        if (filter->fatal) {
                if (avail)
                        *avail = ARCHIVE_FATAL;
                return (NULL);
        }

        /*
         * Keep pulling more data until we can satisfy the request.
         */
        for (;;) {

                /*
                 * If we can satisfy from the copy buffer (and the
                 * copy buffer isn't empty), we're done.  In particular,
                 * note that min == 0 is a perfectly well-defined
                 * request.
                 */
                if (filter->avail >= min && filter->avail > 0) {
                        if (avail != NULL)
                                *avail = filter->avail;
                        return (filter->next);
                }

                /*
                 * We can satisfy directly from client buffer if everything
                 * currently in the copy buffer is still in the client buffer.
                 */
                if (filter->client_total >= filter->client_avail + filter->avail
                    && filter->client_avail + filter->avail >= min) {
                        /* "Roll back" to client buffer. */
                        filter->client_avail += filter->avail;
                        filter->client_next -= filter->avail;
                        /* Copy buffer is now empty. */
                        filter->avail = 0;
                        filter->next = filter->buffer;
                        /* Return data from client buffer. */
                        if (avail != NULL)
                                *avail = filter->client_avail;
                        return (filter->client_next);
                }

                /* Move data forward in copy buffer if necessary. */
                if (filter->next > filter->buffer &&
                    filter->next + min > filter->buffer + filter->buffer_size) {
                        if (filter->avail > 0)
                                memmove(filter->buffer, filter->next,
                                    filter->avail);
                        filter->next = filter->buffer;
                }

                /* If we've used up the client data, get more. */
                if (filter->client_avail <= 0) {
                        if (filter->end_of_file) {
                                if (avail != NULL)
                                        *avail = 0;
                                return (NULL);
                        }
                        bytes_read = (filter->read)(filter,
                            &filter->client_buff);
                        if (bytes_read < 0) {           /* Read error. */
                                filter->client_total = filter->client_avail = 0;
                                filter->client_next = NULL;
                                    filter->client_buff = NULL;
                                filter->fatal = 1;
                                if (avail != NULL)
                                        *avail = ARCHIVE_FATAL;
                                return (NULL);
                        }
                        if (bytes_read == 0) {
                                /* Check for another client object first */
                                if (filter->archive->client.cursor !=
                                      filter->archive->client.nodes - 1) {
                                        if (client_switch_proxy(filter,
                                            filter->archive->client.cursor + 1)
                                            == ARCHIVE_OK)
                                                continue;
                                }
                                /* Premature end-of-file. */
                                filter->client_total = filter->client_avail = 0;
                                filter->client_next = NULL;
                                    filter->client_buff = NULL;
                                filter->end_of_file = 1;
                                /* Return whatever we do have. */
                                if (avail != NULL)
                                        *avail = filter->avail;
                                return (NULL);
                        }
                        filter->client_total = bytes_read;
                        filter->client_avail = filter->client_total;
                        filter->client_next = (char*)filter->client_buff;
                } else {
                        /*
                         * We can't satisfy the request from the copy
                         * buffer or the existing client data, so we
                         * need to copy more client data over to the
                         * copy buffer.
                         */

                        /* Ensure the buffer is big enough. */
                        if (min > filter->buffer_size) {
                                size_t s, t;
                                char *p;

                                /* Double the buffer; watch for overflow. */
                                s = t = filter->buffer_size;
                                if (s == 0)
                                        s = min;
                                while (s < min) {
                                        t *= 2;
                                        if (t <= s) { /* Integer overflow! */
                                                archive_set_error(
                                                    &filter->archive->archive,
                                                    ENOMEM,
                                                    "Unable to allocate copy"
                                                    " buffer");
                                                filter->fatal = 1;
                                                if (avail != NULL)
                                                        *avail = ARCHIVE_FATAL;
                                                return (NULL);
                                        }
                                        s = t;
                                }
                                /* Now s >= min, so allocate a new buffer. */
                                p = (char *)malloc(s);
                                if (p == NULL) {
                                        archive_set_error(
                                                &filter->archive->archive,
                                                ENOMEM,
                                            "Unable to allocate copy buffer");
                                        filter->fatal = 1;
                                        if (avail != NULL)
                                                *avail = ARCHIVE_FATAL;
                                        return (NULL);
                                }
                                /* Move data into newly-enlarged buffer. */
                                if (filter->avail > 0)
                                        memmove(p, filter->next, filter->avail);
                                free(filter->buffer);
                                filter->next = filter->buffer = p;
                                filter->buffer_size = s;
                        }

                        /* We can add client data to copy buffer. */
                        /* First estimate: copy to fill rest of buffer. */
                        tocopy = (filter->buffer + filter->buffer_size)
                            - (filter->next + filter->avail);
                        /* Don't waste time buffering more than we need to. */
                        if (tocopy + filter->avail > min)
                                tocopy = min - filter->avail;
                        /* Don't copy more than is available. */
                        if (tocopy > filter->client_avail)
                                tocopy = filter->client_avail;

                        memcpy(filter->next + filter->avail,
                            filter->client_next, tocopy);
                        /* Remove this data from client buffer. */
                        filter->client_next += tocopy;
                        filter->client_avail -= tocopy;
                        /* add it to copy buffer. */
                        filter->avail += tocopy;
                }
        }
}



/*
 * Move the file pointer forward.
 */
int64_t
__archive_read_consume(struct archive_read *a, int64_t request)
{
        return (__archive_read_filter_consume(a->filter, request));
}

int64_t
__archive_read_filter_consume(struct archive_read_filter * filter,
    int64_t request)
{
        int64_t skipped;

        if (request == 0)
                return 0;

        skipped = advance_file_pointer(filter, request);
        if (skipped == request)
                return (skipped);
        /* We hit EOF before we satisfied the skip request. */
        if (skipped < 0)  /* Map error code to 0 for error message below. */
                skipped = 0;
        archive_set_error(&filter->archive->archive,
            ARCHIVE_ERRNO_MISC,
            "Truncated input file (needed %jd bytes, only %jd available)",
            (intmax_t)request, (intmax_t)skipped);
        return (ARCHIVE_FATAL);
}


////////////////////////////////////////////////////////////////////////
//
//      archive_write
//
////////////////////////////////////////////////////////////////////////
#if 0
struct archive_write;

struct archive_write_filter {
        int64_t bytes_written;
        struct archive *archive; /* Associated archive. */
        struct archive_write_filter *next_filter; /* Who I write to. */
        int     (*options)(struct archive_write_filter *,
            const char *key, const char *value);
        int     (*open)(struct archive_write_filter *);
        int     (*write)(struct archive_write_filter *, const void *, size_t);
        int     (*close)(struct archive_write_filter *);
        int     (*free)(struct archive_write_filter *);
        void     *data;
        const char *name;
        int       code;
        int       bytes_per_block;
        int       bytes_in_last_block;
};

struct archive_write {
        struct archive  archive;

        /* Dev/ino of the archive being written. */
        int               skip_file_set;
        int64_t           skip_file_dev;
        int64_t           skip_file_ino;

        /* Utility:  Pointer to a block of nulls. */
        const unsigned char     *nulls;
        size_t                   null_length;

        /* Callbacks to open/read/write/close archive stream. */
        archive_open_callback   *client_opener;
        archive_write_callback  *client_writer;
        archive_close_callback  *client_closer;
        void                    *client_data;

        /*
         * Blocking information.  Note that bytes_in_last_block is
         * misleadingly named; I should find a better name.  These
         * control the final output from all compressors, including
         * compression_none.
         */
        int               bytes_per_block;
        int               bytes_in_last_block;

        /*
         * First and last write filters in the pipeline.
         */
        struct archive_write_filter *filter_first;
        struct archive_write_filter *filter_last;

        /*
         * Pointers to format-specific functions for writing.  They're
         * initialized by archive_write_set_format_XXX() calls.
         */
        void     *format_data;
        const char *format_name;
        int     (*format_init)(struct archive_write *);
        int     (*format_options)(struct archive_write *,
                    const char *key, const char *value);
        int     (*format_finish_entry)(struct archive_write *);
        int     (*format_write_header)(struct archive_write *,
                    struct archive_entry *);
        ssize_t (*format_write_data)(struct archive_write *,
                    const void *buff, size_t);
        int     (*format_close)(struct archive_write *);
        int     (*format_free)(struct archive_write *);
};
#endif

//static int      _archive_filter_code(struct archive *, int);
//static const char *_archive_filter_name(struct archive *, int);
//static int64_t  _archive_filter_bytes(struct archive *, int);
//static int  _archive_write_filter_count(struct archive *);
static int      _archive_write_close(struct archive *);
static int      _archive_write_free(struct archive *);
static int      _archive_write_header(struct archive *, struct archive_entry *);
static int      _archive_write_finish_entry(struct archive *);
//static ssize_t  _archive_write_data(struct archive *, const void *, size_t);

struct archive_none {
        size_t buffer_size;
        size_t avail;
        char *buffer;
        char *next;
};

static struct archive_vtable *
archive_write_vtable(void)
{
        static struct archive_vtable av;
        static int inited = 0;

        if (!inited) {
                av.archive_close = _archive_write_close;
//                av.archive_filter_bytes = _archive_filter_bytes;
//                av.archive_filter_code = _archive_filter_code;
//                av.archive_filter_name = _archive_filter_name;
//                av.archive_filter_count = _archive_write_filter_count;
                av.archive_free = _archive_write_free;
                av.archive_write_header = _archive_write_header;
                av.archive_write_finish_entry = _archive_write_finish_entry;
//                av.archive_write_data = _archive_write_data;
                inited = 1;
        }
        return (&av);
}

struct archive *
archive_write_new(void)
{
        struct archive_write *a;
        unsigned char *nulls;

        a = (struct archive_write *)malloc(sizeof(*a));
        if (a == NULL)
                return (NULL);
        memset(a, 0, sizeof(*a));
        a->archive.magic = ARCHIVE_WRITE_MAGIC;
        a->archive.state = ARCHIVE_STATE_NEW;
        a->archive.vtable = archive_write_vtable();
        /*
         * The value 10240 here matches the traditional tar default,
         * but is otherwise arbitrary.
         * TODO: Set the default block size from the format selected.
         */
        a->bytes_per_block = 10240;
        a->bytes_in_last_block = -1;    /* Default */

        /* Initialize a block of nulls for padding purposes. */
        a->null_length = 1024;
        nulls = (unsigned char *)malloc(a->null_length);
        if (nulls == NULL) {
                free(a);
                return (NULL);
        }
        memset(nulls, 0, a->null_length);
        a->nulls = nulls;
        return (&a->archive);
}

int
archive_write_close(struct archive *a)
{
        return ((a->vtable->archive_close)(a));
}

int
archive_write_free(struct archive *a)
{
        if (a == NULL)
                return (ARCHIVE_OK);
        return ((a->vtable->archive_free)(a));
}

int
archive_write_header(struct archive *a, struct archive_entry *entry)
{
        ++a->file_count;
        return ((a->vtable->archive_write_header)(a, entry));
}

int
archive_write_finish_entry(struct archive *a)
{
        return ((a->vtable->archive_write_finish_entry)(a));
}

void
__archive_write_filters_free(struct archive *_a)
{
        struct archive_write *a = (struct archive_write *)_a;
        int r = ARCHIVE_OK, r1;

        while (a->filter_first != NULL) {
                struct archive_write_filter *next
                    = a->filter_first->next_filter;
                if (a->filter_first->free != NULL) {
                        r1 = (*a->filter_first->free)(a->filter_first);
                        if (r > r1)
                                r = r1;
                }
                free(a->filter_first);
                a->filter_first = next;
        }
        a->filter_last = NULL;
}

/*
 * Destroy the archive structure.
 *
 * Be careful: user might just call write_new and then write_free.
 * Don't assume we actually wrote anything or performed any non-trivial
 * initialization.
 */
static int
_archive_write_free(struct archive *_a)
{
        struct archive_write *a = (struct archive_write *)_a;
        int r = ARCHIVE_OK, r1;

        if (_a == NULL)
                return (ARCHIVE_OK);
        /* It is okay to call free() in state FATAL. */
//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_ANY | ARCHIVE_STATE_FATAL, "archive_write_free");
        if (a->archive.state != ARCHIVE_STATE_FATAL)
                r = archive_write_close(&a->archive);

        /* Release format resources. */
        if (a->format_free != NULL) {
                r1 = (a->format_free)(a);
                if (r1 < r)
                        r = r1;
        }

        __archive_write_filters_free(_a);

        /* Release various dynamic buffers. */
        free((void *)(uintptr_t)(const void *)a->nulls);
        archive_string_free(&a->archive.error_string);
        a->archive.magic = 0;
        __archive_clean(&a->archive);
        free(a);
        return (r);
}


static int
_archive_write_header(struct archive *_a, struct archive_entry *entry)
{
        struct archive_write *a = (struct archive_write *)_a;
        int ret = ARCHIVE_OK, r2;

//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_DATA | ARCHIVE_STATE_HEADER, "archive_write_header");
//        archive_clear_error(&a->archive);
//
//        if (a->format_write_header == NULL) {
//                archive_set_error(&(a->archive), -1,
//                    "Format must be set before you can write to an archive.");
//                a->archive.state = ARCHIVE_STATE_FATAL;
//                return (ARCHIVE_FATAL);
//        }
//
//        /* In particular, "retry" and "fatal" get returned immediately. */
//        ret = archive_write_finish_entry(&a->archive);
//        if (ret == ARCHIVE_FATAL) {
//                a->archive.state = ARCHIVE_STATE_FATAL;
//                return (ARCHIVE_FATAL);
//        }
//        if (ret < ARCHIVE_OK && ret != ARCHIVE_WARN)
//                return (ret);
//
//        if (a->skip_file_set &&
//            archive_entry_dev_is_set(entry) &&
//            archive_entry_ino_is_set(entry) &&
//            archive_entry_dev(entry) == (dev_t)a->skip_file_dev &&
//            archive_entry_ino64(entry) == a->skip_file_ino) {
//                archive_set_error(&a->archive, 0,
//                    "Can't add archive to itself");
//                return (ARCHIVE_FAILED);
//        }

        /* Format and write header. */
        r2 = ((a->format_write_header)(a, entry));
        if (r2 == ARCHIVE_FATAL) {
                a->archive.state = ARCHIVE_STATE_FATAL;
                return (ARCHIVE_FATAL);
        }
        if (r2 < ret)
                ret = r2;

        // mdtm: we only use header
        // a->archive.state = ARCHIVE_STATE_DATA;
        return (ret);
}

static int
_archive_write_finish_entry(struct archive *_a)
{
        struct archive_write *a = (struct archive_write *)_a;
        int ret = ARCHIVE_OK;

//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_HEADER | ARCHIVE_STATE_DATA,
//            "archive_write_finish_entry");
        if (a->archive.state & ARCHIVE_STATE_DATA)
                ret = (a->format_finish_entry)(a);
        a->archive.state = ARCHIVE_STATE_HEADER;
        return (ret);
}

/*
 * Set the size for the last block.
 * Returns 0 if successful.
 */
int
archive_write_set_bytes_in_last_block(struct archive *_a, int bytes)
{
        struct archive_write *a = (struct archive_write *)_a;
//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_ANY, "archive_write_set_bytes_in_last_block");
        a->bytes_in_last_block = bytes;
        return (ARCHIVE_OK);
}

/*
 * Return the value set above.  -1 indicates it has not been set.
 */
int
archive_write_get_bytes_in_last_block(struct archive *_a)
{
        struct archive_write *a = (struct archive_write *)_a;
//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_ANY, "archive_write_get_bytes_in_last_block");
        return (a->bytes_in_last_block);
}

/*
 * dev/ino of a file to be rejected.  Used to prevent adding
 * an archive to itself recursively.
 */
int
archive_write_set_skip_file(struct archive *_a, int64_t d, int64_t i)
{
        struct archive_write *a = (struct archive_write *)_a;
//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_ANY, "archive_write_set_skip_file");
        a->skip_file_set = 1;
        a->skip_file_dev = d;
        a->skip_file_ino = i;
        return (ARCHIVE_OK);
}

/*
 * Allocate and return the next filter structure.
 */
struct archive_write_filter *
__archive_write_allocate_filter(struct archive *_a)
{
        struct archive_write *a = (struct archive_write *)_a;
        struct archive_write_filter *f;

        f = (struct archive_write_filter *)calloc(1, sizeof(*f));
        f->archive = _a;
        if (a->filter_first == NULL)
                a->filter_first = f;
        else
                a->filter_last->next_filter = f;
        a->filter_last = f;
        return f;
}

/*
 * Write data to a particular filter.
 */
int
__archive_write_filter(struct archive_write_filter *f,
    const void *buff, size_t length)
{
        int r;
        if (length == 0)
                return(ARCHIVE_OK);
        if (f->write == NULL)
                /* If unset, a fatal error has already ocuured, so this filter
                 * didn't open. We cannot write anything. */
                return(ARCHIVE_FATAL);
        r = (f->write)(f, buff, length);
        f->bytes_written += length;
        return (r);
}

/*
 * Open a filter.
 */
int
__archive_write_open_filter(struct archive_write_filter *f)
{
        if (f->open == NULL)
                return (ARCHIVE_OK);
        return (f->open)(f);
}

/*
 * Close a filter.
 */
int
__archive_write_close_filter(struct archive_write_filter *f)
{
        if (f->close != NULL)
                return (f->close)(f);
        if (f->next_filter != NULL)
                return (__archive_write_close_filter(f->next_filter));
        return (ARCHIVE_OK);
}

int
__archive_write_output(struct archive_write *a, const void *buff, size_t length)
{
        return (__archive_write_filter(a->filter_first, buff, length));
}

int
__archive_write_nulls(struct archive_write *a, size_t length)
{
        if (length == 0)
                return (ARCHIVE_OK);

        while (length > 0) {
                size_t to_write = length < a->null_length ? length : a->null_length;
                int r = __archive_write_output(a, a->nulls, to_write);
                if (r < ARCHIVE_OK)
                        return (r);
                length -= to_write;
        }
        return (ARCHIVE_OK);
}

static int
archive_write_client_open(struct archive_write_filter *f)
{
        struct archive_write *a = (struct archive_write *)f->archive;
        struct archive_none *state;
        void *buffer;
        size_t buffer_size;

        f->bytes_per_block = archive_write_get_bytes_per_block(f->archive);
        f->bytes_in_last_block =
            archive_write_get_bytes_in_last_block(f->archive);
        buffer_size = f->bytes_per_block;

        state = (struct archive_none *)calloc(1, sizeof(*state));
        buffer = (char *)malloc(buffer_size);
        if (state == NULL || buffer == NULL) {
                free(state);
                free(buffer);
                archive_set_error(f->archive, ENOMEM,
                    "Can't allocate data for output buffering");
                return (ARCHIVE_FATAL);
        }

        state->buffer_size = buffer_size;
        state->buffer = (char*)buffer;
        state->next = state->buffer;
        state->avail = state->buffer_size;
        f->data = state;

        if (a->client_opener == NULL)
                return (ARCHIVE_OK);
        return (a->client_opener(f->archive, a->client_data));
}

static int
archive_write_client_write(struct archive_write_filter *f,
    const void *_buff, size_t length)
{
        struct archive_write *a = (struct archive_write *)f->archive;
        struct archive_none *state = (struct archive_none *)f->data;
        const char *buff = (const char *)_buff;
        ssize_t remaining, to_copy;
        ssize_t bytes_written;

        remaining = length;

        /*
         * If there is no buffer for blocking, just pass the data
         * straight through to the client write callback.  In
         * particular, this supports "no write delay" operation for
         * special applications.  Just set the block size to zero.
         */
        if (state->buffer_size == 0) {
                while (remaining > 0) {
                        bytes_written = (a->client_writer)(&a->archive,
                            a->client_data, buff, remaining);
                        if (bytes_written <= 0)
                                return (ARCHIVE_FATAL);
                        remaining -= bytes_written;
                        buff += bytes_written;
                }
                return (ARCHIVE_OK);
        }

        /* If the copy buffer isn't empty, try to fill it. */
        if (state->avail < state->buffer_size) {
                /* If buffer is not empty... */
                /* ... copy data into buffer ... */
                to_copy = ((size_t)remaining > state->avail) ?
                        state->avail : (size_t)remaining;
                memcpy(state->next, buff, to_copy);
                state->next += to_copy;
                state->avail -= to_copy;
                buff += to_copy;
                remaining -= to_copy;
                /* ... if it's full, write it out. */
                if (state->avail == 0) {
                        char *p = state->buffer;
                        size_t to_write = state->buffer_size;
                        while (to_write > 0) {
                                bytes_written = (a->client_writer)(&a->archive,
                                    a->client_data, p, to_write);
                                if (bytes_written <= 0)
                                        return (ARCHIVE_FATAL);
                                if ((size_t)bytes_written > to_write) {
                                        archive_set_error(&(a->archive),
                                            -1, "write overrun");
                                        return (ARCHIVE_FATAL);
                                }
                                p += bytes_written;
                                to_write -= bytes_written;
                        }
                        state->next = state->buffer;
                        state->avail = state->buffer_size;
                }
        }

        while ((size_t)remaining >= state->buffer_size) {
                /* Write out full blocks directly to client. */
                bytes_written = (a->client_writer)(&a->archive,
                    a->client_data, buff, state->buffer_size);
                if (bytes_written <= 0)
                        return (ARCHIVE_FATAL);
                buff += bytes_written;
                remaining -= bytes_written;
        }

        if (remaining > 0) {
                /* Copy last bit into copy buffer. */
                memcpy(state->next, buff, remaining);
                state->next += remaining;
                state->avail -= remaining;
        }
        return (ARCHIVE_OK);
}

static int
archive_write_client_close(struct archive_write_filter *f)
{
        struct archive_write *a = (struct archive_write *)f->archive;
        struct archive_none *state = (struct archive_none *)f->data;
        ssize_t block_length;
        ssize_t target_block_length;
        ssize_t bytes_written;
        int ret = ARCHIVE_OK;

        /* If there's pending data, pad and write the last block */
        if (state->next != state->buffer) {
                block_length = state->buffer_size - state->avail;

                /* Tricky calculation to determine size of last block */
                if (a->bytes_in_last_block <= 0)
                        /* Default or Zero: pad to full block */
                        target_block_length = a->bytes_per_block;
                else
                        /* Round to next multiple of bytes_in_last_block. */
                        target_block_length = a->bytes_in_last_block *
                            ( (block_length + a->bytes_in_last_block - 1) /
                                a->bytes_in_last_block);
                if (target_block_length > a->bytes_per_block)
                        target_block_length = a->bytes_per_block;
                if (block_length < target_block_length) {
                        memset(state->next, 0,
                            target_block_length - block_length);
                        block_length = target_block_length;
                }
                bytes_written = (a->client_writer)(&a->archive,
                    a->client_data, state->buffer, block_length);
                ret = bytes_written <= 0 ? ARCHIVE_FATAL : ARCHIVE_OK;
        }
        if (a->client_closer)
                (*a->client_closer)(&a->archive, a->client_data);
        free(state->buffer);
        free(state);
        /* Clear the close handler myself not to be called again. */
        f->close = NULL;
        a->client_data = NULL;
        return (ret);
}

/*
 * Open the archive using the current settings.
 */
int
archive_write_open(struct archive *_a, void *client_data,
    archive_open_callback *opener, archive_write_callback *writer,
    archive_close_callback *closer)
{
        struct archive_write *a = (struct archive_write *)_a;
        struct archive_write_filter *client_filter;
        int ret, r1;

//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_NEW, "archive_write_open");
//        archive_clear_error(&a->archive);

        a->client_writer = writer;
        a->client_opener = opener;
        a->client_closer = closer;
        a->client_data = client_data;

        client_filter = __archive_write_allocate_filter(_a);
        client_filter->open = archive_write_client_open;
        client_filter->write = archive_write_client_write;
        client_filter->close = archive_write_client_close;

        ret = __archive_write_open_filter(a->filter_first);
        if (ret < ARCHIVE_WARN) {
                r1 = __archive_write_close_filter(a->filter_first);
                return (r1 < ret ? r1 : ret);
        }

        a->archive.state = ARCHIVE_STATE_HEADER;
        if (a->format_init)
                ret = (a->format_init)(a);
        return (ret);
}

/*
 * Close out the archive.
 */
static int
_archive_write_close(struct archive *_a)
{
        struct archive_write *a = (struct archive_write *)_a;
        int r = ARCHIVE_OK, r1 = ARCHIVE_OK;

//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_ANY | ARCHIVE_STATE_FATAL,
//            "archive_write_close");
        if (a->archive.state == ARCHIVE_STATE_NEW
            || a->archive.state == ARCHIVE_STATE_CLOSED)
                return (ARCHIVE_OK); /* Okay to close() when not open. */

//        archive_clear_error(&a->archive);

        /* Finish the last entry. */
        if (a->archive.state == ARCHIVE_STATE_DATA)
                r = ((a->format_finish_entry)(a));

        /* Finish off the archive. */
        /* TODO: have format closers invoke compression close. */
        if (a->format_close != NULL) {
                r1 = (a->format_close)(a);
                if (r1 < r)
                        r = r1;
        }

        /* Finish the compression and close the stream. */
        r1 = __archive_write_close_filter(a->filter_first);
        if (r1 < r)
                r = r1;

        if (a->archive.state != ARCHIVE_STATE_FATAL)
                a->archive.state = ARCHIVE_STATE_CLOSED;
        return (r);
}

/*
 * Set the block size.  Returns 0 if successful.
 */
int
archive_write_set_bytes_per_block(struct archive *_a, int bytes_per_block)
{
        struct archive_write *a = (struct archive_write *)_a;
//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_NEW, "archive_write_set_bytes_per_block");
        a->bytes_per_block = bytes_per_block;
        return (ARCHIVE_OK);
}

/*
 * Get the current block size.  -1 if it has never been set.
 */
int
archive_write_get_bytes_per_block(struct archive *_a)
{
        struct archive_write *a = (struct archive_write *)_a;
//        archive_check_magic(&a->archive, ARCHIVE_WRITE_MAGIC,
//            ARCHIVE_STATE_ANY, "archive_write_get_bytes_per_block");
        return (a->bytes_per_block);
}

#define tar_min(a,b) ((a) < (b) ? (a) : (b))

/*
 * Layout of POSIX 'ustar' tar header.
 */
struct archive_entry_header_ustar {
        char    name[100];
        char    mode[8];
        char    uid[8];
        char    gid[8];
        char    size[12];
        char    mtime[12];
        char    checksum[8];
        char    typeflag[1];
        char    linkname[100];  /* "old format" header ends here */
        char    magic[6];       /* For POSIX: "ustar\0" */
        char    version[2];     /* For POSIX: "00" */
        char    uname[32];
        char    gname[32];
        char    rdevmajor[8];
        char    rdevminor[8];
        char    prefix[155];
};

/*
 * Structure of GNU tar header
 */
struct gnu_sparse {
        char    offset[12];
        char    numbytes[12];
};

struct archive_entry_header_gnutar {
        char    name[100];
        char    mode[8];
        char    uid[8];
        char    gid[8];
        char    size[12];
        char    mtime[12];
        char    checksum[8];
        char    typeflag[1];
        char    linkname[100];
        char    magic[8];  /* "ustar  \0" (note blank/blank/null at end) */
        char    uname[32];
        char    gname[32];
        char    rdevmajor[8];
        char    rdevminor[8];
        char    atime[12];
        char    ctime[12];
        char    offset[12];
        char    longnames[4];
        char    unused[1];
        struct gnu_sparse sparse[4];
        char    isextended[1];
        char    realsize[12];
        /*
         * Old GNU format doesn't use POSIX 'prefix' field; they use
         * the 'L' (longname) entry instead.
         */
};

/*
 * Data specific to this format.
 */
struct sparse_block {
        struct sparse_block     *next;
        int64_t offset;
        int64_t remaining;
        int hole;
};

struct tar {
        struct archive_string    acl_text;
        struct archive_string    entry_pathname;
        /* For "GNU.sparse.name" and other similar path extensions. */
        struct archive_string    entry_pathname_override;
        struct archive_string    entry_linkpath;
        struct archive_string    entry_uname;
        struct archive_string    entry_gname;
        struct archive_string    longlink;
        struct archive_string    longname;
        struct archive_string    pax_header;
        struct archive_string    pax_global;
        struct archive_string    line;
        int                      pax_hdrcharset_binary;
        int                      header_recursion_depth;
        int64_t                  entry_bytes_remaining;
        int64_t                  entry_offset;
        int64_t                  entry_padding;
        int64_t                  entry_bytes_unconsumed;
        int64_t                  realsize;
        struct sparse_block     *sparse_list;
        struct sparse_block     *sparse_last;
        int64_t                  sparse_offset;
        int64_t                  sparse_numbytes;
        int                      sparse_gnu_major;
        int                      sparse_gnu_minor;
        char                     sparse_gnu_pending;

        struct archive_string    localname;
        struct archive_string_conv *opt_sconv;
        struct archive_string_conv *sconv;
        struct archive_string_conv *sconv_acl;
        struct archive_string_conv *sconv_default;
        int                      init_default_conversion;
        int                      compat_2x;
};

static int      archive_block_is_null(const char *p);
static char     *base64_decode(const char *, size_t, size_t *);
static int      gnu_add_sparse_entry(struct archive_read *, struct tar *,
                    int64_t offset, int64_t remaining);

static void     gnu_clear_sparse_list(struct tar *);
static int      gnu_sparse_old_read(struct archive_read *, struct tar *,
                    const struct archive_entry_header_gnutar *header, size_t *);
static int      gnu_sparse_old_parse(struct archive_read *, struct tar *,
                    const struct gnu_sparse *sparse, int length);
static int      gnu_sparse_01_parse(struct archive_read *, struct tar *,
                    const char *);
static ssize_t  gnu_sparse_10_read(struct archive_read *, struct tar *,
                        size_t *);
static int      header_Solaris_ACL(struct archive_read *,  struct tar *,
                    struct archive_entry *, const void *, size_t *);
static int      header_common(struct archive_read *,  struct tar *,
                    struct archive_entry *, const void *);
static int      header_old_tar(struct archive_read *, struct tar *,
                    struct archive_entry *, const void *);
static int      header_pax_extensions(struct archive_read *, struct tar *,
                    struct archive_entry *, const void *, size_t *);
static int      header_pax_global(struct archive_read *, struct tar *,
                    struct archive_entry *, const void *h, size_t *);
static int      header_longlink(struct archive_read *, struct tar *,
                    struct archive_entry *, const void *h, size_t *);
static int      header_longname(struct archive_read *, struct tar *,
                    struct archive_entry *, const void *h, size_t *);
static int      read_mac_metadata_blob(struct archive_read *, struct tar *,
                    struct archive_entry *, const void *h, size_t *);
static int      header_volume(struct archive_read *, struct tar *,
                    struct archive_entry *, const void *h, size_t *);
static int      header_ustar(struct archive_read *, struct tar *,
                    struct archive_entry *, const void *h);
static int      header_gnutar(struct archive_read *, struct tar *,
                    struct archive_entry *, const void *h, size_t *);
static int      archive_read_format_tar_bid(struct archive_read *, int);
static int      archive_read_format_tar_options(struct archive_read *,
                    const char *, const char *);
static int      archive_read_format_tar_cleanup(struct archive_read *);
static int      archive_read_format_tar_read_data(struct archive_read *a,
                    const void **buff, size_t *size, int64_t *offset);
static int      archive_read_format_tar_skip(struct archive_read *a);
static int      archive_read_format_tar_read_header(struct archive_read *,
                    struct archive_entry *);
static int      checksum(struct archive_read *, const void *);
static int      pax_attribute(struct archive_read *, struct tar *,
                    struct archive_entry *, char *key, char *value);
static int      pax_header(struct archive_read *, struct tar *,
                    struct archive_entry *, char *attr);
static void     pax_time(const char *, int64_t *sec, long *nanos);
static ssize_t  readline(struct archive_read *, struct tar *, const char **,
                    ssize_t limit, size_t *);
static int      read_body_to_string(struct archive_read *, struct tar *,
                    struct archive_string *, const void *h, size_t *);
static int      solaris_sparse_parse(struct archive_read *, struct tar *,
                    struct archive_entry *, const char *);
static int64_t  tar_atol(const char *, size_t);
static int64_t  tar_atol10(const char *, size_t);
static int64_t  tar_atol256(const char *, size_t);
static int64_t  tar_atol8(const char *, size_t);
static int      tar_read_header(struct archive_read *, struct tar *,
                    struct archive_entry *, size_t *);
static int      tohex(int c);
static char     *url_decode(const char *);
static void     tar_flush_unconsumed(struct archive_read *, size_t *);


int
archive_read_support_format_gnutar(struct archive *a)
{
//        archive_check_magic(a, ARCHIVE_READ_MAGIC,
//            ARCHIVE_STATE_NEW, "archive_read_support_format_gnutar");
        return (archive_read_support_format_tar(a));
}


int
archive_read_support_format_tar(struct archive *_a)
{
        struct archive_read *a = (struct archive_read *)_a;
        struct tar *tar;
        int r;

//        archive_check_magic(_a, ARCHIVE_READ_MAGIC,
//            ARCHIVE_STATE_NEW, "archive_read_support_format_tar");

        tar = (struct tar *)calloc(1, sizeof(*tar));
        if (tar == NULL) {
                archive_set_error(&a->archive, ENOMEM,
                    "Can't allocate tar data");
                return (ARCHIVE_FATAL);
        }

        r = __archive_read_register_format(a, tar, "tar",
            archive_read_format_tar_bid,
            archive_read_format_tar_options,
            archive_read_format_tar_read_header,
            archive_read_format_tar_read_data,
            archive_read_format_tar_skip,
            NULL,
            archive_read_format_tar_cleanup);

        if (r != ARCHIVE_OK)
                free(tar);
        return (ARCHIVE_OK);
}

static int
archive_read_format_tar_cleanup(struct archive_read *a)
{
        struct tar *tar;

        tar = (struct tar *)(a->format->data);
//        gnu_clear_sparse_list(tar);
        archive_string_free(&tar->acl_text);
        archive_string_free(&tar->entry_pathname);
        archive_string_free(&tar->entry_pathname_override);
        archive_string_free(&tar->entry_linkpath);
        archive_string_free(&tar->entry_uname);
        archive_string_free(&tar->entry_gname);
        archive_string_free(&tar->line);
        archive_string_free(&tar->pax_global);
        archive_string_free(&tar->pax_header);
        archive_string_free(&tar->longname);
        archive_string_free(&tar->longlink);
        archive_string_free(&tar->localname);
        free(tar);
        (a->format->data) = NULL;
        return (ARCHIVE_OK);
}


static int
archive_read_format_tar_bid(struct archive_read *a, int best_bid)
{
        int bid;
        const char *h;
        const struct archive_entry_header_ustar *header;

        (void)best_bid; /* UNUSED */

        bid = 0;

        /* Now let's look at the actual header and see if it matches. */
        h = (char*)__archive_read_ahead(a, 512, NULL);
        if (h == NULL)
                return (-1);

        /* If it's an end-of-archive mark, we can handle it. */
        if (h[0] == 0 && archive_block_is_null(h)) {
                /*
                 * Usually, I bid the number of bits verified, but
                 * in this case, 4096 seems excessive so I picked 10 as
                 * an arbitrary but reasonable-seeming value.
                 */
                return (10);
        }

        /* If it's not an end-of-archive mark, it must have a valid checksum.*/
        if (!checksum(a, h))
                return (0);
        bid += 48;  /* Checksum is usually 6 octal digits. */

        header = (const struct archive_entry_header_ustar *)h;

        /* Recognize POSIX formats. */
        if ((memcmp(header->magic, "ustar\0", 6) == 0)
            && (memcmp(header->version, "00", 2) == 0))
                bid += 56;

        /* Recognize GNU tar format. */
        if ((memcmp(header->magic, "ustar ", 6) == 0)
            && (memcmp(header->version, " \0", 2) == 0))
                bid += 56;

        /* Type flag must be null, digit or A-Z, a-z. */
        if (header->typeflag[0] != 0 &&
            !( header->typeflag[0] >= '0' && header->typeflag[0] <= '9') &&
            !( header->typeflag[0] >= 'A' && header->typeflag[0] <= 'Z') &&
            !( header->typeflag[0] >= 'a' && header->typeflag[0] <= 'z') )
                return (0);
        bid += 2;  /* 6 bits of variation in an 8-bit field leaves 2 bits. */

        /* Sanity check: Look at first byte of mode field. */
        switch (255 & (unsigned)header->mode[0]) {
        case 0: case 255:
                /* Base-256 value: No further verification possible! */
                break;
        case ' ': /* Not recommended, but not illegal, either. */
                break;
        case '0': case '1': case '2': case '3':
        case '4': case '5': case '6': case '7':
                /* Octal Value. */
                /* TODO: Check format of remainder of this field. */
                break;
        default:
                /* Not a valid mode; bail out here. */
                return (0);
        }
        /* TODO: Sanity test uid/gid/size/mtime/rdevmajor/rdevminor fields. */

        return (bid);
}

static int
archive_read_format_tar_options(struct archive_read *a,
    const char *key, const char *val)
{
        struct tar *tar;
        int ret = ARCHIVE_FAILED;

        tar = (struct tar *)(a->format->data);
        if (strcmp(key, "compat-2x")  == 0) {
                /* Handle UTF-8 filnames as libarchive 2.x */
                tar->compat_2x = (val != NULL)?1:0;
                tar->init_default_conversion = tar->compat_2x;
                return (ARCHIVE_OK);
        } else if (strcmp(key, "hdrcharset")  == 0) {
                if (val == NULL || val[0] == 0)
                        archive_set_error(&a->archive, ARCHIVE_ERRNO_MISC,
                            "tar: hdrcharset option needs a character-set name");
                else {
                        tar->opt_sconv =
                            archive_string_conversion_from_charset(
                                &a->archive, val, 0);
                        if (tar->opt_sconv != NULL)
                                ret = ARCHIVE_OK;
                        else
                                ret = ARCHIVE_FATAL;
                }
                return (ret);
        }

        /* Note: The "warn" return is just to inform the options
         * supervisor that we didn't handle it.  It will generate
         * a suitable error if no one used this option. */
        return (ARCHIVE_WARN);
}



/*-
 * Convert text->integer.
 *
 * Traditional tar formats (including POSIX) specify base-8 for
 * all of the standard numeric fields.  This is a significant limitation
 * in practice:
 *   = file size is limited to 8GB
 *   = rdevmajor and rdevminor are limited to 21 bits
 *   = uid/gid are limited to 21 bits
 *
 * There are two workarounds for this:
 *   = pax extended headers, which use variable-length string fields
 *   = GNU tar and STAR both allow either base-8 or base-256 in
 *      most fields.  The high bit is set to indicate base-256.
 *
 * On read, this implementation supports both extensions.
 */
static int64_t
tar_atol(const char *p, size_t char_cnt)
{
        /*
         * Technically, GNU tar considers a field to be in base-256
         * only if the first byte is 0xff or 0x80.
         */
        if (*p & 0x80)
                return (tar_atol256(p, char_cnt));
        return (tar_atol8(p, char_cnt));
}




/*
 * Note that this implementation does not (and should not!) obey
 * locale settings; you cannot simply substitute strtol here, since
 * it does obey locale.
 */
static int64_t
tar_atol_base_n(const char *p, size_t char_cnt, int base)
{
        int64_t l, limit, last_digit_limit;
        int digit, sign;

        limit = INT64_MAX / base;
        last_digit_limit = INT64_MAX % base;

        /* the pointer will not be dereferenced if char_cnt is zero
         * due to the way the && operator is evaulated.
         */
        while (char_cnt != 0 && (*p == ' ' || *p == '\t')) {
                p++;
                char_cnt--;
        }

        sign = 1;
        if (char_cnt != 0 && *p == '-') {
                sign = -1;
                p++;
                char_cnt--;
        }

        l = 0;
        if (char_cnt != 0) {
                digit = *p - '0';
                while (digit >= 0 && digit < base  && char_cnt != 0) {
                        if (l>limit || (l == limit && digit > last_digit_limit)) {
                                l = INT64_MAX; /* Truncate on overflow. */
                                break;
                        }
                        l = (l * base) + digit;
                        digit = *++p - '0';
                        char_cnt--;
                }
        }
        return (sign < 0) ? -l : l;
}

/*
 * Parse a base-256 integer.  This is just a straight signed binary
 * value in big-endian order, except that the high-order bit is
 * ignored.
 */
static int64_t
tar_atol256(const char *_p, size_t char_cnt)
{
        int64_t l, upper_limit, lower_limit;
        const unsigned char *p = (const unsigned char *)_p;

        upper_limit = INT64_MAX / 256;
        lower_limit = INT64_MIN / 256;

        /* Pad with 1 or 0 bits, depending on sign. */
        if ((0x40 & *p) == 0x40)
                l = (int64_t)-1;
        else
                l = 0;
        l = (l << 6) | (0x3f & *p++);
        while (--char_cnt > 0) {
                if (l > upper_limit) {
                        l = INT64_MAX; /* Truncate on overflow */
                        break;
                } else if (l < lower_limit) {
                        l = INT64_MIN;
                        break;
                }
                l = (l << 8) | (0xff & (int64_t)*p++);
        }
        return (l);
}



static int64_t
tar_atol8(const char *p, size_t char_cnt)
{
        return tar_atol_base_n(p, char_cnt, 8);
}

/*
 * Returns length of line (including trailing newline)
 * or negative on error.  'start' argument is updated to
 * point to first character of line.  This avoids copying
 * when possible.
 */
static ssize_t
readline(struct archive_read *a, struct tar *tar, const char **start,
    ssize_t limit, size_t *unconsumed)
{
        ssize_t bytes_read;
        ssize_t total_size = 0;
        const void *t;
        const char *s;
        void *p;

        tar_flush_unconsumed(a, unconsumed);

        t = __archive_read_ahead(a, 1, &bytes_read);
        if (bytes_read <= 0)
                return (ARCHIVE_FATAL);
        s = (char*)t;  /* Start of line? */
        p = (void*)memchr(t, '\n', bytes_read);
        /* If we found '\n' in the read buffer, return pointer to that. */
        if (p != NULL) {
                bytes_read = 1 + ((const char *)p) - s;
                if (bytes_read > limit) {
                        archive_set_error(&a->archive,
                            ARCHIVE_ERRNO_FILE_FORMAT,
                            "Line too long");
                        return (ARCHIVE_FATAL);
                }
                *unconsumed = bytes_read;
                *start = s;
                return (bytes_read);
        }
        *unconsumed = bytes_read;
        /* Otherwise, we need to accumulate in a line buffer. */
        for (;;) {
                if (total_size + bytes_read > limit) {
                        archive_set_error(&a->archive,
                            ARCHIVE_ERRNO_FILE_FORMAT,
                            "Line too long");
                        return (ARCHIVE_FATAL);
                }
                if (archive_string_ensure(&tar->line, total_size + bytes_read) == NULL) {
                        archive_set_error(&a->archive, ENOMEM,
                            "Can't allocate working buffer");
                        return (ARCHIVE_FATAL);
                }
                memcpy(tar->line.s + total_size, t, bytes_read);
                tar_flush_unconsumed(a, unconsumed);
                total_size += bytes_read;
                /* If we found '\n', clean up and return. */
                if (p != NULL) {
                        *start = tar->line.s;
                        return (total_size);
                }
                /* Read some more. */
                t = __archive_read_ahead(a, 1, &bytes_read);
                if (bytes_read <= 0)
                        return (ARCHIVE_FATAL);
                s = (char*)t;  /* Start of line? */
                p = (void*)memchr(t, '\n', bytes_read);
                /* If we found '\n', trim the read. */
                if (p != NULL) {
                        bytes_read = 1 + ((const char *)p) - s;
                }
                *unconsumed = bytes_read;
        }
}

/*
 * Read the next line from the input, and parse it as a decimal
 * integer followed by '\n'.  Returns positive integer value or
 * negative on error.
 */
static int64_t
gnu_sparse_10_atol(struct archive_read *a, struct tar *tar,
    int64_t *remaining, size_t *unconsumed)
{
        int64_t l, limit, last_digit_limit;
        const char *p;
        ssize_t bytes_read;
        int base, digit;

        base = 10;
        limit = INT64_MAX / base;
        last_digit_limit = INT64_MAX % base;

        /*
         * Skip any lines starting with '#'; GNU tar specs
         * don't require this, but they should.
         */
        do {
                bytes_read = readline(a, tar, &p,
                        (ssize_t)tar_min(*remaining, 100), unconsumed);
                if (bytes_read <= 0)
                        return (ARCHIVE_FATAL);
                *remaining -= bytes_read;
        } while (p[0] == '#');

        l = 0;
        while (bytes_read > 0) {
                if (*p == '\n')
                        return (l);
                if (*p < '0' || *p >= '0' + base)
                        return (ARCHIVE_WARN);
                digit = *p - '0';
                if (l > limit || (l == limit && digit > last_digit_limit))
                        l = INT64_MAX; /* Truncate on overflow. */
                else
                        l = (l * base) + digit;
                p++;
                bytes_read--;
        }
        /* TODO: Error message. */
        return (ARCHIVE_WARN);
}

/* utility function- this exists to centralize the logic of tracking
 * how much unconsumed data we have floating around, and to consume
 * anything outstanding since we're going to do read_aheads
 */
static void
tar_flush_unconsumed(struct archive_read *a, size_t *unconsumed)
{
        if (*unconsumed) {
/*
                void *data = (void *)__archive_read_ahead(a, *unconsumed, NULL);
                 * this block of code is to poison claimed unconsumed space, ensuring
                 * things break if it is in use still.
                 * currently it WILL break things, so enable it only for debugging this issue
                if (data) {
                        memset(data, 0xff, *unconsumed);
                }
*/
                __archive_read_consume(a, *unconsumed);
                *unconsumed = 0;
        }
}

/*
 * The function invoked by archive_read_next_header().  This
 * just sets up a few things and then calls the internal
 * tar_read_header() function below.
 */
static int
archive_read_format_tar_read_header(struct archive_read *a,
    struct archive_entry *entry)
{
        /*
         * When converting tar archives to cpio archives, it is
         * essential that each distinct file have a distinct inode
         * number.  To simplify this, we keep a static count here to
         * assign fake dev/inode numbers to each tar entry.  Note that
         * pax format archives may overwrite this with something more
         * useful.
         *
         * Ideally, we would track every file read from the archive so
         * that we could assign the same dev/ino pair to hardlinks,
         * but the memory required to store a complete lookup table is
         * probably not worthwhile just to support the relatively
         * obscure tar->cpio conversion case.
         */
        static int default_inode;
        static int default_dev;
        struct tar *tar;
        const char *p;
        int r;
        size_t l, unconsumed = 0;

        /* Assign default device/inode values. */
        archive_entry_set_dev(entry, 1 + default_dev); /* Don't use zero. */
        archive_entry_set_ino(entry, ++default_inode); /* Don't use zero. */
        /* Limit generated st_ino number to 16 bits. */
        if (default_inode >= 0xffff) {
                ++default_dev;
                default_inode = 0;
        }

        tar = (struct tar *)(a->format->data);
        tar->entry_offset = 0;
        gnu_clear_sparse_list(tar);
        tar->realsize = -1; /* Mark this as "unset" */

        /* Setup default string conversion. */
        tar->sconv = tar->opt_sconv;
        if (tar->sconv == NULL) {
                if (!tar->init_default_conversion) {
                        tar->sconv_default =
                            archive_string_default_conversion_for_read(&(a->archive));
                        tar->init_default_conversion = 1;
                }
                tar->sconv = tar->sconv_default;
        }

        r = tar_read_header(a, tar, entry, &unconsumed);

        tar_flush_unconsumed(a, &unconsumed);

        /*
         * "non-sparse" files are really just sparse files with
         * a single block.
         */
        if (tar->sparse_list == NULL) {
                if (gnu_add_sparse_entry(a, tar, 0, tar->entry_bytes_remaining)
                    != ARCHIVE_OK)
                        return (ARCHIVE_FATAL);
        } else {
//                struct sparse_block *sb;
//
//                for (sb = tar->sparse_list; sb != NULL; sb = sb->next) {
//                        if (!sb->hole)
//                                archive_entry_sparse_add_entry(entry,
//                                    sb->offset, sb->remaining);
//                }
        }

        if (r == ARCHIVE_OK) {
                /*
                 * "Regular" entry with trailing '/' is really
                 * directory: This is needed for certain old tar
                 * variants and even for some broken newer ones.
                 */
                const wchar_t *wp;
                wp = archive_entry_pathname_w(entry);
                if (wp != NULL) {
                        l = wcslen(wp);
                        if (archive_entry_filetype(entry) == AE_IFREG
                            && wp[l-1] == L'/')
                                archive_entry_set_filetype(entry, AE_IFDIR);
                } else {
                        p = archive_entry_pathname(entry);
                        if (p == NULL)
                                return (ARCHIVE_FAILED);
                        l = strlen(p);
                        if (archive_entry_filetype(entry) == AE_IFREG
                            && p[l-1] == '/')
                                archive_entry_set_filetype(entry, AE_IFDIR);
                }
        }
        return (r);
}

static int
archive_read_format_tar_read_data(struct archive_read *a,
    const void **buff, size_t *size, int64_t *offset)
{
        ssize_t bytes_read;
        struct tar *tar;
        struct sparse_block *p;

        tar = (struct tar *)(a->format->data);

        for (;;) {
                /* Remove exhausted entries from sparse list. */
                while (tar->sparse_list != NULL &&
                    tar->sparse_list->remaining == 0) {
                        p = tar->sparse_list;
                        tar->sparse_list = p->next;
                        free(p);
                }

                if (tar->entry_bytes_unconsumed) {
                        __archive_read_consume(a, tar->entry_bytes_unconsumed);
                        tar->entry_bytes_unconsumed = 0;
                }

                /* If we're at end of file, return EOF. */
                if (tar->sparse_list == NULL ||
                    tar->entry_bytes_remaining == 0) {
                        if (__archive_read_consume(a, tar->entry_padding) < 0)
                                return (ARCHIVE_FATAL);
                        tar->entry_padding = 0;
                        *buff = NULL;
                        *size = 0;
                        *offset = tar->realsize;
                        return (ARCHIVE_EOF);
                }

                *buff = __archive_read_ahead(a, 1, &bytes_read);
                if (bytes_read < 0)
                        return (ARCHIVE_FATAL);
                if (*buff == NULL) {
                        archive_set_error(&a->archive, ARCHIVE_ERRNO_MISC,
                            "Truncated tar archive");
                        return (ARCHIVE_FATAL);
                }
                if (bytes_read > tar->entry_bytes_remaining)
                        bytes_read = (ssize_t)tar->entry_bytes_remaining;
                /* Don't read more than is available in the
                 * current sparse block. */
                if (tar->sparse_list->remaining < bytes_read)
                        bytes_read = (ssize_t)tar->sparse_list->remaining;
                *size = bytes_read;
                *offset = tar->sparse_list->offset;
                tar->sparse_list->remaining -= bytes_read;
                tar->sparse_list->offset += bytes_read;
                tar->entry_bytes_remaining -= bytes_read;
                tar->entry_bytes_unconsumed = bytes_read;

                if (!tar->sparse_list->hole)
                        return (ARCHIVE_OK);
                /* Current is hole data and skip this. */
        }
}

static int
archive_read_format_tar_skip(struct archive_read *a)
{
        int64_t bytes_skipped;
        struct tar* tar;

        tar = (struct tar *)(a->format->data);

        bytes_skipped = __archive_read_consume(a,
            tar->entry_bytes_remaining + tar->entry_padding +
            tar->entry_bytes_unconsumed);
        if (bytes_skipped < 0)
                return (ARCHIVE_FATAL);

        tar->entry_bytes_remaining = 0;
        tar->entry_bytes_unconsumed = 0;
        tar->entry_padding = 0;

        /* Free the sparse list. */
//        gnu_clear_sparse_list(tar);

        return (ARCHIVE_OK);
}





/*
 * Parse a file header for a Posix "ustar" archive entry.  This also
 * handles "pax" or "extended ustar" entries.
 */
static int
header_ustar(struct archive_read *a, struct tar *tar,
    struct archive_entry *entry, const void *h)
{
        const struct archive_entry_header_ustar *header;
        struct archive_string *as;
        int err = ARCHIVE_OK, r;

        header = (const struct archive_entry_header_ustar *)h;

        /* Copy name into an internal buffer to ensure null-termination. */
        as = &(tar->entry_pathname);
        if (header->prefix[0]) {
                archive_strncpy(as, header->prefix, sizeof(header->prefix));
                if (as->s[archive_strlen(as) - 1] != '/')
                        archive_strappend_char(as, '/');
                archive_strncat(as, header->name, sizeof(header->name));
        } else {
                archive_strncpy(as, header->name, sizeof(header->name));
        }
        if (archive_entry_copy_pathname_l(entry, as->s, archive_strlen(as),
            tar->sconv) != 0) {
//                err = set_conversion_failed_error(a, tar->sconv, "Pathname");
//                if (err == ARCHIVE_FATAL)
//                        return (err);
            printf("%s:error\n",__FUNCTION__);
        }

        /* Handle rest of common fields. */
        r = header_common(a, tar, entry, h);
        if (r == ARCHIVE_FATAL)
                return (r);
        if (r < err)
                err = r;

//        /* Handle POSIX ustar fields. */
//        if (archive_entry_copy_uname_l(entry,
//            header->uname, sizeof(header->uname), tar->sconv) != 0) {
//                err = set_conversion_failed_error(a, tar->sconv, "Uname");
//                if (err == ARCHIVE_FATAL)
//                        return (err);
//        }
//
//        if (archive_entry_copy_gname_l(entry,
//            header->gname, sizeof(header->gname), tar->sconv) != 0) {
//                err = set_conversion_failed_error(a, tar->sconv, "Gname");
//                if (err == ARCHIVE_FATAL)
//                        return (err);
//        }

        /* Parse out device numbers only for char and block specials. */
//        if (header->typeflag[0] == '3' || header->typeflag[0] == '4') {
//                archive_entry_set_rdevmajor(entry, (dev_t)
//                    tar_atol(header->rdevmajor, sizeof(header->rdevmajor)));
//                archive_entry_set_rdevminor(entry, (dev_t)
//                    tar_atol(header->rdevminor, sizeof(header->rdevminor)));
//        }

        tar->entry_padding = 0x1ff & (-tar->entry_bytes_remaining);

        return (err);
}

/*
 * Return true if this block contains only nulls.
 */
static int
archive_block_is_null(const char *p)
{
        unsigned i;

        for (i = 0; i < 512; i++)
                if (*p++)
                        return (0);
        return (1);
}

static void
gnu_clear_sparse_list(struct tar *tar)
{
        struct sparse_block *p;

        while (tar->sparse_list != NULL) {
                p = tar->sparse_list;
                tar->sparse_list = p->next;
                free(p);
        }
        tar->sparse_last = NULL;
}



/*
 * Returns length (in bytes) of the sparse data description
 * that was read.
 */
static ssize_t
gnu_sparse_10_read(struct archive_read *a, struct tar *tar, size_t *unconsumed)
{
        ssize_t bytes_read;
        int entries;
        int64_t offset, size, to_skip, remaining;

        /* Clear out the existing sparse list. */
        gnu_clear_sparse_list(tar);

        remaining = tar->entry_bytes_remaining;

        /* Parse entries. */
        entries = (int)gnu_sparse_10_atol(a, tar, &remaining, unconsumed);
        if (entries < 0)
                return (ARCHIVE_FATAL);
        /* Parse the individual entries. */
        while (entries-- > 0) {
                /* Parse offset/size */
                offset = gnu_sparse_10_atol(a, tar, &remaining, unconsumed);
                if (offset < 0)
                        return (ARCHIVE_FATAL);
                size = gnu_sparse_10_atol(a, tar, &remaining, unconsumed);
                if (size < 0)
                        return (ARCHIVE_FATAL);
                /* Add a new sparse entry. */
                if (gnu_add_sparse_entry(a, tar, offset, size) != ARCHIVE_OK)
                        return (ARCHIVE_FATAL);
        }
        /* Skip rest of block... */
        tar_flush_unconsumed(a, unconsumed);
        bytes_read = (ssize_t)(tar->entry_bytes_remaining - remaining);
        to_skip = 0x1ff & -bytes_read;
        if (to_skip != __archive_read_consume(a, to_skip))
                return (ARCHIVE_FATAL);
        return ((ssize_t)(bytes_read + to_skip));
}

/*
 * Parse GNU tar header
 */
static int
header_gnutar(struct archive_read *a, struct tar *tar,
    struct archive_entry *entry, const void *h, size_t *unconsumed)
{
        const struct archive_entry_header_gnutar *header;
        int64_t t;
        int err = ARCHIVE_OK;

        /*
         * GNU header is like POSIX ustar, except 'prefix' is
         * replaced with some other fields. This also means the
         * filename is stored as in old-style archives.
         */

        /* Grab fields common to all tar variants. */
        err = header_common(a, tar, entry, h);
        if (err == ARCHIVE_FATAL)
                return (err);

        /* Copy filename over (to ensure null termination). */
        header = (const struct archive_entry_header_gnutar *)h;
        if (archive_entry_copy_pathname_l(entry,
            header->name, sizeof(header->name), tar->sconv) != 0) {
//                err = set_conversion_failed_error(a, tar->sconv, "Pathname");
//                if (err == ARCHIVE_FATAL)
//                        return (err);
            printf("%s %d: errr\n",__FUNCTION__,__LINE__);
        }

        /* Fields common to ustar and GNU */
        /* XXX Can the following be factored out since it's common
         * to ustar and gnu tar?  Is it okay to move it down into
         * header_common, perhaps?  */
//        if (archive_entry_copy_uname_l(entry,
//            header->uname, sizeof(header->uname), tar->sconv) != 0) {
////                err = set_conversion_failed_error(a, tar->sconv, "Uname");
////                if (err == ARCHIVE_FATAL)
////                        return (err);
//            printf("%s %d: errr\n",__FUNCTION__,__LINE__);
//        }
//
//        if (archive_entry_copy_gname_l(entry,
//            header->gname, sizeof(header->gname), tar->sconv) != 0) {
////                err = set_conversion_failed_error(a, tar->sconv, "Gname");
////                if (err == ARCHIVE_FATAL)
////                        return (err);
//            printf("%s %d: errr\n",__FUNCTION__,__LINE__);
//        }

        /* Parse out device numbers only for char and block specials */
//        if (header->typeflag[0] == '3' || header->typeflag[0] == '4') {
//                archive_entry_set_rdevmajor(entry, (dev_t)
//                    tar_atol(header->rdevmajor, sizeof(header->rdevmajor)));
//                archive_entry_set_rdevminor(entry, (dev_t)
//                    tar_atol(header->rdevminor, sizeof(header->rdevminor)));
//        } else
//                archive_entry_set_rdev(entry, 0);

        tar->entry_padding = 0x1ff & (-tar->entry_bytes_remaining);

        /* Grab GNU-specific fields. */
//        t = tar_atol(header->atime, sizeof(header->atime));
//        if (t > 0)
//                archive_entry_set_atime(entry, t, 0);
//        t = tar_atol(header->ctime, sizeof(header->ctime));
//        if (t > 0)
//                archive_entry_set_ctime(entry, t, 0);

        if (header->realsize[0] != 0) {
                tar->realsize
                    = tar_atol(header->realsize, sizeof(header->realsize));
                archive_entry_set_size(entry, tar->realsize);
        }

//        if (header->sparse[0].offset[0] != 0) {
//                if (gnu_sparse_old_read(a, tar, header, unconsumed)
//                    != ARCHIVE_OK)
//                        return (ARCHIVE_FATAL);
//        } else {
//                if (header->isextended[0] != 0) {
//                        /* XXX WTF? XXX */
//                }
//        }

        return (err);
}

static int
gnu_add_sparse_entry(struct archive_read *a, struct tar *tar,
    int64_t offset, int64_t remaining)
{
        struct sparse_block *p;

        p = (struct sparse_block *)malloc(sizeof(*p));
        if (p == NULL) {
                archive_set_error(&a->archive, ENOMEM, "Out of memory");
                return (ARCHIVE_FATAL);
        }
        memset(p, 0, sizeof(*p));
        if (tar->sparse_last != NULL)
                tar->sparse_last->next = p;
        else
                tar->sparse_list = p;
        tar->sparse_last = p;
        p->offset = offset;
        p->remaining = remaining;
        return (ARCHIVE_OK);
}



/*
 * Parse out common header elements.
 *
 * This would be the same as header_old_tar, except that the
 * filename is handled slightly differently for old and POSIX
 * entries  (POSIX entries support a 'prefix').  This factoring
 * allows header_old_tar and header_ustar
 * to handle filenames differently, while still putting most of the
 * common parsing into one place.
 */
static int
header_common(struct archive_read *a, struct tar *tar,
    struct archive_entry *entry, const void *h)
{
        const struct archive_entry_header_ustar *header;
        char    tartype;
        int     err = ARCHIVE_OK;

        header = (const struct archive_entry_header_ustar *)h;
        if (header->linkname[0])
                archive_strncpy(&(tar->entry_linkpath),
                    header->linkname, sizeof(header->linkname));
        else
                archive_string_empty(&(tar->entry_linkpath));

        /* Parse out the numeric fields (all are octal) */
        archive_entry_set_mode(entry,
                (mode_t)tar_atol(header->mode, sizeof(header->mode)));
//        archive_entry_set_uid(entry, tar_atol(header->uid, sizeof(header->uid)));
//        archive_entry_set_gid(entry, tar_atol(header->gid, sizeof(header->gid)));
        tar->entry_bytes_remaining = tar_atol(header->size, sizeof(header->size));
        if (tar->entry_bytes_remaining < 0) {
                tar->entry_bytes_remaining = 0;
                archive_set_error(&a->archive, ARCHIVE_ERRNO_MISC,
                    "Tar entry has negative size?");
                err = ARCHIVE_WARN;
        }
        tar->realsize = tar->entry_bytes_remaining;
        archive_entry_set_size(entry, tar->entry_bytes_remaining);
//        archive_entry_set_mtime(entry, tar_atol(header->mtime, sizeof(header->mtime)), 0);

        /* Handle the tar type flag appropriately. */
        tartype = header->typeflag[0];

        switch (tartype) {
        case '1': /* Hard link */
//                if (archive_entry_copy_hardlink_l(entry, tar->entry_linkpath.s,
//                    archive_strlen(&(tar->entry_linkpath)), tar->sconv) != 0) {
//                        err = set_conversion_failed_error(a, tar->sconv,
//                            "Linkname");
//                        if (err == ARCHIVE_FATAL)
//                                return (err);
//                }
//                /*
//                 * The following may seem odd, but: Technically, tar
//                 * does not store the file type for a "hard link"
//                 * entry, only the fact that it is a hard link.  So, I
//                 * leave the type zero normally.  But, pax interchange
//                 * format allows hard links to have data, which
//                 * implies that the underlying entry is a regular
//                 * file.
//                 */
//                if (archive_entry_size(entry) > 0)
//                        archive_entry_set_filetype(entry, AE_IFREG);
//
//                /*
//                 * A tricky point: Traditionally, tar readers have
//                 * ignored the size field when reading hardlink
//                 * entries, and some writers put non-zero sizes even
//                 * though the body is empty.  POSIX blessed this
//                 * convention in the 1988 standard, but broke with
//                 * this tradition in 2001 by permitting hardlink
//                 * entries to store valid bodies in pax interchange
//                 * format, but not in ustar format.  Since there is no
//                 * hard and fast way to distinguish pax interchange
//                 * from earlier archives (the 'x' and 'g' entries are
//                 * optional, after all), we need a heuristic.
//                 */
//                if (archive_entry_size(entry) == 0) {
//                        /* If the size is already zero, we're done. */
//                }  else if (a->archive.archive_format
//                    == ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE) {
//                        /* Definitely pax extended; must obey hardlink size. */
//                } else if (a->archive.archive_format == ARCHIVE_FORMAT_TAR
//                    || a->archive.archive_format == ARCHIVE_FORMAT_TAR_GNUTAR)
//                {
//                        /* Old-style or GNU tar: we must ignore the size. */
//                        archive_entry_set_size(entry, 0);
//                        tar->entry_bytes_remaining = 0;
//                } else if (archive_read_format_tar_bid(a, 50) > 50) {
//                        /*
//                         * We don't know if it's pax: If the bid
//                         * function sees a valid ustar header
//                         * immediately following, then let's ignore
//                         * the hardlink size.
//                         */
//                        archive_entry_set_size(entry, 0);
//                        tar->entry_bytes_remaining = 0;
//                }
                /*
                 * TODO: There are still two cases I'd like to handle:
                 *   = a ustar non-pax archive with a hardlink entry at
                 *     end-of-archive.  (Look for block of nulls following?)
                 *   = a pax archive that has not seen any pax headers
                 *     and has an entry which is a hardlink entry storing
                 *     a body containing an uncompressed tar archive.
                 * The first is worth addressing; I don't see any reliable
                 * way to deal with the second possibility.
                 */
                break;
        case '2': /* Symlink */
                archive_entry_set_filetype(entry, AE_IFLNK);
                archive_entry_set_size(entry, 0);
                tar->entry_bytes_remaining = 0;
                if (archive_entry_copy_symlink_l(entry, tar->entry_linkpath.s,
                    archive_strlen(&(tar->entry_linkpath)), tar->sconv) != 0) {
//                        err = set_conversion_failed_error(a, tar->sconv,
//                            "Linkname");
//                        if (err == ARCHIVE_FATAL)
//                                return (err);
                    return ARCHIVE_FATAL;
                }
                break;
        case '3': /* Character device */
                archive_entry_set_filetype(entry, AE_IFCHR);
                archive_entry_set_size(entry, 0);
                tar->entry_bytes_remaining = 0;
                break;
        case '4': /* Block device */
                archive_entry_set_filetype(entry, AE_IFBLK);
                archive_entry_set_size(entry, 0);
                tar->entry_bytes_remaining = 0;
                break;
        case '5': /* Dir */
                archive_entry_set_filetype(entry, AE_IFDIR);
                archive_entry_set_size(entry, 0);
                tar->entry_bytes_remaining = 0;
                break;
        case '6': /* FIFO device */
                archive_entry_set_filetype(entry, AE_IFIFO);
                archive_entry_set_size(entry, 0);
                tar->entry_bytes_remaining = 0;
                break;
        case 'D': /* GNU incremental directory type */
                /*
                 * No special handling is actually required here.
                 * It might be nice someday to preprocess the file list and
                 * provide it to the client, though.
                 */
                archive_entry_set_filetype(entry, AE_IFDIR);
                break;
        case 'M': /* GNU "Multi-volume" (remainder of file from last archive)*/
                /*
                 * As far as I can tell, this is just like a regular file
                 * entry, except that the contents should be _appended_ to
                 * the indicated file at the indicated offset.  This may
                 * require some API work to fully support.
                 */
                break;
        case 'N': /* Old GNU "long filename" entry. */
                /* The body of this entry is a script for renaming
                 * previously-extracted entries.  Ugh.  It will never
                 * be supported by libarchive. */
                archive_entry_set_filetype(entry, AE_IFREG);
                break;
        case 'S': /* GNU sparse files */
                /*
                 * Sparse files are really just regular files with
                 * sparse information in the extended area.
                 */
                /* FALLTHROUGH */
        default: /* Regular file  and non-standard types */
                /*
                 * Per POSIX: non-recognized types should always be
                 * treated as regular files.
                 */
                archive_entry_set_filetype(entry, AE_IFREG);
                break;
        }
        return (err);
}

/*
 * Return true if block checksum is correct.
 */
static int
checksum(struct archive_read *a, const void *h)
{
        const unsigned char *bytes;
        const struct archive_entry_header_ustar *header;
        int check, i, sum;

        (void)a; /* UNUSED */
        bytes = (const unsigned char *)h;
        header = (const struct archive_entry_header_ustar *)h;

        /*
         * Test the checksum.  Note that POSIX specifies _unsigned_
         * bytes for this calculation.
         */
        sum = (int)tar_atol(header->checksum, sizeof(header->checksum));
        check = 0;
        for (i = 0; i < 148; i++)
                check += (unsigned char)bytes[i];
        for (; i < 156; i++)
                check += 32;
        for (; i < 512; i++)
                check += (unsigned char)bytes[i];
        if (sum == check)
                return (1);

        /*
         * Repeat test with _signed_ bytes, just in case this archive
         * was created by an old BSD, Solaris, or HP-UX tar with a
         * broken checksum calculation.
         */
        check = 0;
        for (i = 0; i < 148; i++)
                check += (signed char)bytes[i];
        for (; i < 156; i++)
                check += 32;
        for (; i < 512; i++)
                check += (signed char)bytes[i];
        if (sum == check)
                return (1);

        return (0);
}

/*
 * Interpret 'K' long linkname header.
 */
//static int
//header_longlink(struct archive_read *a, struct tar *tar,
//    struct archive_entry *entry, const void *h, size_t *unconsumed)
//{
//        int err;
//
//        err = read_body_to_string(a, tar, &(tar->longlink), h, unconsumed);
//        if (err != ARCHIVE_OK)
//                return (err);
//        err = tar_read_header(a, tar, entry, unconsumed);
//        if ((err != ARCHIVE_OK) && (err != ARCHIVE_WARN))
//                return (err);
//        /* Set symlink if symlink already set, else hardlink. */
//        archive_entry_copy_link(entry, tar->longlink.s);
//        return (ARCHIVE_OK);
//}

static int
set_conversion_failed_error(struct archive_read *a,
    struct archive_string_conv *sconv, const char *name)
{
        if (errno == ENOMEM) {
                archive_set_error(&a->archive, ENOMEM,
                    "Can't allocate memory for %s", name);
                return (ARCHIVE_FATAL);
        }
        archive_set_error(&a->archive, ARCHIVE_ERRNO_FILE_FORMAT,
            "%s can't be converted from %s to current locale.",
            name, archive_string_conversion_charset_name(sconv));
        return (ARCHIVE_WARN);
}

/*
 * Interpret 'L' long filename header.
 */
static int
header_longname(struct archive_read *a, struct tar *tar,
    struct archive_entry *entry, const void *h, size_t *unconsumed)
{
        int err;

        err = read_body_to_string(a, tar, &(tar->longname), h, unconsumed);
        if (err != ARCHIVE_OK)
                return (err);
        /* Read and parse "real" header, then override name. */
        err = tar_read_header(a, tar, entry, unconsumed);
        if ((err != ARCHIVE_OK) && (err != ARCHIVE_WARN))
                return (err);
        if (archive_entry_copy_pathname_l(entry, tar->longname.s,
            archive_strlen(&(tar->longname)), tar->sconv) != 0)
                err = set_conversion_failed_error(a, tar->sconv, "Pathname");
        return (err);
}


/*
 * Interpret 'V' GNU tar volume header.
 */
static int
header_volume(struct archive_read *a, struct tar *tar,
    struct archive_entry *entry, const void *h, size_t *unconsumed)
{
        (void)h;

        /* Just skip this and read the next header. */
        return (tar_read_header(a, tar, entry, unconsumed));
}

/*
 * Read body of an archive entry into an archive_string object.
 */
static int
read_body_to_string(struct archive_read *a, struct tar *tar,
    struct archive_string *as, const void *h, size_t *unconsumed)
{
        int64_t size;
        const struct archive_entry_header_ustar *header;
        const void *src;

        (void)tar; /* UNUSED */
        header = (const struct archive_entry_header_ustar *)h;
        size  = tar_atol(header->size, sizeof(header->size));
        if ((size > 1048576) || (size < 0)) {
                archive_set_error(&a->archive, EINVAL,
                    "Special header too large");
                return (ARCHIVE_FATAL);
        }

        /* Fail if we can't make our buffer big enough. */
        if (archive_string_ensure(as, (size_t)size+1) == NULL) {
                archive_set_error(&a->archive, ENOMEM,
                    "No memory");
                return (ARCHIVE_FATAL);
        }

        tar_flush_unconsumed(a, unconsumed);

        /* Read the body into the string. */
        *unconsumed = (size_t)((size + 511) & ~ 511);
        src = __archive_read_ahead(a, *unconsumed, NULL);
        if (src == NULL) {
                *unconsumed = 0;
                return (ARCHIVE_FATAL);
        }
        memcpy(as->s, src, (size_t)size);
        as->s[size] = '\0';
        as->length = (size_t)size;
        return (ARCHIVE_OK);
}



/*
 * This function recursively interprets all of the headers associated
 * with a single entry.
 */
static int
tar_read_header(struct archive_read *a, struct tar *tar,
    struct archive_entry *entry, size_t *unconsumed)
{
        ssize_t bytes;
        int err;
        const char *h;
        const struct archive_entry_header_ustar *header;
        const struct archive_entry_header_gnutar *gnuheader;

        tar_flush_unconsumed(a, unconsumed);

        /* Read 512-byte header record */
        h = (char*)__archive_read_ahead(a, 512, &bytes);
        if (bytes < 0)
                return ((int)bytes);
        if (bytes == 0) { /* EOF at a block boundary. */
                /* Some writers do omit the block of nulls. <sigh> */
            	fprintf(stderr, "libmdtm: warning: %s:%d:DETECT EOF\n",__FILE__,__LINE__);
                return (ARCHIVE_EOF);
        }
        if (bytes < 512) {  /* Short block at EOF; this is bad. */
                archive_set_error(&a->archive, ARCHIVE_ERRNO_FILE_FORMAT,
                    "Truncated tar archive");
                return (ARCHIVE_FATAL);
        }
        *unconsumed = 512;

        /* Check for end-of-archive mark. */
        if (h[0] == 0 && archive_block_is_null(h)) {
                /* Try to consume a second all-null record, as well. */
                tar_flush_unconsumed(a, unconsumed);
                h = (char*)__archive_read_ahead(a, 512, NULL);
                if (h != NULL)
                        __archive_read_consume(a, 512);
//                archive_clear_error(&a->archive);
                if (a->archive.archive_format_name == NULL) {
                        a->archive.archive_format = ARCHIVE_FORMAT_TAR;
                        a->archive.archive_format_name = "tar";
                }
                return (ARCHIVE_EOF);
        }

        /*
         * Note: If the checksum fails and we return ARCHIVE_RETRY,
         * then the client is likely to just retry.  This is a very
         * crude way to search for the next valid header!
         *
         * TODO: Improve this by implementing a real header scan.
         */
        if (!checksum(a, h)) {
                tar_flush_unconsumed(a, unconsumed);
                archive_set_error(&a->archive, EINVAL, "Damaged tar archive");
                return (ARCHIVE_RETRY); /* Retryable: Invalid header */
        }

        if (++tar->header_recursion_depth > 32) {
                tar_flush_unconsumed(a, unconsumed);
                archive_set_error(&a->archive, EINVAL, "Too many special headers");
                return (ARCHIVE_WARN);
        }

        /* Determine the format variant. */
        header = (const struct archive_entry_header_ustar *)h;

        switch(header->typeflag[0]) {
//        case 'A': /* Solaris tar ACL */
//                a->archive.archive_format = ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE;
//                a->archive.archive_format_name = "Solaris tar";
//                err = header_Solaris_ACL(a, tar, entry, h, unconsumed);
//                break;
//        case 'g': /* POSIX-standard 'g' header. */
//                a->archive.archive_format = ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE;
//                a->archive.archive_format_name = "POSIX pax interchange format";
//                err = header_pax_global(a, tar, entry, h, unconsumed);
//                break;
//        case 'K': /* Long link name (GNU tar, others) */
//                err = header_longlink(a, tar, entry, h, unconsumed);
//                break;
        case 'L': /* Long filename (GNU tar, others) */
                err = header_longname(a, tar, entry, h, unconsumed);
                break;
//        case 'V': /* GNU volume header */
//                err = header_volume(a, tar, entry, h, unconsumed);
//                break;
//        case 'X': /* Used by SUN tar; same as 'x'. */
//                a->archive.archive_format = ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE;
//                a->archive.archive_format_name =
//                    "POSIX pax interchange format (Sun variant)";
//                err = header_pax_extensions(a, tar, entry, h, unconsumed);
//                break;
//        case 'x': /* POSIX-standard 'x' header. */
//                a->archive.archive_format = ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE;
//                a->archive.archive_format_name = "POSIX pax interchange format";
//                err = header_pax_extensions(a, tar, entry, h, unconsumed);
//                break;
        default:
                gnuheader = (const struct archive_entry_header_gnutar *)h;
                if (memcmp(gnuheader->magic, "ustar  \0", 8) == 0) {
                        a->archive.archive_format = ARCHIVE_FORMAT_TAR_GNUTAR;
                        a->archive.archive_format_name = "GNU tar format";
                        err = header_gnutar(a, tar, entry, h, unconsumed);
                } else if (memcmp(header->magic, "ustar", 5) == 0) {
                        if (a->archive.archive_format != ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE) {
                                a->archive.archive_format = ARCHIVE_FORMAT_TAR_USTAR;
                                a->archive.archive_format_name = "POSIX ustar format";
                        }
                        err = header_ustar(a, tar, entry, h);
                } else {
//                        a->archive.archive_format = ARCHIVE_FORMAT_TAR;
//                        a->archive.archive_format_name = "tar (non-POSIX)";
//                        err = header_old_tar(a, tar, entry, h);
                }
        }
        if (err == ARCHIVE_FATAL)
                return (err);

        tar_flush_unconsumed(a, unconsumed);

        h = NULL;
        header = NULL;

        --tar->header_recursion_depth;
        /* Yuck.  Apple's design here ends up storing long pathname
         * extensions for both the AppleDouble extension entry and the
         * regular entry.
         */
        /* TODO: Should this be disabled on non-Mac platforms? */
//        if ((err == ARCHIVE_WARN || err == ARCHIVE_OK) &&
//            tar->header_recursion_depth == 0) {
//                int err2 = read_mac_metadata_blob(a, tar, entry, h, unconsumed);
//                if (err2 < err)
//                        err = err2;
//        }

        /* We return warnings or success as-is.  Anything else is fatal. */
        if (err == ARCHIVE_WARN || err == ARCHIVE_OK) {
                if (tar->sparse_gnu_pending) {
                        if (tar->sparse_gnu_major == 1 &&
                            tar->sparse_gnu_minor == 0) {
                                ssize_t bytes_read;

                                tar->sparse_gnu_pending = 0;
                                /* Read initial sparse map. */
                                bytes_read = gnu_sparse_10_read(a, tar, unconsumed);
                                tar->entry_bytes_remaining -= bytes_read;
                                if (bytes_read < 0)
                                        return ((int)bytes_read);
                        } else {
                                archive_set_error(&a->archive,
                                    ARCHIVE_ERRNO_MISC,
                                    "Unrecognized GNU sparse file format");
                                return (ARCHIVE_WARN);
                        }
                        tar->sparse_gnu_pending = 0;
                }
                return (err);
        }
        if (err == ARCHIVE_EOF)
                /* EOF when recursively reading a header is bad. */
                archive_set_error(&a->archive, EINVAL, "Damaged tar archive");
        return (ARCHIVE_FATAL);
}
///////////////////////////////////////////////////

//int
//archive_read_next_header(struct archive *a, struct archive_entry **entry)
//{
//        return ((a->vtable->archive_read_next_header)(a, entry));
//}
//
//static int
//tar_read_header(struct archive_read *a, struct tar *tar,
//    struct archive_entry *entry, size_t *unconsumed)
//{
//        ssize_t bytes;
//        int err;
//        const char *h;
//        const struct archive_entry_header_ustar *header;
//        const struct archive_entry_header_gnutar *gnuheader;
//
//        tar_flush_unconsumed(a, unconsumed);
//
//        /* Read 512-byte header record */
//        h = __archive_read_ahead(a, 512, &bytes);
//        if (bytes < 0)
//                return ((int)bytes);
//        if (bytes == 0) { /* EOF at a block boundary. */
//                /* Some writers do omit the block of nulls. <sigh> */
//                return (ARCHIVE_EOF);
//        }
//        if (bytes < 512) {  /* Short block at EOF; this is bad. */
//                archive_set_error(&a->archive, ARCHIVE_ERRNO_FILE_FORMAT,
//                    "Truncated tar archive");
//                return (ARCHIVE_FATAL);
//        }
//        *unconsumed = 512;
//
//        /* Check for end-of-archive mark. */
//        if (h[0] == 0 && archive_block_is_null(h)) {
//                /* Try to consume a second all-null record, as well. */
//                tar_flush_unconsumed(a, unconsumed);
//                h = __archive_read_ahead(a, 512, NULL);
//                if (h != NULL)
//                        __archive_read_consume(a, 512);
//                archive_clear_error(&a->archive);
//                if (a->archive.archive_format_name == NULL) {
//                        a->archive.archive_format = ARCHIVE_FORMAT_TAR;
//                        a->archive.archive_format_name = "tar";
//                }
//                return (ARCHIVE_EOF);
//        }
//
//        /*
//         * Note: If the checksum fails and we return ARCHIVE_RETRY,
//         * then the client is likely to just retry.  This is a very
//         * crude way to search for the next valid header!
//         *
//         * TODO: Improve this by implementing a real header scan.
//         */
//        if (!checksum(a, h)) {
//                tar_flush_unconsumed(a, unconsumed);
//                archive_set_error(&a->archive, EINVAL, "Damaged tar archive");
//                return (ARCHIVE_RETRY); /* Retryable: Invalid header */
//        }
//
//        if (++tar->header_recursion_depth > 32) {
//                tar_flush_unconsumed(a, unconsumed);
//                archive_set_error(&a->archive, EINVAL, "Too many special headers");
//                return (ARCHIVE_WARN);
//        }
//
//        /* Determine the format variant. */
//        header = (const struct archive_entry_header_ustar *)h;
//
//        switch(header->typeflag[0]) {
//        case 'A': /* Solaris tar ACL */
//                a->archive.archive_format = ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE;
//                a->archive.archive_format_name = "Solaris tar";
//                err = header_Solaris_ACL(a, tar, entry, h, unconsumed);
//                break;
//        case 'g': /* POSIX-standard 'g' header. */
//                a->archive.archive_format = ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE;
//                a->archive.archive_format_name = "POSIX pax interchange format";
//                err = header_pax_global(a, tar, entry, h, unconsumed);
//                break;
//        case 'K': /* Long link name (GNU tar, others) */
//                err = header_longlink(a, tar, entry, h, unconsumed);
//                break;
//        case 'L': /* Long filename (GNU tar, others) */
//                err = header_longname(a, tar, entry, h, unconsumed);
//                break;
//        case 'V': /* GNU volume header */
//                err = header_volume(a, tar, entry, h, unconsumed);
//                break;
//        case 'X': /* Used by SUN tar; same as 'x'. */
//                a->archive.archive_format = ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE;
//                a->archive.archive_format_name =
//                    "POSIX pax interchange format (Sun variant)";
//                err = header_pax_extensions(a, tar, entry, h, unconsumed);
//                break;
//        case 'x': /* POSIX-standard 'x' header. */
//                a->archive.archive_format = ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE;
//                a->archive.archive_format_name = "POSIX pax interchange format";
//                err = header_pax_extensions(a, tar, entry, h, unconsumed);
//                break;
//        default:
//                gnuheader = (const struct archive_entry_header_gnutar *)h;
//                if (memcmp(gnuheader->magic, "ustar  \0", 8) == 0) {
//                        a->archive.archive_format = ARCHIVE_FORMAT_TAR_GNUTAR;
//                        a->archive.archive_format_name = "GNU tar format";
//                        err = header_gnutar(a, tar, entry, h, unconsumed);
//                } else if (memcmp(header->magic, "ustar", 5) == 0) {
//                        if (a->archive.archive_format != ARCHIVE_FORMAT_TAR_PAX_INTERCHANGE) {
//                                a->archive.archive_format = ARCHIVE_FORMAT_TAR_USTAR;
//                                a->archive.archive_format_name = "POSIX ustar format";
//                        }
//                        err = header_ustar(a, tar, entry, h);
//                } else {
//                        a->archive.archive_format = ARCHIVE_FORMAT_TAR;
//                        a->archive.archive_format_name = "tar (non-POSIX)";
//                        err = header_old_tar(a, tar, entry, h);
//                }
//        }
//        if (err == ARCHIVE_FATAL)
//                return (err);
//
//        tar_flush_unconsumed(a, unconsumed);
//
//        h = NULL;
//        header = NULL;
//
//        --tar->header_recursion_depth;
//        /* Yuck.  Apple's design here ends up storing long pathname
//         * extensions for both the AppleDouble extension entry and the
//         * regular entry.
//         */
//        /* TODO: Should this be disabled on non-Mac platforms? */
//        if ((err == ARCHIVE_WARN || err == ARCHIVE_OK) &&
//            tar->header_recursion_depth == 0) {
//                int err2 = read_mac_metadata_blob(a, tar, entry, h, unconsumed);
//                if (err2 < err)
//                        err = err2;
//        }
//
//        /* We return warnings or success as-is.  Anything else is fatal. */
//        if (err == ARCHIVE_WARN || err == ARCHIVE_OK) {
//                if (tar->sparse_gnu_pending) {
//                        if (tar->sparse_gnu_major == 1 &&
//                            tar->sparse_gnu_minor == 0) {
//                                ssize_t bytes_read;
//
//                                tar->sparse_gnu_pending = 0;
//                                /* Read initial sparse map. */
//                                bytes_read = gnu_sparse_10_read(a, tar, unconsumed);
//                                tar->entry_bytes_remaining -= bytes_read;
//                                if (bytes_read < 0)
//                                        return ((int)bytes_read);
//                        } else {
//                                archive_set_error(&a->archive,
//                                    ARCHIVE_ERRNO_MISC,
//                                    "Unrecognized GNU sparse file format");
//                                return (ARCHIVE_WARN);
//                        }
//                        tar->sparse_gnu_pending = 0;
//                }
//                return (err);
//        }
//        if (err == ARCHIVE_EOF)
//                /* EOF when recursively reading a header is bad. */
//                archive_set_error(&a->archive, EINVAL, "Damaged tar archive");
//        return (ARCHIVE_FATAL);
//}
//
//static int
//archive_read_format_tar_read_header(struct archive_read *a,
//    struct archive_entry *entry)
//{
//        /*
//         * When converting tar archives to cpio archives, it is
//         * essential that each distinct file have a distinct inode
//         * number.  To simplify this, we keep a static count here to
//         * assign fake dev/inode numbers to each tar entry.  Note that
//         * pax format archives may overwrite this with something more
//         * useful.
//         *
//         * Ideally, we would track every file read from the archive so
//         * that we could assign the same dev/ino pair to hardlinks,
//         * but the memory required to store a complete lookup table is
//         * probably not worthwhile just to support the relatively
//         * obscure tar->cpio conversion case.
//         */
//        static int default_inode;
//        static int default_dev;
//        struct tar *tar;
//        const char *p;
//        int r;
//        size_t l, unconsumed = 0;
//
//        /* Assign default device/inode values. */
//        archive_entry_set_dev(entry, 1 + default_dev); /* Don't use zero. */
//        archive_entry_set_ino(entry, ++default_inode); /* Don't use zero. */
//        /* Limit generated st_ino number to 16 bits. */
//        if (default_inode >= 0xffff) {
//                ++default_dev;
//                default_inode = 0;
//        }
//
//        tar = (struct tar *)(a->format->data);
//        tar->entry_offset = 0;
//        gnu_clear_sparse_list(tar);
//        tar->realsize = -1; /* Mark this as "unset" */
//
//        /* Setup default string conversion. */
//        tar->sconv = tar->opt_sconv;
//        if (tar->sconv == NULL) {
//                if (!tar->init_default_conversion) {
//                        tar->sconv_default =
//                            archive_string_default_conversion_for_read(&(a->archive));
//                        tar->init_default_conversion = 1;
//                }
//                tar->sconv = tar->sconv_default;
//        }
//
//        r = tar_read_header(a, tar, entry, &unconsumed);
//
//        tar_flush_unconsumed(a, &unconsumed);
//
//        /*
//         * "non-sparse" files are really just sparse files with
//         * a single block.
//         */
//        if (tar->sparse_list == NULL) {
//                if (gnu_add_sparse_entry(a, tar, 0, tar->entry_bytes_remaining)
//                    != ARCHIVE_OK)
//                        return (ARCHIVE_FATAL);
//        } else {
//                struct sparse_block *sb;
//
//                for (sb = tar->sparse_list; sb != NULL; sb = sb->next) {
//                        if (!sb->hole)
//                                archive_entry_sparse_add_entry(entry,
//                                    sb->offset, sb->remaining);
//                }
//        }
//
//        if (r == ARCHIVE_OK) {
//                /*
//                 * "Regular" entry with trailing '/' is really
//                 * directory: This is needed for certain old tar
//                 * variants and even for some broken newer ones.
//                 */
//                const wchar_t *wp;
//                wp = archive_entry_pathname_w(entry);
//                if (wp != NULL) {
//                        l = wcslen(wp);
//                        if (archive_entry_filetype(entry) == AE_IFREG
//                            && wp[l-1] == L'/')
//                                archive_entry_set_filetype(entry, AE_IFDIR);
//                } else {
//                        p = archive_entry_pathname(entry);
//                        if (p == NULL)
//                                return (ARCHIVE_FAILED);
//                        l = strlen(p);
//                        if (archive_entry_filetype(entry) == AE_IFREG
//                            && p[l-1] == '/')
//                                archive_entry_set_filetype(entry, AE_IFDIR);
//                }
//        }
//        return (r);
//}

////////////////////////////////////////////////////////////////////////
//
//      archive_write_disk
//
////////////////////////////////////////////////////////////////////////
#define TODO_MODE_FORCE         0x40000000
#define TODO_MODE_BASE          0x20000000
#define TODO_SUID               0x10000000
#define TODO_SUID_CHECK         0x08000000
#define TODO_SGID               0x04000000
#define TODO_SGID_CHECK         0x02000000
#define TODO_APPLEDOUBLE        0x01000000
#define TODO_MODE               (TODO_MODE_BASE|TODO_SUID|TODO_SGID)
#define TODO_TIMES              ARCHIVE_EXTRACT_TIME
#define TODO_OWNER              ARCHIVE_EXTRACT_OWNER
#define TODO_FFLAGS             ARCHIVE_EXTRACT_FFLAGS
#define TODO_ACLS               ARCHIVE_EXTRACT_ACL
#define TODO_XATTR              ARCHIVE_EXTRACT_XATTR
#define TODO_MAC_METADATA       ARCHIVE_EXTRACT_MAC_METADATA
#define TODO_HFS_COMPRESSION    ARCHIVE_EXTRACT_HFS_COMPRESSION_FORCED

struct archive_write_disk {
        struct archive  archive;

        mode_t                   user_umask;
        struct fixup_entry      *fixup_list;
        struct fixup_entry      *current_fixup;
        int64_t                  user_uid;
        int                      skip_file_set;
        int64_t                  skip_file_dev;
        int64_t                  skip_file_ino;
        time_t                   start_time;

        int64_t (*lookup_gid)(void *privated, const char *gname, int64_t gid);
        void  (*cleanup_gid)(void *privated);
        void                    *lookup_gid_data;
        int64_t (*lookup_uid)(void *privated, const char *uname, int64_t uid);
        void  (*cleanup_uid)(void *privated);
        void                    *lookup_uid_data;

        /*
         * Full path of last file to satisfy symlink checks.
         */
        struct archive_string   path_safe;

        /*
         * Cached stat data from disk for the current entry.
         * If this is valid, pst points to st.  Otherwise,
         * pst is null.
         */
        struct stat              st;
        struct stat             *pst;

        /* Information about the object being restored right now. */
        struct archive_entry    *entry; /* Entry being extracted. */
        char                    *name; /* Name of entry, possibly edited. */
        struct archive_string    _name_data; /* backing store for 'name' */
        /* Tasks remaining for this object. */
        int                      todo;
        /* Tasks deferred until end-of-archive. */
        int                      deferred;
        /* Options requested by the client. */
        int                      flags;
        /* Handle for the file we're restoring. */
        int                      fd;
        /* Current offset for writing data to the file. */
        int64_t                  offset;
        /* Last offset actually written to disk. */
        int64_t                  fd_offset;
        /* Total bytes actually written to files. */
        int64_t                  total_bytes_written;
        /* Maximum size of file, -1 if unknown. */
        int64_t                  filesize;
        /* Dir we were in before this restore; only for deep paths. */
        int                      restore_pwd;
        /* Mode we should use for this entry; affected by _PERM and umask. */
        mode_t                   mode;
        /* UID/GID to use in restoring this entry. */
        int64_t                  uid;
        int64_t                  gid;
        /*
         * HFS+ Compression.
         */
        /* Xattr "com.apple.decmpfs". */
        uint32_t                 decmpfs_attr_size;
        unsigned char           *decmpfs_header_p;
        /* ResourceFork set options used for fsetxattr. */
        int                      rsrc_xattr_options;
        /* Xattr "com.apple.ResourceFork". */
        unsigned char           *resource_fork;
        size_t                   resource_fork_allocated_size;
        unsigned int             decmpfs_block_count;
        uint32_t                *decmpfs_block_info;
        /* Buffer for compressed data. */
        unsigned char           *compressed_buffer;
        size_t                   compressed_buffer_size;
        size_t                   compressed_buffer_remaining;
        /* The offset of the ResourceFork where compressed data will
         * be placed. */
        uint32_t                 compressed_rsrc_position;
        uint32_t                 compressed_rsrc_position_v;
        /* Buffer for uncompressed data. */
        char                    *uncompressed_buffer;
        size_t                   block_remaining_bytes;
        size_t                   file_remaining_bytes;
#ifdef HAVE_ZLIB_H
        z_stream                 stream;
        int                      stream_valid;
        int                      decmpfs_compression_level;
#endif
};

/*
 * Default mode for dirs created automatically (will be modified by umask).
 * Note that POSIX specifies 0777 for implicitly-created dirs, "modified
 * by the process' file creation mask."
 */
#define DEFAULT_DIR_MODE 0777
/*
 * Dir modes are restored in two steps:  During the extraction, the permissions
 * in the archive are modified to match the following limits.  During
 * the post-extract fixup pass, the permissions from the archive are
 * applied.
 */
#define MINIMUM_DIR_MODE 0700
#define MAXIMUM_DIR_MODE 0775

static int      check_symlinks(struct archive_write_disk *);
static int      create_filesystem_object(struct archive_write_disk *);

static int      cleanup_pathname(struct archive_write_disk *);
static int      create_dir(struct archive_write_disk *, char *);
static int      create_parent_dir(struct archive_write_disk *, char *);
static ssize_t  hfs_write_data_block(struct archive_write_disk *,
                    const char *, size_t);
static int      fixup_appledouble(struct archive_write_disk *, const char *);
static int      older(struct stat *, struct archive_entry *);
static int      restore_entry(struct archive_write_disk *);


static struct archive_vtable *archive_write_disk_vtable(void);

static int      _archive_write_disk_close(struct archive *);
static int      _archive_write_disk_free(struct archive *);
static int      _archive_write_disk_header(struct archive *, struct archive_entry *);
static int64_t  _archive_write_disk_filter_bytes(struct archive *, int);
static int      _archive_write_disk_finish_entry(struct archive *);
static ssize_t  _archive_write_disk_data(struct archive *, const void *, size_t);
static ssize_t  _archive_write_disk_data_block(struct archive *, const void *, size_t, int64_t);

static struct archive_vtable *
archive_write_disk_vtable(void)
{
        static struct archive_vtable av;
        static int inited = 0;

        if (!inited) {
                av.archive_close = _archive_write_disk_close;
                av.archive_filter_bytes = _archive_write_disk_filter_bytes;
                av.archive_free = _archive_write_disk_free;
                av.archive_write_header = _archive_write_disk_header;
                av.archive_write_finish_entry
                    = _archive_write_disk_finish_entry;
//                av.archive_write_data = _archive_write_disk_data;
//                av.archive_write_data_block = _archive_write_disk_data_block;
                inited = 1;
        }
        return (&av);
}

static int64_t
_archive_write_disk_filter_bytes(struct archive *_a, int n)
{
        struct archive_write_disk *a = (struct archive_write_disk *)_a;
        (void)n; /* UNUSED */
        if (n == -1 || n == 0)
                return (a->total_bytes_written);
        return (-1);
}

/*
 * Extract this entry to disk.
 *
 * TODO: Validate hardlinks.  According to the standards, we're
 * supposed to check each extracted hardlink and squawk if it refers
 * to a file that we didn't restore.  I'm not entirely convinced this
 * is a good idea, but more importantly: Is there any way to validate
 * hardlinks without keeping a complete list of filenames from the
 * entire archive?? Ugh.
 *
 */
static int
_archive_write_disk_header(struct archive *_a, struct archive_entry *entry)
{
        struct archive_write_disk *a = (struct archive_write_disk *)_a;
        struct fixup_entry *fe;
        int ret, r;

//        archive_check_magic(&a->archive, ARCHIVE_WRITE_DISK_MAGIC,
//            ARCHIVE_STATE_HEADER | ARCHIVE_STATE_DATA,
//            "archive_write_disk_header");
//        archive_clear_error(&a->archive);
//        if (a->archive.state & ARCHIVE_STATE_DATA) {
//                r = _archive_write_disk_finish_entry(&a->archive);
//                if (r == ARCHIVE_FATAL)
//                        return (r);
//        }

        /* Set up for this particular entry. */
        a->pst = NULL;
        a->current_fixup = NULL;
        a->deferred = 0;
        if (a->entry) {
                archive_entry_free(a->entry);
                a->entry = NULL;
        }
        a->entry = archive_entry_clone(entry);
        a->fd = -1;
        a->fd_offset = 0;
        a->offset = 0;
        a->restore_pwd = -1;
        a->uid = a->user_uid;
        a->mode = archive_entry_mode(a->entry);
        if (archive_entry_size_is_set(a->entry))
                a->filesize = archive_entry_size(a->entry);
        else
                a->filesize = -1;
        archive_strcpy(&(a->_name_data), archive_entry_pathname(a->entry));
        a->name = a->_name_data.s;
//        archive_clear_error(&a->archive);

        /*
         * Clean up the requested path.  This is necessary for correct
         * dir restores; the dir restore logic otherwise gets messed
         * up by nonsense like "dir/.".
         */
        ret = cleanup_pathname(a);
        if (ret != ARCHIVE_OK)
                return (ret);

        /*
         * Query the umask so we get predictable mode settings.
         * This gets done on every call to _write_header in case the
         * user edits their umask during the extraction for some
         * reason.
         */
        umask(a->user_umask = umask(0));

        /* Figure out what we need to do for this entry. */
        a->todo = TODO_MODE_BASE;
        if (a->flags & ARCHIVE_EXTRACT_PERM) {
                a->todo |= TODO_MODE_FORCE; /* Be pushy about permissions. */
                /*
                 * SGID requires an extra "check" step because we
                 * cannot easily predict the GID that the system will
                 * assign.  (Different systems assign GIDs to files
                 * based on a variety of criteria, including process
                 * credentials and the gid of the enclosing
                 * directory.)  We can only restore the SGID bit if
                 * the file has the right GID, and we only know the
                 * GID if we either set it (see set_ownership) or if
                 * we've actually called stat() on the file after it
                 * was restored.  Since there are several places at
                 * which we might verify the GID, we need a TODO bit
                 * to keep track.
                 */
                if (a->mode & S_ISGID)
                        a->todo |= TODO_SGID | TODO_SGID_CHECK;
                /*
                 * Verifying the SUID is simpler, but can still be
                 * done in multiple ways, hence the separate "check" bit.
                 */
                if (a->mode & S_ISUID)
                        a->todo |= TODO_SUID | TODO_SUID_CHECK;
        } else {
                /*
                 * User didn't request full permissions, so don't
                 * restore SUID, SGID bits and obey umask.
                 */
                a->mode &= ~S_ISUID;
                a->mode &= ~S_ISGID;
                a->mode &= ~S_ISVTX;
                a->mode &= ~a->user_umask;
        }
        if (a->flags & ARCHIVE_EXTRACT_OWNER)
                a->todo |= TODO_OWNER;
        if (a->flags & ARCHIVE_EXTRACT_TIME)
                a->todo |= TODO_TIMES;
        if (a->flags & ARCHIVE_EXTRACT_ACL) {
                if (archive_entry_filetype(a->entry) == AE_IFDIR)
                        a->deferred |= TODO_ACLS;
                else
                        a->todo |= TODO_ACLS;
        }
        if (a->flags & ARCHIVE_EXTRACT_MAC_METADATA) {
                if (archive_entry_filetype(a->entry) == AE_IFDIR)
                        a->deferred |= TODO_MAC_METADATA;
                else
                        a->todo |= TODO_MAC_METADATA;
        }
#if defined(__APPLE__) && defined(UF_COMPRESSED) && defined(HAVE_ZLIB_H)
        if ((a->flags & ARCHIVE_EXTRACT_NO_HFS_COMPRESSION) == 0) {
                unsigned long set, clear;
                archive_entry_fflags(a->entry, &set, &clear);
                if ((set & ~clear) & UF_COMPRESSED) {
                        a->todo |= TODO_HFS_COMPRESSION;
                        a->decmpfs_block_count = (unsigned)-1;
                }
        }
        if ((a->flags & ARCHIVE_EXTRACT_HFS_COMPRESSION_FORCED) != 0 &&
            (a->mode & AE_IFMT) == AE_IFREG && a->filesize > 0) {
                a->todo |= TODO_HFS_COMPRESSION;
                a->decmpfs_block_count = (unsigned)-1;
        }
        {
                const char *p;

                /* Check if the current file name is a type of the
                 * resource fork file. */
                p = strrchr(a->name, '/');
                if (p == NULL)
                        p = a->name;
                else
                        p++;
                if (p[0] == '.' && p[1] == '_') {
                        /* Do not compress "._XXX" files. */
                        a->todo &= ~TODO_HFS_COMPRESSION;
                        if (a->filesize > 0)
                                a->todo |= TODO_APPLEDOUBLE;
                }
        }
#endif

//        if (a->flags & ARCHIVE_EXTRACT_XATTR)
//                a->todo |= TODO_XATTR;
//        if (a->flags & ARCHIVE_EXTRACT_FFLAGS)
//                a->todo |= TODO_FFLAGS;
//        if (a->flags & ARCHIVE_EXTRACT_SECURE_SYMLINKS) {
//                ret = check_symlinks(a);
//                if (ret != ARCHIVE_OK)
//                        return (ret);
//        }
#if defined(HAVE_FCHDIR) && defined(PATH_MAX)
        /* If path exceeds PATH_MAX, shorten the path. */
        edit_deep_directories(a);
#endif

        ret = restore_entry(a);

#if defined(__APPLE__) && defined(UF_COMPRESSED) && defined(HAVE_ZLIB_H)
        /*
         * Check if the filesystem the file is restoring on supports
         * HFS+ Compression. If not, cancel HFS+ Compression.
         */
        if (a->todo | TODO_HFS_COMPRESSION) {
                /*
                 * NOTE: UF_COMPRESSED is ignored even if the filesystem
                 * supports HFS+ Compression because the file should
                 * have at least an extended attriute "com.apple.decmpfs"
                 * before the flag is set to indicate that the file have
                 * been compressed. If hte filesystem does not support
                 * HFS+ Compression the system call will fail.
                 */
                if (a->fd < 0 || fchflags(a->fd, UF_COMPRESSED) != 0)
                        a->todo &= ~TODO_HFS_COMPRESSION;
        }
#endif

        /*
         * TODO: There are rumours that some extended attributes must
         * be restored before file data is written.  If this is true,
         * then we either need to write all extended attributes both
         * before and after restoring the data, or find some rule for
         * determining which must go first and which last.  Due to the
         * many ways people are using xattrs, this may prove to be an
         * intractable problem.
         */

#ifdef HAVE_FCHDIR
        /* If we changed directory above, restore it here. */
        if (a->restore_pwd >= 0) {
                r = fchdir(a->restore_pwd);
                if (r != 0) {
                        archive_set_error(&a->archive, errno, "chdir() failure");
                        ret = ARCHIVE_FATAL;
                }
                close(a->restore_pwd);
                a->restore_pwd = -1;
        }
#endif

        /*
         * Fixup uses the unedited pathname from archive_entry_pathname(),
         * because it is relative to the base dir and the edited path
         * might be relative to some intermediate dir as a result of the
         * deep restore logic.
         */
//        if (a->deferred & TODO_MODE) {
//                fe = current_fixup(a, archive_entry_pathname(entry));
//                if (fe == NULL)
//                        return (ARCHIVE_FATAL);
//                fe->fixup |= TODO_MODE_BASE;
//                fe->mode = a->mode;
//        }
//
//        if ((a->deferred & TODO_TIMES)
//                && (archive_entry_mtime_is_set(entry)
//                    || archive_entry_atime_is_set(entry))) {
//                fe = current_fixup(a, archive_entry_pathname(entry));
//                if (fe == NULL)
//                        return (ARCHIVE_FATAL);
//                fe->mode = a->mode;
//                fe->fixup |= TODO_TIMES;
//                if (archive_entry_atime_is_set(entry)) {
//                        fe->atime = archive_entry_atime(entry);
//                        fe->atime_nanos = archive_entry_atime_nsec(entry);
//                } else {
//                        /* If atime is unset, use start time. */
//                        fe->atime = a->start_time;
//                        fe->atime_nanos = 0;
//                }
//                if (archive_entry_mtime_is_set(entry)) {
//                        fe->mtime = archive_entry_mtime(entry);
//                        fe->mtime_nanos = archive_entry_mtime_nsec(entry);
//                } else {
//                        /* If mtime is unset, use start time. */
//                        fe->mtime = a->start_time;
//                        fe->mtime_nanos = 0;
//                }
//                if (archive_entry_birthtime_is_set(entry)) {
//                        fe->birthtime = archive_entry_birthtime(entry);
//                        fe->birthtime_nanos = archive_entry_birthtime_nsec(entry);
//                } else {
//                        /* If birthtime is unset, use mtime. */
//                        fe->birthtime = fe->mtime;
//                        fe->birthtime_nanos = fe->mtime_nanos;
//                }
//        }
//
//        if (a->deferred & TODO_ACLS) {
//                fe = current_fixup(a, archive_entry_pathname(entry));
//                if (fe == NULL)
//                        return (ARCHIVE_FATAL);
//                fe->fixup |= TODO_ACLS;
//                archive_acl_copy(&fe->acl, archive_entry_acl(entry));
//        }
//
//        if (a->deferred & TODO_MAC_METADATA) {
//                const void *metadata;
//                size_t metadata_size;
//                metadata = archive_entry_mac_metadata(a->entry, &metadata_size);
//                if (metadata != NULL && metadata_size > 0) {
//                        fe = current_fixup(a, archive_entry_pathname(entry));
//                        if (fe == NULL)
//                                return (ARCHIVE_FATAL);
//                        fe->mac_metadata = malloc(metadata_size);
//                        if (fe->mac_metadata != NULL) {
//                                memcpy(fe->mac_metadata, metadata, metadata_size);
//                                fe->mac_metadata_size = metadata_size;
//                                fe->fixup |= TODO_MAC_METADATA;
//                        }
//                }
//        }
//
//        if (a->deferred & TODO_FFLAGS) {
//                fe = current_fixup(a, archive_entry_pathname(entry));
//                if (fe == NULL)
//                        return (ARCHIVE_FATAL);
//                fe->fixup |= TODO_FFLAGS;
//                /* TODO: Complete this.. defer fflags from below. */
//        }
//
//        /* We've created the object and are ready to pour data into it. */
//        if (ret >= ARCHIVE_WARN)
//                a->archive.state = ARCHIVE_STATE_DATA;
        /*
         * If it's not open, tell our client not to try writing.
         * In particular, dirs, links, etc, don't get written to.
         */
        if (a->fd < 0) {
                archive_entry_set_size(entry, 0);
                a->filesize = 0;
        }

        return (ret);
}

/*
 * Create a new archive_write_disk object and initialize it with global state.
 */
struct archive *
archive_write_disk_new(void)
{
        struct archive_write_disk *a;

        a = (struct archive_write_disk *)malloc(sizeof(*a));
        if (a == NULL)
                return (NULL);
        memset(a, 0, sizeof(*a));
//        a->archive.magic = ARCHIVE_WRITE_DISK_MAGIC;
        /* We're ready to write a header immediately. */
        a->archive.state = ARCHIVE_STATE_HEADER;
        a->archive.vtable = archive_write_disk_vtable();
        a->start_time = times(NULL);
        /* Query and restore the umask. */
        umask(a->user_umask = umask(0));
#ifdef HAVE_GETEUID
        a->user_uid = geteuid();
#endif /* HAVE_GETEUID */
        if (archive_string_ensure(&a->path_safe, 512) == NULL) {
                free(a);
                return (NULL);
        }
#ifdef HAVE_ZLIB_H
        a->decmpfs_compression_level = 5;
#endif
        return (&a->archive);
}

/*
 * The main restore function.
 */
static int
restore_entry(struct archive_write_disk *a)
{
        int ret = ARCHIVE_OK, en;

//        if (a->flags & ARCHIVE_EXTRACT_UNLINK && !S_ISDIR(a->mode)) {
//                /*
//                 * TODO: Fix this.  Apparently, there are platforms
//                 * that still allow root to hose the entire filesystem
//                 * by unlinking a dir.  The S_ISDIR() test above
//                 * prevents us from using unlink() here if the new
//                 * object is a dir, but that doesn't mean the old
//                 * object isn't a dir.
//                 */
//                if (unlink(a->name) == 0) {
//                        /* We removed it, reset cached stat. */
//                        a->pst = NULL;
//                } else if (errno == ENOENT) {
//                        /* File didn't exist, that's just as good. */
//                } else if (rmdir(a->name) == 0) {
//                        /* It was a dir, but now it's gone. */
//                        a->pst = NULL;
//                } else {
//                        /* We tried, but couldn't get rid of it. */
//                        archive_set_error(&a->archive, errno,
//                            "Could not unlink");
//                        return(ARCHIVE_FAILED);
//                }
//        }

        /* Try creating it first; if this fails, we'll try to recover. */
        en = create_filesystem_object(a);

//        if ((en == ENOTDIR || en == ENOENT)
//            && !(a->flags & ARCHIVE_EXTRACT_NO_AUTODIR)) {
//                /* If the parent dir doesn't exist, try creating it. */
//                create_parent_dir(a, a->name);
//                /* Now try to create the object again. */
//                en = create_filesystem_object(a);
//        }
//
        if ((en == EISDIR || en == EEXIST)
           /* && (a->flags & ARCHIVE_EXTRACT_NO_OVERWRITE)*/) {
                /* If we're not overwriting, we're done. */
                archive_entry_unset_size(a->entry);
                return (ARCHIVE_OK);
        }
//
//        /*
//         * Some platforms return EISDIR if you call
//         * open(O_WRONLY | O_EXCL | O_CREAT) on a directory, some
//         * return EEXIST.  POSIX is ambiguous, requiring EISDIR
//         * for open(O_WRONLY) on a dir and EEXIST for open(O_EXCL | O_CREAT)
//         * on an existing item.
//         */
//        if (en == EISDIR) {
//                /* A dir is in the way of a non-dir, rmdir it. */
//                if (rmdir(a->name) != 0) {
//                        archive_set_error(&a->archive, errno,
//                            "Can't remove already-existing dir");
//                        return (ARCHIVE_FAILED);
//                }
//                a->pst = NULL;
//                /* Try again. */
//                en = create_filesystem_object(a);
//        } else if (en == EEXIST) {
//                /*
//                 * We know something is in the way, but we don't know what;
//                 * we need to find out before we go any further.
//                 */
//                int r = 0;
//                /*
//                 * The SECURE_SYMLINKS logic has already removed a
//                 * symlink to a dir if the client wants that.  So
//                 * follow the symlink if we're creating a dir.
//                 */
//                if (S_ISDIR(a->mode))
//                        r = stat(a->name, &a->st);
//                /*
//                 * If it's not a dir (or it's a broken symlink),
//                 * then don't follow it.
//                 */
//                if (r != 0 || !S_ISDIR(a->mode))
//                        r = lstat(a->name, &a->st);
//                if (r != 0) {
//                        archive_set_error(&a->archive, errno,
//                            "Can't stat existing object");
//                        return (ARCHIVE_FAILED);
//                }
//
//                /*
//                 * NO_OVERWRITE_NEWER doesn't apply to directories.
//                 */
//                if ((a->flags & ARCHIVE_EXTRACT_NO_OVERWRITE_NEWER)
//                    &&  !S_ISDIR(a->st.st_mode)) {
//                        if (!older(&(a->st), a->entry)) {
//                                archive_entry_unset_size(a->entry);
//                                return (ARCHIVE_OK);
//                        }
//                }
//
//                /* If it's our archive, we're done. */
//                if (a->skip_file_set &&
//                    a->st.st_dev == (dev_t)a->skip_file_dev &&
//                    a->st.st_ino == (ino_t)a->skip_file_ino) {
//                        archive_set_error(&a->archive, 0,
//                            "Refusing to overwrite archive");
//                        return (ARCHIVE_FAILED);
//                }
//
//                if (!S_ISDIR(a->st.st_mode)) {
//                        /* A non-dir is in the way, unlink it. */
//                        if (unlink(a->name) != 0) {
//                                archive_set_error(&a->archive, errno,
//                                    "Can't unlink already-existing object");
//                                return (ARCHIVE_FAILED);
//                        }
//                        a->pst = NULL;
//                        /* Try again. */
//                        en = create_filesystem_object(a);
//                } else if (!S_ISDIR(a->mode)) {
//                        /* A dir is in the way of a non-dir, rmdir it. */
//                        if (rmdir(a->name) != 0) {
//                                archive_set_error(&a->archive, errno,
//                                    "Can't replace existing directory with non-directory");
//                                return (ARCHIVE_FAILED);
//                        }
//                        /* Try again. */
//                        en = create_filesystem_object(a);
//                } else {
//                        /*
//                         * There's a dir in the way of a dir.  Don't
//                         * waste time with rmdir()/mkdir(), just fix
//                         * up the permissions on the existing dir.
//                         * Note that we don't change perms on existing
//                         * dirs unless _EXTRACT_PERM is specified.
//                         */
//                        if ((a->mode != a->st.st_mode)
//                            && (a->todo & TODO_MODE_FORCE))
//                                a->deferred |= (a->todo & TODO_MODE);
//                        /* Ownership doesn't need deferred fixup. */
//                        en = 0; /* Forget the EEXIST. */
//                }
//        }

        if (en) {
                /* Everything failed; give up here. */
                archive_set_error(&a->archive, en, "Can't create '%s'",
                    a->name);
                return (ARCHIVE_FAILED);
        }

//        a->pst = NULL; /* Cached stat data no longer valid. */
        return (ret);
}

/*
 * Returns 0 if creation succeeds, or else returns errno value from
 * the failed system call.   Note:  This function should only ever perform
 * a single system call.
 */
static int
create_filesystem_object(struct archive_write_disk *a)
{
        /* Create the entry. */
        const char *linkname;
        mode_t final_mode, mode;
        int r;

        /* We identify hard/symlinks according to the link names. */
        /* Since link(2) and symlink(2) don't handle modes, we're done here. */
        linkname = archive_entry_hardlink(a->entry);
        if (linkname != NULL) {
#if !HAVE_LINK
                return (EPERM);
#else
                r = link(linkname, a->name) ? errno : 0;
                /*
                 * New cpio and pax formats allow hardlink entries
                 * to carry data, so we may have to open the file
                 * for hardlink entries.
                 *
                 * If the hardlink was successfully created and
                 * the archive doesn't have carry data for it,
                 * consider it to be non-authoritative for meta data.
                 * This is consistent with GNU tar and BSD pax.
                 * If the hardlink does carry data, let the last
                 * archive entry decide ownership.
                 */
                if (r == 0 && a->filesize <= 0) {
                        a->todo = 0;
                        a->deferred = 0;
                } else if (r == 0 && a->filesize > 0) {
                        a->fd = open(a->name,
                                     O_WRONLY | O_TRUNC | O_BINARY | O_CLOEXEC);
                        __archive_ensure_cloexec_flag(a->fd);
                        if (a->fd < 0)
                                r = errno;
                }
                return (r);
#endif
        }
        linkname = archive_entry_symlink(a->entry);
        if (linkname != NULL) {
#if 1//HAVE_SYMLINK
                return symlink(linkname, a->name) ? errno : 0;
#else
                return (EPERM);
#endif
        }

        /*
         * The remaining system calls all set permissions, so let's
         * try to take advantage of that to avoid an extra chmod()
         * call.  (Recall that umask is set to zero right now!)
         */

        /* Mode we want for the final restored object (w/o file type bits). */
        final_mode = a->mode & 07777;
        /*
         * The mode that will actually be restored in this step.  Note
         * that SUID, SGID, etc, require additional work to ensure
         * security, so we never restore them at this point.
         */
        mode = final_mode & 0777 & ~a->user_umask;

        switch (a->mode & AE_IFMT) {
        default:
                /* POSIX requires that we fall through here. */
                /* FALLTHROUGH */
        case AE_IFREG:
                a->fd = open(a->name,
                    O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, mode);     //O_BINARY |
                __archive_ensure_cloexec_flag(a->fd);
                r = (a->fd < 0);
                break;
        case AE_IFCHR:
#ifdef HAVE_MKNOD
                /* Note: we use AE_IFCHR for the case label, and
                 * S_IFCHR for the mknod() call.  This is correct.  */
                r = mknod(a->name, mode | S_IFCHR,
                    archive_entry_rdev(a->entry));
                break;
#else
                /* TODO: Find a better way to warn about our inability
                 * to restore a char device node. */
                return (EINVAL);
#endif /* HAVE_MKNOD */
        case AE_IFBLK:
#ifdef HAVE_MKNOD
                r = mknod(a->name, mode | S_IFBLK,
                    archive_entry_rdev(a->entry));
                break;
#else
                /* TODO: Find a better way to warn about our inability
                 * to restore a block device node. */
                return (EINVAL);
#endif /* HAVE_MKNOD */
        case AE_IFDIR:
                mode = (mode | MINIMUM_DIR_MODE) & MAXIMUM_DIR_MODE;
                r = mkdir(a->name, mode);
                if (r == 0) {
                        /* Defer setting dir times. */
                        a->deferred |= (a->todo & TODO_TIMES);
                        a->todo &= ~TODO_TIMES;
                        /* Never use an immediate chmod(). */
                        /* We can't avoid the chmod() entirely if EXTRACT_PERM
                         * because of SysV SGID inheritance. */
                        if ((mode != final_mode)
                            || (a->flags & ARCHIVE_EXTRACT_PERM))
                                a->deferred |= (a->todo & TODO_MODE);
                        a->todo &= ~TODO_MODE;
                }
                break;
        case AE_IFIFO:
#ifdef HAVE_MKFIFO
                r = mkfifo(a->name, mode);
                break;
#else
                /* TODO: Find a better way to warn about our inability
                 * to restore a fifo. */
                return (EINVAL);
#endif /* HAVE_MKFIFO */
        }

        /* All the system calls above set errno on failure. */
        if (r)
                return (errno);

        /* If we managed to set the final mode, we've avoided a chmod(). */
        if (mode == final_mode)
                a->todo &= ~TODO_MODE;
        return (0);
}

/*
 * Cleanup function for archive_extract.  Mostly, this involves processing
 * the fixup list, which is used to address a number of problems:
 *   * Dir permissions might prevent us from restoring a file in that
 *     dir, so we restore the dir with minimum 0700 permissions first,
 *     then correct the mode at the end.
 *   * Similarly, the act of restoring a file touches the directory
 *     and changes the timestamp on the dir, so we have to touch-up dir
 *     timestamps at the end as well.
 *   * Some file flags can interfere with the restore by, for example,
 *     preventing the creation of hardlinks to those files.
 *   * Mac OS extended metadata includes ACLs, so must be deferred on dirs.
 *
 * Note that tar/cpio do not require that archives be in a particular
 * order; there is no way to know when the last file has been restored
 * within a directory, so there's no way to optimize the memory usage
 * here by fixing up the directory any earlier than the
 * end-of-archive.
 *
 * XXX TODO: Directory ACLs should be restored here, for the same
 * reason we set directory perms here. XXX
 */
static int
_archive_write_disk_close(struct archive *_a)
{
//        struct archive_write_disk *a = (struct archive_write_disk *)_a;
//        struct fixup_entry *next, *p;
//        int ret;
//
////        archive_check_magic(&a->archive, ARCHIVE_WRITE_DISK_MAGIC,
////            ARCHIVE_STATE_HEADER | ARCHIVE_STATE_DATA,
////            "archive_write_disk_close");
//        ret = _archive_write_disk_finish_entry(&a->archive);
//
//        /* Sort dir list so directories are fixed up in depth-first order. */
//        p = sort_dir_list(a->fixup_list);
//
//        while (p != NULL) {
//                a->pst = NULL; /* Mark stat cache as out-of-date. */
//                if (p->fixup & TODO_TIMES) {
//                        set_times(a, -1, p->mode, p->name,
//                            p->atime, p->atime_nanos,
//                            p->birthtime, p->birthtime_nanos,
//                            p->mtime, p->mtime_nanos,
//                            p->ctime, p->ctime_nanos);
//                }
//                if (p->fixup & TODO_MODE_BASE)
//                        chmod(p->name, p->mode);
//                if (p->fixup & TODO_ACLS)
//                        archive_write_disk_set_acls(&a->archive,
//                                                    -1, p->name, &p->acl);
//                if (p->fixup & TODO_FFLAGS)
//                        set_fflags_platform(a, -1, p->name,
//                            p->mode, p->fflags_set, 0);
//                if (p->fixup & TODO_MAC_METADATA)
//                        set_mac_metadata(a, p->name, p->mac_metadata,
//                                         p->mac_metadata_size);
//                next = p->next;
//                archive_acl_clear(&p->acl);
//                free(p->mac_metadata);
//                free(p->name);
//                free(p);
//                p = next;
//        }
//        a->fixup_list = NULL;
//        return (ret);
  printf("%s:%d:%s: unfinished\n",__FILE__,__LINE__,__FUNCTION__);
  return 0;
}

static int
_archive_write_disk_free(struct archive *_a)
{
        struct archive_write_disk *a;
        int ret;
        if (_a == NULL)
                return (ARCHIVE_OK);
//        archive_check_magic(_a, ARCHIVE_WRITE_DISK_MAGIC,
//            ARCHIVE_STATE_ANY | ARCHIVE_STATE_FATAL, "archive_write_disk_free");
        a = (struct archive_write_disk *)_a;
        ret = _archive_write_disk_close(&a->archive);
//        archive_write_disk_set_group_lookup(&a->archive, NULL, NULL, NULL);
//        archive_write_disk_set_user_lookup(&a->archive, NULL, NULL, NULL);
        if (a->entry)
                archive_entry_free(a->entry);
        archive_string_free(&a->_name_data);
        archive_string_free(&a->archive.error_string);
        archive_string_free(&a->path_safe);
        a->archive.magic = 0;
        __archive_clean(&a->archive);
        free(a->decmpfs_header_p);
        free(a->resource_fork);
        free(a->compressed_buffer);
        free(a->uncompressed_buffer);
#ifdef HAVE_ZLIB_H
        if (a->stream_valid) {
                switch (deflateEnd(&a->stream)) {
                case Z_OK:
                        break;
                default:
                        archive_set_error(&a->archive, ARCHIVE_ERRNO_MISC,
                            "Failed to clean up compressor");
                        ret = ARCHIVE_FATAL;
                        break;
                }
        }
#endif
        free(a);
        return (ret);
}



static int
_archive_write_disk_finish_entry(struct archive *_a)
{
        struct archive_write_disk *a = (struct archive_write_disk *)_a;
        int ret = ARCHIVE_OK;

//        archive_check_magic(&a->archive, ARCHIVE_WRITE_DISK_MAGIC,
//            ARCHIVE_STATE_HEADER | ARCHIVE_STATE_DATA,
//            "archive_write_finish_entry");
//        if (a->archive.state & ARCHIVE_STATE_HEADER)
//                return (ARCHIVE_OK);
//        archive_clear_error(&a->archive);
//
//        /* Pad or truncate file to the right size. */
//        if (a->fd < 0) {
//                /* There's no file. */
//        } else if (a->filesize < 0) {
//                /* File size is unknown, so we can't set the size. */
//        } else if (a->fd_offset == a->filesize) {
//                /* Last write ended at exactly the filesize; we're done. */
//                /* Hopefully, this is the common case. */
//#if defined(__APPLE__) && defined(UF_COMPRESSED) && defined(HAVE_ZLIB_H)
//        } else if (a->todo & TODO_HFS_COMPRESSION) {
//                char null_d[1024];
//                ssize_t r;
//
//                if (a->file_remaining_bytes)
//                        memset(null_d, 0, sizeof(null_d));
//                while (a->file_remaining_bytes) {
//                        if (a->file_remaining_bytes > sizeof(null_d))
//                                r = hfs_write_data_block(
//                                    a, null_d, sizeof(null_d));
//                        else
//                                r = hfs_write_data_block(
//                                    a, null_d, a->file_remaining_bytes);
//                        if (r < 0)
//                                return ((int)r);
//                }
//#endif
//        } else {
//#if HAVE_FTRUNCATE
//                if (ftruncate(a->fd, a->filesize) == -1 &&
//                    a->filesize == 0) {
//                        archive_set_error(&a->archive, errno,
//                            "File size could not be restored");
//                        return (ARCHIVE_FAILED);
//                }
//#endif
//                /*
//                 * Not all platforms implement the XSI option to
//                 * extend files via ftruncate.  Stat() the file again
//                 * to see what happened.
//                 */
//                a->pst = NULL;
//                if ((ret = lazy_stat(a)) != ARCHIVE_OK)
//                        return (ret);
//                /* We can use lseek()/write() to extend the file if
//                 * ftruncate didn't work or isn't available. */
//                if (a->st.st_size < a->filesize) {
//                        const char nul = '\0';
//                        if (lseek(a->fd, a->filesize - 1, SEEK_SET) < 0) {
//                                archive_set_error(&a->archive, errno,
//                                    "Seek failed");
//                                return (ARCHIVE_FATAL);
//                        }
//                        if (write(a->fd, &nul, 1) < 0) {
//                                archive_set_error(&a->archive, errno,
//                                    "Write to restore size failed");
//                                return (ARCHIVE_FATAL);
//                        }
//                        a->pst = NULL;
//                }
//        }
//
//        /* Restore metadata. */
//
//        /*
//         * This is specific to Mac OS X.
//         * If the current file is an AppleDouble file, it should be
//         * linked with the data fork file and remove it.
//         */
//        if (a->todo & TODO_APPLEDOUBLE) {
//                int r2 = fixup_appledouble(a, a->name);
//                if (r2 == ARCHIVE_EOF) {
//                        /* The current file has been successfully linked
//                         * with the data fork file and removed. So there
//                         * is nothing to do on the current file.  */
//                        goto finish_metadata;
//                }
//                if (r2 < ret) ret = r2;
//        }
//
//        /*
//         * Look up the "real" UID only if we're going to need it.
//         * TODO: the TODO_SGID condition can be dropped here, can't it?
//         */
//        if (a->todo & (TODO_OWNER | TODO_SUID | TODO_SGID)) {
//                a->uid = archive_write_disk_uid(&a->archive,
//                    archive_entry_uname(a->entry),
//                    archive_entry_uid(a->entry));
//        }
//        /* Look up the "real" GID only if we're going to need it. */
//        /* TODO: the TODO_SUID condition can be dropped here, can't it? */
//        if (a->todo & (TODO_OWNER | TODO_SGID | TODO_SUID)) {
//                a->gid = archive_write_disk_gid(&a->archive,
//                    archive_entry_gname(a->entry),
//                    archive_entry_gid(a->entry));
//         }
//
//        /*
//         * Restore ownership before set_mode tries to restore suid/sgid
//         * bits.  If we set the owner, we know what it is and can skip
//         * a stat() call to examine the ownership of the file on disk.
//         */
//        if (a->todo & TODO_OWNER) {
//                int r2 = set_ownership(a);
//                if (r2 < ret) ret = r2;
//        }
//
//        /*
//         * set_mode must precede ACLs on systems such as Solaris and
//         * FreeBSD where setting the mode implicitly clears extended ACLs
//         */
//        if (a->todo & TODO_MODE) {
//                int r2 = set_mode(a, a->mode);
//                if (r2 < ret) ret = r2;
//        }
//
//        /*
//         * Security-related extended attributes (such as
//         * security.capability on Linux) have to be restored last,
//         * since they're implicitly removed by other file changes.
//         */
//        if (a->todo & TODO_XATTR) {
//                int r2 = set_xattrs(a);
//                if (r2 < ret) ret = r2;
//        }
//
//        /*
//         * Some flags prevent file modification; they must be restored after
//         * file contents are written.
//         */
//        if (a->todo & TODO_FFLAGS) {
//                int r2 = set_fflags(a);
//                if (r2 < ret) ret = r2;
//        }
//
//        /*
//         * Time must follow most other metadata;
//         * otherwise atime will get changed.
//         */
//        if (a->todo & TODO_TIMES) {
//                int r2 = set_times_from_entry(a);
//                if (r2 < ret) ret = r2;
//        }
//
//        /*
//         * Mac extended metadata includes ACLs.
//         */
//        if (a->todo & TODO_MAC_METADATA) {
//                const void *metadata;
//                size_t metadata_size;
//                metadata = archive_entry_mac_metadata(a->entry, &metadata_size);
//                if (metadata != NULL && metadata_size > 0) {
//                        int r2 = set_mac_metadata(a, archive_entry_pathname(
//                            a->entry), metadata, metadata_size);
//                        if (r2 < ret) ret = r2;
//                }
//        }
//
//        /*
//         * ACLs must be restored after timestamps because there are
//         * ACLs that prevent attribute changes (including time).
//         */
//        if (a->todo & TODO_ACLS) {
//                int r2 = archive_write_disk_set_acls(&a->archive, a->fd,
//                                  archive_entry_pathname(a->entry),
//                                  archive_entry_acl(a->entry));
//                if (r2 < ret) ret = r2;
//        }
//
//finish_metadata:
//        /* If there's an fd, we can close it now. */
        if (a->fd >= 0) {
                close(a->fd);
                a->fd = -1;
        }
//        /* If there's an entry, we can release it now. */
//        if (a->entry) {
//                archive_entry_free(a->entry);
//                a->entry = NULL;
//        }
//        a->archive.state = ARCHIVE_STATE_HEADER;
        return (ret);
}

/*
 * Canonicalize the pathname.  In particular, this strips duplicate
 * '/' characters, '.' elements, and trailing '/'.  It also raises an
 * error for an empty path, a trailing '..' or (if _SECURE_NODOTDOT is
 * set) any '..' in the path.
 */
static int
cleanup_pathname(struct archive_write_disk *a)
{
        char *dest, *src;
        char separator = '\0';

        dest = src = a->name;
        if (*src == '\0') {
                archive_set_error(&a->archive, ARCHIVE_ERRNO_MISC,
                    "Invalid empty pathname");
                return (ARCHIVE_FAILED);
        }

#if defined(__CYGWIN__)
        cleanup_pathname_win(a);
#endif
        /* Skip leading '/'. */
        if (*src == '/')
                separator = *src++;

        /* Scan the pathname one element at a time. */
        for (;;) {
                /* src points to first char after '/' */
                if (src[0] == '\0') {
                        break;
                } else if (src[0] == '/') {
                        /* Found '//', ignore second one. */
                        src++;
                        continue;
                } else if (src[0] == '.') {
                        if (src[1] == '\0') {
                                /* Ignore trailing '.' */
                                break;
                        } else if (src[1] == '/') {
                                /* Skip './'. */
                                src += 2;
                                continue;
                        } else if (src[1] == '.') {
                                if (src[2] == '/' || src[2] == '\0') {
                                        /* Conditionally warn about '..' */
                                        if (a->flags & ARCHIVE_EXTRACT_SECURE_NODOTDOT) {
                                                archive_set_error(&a->archive,
                                                    ARCHIVE_ERRNO_MISC,
                                                    "Path contains '..'");
                                                return (ARCHIVE_FAILED);
                                        }
                                }
                                /*
                                 * Note: Under no circumstances do we
                                 * remove '..' elements.  In
                                 * particular, restoring
                                 * '/foo/../bar/' should create the
                                 * 'foo' dir as a side-effect.
                                 */
                        }
                }

                /* Copy current element, including leading '/'. */
                if (separator)
                        *dest++ = '/';
                while (*src != '\0' && *src != '/') {
                        *dest++ = *src++;
                }

                if (*src == '\0')
                        break;

                /* Skip '/' separator. */
                separator = *src++;
        }
        /*
         * We've just copied zero or more path elements, not including the
         * final '/'.
         */
        if (dest == a->name) {
                /*
                 * Nothing got copied.  The path must have been something
                 * like '.' or '/' or './' or '/././././/./'.
                 */
                if (separator)
                        *dest++ = '/';
                else
                        *dest++ = '.';
        }
        /* Terminate the result. */
        *dest = '\0';
        return (ARCHIVE_OK);
}

/*
 * Create the parent directory of the specified path, assuming path
 * is already in mutable storage.
 */
static int
create_parent_dir(struct archive_write_disk *a, char *path)
{
        char *slash;
        int r;

        /* Remove tail element to obtain parent name. */
        slash = strrchr(path, '/');
        if (slash == NULL)
                return (ARCHIVE_OK);
        *slash = '\0';
        r = create_dir(a, path);
        *slash = '/';
        return (r);
}

/*
 * Create the specified dir, recursing to create parents as necessary.
 *
 * Returns ARCHIVE_OK if the path exists when we're done here.
 * Otherwise, returns ARCHIVE_FAILED.
 * Assumes path is in mutable storage; path is unchanged on exit.
 */
static int
create_dir(struct archive_write_disk *a, char *path)
{
        struct stat st;
        struct fixup_entry *le;
        char *slash, *base;
        mode_t mode_final, mode;
        int r;

        /* Check for special names and just skip them. */
        slash = strrchr(path, '/');
        if (slash == NULL)
                base = path;
        else
                base = slash + 1;

        if (base[0] == '\0' ||
            (base[0] == '.' && base[1] == '\0') ||
            (base[0] == '.' && base[1] == '.' && base[2] == '\0')) {
                /* Don't bother trying to create null path, '.', or '..'. */
                if (slash != NULL) {
                        *slash = '\0';
                        r = create_dir(a, path);
                        *slash = '/';
                        return (r);
                }
                return (ARCHIVE_OK);
        }

        /*
         * Yes, this should be stat() and not lstat().  Using lstat()
         * here loses the ability to extract through symlinks.  Also note
         * that this should not use the a->st cache.
         */
        if (stat(path, &st) == 0) {
                if (S_ISDIR(st.st_mode))
                        return (ARCHIVE_OK);
                if ((a->flags & ARCHIVE_EXTRACT_NO_OVERWRITE)) {
                        archive_set_error(&a->archive, EEXIST,
                            "Can't create directory '%s'", path);
                        return (ARCHIVE_FAILED);
                }
                if (unlink(path) != 0) {
                        archive_set_error(&a->archive, errno,
                            "Can't create directory '%s': "
                            "Conflicting file cannot be removed",
                            path);
                        return (ARCHIVE_FAILED);
                }
        } else if (errno != ENOENT && errno != ENOTDIR) {
                /* Stat failed? */
                archive_set_error(&a->archive, errno, "Can't test directory '%s'", path);
                return (ARCHIVE_FAILED);
        } else if (slash != NULL) {
                *slash = '\0';
                r = create_dir(a, path);
                *slash = '/';
                if (r != ARCHIVE_OK)
                        return (r);
        }

        /*
         * Mode we want for the final restored directory.  Per POSIX,
         * implicitly-created dirs must be created obeying the umask.
         * There's no mention whether this is different for privileged
         * restores (which the rest of this code handles by pretending
         * umask=0).  I've chosen here to always obey the user's umask for
         * implicit dirs, even if _EXTRACT_PERM was specified.
         */
        mode_final = DEFAULT_DIR_MODE & ~a->user_umask;
        /* Mode we want on disk during the restore process. */
        mode = mode_final;
        mode |= MINIMUM_DIR_MODE;
        mode &= MAXIMUM_DIR_MODE;
        if (mkdir(path, mode) == 0) {
                if (mode != mode_final) {
//                        le = new_fixup(a, path);
//                        if (le == NULL)
                                return (ARCHIVE_FATAL);
//                        le->fixup |=TODO_MODE_BASE;
//                        le->mode = mode_final;
                }
                return (ARCHIVE_OK);
        }

        /*
         * Without the following check, a/b/../b/c/d fails at the
         * second visit to 'b', so 'd' can't be created.  Note that we
         * don't add it to the fixup list here, as it's already been
         * added.
         */
        if (stat(path, &st) == 0 && S_ISDIR(st.st_mode))
                return (ARCHIVE_OK);

        archive_set_error(&a->archive, errno, "Failed to create dir '%s'",
            path);
        return (ARCHIVE_FAILED);
}

#ifdef __cplusplus
}
#endif

