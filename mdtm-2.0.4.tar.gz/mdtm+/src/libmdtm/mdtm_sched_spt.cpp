/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

//#define _GNU_SOURCE

#include <sched.h>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <syslog.h>

#include "include/private/mdtm_debug.h"
#include "include/private/mdtm_tree_intern.h"
#include "mdtm_sched_spt.h"
#include "mdtm_schedaffinity.h"

int mdtm_sched_spt::mdtm_create_spt(void) {
  mdtm_duplicate_tree(mdtmtree, &spt, 0);
//  mdtm_connect_numas();
  return 0;
}

int mdtm_sched_spt::mdtm_cost(float dist, int factor) {
  return (int)(dist * factor);
}

void mdtm_sched_spt::mdtm_connect_numas(void) {
//  unsigned distance[2][2] = {{10, 20}, {20, 10}}; //TODO: create a function to get the distance matrix
  float *dist_matrix, dist;

  mdtm_node_t *newnode = 0;
  mdtm_node_t **numas = (mdtm_node_t **)malloc(sizeof(mdtm_node_t*)*16);
  int nnuma = 0, numaindex, i, j, k,n;

  if(!spt) mdtm_create_spt();

  n = mdtm_getnumadistance(&dist_matrix);
  mdtm_getnodesbytype(spt, "NUMANode", numas, &nnuma);
  assert(n==nnuma);
  for(int count=0; count < nnuma; count++) {
      numaindex = numas[count]->logical_index;
      for(i = 0, k = 0; i < nnuma; i++) {
          if(i == numaindex) continue;
          if((dist = dist_matrix[numaindex*nnuma + i]) > 0) {
              for(j = 0; j < nnuma; j++) {
                  if(numas[j]->logical_index == i)
                    break;
              }
              numas[count]->siblings[k] = numas[j];
              numas[count]->siblingscost[k] = mdtm_cost(dist, numa_dist_factor);        // numa cost
              k++;
          }
      }
      numas[count]->numSiblings = k;

      //TODO: double check it here
      if(numas[count]->parent)
        numas[count]->parentcost = (unsigned) -1;
  }

  // creating links between NUMA nodes
//   if(newnode->type && !strcmp(newnode->type, "NUMANode")) {
//       int dist, k = 0, numaindex = newnode->logical_index;
//       unsigned distance[2][2] = {{10, 20}, {20, 10}};
//       for(int i = 0; i < g_nNumas; i++) {
//           if(i == numaindex) continue;
//           if((dist = distance[numaindex][i]) > 0) {
//               mdtm_node_t *node = first_numa0;
//               for(int j = 0; j < g_nNumas; j++) {
//                   if(node->logical_index == i)
//                     break;
//                   node = node->next;
//               }
//               newnode->siblings[k] = node;
//               newnode->siblingscost[k++] = dist;        // numa cost
//           }
//       }
//       newnode->numSiblings = k;
//   }
  return;
}

void mdtm_sched_spt::mdtm_print_path(char * src, char*dst) {
  assert(mdtm_getnodebyname(spt, src));
  assert(mdtm_getnodebyname(spt, dst));
  mdtm_print_path((mdtm_node_t*)mdtm_getnodebyname(spt, src), (mdtm_node_t*)mdtm_getnodebyname(spt, dst));
}

void mdtm_sched_spt::mdtm_print_path(mdtm_node_t * src, mdtm_node_t*dst) {
  mdtm_node_t *path[64];        //TODO: Magic number
  char result[128];
  int depth = 0, max_depth = 0;;

  mdtm_resetcostnflag(spt);
  if(true == mdtm_get_path(src, dst, path, &depth, &max_depth)) {
      path[depth] = src;

      mdtm_debug("(");
      if(path[0]->name)
        mdtm_debug("%s", path[0]->name);
      else
        mdtm_debug("%s %d",path[0]->type, path[0]->logical_index);
      mdtm_debug(")");
      for(int i=1; i<max_depth + 1; i++){
          mdtm_debug("==>(");
          if(path[i]->name)
            mdtm_debug("%s", path[i]->name);
          else
            mdtm_debug("%s %d",path[i]->type, path[i]->logical_index);
          mdtm_debug(")");
      }
      mdtm_debug("\n");
  }

  return;
}

bool mdtm_sched_spt::mdtm_get_path(mdtm_node_t*src, mdtm_node_t*dst, mdtm_node_t** path, int* depth, int* maxdepth) {
  if(src == dst) {
      if(*depth > *maxdepth) *maxdepth = *depth;
      return true;
  }

  (*depth)++;
  src->setflag = 1;

  if(strcmp(src->type, "Core")){
      for(int i = 0; i < src->numChildren; i++) {
          if(src->children[i] && !src->children[i]->setflag && true == mdtm_get_path(src->children[i], dst, path, depth, maxdepth)) {
              path[*depth] = src->children[i];
              (*depth)--;
              return true;
          }
      }
  }

  if(src->type && !strcmp(src->type, "NUMANode")){
      for(int i = 0; i < src->numSiblings; i++) {
          if(src->siblings[i] && !src->siblings[i]->setflag && true == mdtm_get_path(src->siblings[i], dst, path, depth, maxdepth)) {
              path[*depth] = src->siblings[i];
              (*depth)--;
              return true;
          }
      }
      (*depth)--;
      return false;
  }

  if(src->parent && !src->parent->setflag &&true == mdtm_get_path(src->parent, dst, path, depth, maxdepth)) {
      path[*depth] = src->parent;
      (*depth)--;
      return true;
  }

  (*depth)--;
  return false;
}

/* \brief schedule the CPU core according the given numa index
 *
 */
int mdtm_sched_spt::mdtm_sched_cpu(int numa, pid_t pid){
  int count, index;
  mdtm_node_t* numa_node;
  unsigned *cpus;

  numa_node = mdtm_getnumanode(numa);
  count = mdtm_online_cpuset((mdtm_node_t*)numa_node, (unsigned **)&cpus);

  // look for the single cpu to bind
  int targetcpu = roundrobin((int*)cpus, count);
  affinity->SetAffinity(&targetcpu, 1, pid);
  affinity->ShowAffinity(pid);

  //update the cpu descriptor
  cpudesc[targetcpu].numboundthreads ++;

  free(cpus);

  //return cpu indexes
  return targetcpu;
}

/* \brief schedule the CPU core according the given numa index
 *
 */
int mdtm_sched_spt::mdtm_sched_cpu(int numa, pthread_t tid){
  int count, index;
  mdtm_node_t* numa_node;
  unsigned *cpus = 0;

  numa_node = mdtm_getnumanode(numa);
  count = mdtm_online_cpuset((mdtm_node_t*)numa_node, (unsigned **)&cpus);

  // look for the single cpu to bind
  int targetcpu = roundrobin((int*)cpus, count);
  affinity->SetAffinity(&targetcpu, 1, tid);
  affinity->ShowAffinity(tid);

  //update the cpu descriptor
  cpudesc[targetcpu].numboundthreads ++;

  free(cpus);

  //return cpu indexes
  return targetcpu;
}

int mdtm_sched_spt::roundrobin(int *cpus, int count) {
  int cpu;
  assert(cpus);
  unsigned minval = (unsigned)(-1), mincpu = 0;
  for(int i = 0; i < count; i++) {
      cpu = cpus[i];
      if (cpudesc[cpu].numboundthreads < minval) {
          minval = cpudesc[cpu].numboundthreads;
          mincpu = cpu;
      }
  }
  return mincpu;
}

int mdtm_sched_spt::mdtm_sched_cpu(char* srcdevice, pid_t pid){
  mdtm_node_t *srcnode, *dstnode;
  cpu_cost_t *cpusrc, *cpudst;
  int ncpusrc, ncpudst;
  int ncpu;
  unsigned min = cost_max, index = 0, sum = 0, count;
  int *cpuindex = 0;
  int cpus[128];        //TODO: magic number

  if(!srcdevice ||
      !mdtm_getnodebyname(spt, srcdevice))
    return -1;

  ncpu = affinity->ncpu;
  cpusrc = (cpu_cost_t*)malloc(sizeof(cpu_cost_t) * ncpu);
  cpuindex = (int*)malloc(sizeof(int)*ncpu);

  mdtm_debug("Device\tCPU:Cost\n");
  ncpusrc = mdtm_calc_costs(srcdevice, cpusrc);
  mdtm_debug("%s\t", srcdevice);
  for(int i=0; i<ncpusrc; i++) {
      mdtm_debug("%d:%u ",cpusrc[i].index, cpusrc[i].cost);
  }
  mdtm_debug("\n");

  //search for the minimum of cpusrc
  for(int i = 0; i < ncpusrc; i++) {
      sum = cpusrc[i].cost;
      if( sum <= min) {
          if(sum < min) count = 0, min = sum;
          cpuindex[count++] = i;
      }
  }

//  affinity->ShowAffinity((pid_t)0);

  mdtm_debug("CPUs\tCosts\tPath\n");
  for(int i = 0; i < count; i++) {
      mdtm_debug("%d\t %d\t",cpusrc[cpuindex[i]].index,cpusrc[cpuindex[i]].cost);
      mdtm_print_path(cpusrc[cpuindex[i]].ptr, (mdtm_node_t*)mdtm_getnodebyname(spt, srcdevice));
  }


  for(int i = 0; i < count; i++) {
      cpus[i] = cpusrc[cpuindex[i]].index;
  }


  // look for the single cpu to bind
  int targetcpu = roundrobin(cpus, count);

  // interrupt affinity
  // irqaffinity

  // application thread affinity
//  affinity->SetAffinity(cpus, count, pid);
  affinity->SetAffinity(&targetcpu, 1, pid);
  affinity->ShowAffinity(pid);

  //update the cpu descriptor
  cpudesc[targetcpu].numboundthreads ++;

  //mdtm_print_path((mdtm_node_t*)mdtm_getnodebyname(spt, "eth1"), (mdtm_node_t*)mdtm_getnodebyname(spt, "sda"));
  free(cpusrc[0].buf);
  free(cpusrc);
  free(cpuindex);

  //return cpu indexes
  return targetcpu;
}


int mdtm_sched_spt::mdtm_sched_cpu(char* srcdevice, pthread_t tid){
  mdtm_node_t *srcnode, *dstnode;
  cpu_cost_t *cpusrc, *cpudst;
  int ncpusrc, ncpudst, ncpu;
  unsigned min = cost_max, count = 0;
  unsigned index = 0, sum = 0;
  int *cpuindex = 0;
  int cpus[128];

  if(!srcdevice ||
      !mdtm_getnodebyname(spt, srcdevice))
    return -1;

  ncpu = affinity->ncpu;
  cpusrc = (cpu_cost_t*)malloc(sizeof(cpu_cost_t) * ncpu);
  cpuindex = (int*)malloc(sizeof(int)*ncpu);

  ncpusrc = mdtm_calc_costs(srcdevice, cpusrc);

  //search for the minimum of cpusrc and count their numbers
  for(int i = 0; i < ncpusrc; i++) {
      sum = cpusrc[i].cost;
      if( sum <= min) {
          if(sum < min) count = 0, min = sum;
          cpuindex[count++] = i;
      }
  }

  for(int i = 0; i < count; i++) {
      cpus[i] = cpusrc[cpuindex[i]].index;
  }

  // look for the single cpu to bind
  int targetcpu = roundrobin(cpus, count);

//  affinity->SetAffinity(cpus, count, tid);
  affinity->SetAffinity(&targetcpu, 1, tid);
  affinity->ShowAffinity(tid);

  //update the cpu descriptor
  cpudesc[targetcpu].numboundthreads ++;

  free(cpusrc[0].buf);
  free(cpusrc);
  free(cpuindex);

  //return cpu indexes
  return targetcpu;
}


int mdtm_sched_spt::mdtm_sched_cpu_r(char* srcdevice, pthread_t tid){
  int targetcpu;

  if(!srcdevice ||
      !mdtm_getnodebyname(spt, srcdevice))
    return -1;

  // fill the cmdline_
  cmdline_->cmd = SCHED;
  strcpy(cmdline_->argv.device, srcdevice);

  //send ipc msg to daemon
  MdtmIpcMessage::send();

  // parse the result returned from daemon
  if(result_->returnval == 0) {
      targetcpu = result_->data.cpu;
      affinity->SetAffinity(&targetcpu, 1, tid);
      affinity->ShowAffinity(tid);
  }
  else
    targetcpu = -1;

  //return cpu indexes
  return targetcpu;
}

int mdtm_sched_spt::mdtm_sched_cpu_l(char* srcdevice){
  mdtm_node_t *srcnode, *dstnode;
  cpu_cost_t *cpusrc, *cpudst;
  int ncpusrc, ncpudst;
  int ncpu;
  unsigned min = cost_max, index = 0, sum = 0, count;
  int *cpuindex = 0;
  int cpus[128];

  if(!srcdevice ||
      !mdtm_getnodebyname(spt, srcdevice))
    return -1;

  ncpu = affinity->ncpu;
  cpusrc = (cpu_cost_t*)calloc(ncpu, sizeof(cpu_cost_t));
  cpuindex = (int*)calloc(ncpu, sizeof(int));
  ncpusrc = mdtm_calc_costs(srcdevice, cpusrc);

  //search for the minimum of cpusrc
  for(int i = 0; i < ncpusrc; i++) {
      sum = cpusrc[i].cost;
      if( sum <= min) {
          if(sum < min) count = 0, min = sum;
          cpuindex[count++] = i;
      }
  }

  for(int i = 0; i < count; i++) {
      cpus[i] = cpusrc[cpuindex[i]].index;
  }

  // look for the single cpu to bind
  int targetcpu = roundrobin(cpus, count);

  //update the cpu descriptor
  cpudesc[targetcpu].numboundthreads ++;

  free(cpusrc[0].buf);
  free(cpusrc);
  free(cpuindex);

  //return cpu indexes
  return targetcpu;
}

/*
 * place the given thread to the target cpu
 */
int mdtm_sched_spt::mdtm_place_cpu(int targetcpu, pthread_t tid)
{
    affinity->SetAffinity(&targetcpu, 1, tid);
    affinity->ShowAffinity(tid);
    return targetcpu;
}

int mdtm_sched_spt::mdtm_place_cpu(int targetcpu, pid_t pid)
{
    affinity->SetAffinity(&targetcpu, 1, pid);
    affinity->ShowAffinity(pid);
    return targetcpu;
}

int mdtm_sched_spt::mdtm_sched_cpu_on_numa(char* srcdevice, pthread_t tid, int numaid){
  unsigned count;
  mdtm_node_t **nodes;
  int nnode = 0;
  unsigned* ids = 0;
  int nids = 0;
  int targetcpu = 0;    // by default, set target cpu to 0

  if(!srcdevice)
    return -1;

  if(!spt) mdtm_create_spt();

  nodes = (mdtm_node_t **)malloc(sizeof(mdtm_node_t*) * max_numa_nodes);
  if(nodes == 0)
    return -1;

  mdtm_getnodesbytype(spt, "NUMANode", nodes, &nnode);
  if(nnode > 0) {
      for(count=0; count < nnode; count++) {
          if(numaid == nodes[count]->logical_index) break;
      }
      if(count == nnode) {
          if(nodes) free(nodes);
          return -1;
      }
      nids = mdtm_online_cpuset((const mdtm_node_t*) nodes[count], &ids);
  }
  else {
      mdtm_getnodesbytype(spt, "Socket", nodes, &nnode);
      if(nnode > 0)
        nids = mdtm_online_cpuset((const mdtm_node_t*) nodes[0], &ids);
      else {
          mdtm_getnodesbytype(spt, "Package", nodes, &nnode);
          if(nnode > 0)
            nids = mdtm_online_cpuset((const mdtm_node_t*) nodes[0], &ids);
      }
  }

  // look for the single cpu to bind
  if(nids > 0)
    targetcpu = roundrobin((int*)ids, nids);

  if(nodes) free(nodes);
  if(ids) free(ids);

//  mdtm_debug("DEBUG@%s:%d:\ndevice\tnuma\tFrom configure file\n%s\t%d\n",__FILE__,__LINE__, srcdevice, numaid);
  affinity->SetAffinity(&targetcpu, 1, tid);
  affinity->ShowAffinity(tid);

  //update the cpu descriptor
  cpudesc[targetcpu].numboundthreads ++;

  //return cpu indexes
  return targetcpu;
}

int mdtm_sched_spt::mdtm_sched_cpu_on_numa(char* srcdevice, pid_t pid, int numaid){
#if 0
  mdtm_node_t *srcnode, *dstnode;
  cpu_cost_t *cpusrc, *cpudst;
  int ncpusrc, ncpudst;
  int ncpu;
  unsigned min = cost_max, index = 0, sum = 0, count;
  int *cpuindex = 0;
  int cpus[128];
  mdtm_node_t **nnode = (mdtm_node_t **)malloc(sizeof(mdtm_node_t*)*16);
  int nnuma = 0;
  unsigned** ids;
  int targetcpu;

  if(!srcdevice)
    return -1;

//  if(!spt) mdtm_create_spt();
//
//  mdtm_getnodesbytype(spt, "NUMANode", numas, &nnuma);
//  for(count=0; count < nnuma; count++) {
//      if(numaid == numas[count]->logical_index) break;
//  }
//  if(count == nnuma) return -1;
//
//  mdtm_online_cpuset((const mdtm_node_t*) numas[count], ids);
//  targetcpu = *ids[0];
//
//  affinity->SetAffinity(&targetcpu, 1, tid);
//  affinity->ShowAffinity(tid);
//
//  mdtm_debug("DEBUG@%s:%d: sched_cpu %d of numa %d\n",__FILE__,__LINE__, targetcpu, numaid);

//  free(numas);
//  free(*ids);

  //return cpu indexes
  return targetcpu;
#endif
  return 0;
}

int mdtm_sched_spt::mdtm_sched_cpu(char* srcdevice, char*dstdevice){
  mdtm_node_t *srcnode, *dstnode;
  cpu_cost_t *cpusrc, *cpudst;
  int ncpusrc, ncpudst;
  int ncpu;
  unsigned min = cost_max, index = 0, sum = 0, count;
  int *cpuindex = 0;

  if(!srcdevice || !dstdevice ||
      !mdtm_getnodebyname(spt, srcdevice) ||
      !mdtm_getnodebyname(spt, dstdevice))
    return -1;

  ncpu = affinity->ncpu;
  cpusrc = (cpu_cost_t*)malloc(sizeof(cpu_cost_t) * 2 * ncpu);
  cpudst = cpusrc + ncpu;
  cpuindex = (int*)malloc(sizeof(int)*ncpu);

  mdtm_debug("Device\tCPU:Cost\n");
  ncpusrc = mdtm_calc_costs(srcdevice, cpusrc);
  mdtm_debug("%s\t", srcdevice);
  for(int i=0; i<ncpusrc; i++) {
      mdtm_debug("%d:%u ",cpusrc[i].index, cpusrc[i].cost);
  }
  mdtm_debug("\n");
  ncpudst = mdtm_calc_costs(dstdevice, cpudst);
  mdtm_debug("%s\t", dstdevice);
  for(int i=0; i<ncpudst; i++) {
      mdtm_debug("%d:%u ",cpudst[i].index, cpudst[i].cost);
  }
  mdtm_debug("\n\n");

  //search for the minimum of cpusrc + cpudst
  for(int i = 0; i < ncpusrc; i++) {
      sum = cpusrc[i].cost + cpudst[i].cost;
      cpusrc[i].cost = sum;
      if( sum <= min) {
          if(sum < min) count = 0, min = sum;
          cpuindex[count++] = i;
      }
  }

  mdtm_debug("CPUs\tCosts\tPath\n");
  for(int i = 0; i < count; i++) {
      mdtm_debug("%d\t %d\t",cpusrc[cpuindex[i]].index,cpusrc[cpuindex[i]].cost);
//      mdtm_print_path((mdtm_node_t*)mdtm_getnodebyname(spt, "eth1"), (mdtm_node_t*)mdtm_getnodebyname(spt, "sda"));
      mdtm_print_path(cpusrc[cpuindex[i]].ptr, (mdtm_node_t*)mdtm_getnodebyname(spt, srcdevice));
      mdtm_debug("\t\t");
      mdtm_print_path(cpusrc[cpuindex[i]].ptr, (mdtm_node_t*)mdtm_getnodebyname(spt, dstdevice));
  }

  //mdtm_print_path((mdtm_node_t*)mdtm_getnodebyname(spt, "eth1"), (mdtm_node_t*)mdtm_getnodebyname(spt, "sda"));
  free(cpusrc[0].buf);
  free(cpusrc);
  free(cpudst[0].buf);
  free(cpudst);
  free(cpuindex);

  //return cpu indexes
  return index;
}

int mdtm_sched_spt::mdtm_calc_costs(const char *device, cpu_cost_t *cpucosts) {
  int i, ncpus = 0;
  mdtm_node_t** cpus = (mdtm_node_t**)malloc(sizeof(mdtm_node_t*) * affinity->ncpu);
  mdtm_getnodesbytype(spt, "Core", cpus, &ncpus);

  for(i = 0; i < ncpus; i++) {
      mdtm_resetcostnflag(spt);
      cpucosts[i].index = cpus[i]->logical_index;
      cpucosts[i].ptr = cpus[i];
      cpucosts[i].cost = mdtm_dijkstra(cpus[i], device);
      cpucosts[i].buf = cpus;
  }
  return i;
}


unsigned mdtm_sched_spt::mdtm_dijkstra(mdtm_node_t *cpu, const char* device) {
  unsigned cost = (unsigned) -1;
  mdtm_node_t *minnode;
  cpu->cost = 0;
  while(1) {
      cost = mdtm_getnodewithmincost(&minnode);
      if(cost >= cost_max) break;
//      mdtm_debug("min cost so far, minnode=%s, index=%d cost=%d\n",minnode->type, minnode->logical_index, cost);
      minnode->setflag = 1;
      mdtm_updateneighborcosts(minnode);
  }
  if((minnode = (mdtm_node_t*)mdtm_getnodebyname(spt, device)) == 0)
      return (-1);
//  mdtm_debug("cpu %d: cost of device %s @ %p is %u\n", cpu->logical_index, device, minnode, minnode->cost);
  return minnode->cost;
}

unsigned mdtm_sched_spt::mdtm_getnodewithmincost(mdtm_node_t **node) {
  unsigned min_cost = cost_max;
  mdtm_node_t *min_node = 0;

  mdtm_getmincost(spt, &min_node, &min_cost);
  *node = min_node;

  return min_cost;
}

void mdtm_sched_spt::mdtm_getmincost(const mdtm_node_t* tree, mdtm_node_t ** minnode, unsigned *mincost) {
  const mdtm_node_t *node =  tree;

  if(!node->setflag && (node->cost < *mincost)) {
      *minnode = (mdtm_node_t*)node;
      *mincost = node->cost;
  }
  if(node->type && !strcmp(node->type, "Core"))
    return;

//  if(node->type && !strcmp(node->type, "NUMANode"))
//    mdtm_debug("NUMA idx=%d@%p, cost=%u\n",node->logical_index, node, node->cost);

  for(int i = 0; i < node->numChildren; i++) {
      mdtm_getmincost(node->children[i], minnode, mincost);
  }
  return;
}

void mdtm_sched_spt::mdtm_resetcostnflag(mdtm_node_t* tree) {
  mdtm_node_t *node =  tree;

  node->cost = (unsigned)-1;
  node->setflag = 0;
  if(node->type && !strcmp(node->type, "Core"))
    return;

  for(int i = 0; i < node->numChildren; i++) {
      mdtm_resetcostnflag(node->children[i]);
  }

  return;
}

void mdtm_sched_spt::mdtm_updateneighborcosts(mdtm_node_t *node) {
  if(node->parentcost < cost_max && node->parent && !node->parent->setflag)
    node->parent->cost = node->cost + node->parentcost;
  if(node->type && strcmp(node->type,"Core")) {
  for(int i = 0; i < node->numChildren; i++)
    if((node->childrencost[i] < cost_max) && !(node->children[i]->setflag))
      node->children[i]->cost = node->cost + node->childrencost[i];
  }
  for(int i = 0; i < node->numSiblings; i++) {
    if((node->siblingscost[i] < cost_max) && !(node->siblings[i]->setflag)) {
      node->siblings[i]->cost = node->cost + node->siblingscost[i];
//      mdtm_debug("%s: %s %d sib_id %d@%p sib_cost=%u updated cost=%u\n",__FUNCTION__,node->type, node->logical_index,node->siblings[i]->logical_index, node->siblings[i], node->siblingscost[i], node->siblings[i]->cost);
    }
  }
  return;
}

int
mdtm_sched_spt::parseit(void* ibuf, int isize, void* obuf, int osize) {
  int used, cpu;

  syslog(LOG_NOTICE, "cmd=%d", cmdline_->cmd);

  memcpy(msg_buf_.bytestream, ibuf, isize);
  result_ = reinterpret_cast<struct result_s*>(obuf);

  switch(cmdline_->cmd) {
  case SCHED:
    if((cpu = mdtm_sched_cpu_l(cmdline_->argv.device)) < 0)
      result_->returnval = -1;
    else {
      result_->returnval = 0;
      result_->data.cpu = cpu;
    }
    used = sizeof(struct result_s);
    break;
  }
  return used;
}

