/*******************************************************************************
 * Copyright (c) 2015 Fermilab Network Research Group.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU General Public License
 * which accompanies this distribution, and is available at
 * Free Software Foundation.
 *
 * Contacts:
 *     Wenji Wu, wenji@fnal.gov
 *     Liang Zhang, liangz@fnal.gov
 *******************************************************************************/

#ifndef SRC_LIBMDTM_MDTM_MEM_H_
#define SRC_LIBMDTM_MDTM_MEM_H_

#include <string>
#include <linux/types.h>
#include "mdtm_ipc.h"

class mdtm_mem : public MdtmIpcMessage {
public:
  const std::string     class_name_;

public:
  mdtm_mem();
  mdtm_mem(MdtmIpc* ipc);
  ~mdtm_mem();
  int   getoptnode(pid_t pid);
  int   parseit(void* ibuf, int isize, void* obuf, int osize);
  void  set_lat_fn(int (*lat_fn)(int*));

//  void* shm_alloc_tonode(int node);
//  void* mem_alloc_tonode(int node);

private:
  enum Command{
    OPTNUMA    = 1
  };

protected:
  struct cmd_line_s {
    Command        cmd;
    union {
      struct{
        char  cpus_buf[1024];
        char  mems_buf[1024];
      }getsetmasks;
      pid_t     pid;
    } argv;
  } * cmdline_;

  struct result_s {
    int        returnval;
    char       errcode[64];
    union {
      struct{
        char  cpus_buf[1024];
        char  mems_buf[1024];
      }getsetmasks;
      pid_t     pid;
      int       numanode;
    } argv;
  } * result_;

//  struct libperf_data *perfdata_[64];
  int numanodes_;
  int *lats_;
  int (*lat_func_)(int*);
};



#endif /* SRC_LIBMDTM_MDTM_MEM_H_ */
