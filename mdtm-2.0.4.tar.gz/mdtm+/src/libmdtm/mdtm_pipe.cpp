/*
 * mdtm_pipe.cpp
 *
 *  Created on: May 24, 2016
 *      Author: liangz
 */

#include <config.h>
#include <iostream>
#include <assert.h>
#include <iterator>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <numaif.h>
#include <numa.h>
#include <linux/limits.h>
#include <malloc.h>
#include <cstdio>
#include <fstream>
#include <string>
#include <sstream>
#include <string>
#include <cstring>
#include <exception>
#include <stdexcept>
#include <queue>
#include <hwloc.h>
#include "include/mdtm/mdtm_tree.h"
#include "include/mdtm.h"
#include "include/private/mdtm_tree_intern.h"
#include "include/private/mdtm_debug.h"
#include "include/private/mdtm_config.h"
#include "mdtm_pipe.h"

#ifdef __cplusplus
extern "C" {
#endif

//TODO: use fcntl.h after 3.12
#define F_SETPIPE_SZ 1031
#define F_GETPIPE_SZ 1032

//typedef struct {
//  long iden[2];
//  int pipefd[2];
//} mdtm_pipefd_t;

typedef struct {
  mdtm_pipefd_t *               pipes;
  std::queue<mdtm_pipefd_t *> *   pipe_queue;
  int                           total;
  int                           used;
  int                           incr;
  size_t                        pipesize;
  pthread_mutex_t               lock;
} mdtm_pipe_pool_t;

typedef struct {
  int                   numa_id;
  int                   group_count;
  mdtm_node_t *         numanode;
  int                   cpu;
  mdtm_pipe_pool_t *    pipepool;
  size_t                pipesize;
  bool                  result;
}pipe_thread_data_t;

static mdtm_pipe_pool_t *               g_mdtm_pipe_pools = 0;
static int                              g_mdtm_pipe_pool_num = 0;
static int                              g_mdtm_pipe_total_num = 0;
static int                              global_group_count = 0;

static
void*
mdtm_thread_alloc_pipe ( void *ptr )
{
  pipe_thread_data_t *data = (pipe_thread_data_t *)ptr;
  int i, rc;
  cpu_set_t cpuset;
  int cpuId = data->cpu;
  pthread_t threadid;

  //bind the current thread to the core
  CPU_ZERO(&cpuset);
  CPU_SET(cpuId, &cpuset);
  threadid = pthread_self();
  if ( pthread_setaffinity_np(threadid, sizeof(cpu_set_t), &cpuset) == -1 ) {
      switch ( errno ) {
      case EPERM: mdtm_debug ( "Error: Insufficient permission.\n" ); break;
      case EFAULT: mdtm_debug ( "Error: Invalid memory address.\n" ); break;
      case ESRCH: mdtm_debug ( "Error: Invalid process ID\n" ); break;
      case EINVAL: mdtm_debug ( "Error: Invalid arguments\n" ); break;
      }
  }

  rc = pthread_getaffinity_np(threadid, sizeof(cpu_set_t), &cpuset);
  assert(rc == 0);

//  for (i = 0; i < CPU_SETSIZE; i++)
//    if (CPU_ISSET(i, &cpuset))
//      mdtm_debug("Thread %u: target to CPU %d, bind to    CPU %d\n", threadid, cpuId, i);

  // create pipes
  if(!data->pipepool->pipe_queue)
    data->pipepool->pipe_queue = new std::queue<mdtm_pipefd_t*>();

  for(i = 0; i < data->group_count; i++) {
#if 0
      if (pipe2(data->pipepool->pipes[i].pipefd, O_DIRECT) < 0 ||
          fcntl(data->pipepool->pipes[i].pipefd[1], F_SETPIPE_SZ, data->pipesize) < 0)
        break;
#else
      mdtm_pipefd_t* tmppipe = (mdtm_pipefd_t*)malloc(sizeof(mdtm_pipefd_t));
      if (pipe2(tmppipe->pipefd, O_DIRECT) < 0 ||
          fcntl(tmppipe->pipefd[1], F_SETPIPE_SZ, data->pipesize) < 0)
        break;
      data->pipepool->pipe_queue->push(tmppipe);
#endif
  }
//  std::cout << data->pipepool->pipe_queue->size() << std::endl;
  if(i < data->group_count) {
      mdtm_debug("libmdtm: Pipe creation failed: %s @%s:%s\n",strerror(errno), __FILE__,__FUNCTION__);
      return NULL;
  }

  //set buffer size
#ifdef GLIBC_NEW
  for (i = 0; i < data->group_count; i++) {
      fcntl(data->pipes[i].pipefd[0], F_SETPIPE_SZ, pipesize);
      fcntl(data->pipes[i].pipefd[1], F_SETPIPE_SZ, pipesize);
  }
#endif

  data->result = true;

  return NULL;
}


/* \brief Create a pipe pool on each NUMA node.
 *
 * group_count: the size of pipepool to be created on each NUMA node
 * pipesize:    the size of pipe buffer
 */
int
mdtm_pipe_init2(
    int group_count,
    size_t pipesize,
    int nNumas,
    void * nodes)
{
  int 					rc, i = 0;
  mdtm_node_t			**numa_nodes = ( mdtm_node_t**) nodes;
  pthread_t 			threadids[MDTM_DEFAULT_NUMAS], *p_threadids = threadids;         /* thread variables */
  pipe_thread_data_t 	data[MDTM_DEFAULT_NUMAS], *p_data = data;
  bool      			default_threadids_data = true;
  unsigned 				*cpus = 0;

  global_group_count = group_count;

  if(nNumas > MDTM_DEFAULT_NUMAS) {
	  if((p_threadids = (pthread_t*)calloc(nNumas, sizeof(pthread_t))) == 0 ||
			  (p_data = (pipe_thread_data_t*)calloc(nNumas, sizeof(pipe_thread_data_t))) == 0)
	  {
		  goto pipe_failed;
	  }
      default_threadids_data = false;
  }

  // create a pipe pool for each NUMA node
  g_mdtm_pipe_pools = (mdtm_pipe_pool_t*)calloc(nNumas, sizeof(mdtm_pipe_pool_t));
  if(g_mdtm_pipe_pools ==NULL)
    goto pipe_failed;
  g_mdtm_pipe_pool_num = nNumas;

  for(i = 0; i < nNumas; i++) {

      if(/*(g_mdtm_pipe_pools[i].pipes == NULL) ||*/
         (pthread_mutex_init(&g_mdtm_pipe_pools[i].lock, NULL) != 0) ||
         (mdtm_online_cpuset(numa_nodes[i], &cpus) <= 0))
        break;

      g_mdtm_pipe_pools[i].total = group_count;
      g_mdtm_pipe_pools[i].used = 0;
      g_mdtm_pipe_pools[i].incr = group_count/2;
      g_mdtm_pipe_pools[i].pipesize = pipesize;

      p_data[i].result = false;
      p_data[i].numa_id = i;
      p_data[i].pipepool =  &g_mdtm_pipe_pools[i];
      p_data[i].group_count = group_count;
      p_data[i].numanode = numa_nodes[i];
      p_data[i].cpu = cpus[0];
      p_data[i].pipesize = pipesize;

      g_mdtm_pipe_total_num += g_mdtm_pipe_pools[i].total;

      if(cpus) {
    	  free(cpus);
    	  cpus = 0;
      }
  }

  if(i <  nNumas)
    goto pipe_failed;

  //create pipes on each NUMA node
  for(i = 0; i < nNumas; i++) {
      rc = pthread_create(&p_threadids[i], NULL, mdtm_thread_alloc_pipe, (void *) &p_data[i]);
      if(rc != 0)
          break;
  }
  for(; i > 0 ; i--)
    pthread_join(p_threadids[i-1], NULL);

  // check the results of pipes creating
  for(i = 0; i < nNumas && p_data[i].result==true; i++);
  if(i < nNumas) {
      i = nNumas - 1;
      goto pipe_failed;
  }

  if(default_threadids_data == false) {
      if(p_threadids)	free(p_threadids);
      if(p_data)		free(p_data);
  }
  return 0;

pipe_failed:
  if(cpus)
    free(cpus);

  for(; i >= 0; i--) {
      if(g_mdtm_pipe_pools[i].pipes)
        free(g_mdtm_pipe_pools[i].pipes);

      pthread_mutex_destroy(&g_mdtm_pipe_pools[i].lock);

      g_mdtm_pipe_pools[i].total = 0;
      g_mdtm_pipe_pools[i].used = 0;
      g_mdtm_pipe_pools[i].incr = 0;
      g_mdtm_pipe_pools[i].pipesize = 0;
  }

  if(g_mdtm_pipe_pools) {
    free(g_mdtm_pipe_pools);
    g_mdtm_pipe_pools = NULL;
  }

  if(default_threadids_data == false) {
	  if(p_threadids) free(p_threadids);
      if(p_data) free(p_data);
  }

  g_mdtm_pipe_total_num = 0;
  g_mdtm_pipe_pool_num = 0;

  return -1;
}

int
mdtm_pipe_destroy()
{
  int i, j;

  if(g_mdtm_pipe_pools) {
      for(i = 0; i < mdtm_numa_nodes(); i++) {
          pthread_mutex_lock(&g_mdtm_pipe_pools[i].lock);
          for(j = 0; j < g_mdtm_pipe_pools[i].total; j++) {
              close(g_mdtm_pipe_pools[i].pipes[j].pipefd[0]);
              close(g_mdtm_pipe_pools[i].pipes[j].pipefd[1]);
          }
          free(g_mdtm_pipe_pools[i].pipes);
          pthread_mutex_unlock(&g_mdtm_pipe_pools[i].lock);
          pthread_mutex_destroy(&g_mdtm_pipe_pools[i].lock);
      }
      free(g_mdtm_pipe_pools);
      g_mdtm_pipe_pools = NULL;
  }
  return 0;
}

void *
mdtm_pipe_get2(int numa, unsigned int size, void **arg)
{
#if 0
  mdtm_pipefd_t** pipes = (mdtm_pipefd_t**)arg;
  int available = 0, allocated = 0;

  assert(g_mdtm_pipe_pools);

  //TODO: add mutex

  *pipes = g_mdtm_pipe_pools[numa].pipes + g_mdtm_pipe_pools[numa].used;
  available = g_mdtm_pipe_pools[numa].total - g_mdtm_pipe_pools[numa].used;
  allocated = (ask < available)? ask : available;
  g_mdtm_pipe_pools[numa].used += allocated;
  return allocated;
#else
  mdtm_pipefd_t** pipe = (mdtm_pipefd_t**)arg;
  mdtm_pipefd_t * pipefd = 0;

  pthread_mutex_lock(&g_mdtm_pipe_pools[numa].lock);
  if(g_mdtm_pipe_pools[numa].pipe_queue->size() > 0) {
      pipefd = g_mdtm_pipe_pools[numa].pipe_queue->front();
      g_mdtm_pipe_pools[numa].pipe_queue->pop();
  }
  else {
      int                       rc;
      pthread_t                 thread_id;
      pipe_thread_data_t        thread_data;

      thread_data.result = false;
      thread_data.numa_id = numa;
      thread_data.pipepool =  &g_mdtm_pipe_pools[numa];
      thread_data.group_count = g_mdtm_pipe_pools[numa].incr;
      thread_data.numanode = 0; //unused
      thread_data.cpu = 0;      //unused
      thread_data.pipesize = g_mdtm_pipe_pools[numa].pipesize;
      rc = pthread_create(&thread_id, NULL, mdtm_thread_alloc_pipe, (void *) &thread_data);
      if(rc == 0) {
          pthread_join(thread_id, NULL);
          if(thread_data.result==true) {
        	  g_mdtm_pipe_pools[numa].total += g_mdtm_pipe_pools[numa].incr;
        	  g_mdtm_pipe_total_num += g_mdtm_pipe_pools[numa].incr;
              pipefd = g_mdtm_pipe_pools[numa].pipe_queue->front();
              g_mdtm_pipe_pools[numa].pipe_queue->pop();
          }
      }
  }
  pthread_mutex_unlock(&g_mdtm_pipe_pools[numa].lock);

  *pipe = pipefd;
  return pipefd;
#endif
}

int
mdtm_pipe_put2(int numa, void * pipe)
{
  pthread_mutex_lock(&g_mdtm_pipe_pools[numa].lock);
  g_mdtm_pipe_pools[numa].pipe_queue->push((mdtm_pipefd_t*)pipe);
  pthread_mutex_unlock(&g_mdtm_pipe_pools[numa].lock);

  return 0;
}

int
mdtm_pipe_allocated2(int numa)
{
	int total = 0, i;

	if(numa < 0) {
		for (i = 0 ; i < g_mdtm_pipe_pool_num; i++) {
			pthread_mutex_lock(&g_mdtm_pipe_pools[i].lock);
			total += g_mdtm_pipe_pools[i].total;
			pthread_mutex_unlock(&g_mdtm_pipe_pools[i].lock);
		}
	}
	else if(numa > g_mdtm_pipe_pool_num - 1)
		total = -1;
	else {
		pthread_mutex_lock(&g_mdtm_pipe_pools[i].lock);
		total =  g_mdtm_pipe_pools[numa].total;
		pthread_mutex_unlock(&g_mdtm_pipe_pools[i].lock);
	}

	return total;
}

int
mdtm_pipe_drain(int pipefd, int size, int flag)
{
  static int fd = 0;
  int rc;

  if(flag & MDTM_PIPEDRAIN_CLOSE) {
    if(!fd) close(fd);
    return 0;
  }

  if(!fd)
    fd = open("/dev/null", O_WRONLY);

  rc = splice(pipefd, NULL,
      fd, NULL,
      (size_t)size,
      SPLICE_F_MOVE|SPLICE_F_MORE);

  return rc;
}

int
mdtm_pipe_check(void *p) {
  mdtm_pipefd_t *       mpipe = (mdtm_pipefd_t*) p;
  return (mpipe && mpipe->pipefd[0] && mpipe->pipefd[1])? 0 : -1;
}

#ifdef __cplusplus
}
#endif



