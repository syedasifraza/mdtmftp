/*
 * mdtm_lvm.h
 *
 *  Created on: Jan 25, 2016
 *      Author: liangz
 */

#ifndef SRC_LIBMDTM_MDTM_LVM_H_
#define SRC_LIBMDTM_MDTM_LVM_H_

#include <stdio.h>
#include <stdint.h>   /* For uint64_t */
#include <inttypes.h> /* For PRIu64 */
#include "include/mdtm.h"

#ifdef __cplusplus
extern "C" {
#endif

//typedef struct _LV_SEG_ {
//  uint64_t      m_start;
//  uint64_t      m_end;
//  char*         dev;
//} mdtm_lv_seg_t;

int mdtm_lvm_display();

/**
 * Initialize the mdtm_lvm object
 */
int
mdtm_lvm_init();

/**
 * Clean up the mdtm_lvm object
 */
void
mdtm_lvm_fini();

/**
 * Print out the underlying lvm2 version.
 */
char*
mdtm_lvm_getlibversion();

/**
 * Return the physical device name for the given logic volume
 *
 * \param lvfullname    full name logic volume, e.g. vg_denali-lv_home
 * \param start         starting position in bytes
 * \param end           ending position in bytes
 * \param psegs         array of segments
 *
 * \return              If success, the number of segments, otherwise -1
 */
int
mdtm_lvm_get_physical_devices(
    char* lvfullname,
    uint64_t start,
    uint64_t end,
    mdtm_lv_seg_t **psegs);

/**
 * Return if the device is logical volume
 *
 * \param  fs           the full name of device, e.g./dev/mapper/vg_denali-lv_home
 *
 * \return              If yes, 1, otherwise 0.
 */
int
mdtm_lvm_islv(char *fs);

/**
 * Return logic volume name
 *
 * \param  fs           The full name of device, e.g./dev/mapper/vg_denali-lv_home
 *
 * \return              logic volume name string.
 */
char*
mdtm_lvm_getlvname(const char *fs);

#ifdef __cplusplus
}
#endif

#endif /* SRC_LIBMDTM_MDTM_LVM_H_ */
