#!/bin/bash

exec "$@"
