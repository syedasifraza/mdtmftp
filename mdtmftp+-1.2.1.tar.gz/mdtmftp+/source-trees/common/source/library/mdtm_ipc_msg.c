/*
 * mdtm_ipc_msg.c
 *
 *  Created on: Mar 24, 2017
 *      Author: liangz
 */

#include "mdtm_ipc_msg.h"

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "globus_libc.h"

void *
mdtm_ipc_msg_init(
    char *fifoname,
    int flags,
    int mode)
{
  int rc = 0;
  mdtm_ipc_t *  ipc;

  if(!fifoname)
    return NULL;

  if(mode & MDTM_IPC_CREATE) {
      /* create the FIFO (named pipe) */
      if((rc = mkfifo(fifoname, 0666)) < 0) {
          if(errno == EEXIST) {
              unlink(fifoname);
              rc = mkfifo(fifoname, 0666);
          }
          if (rc < 0 ) {
              perror("mdtm_ipc_msg_init:");
              return NULL;
          }
      }
  }

  ipc = (mdtm_ipc_t *) globus_calloc(1, sizeof(mdtm_ipc_t));
  if(ipc == NULL)
    return ipc;

  ipc->fd = open(fifoname, flags);
  if(ipc->fd < 0 ) {
      globus_free(ipc);
      return NULL;
  }

  ipc->fifoname = strdup(fifoname);
  ipc->mode = mode;
  ipc->flags = flags;

  return ipc;
}

char *
mdtm_ipc_msg_create_files(
    mdtm_object_t *    files,
    int                nfiles,
    char *             taskid)
{
  char *                        buf;
  char *                        pos;
  unsigned *                    msg_nobjects;
  int                           i, nbytes;
  mdtm_ipc_msg_header_t *       msg_head;
  mdtm_object_t *               obj;

  nbytes = sizeof(mdtm_ipc_msg_header_t) + sizeof(unsigned) + (sizeof(mdtm_object_t) + 1024) * nfiles;
  buf = (char *) globus_malloc(nbytes);
  if(buf == NULL)
    return 0;
  msg_head = (mdtm_ipc_msg_header_t *) buf;
  msg_head->msg_id = 10;
  msg_head->nbytes = nbytes;
  strcpy(msg_head->task_id, taskid);

  msg_nobjects = (unsigned *)(buf + sizeof(mdtm_ipc_msg_header_t));
  *msg_nobjects = nfiles;
  obj = (mdtm_object_t *)(buf + sizeof(mdtm_ipc_msg_header_t) + sizeof(unsigned));
  pos = buf +sizeof(mdtm_ipc_msg_header_t) + sizeof(unsigned) + sizeof(mdtm_object_t) * nfiles;
  for(i = 0; i < nfiles; i++) {
      obj->type = files[i].type;
      obj->size = files[i].size;
      obj->offset = files[i].offset;
      obj->path_src = pos;
      obj->path_dst = pos + 512;
      strcpy(obj->path_src, files[i].path_src); free(files[i].path_src);
      strcpy(obj->path_dst, files[i].path_dst); free(files[i].path_dst);
      obj++;
      pos += 1024;
  }
  return buf;
}

int
mdtm_ipc_msg_parse_files(
    char *               msgbuf,
    char ***             srcfiles,
    char ***             dstfiles,
    size_t **            filesizes,
    char **              taskid)
{
  char *                                files;
  char **                               sfiles;
  char **                               dfiles;
  char *                                buf;
  size_t *                              sizes;
  int                                   i, nfiles;
  mdtm_object_t *                       objects;
  char *                                objects_data;
  int                                   nobjs;
  mdtm_ipc_msg_filelist_t *             msg;

  msg = (mdtm_ipc_msg_filelist_t *) msgbuf;
  nobjs = msg->nobjects;
  *taskid = strdup(msg->task_id);
  objects = (mdtm_object_t *)((char*)msg + sizeof(mdtm_ipc_msg_header_t) + sizeof(msg->nobjects));
  objects_data = (char*)(objects + nobjs);
  for (i = 0; i < nobjs; i++) {
      objects[i].path_src = objects_data + 1024 * i;
      objects[i].path_dst = objects[i].path_src + 512;
  }

  nfiles = nobjs;
  buf = (char *) globus_malloc(
      sizeof(size_t) * nfiles                 // size array
      + 1024 * nfiles
      + sizeof(char*) * nfiles * 2);    // path and pointer array
  sizes = (size_t *) buf;
  files = (char*)(buf + sizeof(size_t) * nfiles);
  sfiles = (char**) globus_malloc(sizeof(char*) * nfiles);
  dfiles = (char**) globus_malloc(sizeof(char*) * nfiles);

  for(i = 0; i < nfiles; i++) {
      sfiles[i] = files + i * 1024;
      dfiles[i] = files + i * 1024 + 512;
      strcpy(sfiles[i], objects[i].path_src);
      strcpy(dfiles[i], objects[i].path_dst);
      sizes[i] = objects[i].size;
  }

  *srcfiles = sfiles;
  *dstfiles = dfiles;
  *filesizes = sizes;

  return nfiles;
}

int
mdtm_ipc_msg_send(
    void * ipc,
    char * buf)
{
  unsigned      nleft, nsent;
  ssize_t	ret;
  mdtm_ipc_msg_header_t *       head;

  head = (mdtm_ipc_msg_header_t *)buf;
  nleft = head->nbytes;
  nsent = 0;
  while (nleft > 0) {
      ret = write(((mdtm_ipc_t*)ipc)->fd, (void*)(buf + nsent), nleft);
      if(ret < 0) {
	if(errno == EAGAIN) {
	   usleep(1000);
	   continue;
        }	
	perror("writting pipe:"); break;
      }
      nsent += ret;
      nleft -= ret;
  }

  return (nleft == 0)? 0 : -1;
}


char *
mdtm_ipc_msg_recv(void * ipc)
{
  int                   nleft, nread, nbytes, msg_bytes;
  char *                readbuffer;
  unsigned              readbuffer_size = 1024 * 2;
  mdtm_ipc_msg_header_t *       msg;
  int                   fd;

  if(ipc == NULL)
    return NULL;

  readbuffer = (char *) globus_malloc(readbuffer_size);
  if(readbuffer == NULL)
    return NULL;

  nread  = 0;
  nleft = sizeof(mdtm_ipc_msg_header_t);
  do {
      nbytes = read(((mdtm_ipc_t*)ipc)->fd, readbuffer + nread, nleft);
      nleft -= nbytes;
      nread += nbytes;
  } while(nread < sizeof(mdtm_ipc_msg_header_t));

  msg = (mdtm_ipc_msg_header_t *) readbuffer;
  msg_bytes = msg->nbytes;
  nleft = msg_bytes - nread;

  if(msg_bytes > readbuffer_size) {
      char *    new_buffer;
      char *    old_buffer;
      old_buffer = readbuffer;
      new_buffer = (char *) globus_realloc(readbuffer, msg_bytes);
      if(new_buffer == NULL) {
          readbuffer = old_buffer;
          globus_free(readbuffer);
          close(fd);
          perror("mdtm_ipc_msg_recv:");
          return NULL;
      }
      readbuffer = new_buffer;
      readbuffer_size = msg_bytes;
      msg = (mdtm_ipc_msg_header_t *) readbuffer;
      msg->nbytes = msg_bytes;
  }

  while(nleft > 0) {
      nbytes = read(((mdtm_ipc_t*)ipc)->fd, readbuffer + nread, nleft);
      if(nbytes < 0) {
	if(errno == EAGAIN) {
	  usleep(1000);
 	  continue;
	}
	perror("reading pipe");
	if(readbuffer)
	  free(readbuffer);
	return NULL;
      }
      nleft -= nbytes;
      nread += nbytes;
  }

  return readbuffer;
}

void
mdtm_ipc_msg_deinit(mdtm_ipc_t * ipc)
{
  if(!ipc)
    return;

  if(ipc->fd > 0)
    close(ipc->fd);

  if(ipc->mode & MDTM_IPC_CREATE)
    unlink(ipc->fifoname);

  globus_free(ipc);
  return;
}

/*
 * mdtm_ipc
 */

char *
mdtm_ipc_msg_create_rate(
    char *      taskid,
    long long   avg,
    long long   inst,
    long long   total_bytes)
{
  mdtm_ipc_msg_rate_t * msg;

  msg = (mdtm_ipc_msg_rate_t *) malloc(sizeof(mdtm_ipc_msg_rate_t));
  if(msg == NULL)
    return NULL;

  msg->msg_id = 0;
  msg->nbytes = sizeof(mdtm_ipc_msg_rate_t);
  strcpy(msg->task_id, taskid);
  msg->avg_rate = avg;
  msg->inst_rate = inst;
  msg->total_bytes = total_bytes;
  return (char*)msg;
}

char *
mdtm_ipc_msg_create_ports(
    char * taskid,
    int * srcports, int nsrcport,
    int * dstports, int ndstport)
{
  mdtm_ipc_msg_portlist_t * msg;
  int i;
  int *         port;

  msg = (mdtm_ipc_msg_portlist_t *)
      malloc(sizeof(mdtm_ipc_msg_portlist_t) + sizeof(int) *(nsrcport +ndstport  - 1));
  if(msg == NULL)
    return NULL;

  msg->msg_id = 9;
  msg->nbytes = sizeof(mdtm_ipc_msg_portlist_t) + sizeof(int) *(nsrcport +ndstport  - 1);
  strcpy(msg->task_id, taskid);

  port = &msg->ports;
  for (i = 0; i < nsrcport; i++) {
      *port = srcports[i];
      port++;
  }
  for (i = 0; i < ndstport; i++) {
      *port = dstports[i];
      port++;
  }
  msg->nports = nsrcport + ndstport;
  return (char*)msg;
}

char *
mdtm_ipc_msg_create_end(const char * taskid, int result)
{
  mdtm_ipc_msg_endjob_t * msg;

  msg = (mdtm_ipc_msg_endjob_t *) malloc(sizeof(mdtm_ipc_msg_endjob_t));
  if(msg == NULL)
    return NULL;

  msg->msg_id = 1;
  msg->nbytes = sizeof(mdtm_ipc_msg_endjob_t);
  strcpy(msg->task_id, taskid);
  msg->result = result;
  return (char*)msg;
}

char *
mdtm_ipc_msg_create_error(const char * taskid, int errorcode)
{
  mdtm_ipc_msg_error_t * msg;

  msg = (mdtm_ipc_msg_error_t *) malloc(sizeof(mdtm_ipc_msg_error_t));
  if(msg == NULL)
    return NULL;

  msg->msg_id = 2;
  msg->nbytes = sizeof(mdtm_ipc_msg_error_t);
  strcpy(msg->task_id, taskid);
  msg->errorcode = errorcode;
  return (char*)msg;
}

char *
mdtm_ipc_msg_create_abort(const pid_t taskpid, int errorcode)
{
	mdtm_ipc_msg_abort_t * msg;

	  msg = (mdtm_ipc_msg_abort_t *) calloc(1, sizeof(mdtm_ipc_msg_abort_t));
	  if(msg == NULL)
	    return NULL;

	  msg->msg_id = 3;
	  msg->nbytes = sizeof(mdtm_ipc_msg_abort_t);
	  msg->task_pid = (long) taskpid;
	  msg->errorcode = errorcode;
	  return (char*)msg;

}

/**
 * check if the IPC/pipe exists. Otherwise recreate it.
 */
int
mdtm_ipc_health_check(void * arg)
{
	mdtm_ipc_t *ipc  = (mdtm_ipc_t *) arg;
	char *fifoname = ipc->fifoname;
	struct stat info;

	if( stat( fifoname, &info ) != 0 ) {
		fprintf(stderr, "cannot access %s\n", fifoname );

		if(ipc->fd > 0)
			close(ipc->fd);

		if(ipc->mode & MDTM_IPC_CREATE) {
			int rc;

			unlink(fifoname);

			if((rc = mkfifo(fifoname, 0666)) < 0) {
				if(errno == EEXIST) {
					unlink(fifoname);
					rc = mkfifo(fifoname, 0666);
				}
				if (rc < 0 ) {
					perror("mdtm_ipc_msg_init:");
					return -1;
				}
			}
		}

		ipc->fd = open(fifoname, ipc->flags);
		if(ipc->fd < 0 ) {
			fprintf(stderr, "cannot open %s\n", fifoname );
			return -1;
		}
		fprintf(stderr, "resume access %s\n", fifoname );
	}

	return 0;
}

void
mdtm_ipc_poll(void * arg)
{
  mdtm_ipc_poll_arg_t *         poll_arg;
  int                           nleft, nread, nbytes, msg_bytes;
  mdtm_ipc_msg_header_t *       msg;

  poll_arg = (mdtm_ipc_poll_arg_t *) arg;

  // check if the listening fifo exists. Otherwise recreate it.
  if(mdtm_ipc_health_check((void*)(poll_arg->ipc)) < 0)
	  return;

  nread = 0;
  nleft = sizeof(mdtm_ipc_msg_header_t);
  do {
      nbytes = read(poll_arg->ipc->fd, poll_arg->buf + nread, nleft);
      if(nbytes < 0) {
          if(errno == EAGAIN)
            return;
          else if(errno == EINTR)
            continue;
          else {
            perror("read failed:");
            return;
          }
      }
      if(nbytes == 0)
        return;
      nleft -= nbytes;
      nread += nbytes;
  } while(nread < sizeof(mdtm_ipc_msg_header_t));

  msg = (mdtm_ipc_msg_header_t *) (poll_arg->buf);
  msg_bytes = msg->nbytes;
  nleft = msg_bytes - sizeof(mdtm_ipc_msg_header_t);

  while(nleft > 0) {
      nbytes = read(poll_arg->ipc->fd, poll_arg->buf + nread, nleft);
      if(nbytes < 0) {
        perror("read message body failed: ");
        return;
      }
      else if(nbytes == 0) {
          fprintf(stderr, " FIFO is closed.\n");
          return;
      }
      nleft -= nbytes;
      nread += nbytes;
  }

  poll_arg->callback(poll_arg->buf, poll_arg->userdata);        // mdtm_ipc_poll_cb
  return;
}
