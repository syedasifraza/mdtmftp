/*
 * mdtm_portinfo.h
 *
 *  Created on: Jun 11, 2017
 *      Author: liangz
 */

#ifndef SOURCE_TREES_COMMON_SOURCE_LIBRARY_MDTMPLUS_MDTM_PORTINFO_H_
#define SOURCE_TREES_COMMON_SOURCE_LIBRARY_MDTMPLUS_MDTM_PORTINFO_H_

#include        <pthread.h>
#include        "globus_list.h"

typedef globus_result_t
    (*mdtm_portinfo_callback_t)( void * arg);

typedef struct {
  int                   enabled;
  pthread_mutex_t       lock;
  globus_list_t *       port_list;
  int                   nparallel;
  int                   nstreams;
  int                   port_inited;
  int                   user_port_min;
  int                   user_port_max;
  int                   port_min;
  int                   port_max;
  int                   port_radix;
  int                   port;
  char                  remote_host[256];
  int                   remote_port;
  mdtm_portinfo_callback_t      callback;
  void *                        callback_arg;
} mdtm_portinfo_t;

typedef globus_result_t
    (*mdtm_xio_tcp_bind_local_func_t)(
        int                                 fd,
        void *                              attr,
        int                                 port);

typedef globus_result_t
    (*mdtm_xio_tcp_bind_func_t)(
        int                                 fd,
        const struct sockaddr *             addr,
        int                                 addr_len,
        int                                 port,
        globus_bool_t                       listener);

mdtm_portinfo_t *
mdtm_portinfo_create(int enabled, int radix);

void
mdtm_portinfo_destroy(mdtm_portinfo_t *info);

int
mdtm_portinfo_set(
    mdtm_portinfo_t *   info,
    char                mask,
    int                 parallel,
    int                 nstreams);

int
mdtm_portinfo_get(
    mdtm_portinfo_t *   info,
    char                mask,
    int *               parallel,
    int *               nstreams);

globus_result_t
mdtm_portinfo_addport(
    mdtm_portinfo_t *   info,
    char *              contact_string);

globus_result_t
mdtm_portinfo_setuserportrange(
    mdtm_portinfo_t *   info,
    int                 connector_min_port,
    int                 connector_max_port);

globus_result_t
mdtm_portinfo_setremote(
    mdtm_portinfo_t *   info,
    char *              host,
    int                 port);

globus_result_t
mdtm_portinfo_bind_local(
    mdtm_portinfo_t *                   info,
    int                                 fd,
    void *                              attr,
    mdtm_xio_tcp_bind_local_func_t      bindfunc);

globus_result_t
mdtm_portinfo_bind(
    mdtm_portinfo_t *                   info,
    int                                 fd,
    const struct sockaddr *             addr,
    int                                 addr_len,
    globus_bool_t                       listener,
    mdtm_xio_tcp_bind_func_t            bindfunc);

void
mdtm_portinfo_printf(void * arg);

int
mdtm_portinfo_allocateport (mdtm_portinfo_t * info);

globus_result_t
mdtm_portinfo_setcallback(
    void *                      obj,
    mdtm_portinfo_callback_t    cb,
    void *                      arg);

void
mdtm_portinfo_purge_report(
    void *   obj);

#endif /* SOURCE_TREES_COMMON_SOURCE_LIBRARY_MDTMPLUS_MDTM_PORTINFO_H_ */
