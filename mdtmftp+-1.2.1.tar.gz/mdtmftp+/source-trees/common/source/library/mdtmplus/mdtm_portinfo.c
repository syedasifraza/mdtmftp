/*
 * mdtm_portinfo.c
 *
 *  Created on: Jun 11, 2017
 *      Author: liangz
 */

#include "globus_libc.h"
#include "mdtm_portinfo.h"

mdtm_portinfo_t *
mdtm_portinfo_create(int enabled, int radix) {
  mdtm_portinfo_t *     info = NULL;

  info = (mdtm_portinfo_t *) globus_calloc(1, sizeof(mdtm_portinfo_t));
  pthread_mutex_init(&info->lock, NULL);
  info->enabled = enabled;
  info->port_radix = radix;
  return info;
}

void
mdtm_portinfo_destroy(mdtm_portinfo_t *info) {
  if(!info)
    return;

//  if(info->lock)
    pthread_mutex_destroy(&info->lock);
  if(info->port_list)
    globus_list_destroy_all(info->port_list, NULL);
  globus_free(info);
  info = NULL;
  return;
}

int
mdtm_portinfo_set(
    mdtm_portinfo_t *   info,
    char                mask,
    int                 parallel,
    int                 nstreams) {
  return 0;
}

int
mdtm_portinfo_get(
    mdtm_portinfo_t *   info,
    char                mask,
    int *               parallel,
    int *               nstreams) {
  return 0;
}

globus_result_t
mdtm_portinfo_setcallback(
    void *                      obj,
    mdtm_portinfo_callback_t    cb,
    void *                      arg)
{
  mdtm_portinfo_t *   info;

  if(!obj || !cb)
    return GLOBUS_FAILURE;

  info = (mdtm_portinfo_t *)obj;

  pthread_mutex_lock(&info->lock);
  info->callback = cb;
  info->callback_arg = arg;
  pthread_mutex_unlock(&info->lock);

  return GLOBUS_SUCCESS;
}

void
mdtm_portinfo_purge_report(
    void *   obj)
{
  int report = 0;
  mdtm_portinfo_t *   info = ( mdtm_portinfo_t *) obj;

  pthread_mutex_lock(&info->lock);
  if(globus_list_size(info->port_list) < info->nparallel * info->nstreams)
    report = 1;
  pthread_mutex_unlock(&info->lock);

  if(report == 1 && info->callback)
    info->callback(info->callback_arg);

  return;
}

globus_result_t
mdtm_portinfo_addport(
    mdtm_portinfo_t * info,
    char * contact_string)
{
  int report = 0;

  if(!info || !info->enabled || !contact_string)
    return GLOBUS_FAILURE;

  pthread_mutex_lock(&info->lock);
  globus_list_insert(&info->port_list, (void*)contact_string);
  if(globus_list_size(info->port_list) >= info->nparallel * info->nstreams)
    report = 1;
  pthread_mutex_unlock(&info->lock);

  if(report == 1 && info->callback)
    info->callback(info->callback_arg);

  return GLOBUS_SUCCESS;
}

globus_result_t
mdtm_portinfo_setuserportrange(
    mdtm_portinfo_t *   info,
    int                 connector_min_port,
    int                 connector_max_port)
{
  if(!info || !info->enabled)
    return GLOBUS_FAILURE;

  pthread_mutex_lock(&info->lock);

  if(!info->port_inited) {
      info->user_port_min = connector_min_port;
      info->user_port_max = connector_max_port;
  }
  pthread_mutex_unlock(&info->lock);

  return GLOBUS_SUCCESS;
}

globus_result_t
mdtm_portinfo_bind_local(
    mdtm_portinfo_t *                   info,
    int                                 fd,
    void *                              attr,
    mdtm_xio_tcp_bind_local_func_t      bindfunc)       //mdtm_l_xio_tcp_bind_local
{
  int       rc, port;

  if(!info || !info->enabled || !attr || !bindfunc)
    return GLOBUS_FAILURE;

  pthread_mutex_lock(&info->lock);

  if(!info->port_inited) {
      if(info->user_port_min % info->port_radix == 0)
        info->port_min = info->user_port_min;
      else
        info->port_min = (info->user_port_min / info->port_radix + 1) * info->port_radix;

      if(info->port_min > info->user_port_max)
        goto find_port_err;

      info->port_max = info->user_port_max;

      port = info->port_min;
      rc = bindfunc(fd, attr, port);
      while (rc != GLOBUS_SUCCESS) {
          port += info->port_radix;
          if(port > info->user_port_max)
            goto find_port_err;                         // out of the user port bound
          rc = bindfunc(fd, attr, port);
      }
      info->port = port;
      info->port_inited = 1;
  }
  else {
      port = info->port;
      if(++port > info->user_port_max)
            goto find_port_err;
      rc = bindfunc(fd, attr, port);
      while (rc != GLOBUS_SUCCESS) {
          port++;
          if(port > info->user_port_max)
            goto find_port_err;                         // out of the user port bound
          rc = bindfunc(fd, attr, port);
      }
      info->port = port;
  }
  pthread_mutex_unlock(&info->lock);

  return GLOBUS_SUCCESS;

find_port_err:
  pthread_mutex_unlock(&info->lock);
  return GLOBUS_FAILURE;
}

globus_result_t
mdtm_portinfo_bind(
    mdtm_portinfo_t *                   info,
    int                                 fd,
    const struct sockaddr *             addr,
    int                                 addr_len,
    globus_bool_t                       listener,
    mdtm_xio_tcp_bind_func_t            bindfunc)       //mdtm_l_xio_tcp_bind
{
  int       rc, port;

  if(!info || !info->enabled || !addr || !bindfunc)
    return GLOBUS_FAILURE;

  pthread_mutex_lock(&info->lock);

  if(!info->port_inited) {
      if(info->user_port_min % info->port_radix == 0)
        info->port_min = info->user_port_min;
      else
        info->port_min = (info->user_port_min / info->port_radix + 1) * info->port_radix;

      if(info->port_min > info->user_port_max)
        goto find_port_err;

      info->port_max = info->user_port_max;

      port = info->port_min;
      rc = bindfunc(fd, addr, addr_len, port, listener);
      while (rc != GLOBUS_SUCCESS) {
          port += info->port_radix;
          if(port > info->user_port_max)
            goto find_port_err;                         // out of the user port bound
          rc = bindfunc(fd, addr, addr_len, port, listener);
      }
      info->port = port;
      info->port_inited = 1;
  }
  else {
      port = info->port;
      rc = bindfunc(fd, addr, addr_len, ++port, listener);
      while (rc != GLOBUS_SUCCESS) {
          port++;
          if(port > info->user_port_max)
            goto find_port_err;                         // out of the user port bound
          rc = bindfunc(fd, addr, addr_len, port, listener);
      }
      info->port = port; //FIXME: how about port greater than the port_radix range
  }
  pthread_mutex_unlock(&info->lock);

  return GLOBUS_SUCCESS;

find_port_err:
  pthread_mutex_unlock(&info->lock);
  return GLOBUS_FAILURE;
}

globus_result_t
mdtm_portinfo_setremote(
    mdtm_portinfo_t *   info,
    char *              host,
    int                 port)
{
  if(!info || !info->enabled)
    return -1;

  pthread_mutex_lock(&info->lock);
  strcpy(info->remote_host, host);
  info->remote_port = port;
  pthread_mutex_unlock(&info->lock);

  return GLOBUS_SUCCESS;
}

void
mdtm_portinfo_printf(void * arg) {
  mdtm_portinfo_t *     info = (mdtm_portinfo_t*) arg;
  globus_list_t *       head;

  head = info->port_list;

//  pthread_mutex_lock(&info->lock);
  while(!globus_list_empty(head)) {
    fprintf(stderr, " %s\n", (char*)globus_list_first(head));
    head = globus_list_rest(head);
  }

  fprintf(stderr, " %s:%d\n", info->remote_host, info->remote_port);
//  pthread_mutex_unlock(&info->lock);
}

int
mdtm_portinfo_allocateport (mdtm_portinfo_t *   info)
{
  int port;

  if(!info || !info->enabled)
    return -1;

  pthread_mutex_lock(&info->lock);

  if(!info->port_inited) {
      if(info->user_port_min % info->port_radix == 0)
        info->port_min = info->user_port_min;
      else
        info->port_min = (info->user_port_min / info->port_radix + 1) * info->port_radix;

      if(info->port_min > info->user_port_max)
        goto find_port_err;

      info->port_max = info->user_port_max;

      port = info->port_min;
//      rc = bindfunc(fd, attr, port);
//      while (rc < 0) {
//          port += info->port_radix;
//          if(port > info->user_port_max)
//            goto find_port_err;                         // out of the user port bound
//          rc = bindfunc(fd, attr, port);
//      }
      info->port = port;
      info->port_inited = 1;
  }
  else {
      port = info->port;
      ++port;
//      rc = bindfunc(fd, attr, ++port);
//      while (rc < 0) {
//          port++;
//          if(port > info->user_port_max)
//            goto find_port_err;                         // out of the user port bound
//          rc = bindfunc(fd, attr, port);
//      }
      info->port = port; //FIXME: how about port greater than the port_radix range
  }
  pthread_mutex_unlock(&info->lock);
  return port;

 find_port_err:
    pthread_mutex_unlock(&info->lock);
    return -1;
}
