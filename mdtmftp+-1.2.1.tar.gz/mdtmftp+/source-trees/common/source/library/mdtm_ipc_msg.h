/*
 * mdtm_ipc_msg.h
 *
 *  Created on: Mar 24, 2017
 *      Author: liangz
 */

#ifndef SOURCE_TREES_COMMON_SOURCE_LIBRARY_MDTM_IPC_MSG_H_
#define SOURCE_TREES_COMMON_SOURCE_LIBRARY_MDTM_IPC_MSG_H_

#include <stdlib.h>
#include "globus_common.h"

#define         MDTM_IPC_CREATE         0x02
#define         MDTM_IPC_OPEN           0x01

typedef struct {
  int           fd;
  char *        fifoname;
  int           mode;
  int			flags;
} mdtm_ipc_t;

/*
 * ======================
 * |    msg_id          |       : int
 * ======================
 * |    nbytes          |       : int: total length including the header
 * ======================
 * |   task_id          |       : char [128]
 * ======================
 */

typedef struct {
  int           msg_id;
  int           nbytes;
  char          task_id[128];
} mdtm_ipc_msg_header_t;

/*
 * Definition of Messages
 *
 * NOTE: every message MUST has the header defined above
 *
 */

/*
 * ======================
 * |   msg_id = 0       |       : 0: rate
 * ======================
 * |   nbytes           |
 * ======================
 * |   task_id          |       : char [128]
 * ======================
 * |   avg_rate         |       : long long
 * ======================
 * |   inst_rate        |       : long long
 * ======================
 * |   total_bytes      |       : long long
 * ======================
 */
typedef struct {
  int           msg_id;
  int           nbytes;
  char          task_id[128];
  long long     avg_rate;
  long long     inst_rate;
  long long     total_bytes;
} mdtm_ipc_msg_rate_t;

/*
 * ======================
 * |   msg_id = 1       |       : 1: end job
 * ======================
 * |   nbytes           |
 * ======================
 * |   task_id          |       : char [128]
 * ======================
 * |   result           |       : int
 * ======================
 */
typedef struct {
  int                   msg_id;
  int                   nbytes;
  char                  task_id[128];
  int                   result;
} mdtm_ipc_msg_endjob_t;

/*
 * ======================
 * |   msg_id = 2       |       : 2: error
 * ======================
 * |   nbytes           |
 * ======================
 * |   task_id          |       : char [128]
 * ======================
 * |   error code       |       : int
 * ======================
 */
typedef struct {
  int                   msg_id;
  int                   nbytes;
  char                  task_id[128];
  int                   errorcode;
} mdtm_ipc_msg_error_t;

/*
 * ======================
 * |   msg_id = 3       |       : 3: abort
 * ======================
 * |   nbytes           |
 * ======================
 * |   task_id          |       : char [128]
 * ======================
 * |   task_pid         |       : long
 * ======================
 * |   error code       |       : int
 * ======================
 */
typedef struct {
  int                   msg_id;
  int                   nbytes;
  char                  task_id[128];   // task id
  long                  task_pid;       // process id for task
  int                   errorcode;
} mdtm_ipc_msg_abort_t;

/*
 * ======================
 * |   msg_id =  9      |       : 9: portlist
 * ======================
 * |   nbytes           |
 * ======================
 * |   task_id          |       : char [128]
 * ======================
 * |   nports           |
 * ======================
 * |   port             |
 * ======================
 * |   port             |
 * ======================
 * |     ....           |
 * ======================
 */

typedef struct {
  int                   msg_id;
  int                   nbytes;
  char                  task_id[128];
  unsigned              nports;
  int                   ports;        //FIXME
} mdtm_ipc_msg_portlist_t;

/*
 * ======================
 * |   msg_id = 10      |       : 10: filelist
 * ======================
 * |   nbytes           |
 * ======================
 * |   task_id          |       : char [128]
 * ======================
 * |   nbojects         |
 * ======================
 * |   mdtm_object_t    |
 * ======================
 * |   mdtm_object_t    |
 * ======================
 * |     ....           |
 * ======================
 * |  src 512  bytes    |
 * |                    |
 * ======================
 * |  dst 512 bytes     |
 * |                    |
 * ======================
 */
typedef struct {
  enum {
    MDTM_IFREG,
    MDTM_IFIDR
  }             type;
  char *        path_src;
  char *        path_dst;
  size_t        size;
  size_t        offset;
} mdtm_object_t;


typedef struct {
  int                   msg_id;
  int                   nbytes;
  char                  task_id[128];
  unsigned              nobjects;
  mdtm_object_t *       objects;        //FIXME
} mdtm_ipc_msg_filelist_t;



typedef void (*mdtm_ipc_poll_cb_t) (
  char *                        buf,
  void *                        userdata);

typedef struct {
  mdtm_ipc_t *                  ipc;
  char *                        buf;
  mdtm_ipc_poll_cb_t            callback;
  void *                        userdata;
}mdtm_ipc_poll_arg_t;

/*
 * FUNCTIONS
 */
void *
mdtm_ipc_msg_init(
    char *fifoname,
    int flags,
    int mode);

void
mdtm_ipc_msg_deinit(mdtm_ipc_t * ipc);

char *
mdtm_ipc_msg_create_files(
    mdtm_object_t *    files,
    int                nfiles,
    char *             taskid);

int
mdtm_ipc_msg_parse_files(
    char *               buf,
    char ***             srcfiles,
    char ***             dstfiles,
    size_t **            filesizes,
    char **              taskid);

int
mdtm_ipc_msg_send(
    void * ipc,
    char * buf);

char *
mdtm_ipc_msg_recv(void * ipc);

void
mdtm_ipc_poll(void * arg);

/**
 * check if the IPC/pipe is in healthy conditions. If not,
 * try to fix the problem.
 */
int
mdtm_ipc_health_check(void * arg);

char *
mdtm_ipc_msg_create_rate(
    char *      taskid,
    long long   avg,
    long long   inst,
    long long   total_bytes);

char *
mdtm_ipc_msg_create_ports(
    char * taskid,
    int * srcports, int nsrcport,
    int * dstports, int ndstport);

char *
mdtm_ipc_msg_create_error(const char * taskid, int errorcode);

char *
mdtm_ipc_msg_create_abort(const pid_t taskpid, int errorcode);

char *
mdtm_ipc_msg_create_end(const char * taskid, int result);

#endif /* SOURCE_TREES_COMMON_SOURCE_LIBRARY_MDTM_IPC_MSG_H_ */
