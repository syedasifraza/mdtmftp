/*
 * mdtm_rrd.c
 *
 *  Created on: Jul 24, 2015
 *      Author: liangz
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rrd.h"
#include "mdtm_rrd.h"

mdtm_rrd_file_t*
mdtm_rrdfile_open(char* path)
{
  mdtm_rrd_file_t *     file;

  file = (mdtm_rrd_file_t *)calloc(1, sizeof(mdtm_rrd_file_t));
  if(file == 0)
    return NULL;
  file->created = 0;
  file->fullpath = strdup(path);
  file->data_format_n = 0;
  file->data = 0;
  file->options.step = 10;
  file->options.rra_avg = 2880;
  file->options.rra_last = 2880;

  return file;
}

void
mdtm_rrdfile_close(mdtm_rrd_file_t* rrdfile)
{
  mdtm_rrd_file_t * file = rrdfile;
  if(file) {
      int i;

      if(file->fullpath) free(file->fullpath);
      if(file->data) free(file->data);
      for(i = 0; i < file->data_format_n; i++)
        if(file->data_format[i])
          free(file->data_format[i]);
      free(file);
  }
  return;
}

void
mdtm_rrdfile_setformat(mdtm_rrd_file_t* rrdfile, char* format)
{
  const char *  delim = ";,";
  int i = 0;
  mdtm_rrd_file_t * file = (mdtm_rrd_file_t *)rrdfile;

  char *rest; // to point to the rest of the string after token extraction.
  char *token; // to point to the actual token returned.
  char *ptr = strdup(format);//hello; // make q point to start of hello.
  char *ptr_saved = ptr;

  while(1) {
      token = strtok_r(ptr, delim, &rest);
      if(token == NULL)
        break;
      file->data_format[i++] = strdup(token);
      ptr = rest;
  }
  file->data_format_n = i;
  free(ptr_saved);
  return;
}

static
int
mdtm_rrdfile_create(void* rrdfile)
{
  mdtm_rrd_file_t *     file = rrdfile;
  int                   n, i;
  char **               argv;
  int                   argc = 0, offset;
  int                   rc;

  argv = (char**)malloc(
      (sizeof(char*) + MDTM_RRD_OPT_ELEM_SIZE) * MDTM_RRD_OPT_ELEM_MAXNUM +
      (sizeof(char*) + MDTM_RRD_DATA_ELEM_SIZE) * MDTM_RRD_DATA_ELEM_MAXNUM);
  offset = sizeof(char*) * (MDTM_RRD_OPT_ELEM_MAXNUM + MDTM_RRD_DATA_ELEM_MAXNUM);

  //write file path
  argv[argc] = (char*)argv + offset;
  n = snprintf(argv[argc++], MDTM_RRD_OPT_ELEM_SIZE, "%s", "create") + 1;
  offset += n;

  argv[argc] = (char*)argv + offset;
  n = snprintf(argv[argc++], MDTM_RRD_OPT_ELEM_SIZE, "%s", file->fullpath) + 1;
  offset += n;

  argv[argc] = (char*)argv + offset;
  n = snprintf(argv[argc++], MDTM_RRD_OPT_ELEM_SIZE, "-s %d", file->options.step) + 1;
  offset += n;

  for(i = 0; i < file->data_format_n; i++) {
      argv[argc] = (char*)argv + offset;
      n = snprintf(argv[argc++], MDTM_RRD_DATA_ELEM_SIZE, "DS:%s:GAUGE:600:U:U", file->data_format[i]) + 1;
      offset += n;
  }

  argv[argc] = (char*)argv + offset;
  n = snprintf(argv[argc++], MDTM_RRD_OPT_ELEM_SIZE, "RRA:AVERAGE:0.5:1:%d", file->options.rra_avg) + 1;
  offset += n;

  argv[argc] = (char*)argv + offset;
  n = snprintf(argv[argc++], MDTM_RRD_OPT_ELEM_SIZE, "RRA:LAST:0.5:1:%d", file->options.rra_last) + 1;

  //flush to rrd file
  rc = rrd_create(argc, argv);
  free(argv);

  if (rrd_test_error()) {
      fprintf(stdout, "ERROR: %s\n", rrd_get_error());
      rrd_clear_error();
      return 1;
  }
  file->created = 1;

  return rc;
}

mdtm_rrd_data_element_t*
mdtm_rrddata_alloc(mdtm_rrd_file_t *rrdfile)
{
  mdtm_rrd_file_t *     file = rrdfile;
  mdtm_rrd_data_element_t *     data;
  int                   i;

  data = (mdtm_rrd_data_element_t*)
      malloc(sizeof(mdtm_rrd_data_element_t) * file->data_format_n);
  if(data == NULL)
    return NULL;

  memset(data, sizeof(data), 0);
  for(i = 0; i < file->data_format_n; i++) {
      data[i].name =file->data_format[i];
      data[i].value = 0;
  }

  return data;
}

void
mdtm_rrddata_free(void *data)
{
  mdtm_rrd_data_element_t *     data_elem = (mdtm_rrd_data_element_t *)data;
  if(data_elem)
    free(data_elem);
}

int
mdtm_rrddata_set(void* data, char* name, size_t value)
{
  mdtm_rrd_data_element_t *     data_element = (mdtm_rrd_data_element_t *) data;
  int                           result = -1;

  while(data_element) {
      if(data_element->name == 0)
        break;
      if(!strcmp(data_element->name, name)) {
          data_element->value = value;
          result = 0;
          break;
      }
      else
        data_element = data_element + 1;
  }
  return result;
}

void
mdtm_rrddata_get(void* data)
{
  return;
}

int
mdtm_rrdfile_write(mdtm_rrd_file_t *rrdfile, void* data)
{
  char **                       argv;
  int                           argc = 0, offset;
  char                          tmpstr[MDTM_RRD_DATA_ELEM_SIZE];
  char *                        format;
  int                           consumed, n, i;
  mdtm_rrd_file_t *             file = rrdfile;
  mdtm_rrd_data_element_t *     data_element = (mdtm_rrd_data_element_t *) data;

  if(!file->created)
    mdtm_rrdfile_create(rrdfile);

  argv = (char**)malloc(
      (sizeof(char*) + MDTM_RRD_OPT_ELEM_SIZE) * MDTM_RRD_OPT_ELEM_MAXNUM +
      (sizeof(char*) + MDTM_RRD_DATA_ELEM_SIZE) * MDTM_RRD_DATA_ELEM_MAXNUM);
  offset = sizeof(char*) * (MDTM_RRD_OPT_ELEM_MAXNUM + MDTM_RRD_DATA_ELEM_MAXNUM);

  //write file path
  argv[argc] = (char*)argv + offset;
  n = snprintf(argv[argc++], MDTM_RRD_OPT_ELEM_SIZE, "%s", "update") + 1;
  offset += n;
  argv[argc] = (char*)argv + offset;
  n = snprintf(argv[argc++], MDTM_RRD_OPT_ELEM_SIZE, "%s", file->fullpath) + 1;
  offset += n;

  //write options & data elements
  consumed = 0;
  n = sprintf(tmpstr + consumed, "%s", "N");
  consumed += n;
  for(i = 0; i < MDTM_RRD_DATA_ELEM_MAXNUM; i++) {
      format = file->data_format[i];
      if(format == 0)
        break;
      if(strcmp(format, data_element->name))
        break;
      n = sprintf(tmpstr + consumed, ":%lld", data_element->value);
      consumed += n;
      data_element += 1;
  }
  argv[argc] = (char*)argv + offset;
  snprintf(argv[argc++], MDTM_RRD_DATA_ELEM_SIZE, "%s",tmpstr);

  // flush to rrd file
  if(i==file->data_format_n) {
      rrd_update(argc, argv);
      if (rrd_test_error()) {
          fprintf(stdout, "ERROR: %s\n", rrd_get_error());
          rrd_clear_error();
          free(argv);
          return -1;
      }
      free(argv);
      return 0;
  }
  else {
      free(argv);
      return -1;
  }
}



