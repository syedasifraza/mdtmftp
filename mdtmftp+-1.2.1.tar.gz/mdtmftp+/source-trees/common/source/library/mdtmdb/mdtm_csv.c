/*
 * mdtm_cvs.c
 *
 *  Created on: Jul 24, 2015
 *      Author: liangz
 */

/*
 * mdtm_csv.c
 *
 *  Created on: Jul 24, 2015
 *      Author: liangz
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mdtm_csv.h"

//typedef struct _mdtm_csv_data_e_ {
//  int                           index;
//  struct _mdtm_csv_data_e_ *    next;
//}mdtm_csv_data_entry_t;

mdtm_csv_file_t*
mdtm_csvfile_open(char* path)
{
  mdtm_csv_file_t *     file;

  file = (mdtm_csv_file_t *)malloc(sizeof(mdtm_csv_file_t));
  if(file == 0)
    return NULL;
  file->created = 0;
  file->fullpath = strdup(path);
  file->fp = 0;
//  file->data_format = 0;
  file->data_format_n = 0;
  file->data = 0;
//  file->options.step = 10;
//  file->options.rra_avg = 2880;
//  file->options.rra_last = 2880;
  file->data_list_begin = 0;
  file->data_list_end = 0;

  return file;
}

void
mdtm_csvfile_close(mdtm_csv_file_t* csvfile)
{
  mdtm_csv_file_t * file = csvfile;
  if(file) {
      //TODO: destroy all data?
      free(file);
  }
  return;
}

void
mdtm_csvfile_setformat(mdtm_csv_file_t* csvfile, char* format)
{
  const char *  delim = ";,";
  int i = 0;
  mdtm_csv_file_t * file = csvfile;

  char *rest; // to point to the rest of the string after token extraction.
  char *token; // to point to the actual token returned.
  char *ptr = strdup(format);//hello; // make q point to start of hello.
  char *ptr_saved = ptr;

  while(1) {
      token = strtok_r(ptr, delim, &rest);
      if(token == NULL)
        break;
      file->data_format[i++] = strdup(token);
      ptr = rest;
  }
  file->data_format_n = i;
  free(ptr_saved);
  return;
}

static
int
mdtm_csvfile_create(mdtm_csv_file_t* csvfile)
{
  mdtm_csv_file_t *     file = csvfile;
  int                   rc = 0;

  file->fp = fopen(file->fullpath,"w+");
  if(file->fp == NULL)
    rc = -1;
  else
    file->created = 1;

  return rc;
}

static
void
mdtm_csvfile_destroy(mdtm_csv_file_t* csvfile)
{
  mdtm_csv_file_t *     file = csvfile;

  if(!csvfile)
    return;

  fclose(file->fp);
  file->created = 0;
}

mdtm_csv_data_element_t*
mdtm_csvdata_alloc(mdtm_csv_file_t *csvfile)
{
  mdtm_csv_file_t *     file = (mdtm_csv_file_t *)csvfile;
  mdtm_csv_data_element_t *     data;
  int                   i;

  data = (mdtm_csv_data_element_t*)
      malloc(sizeof(mdtm_csv_data_element_t) * file->data_format_n);
  if(data == NULL)
    return NULL;

  memset(data, 0, sizeof(mdtm_csv_data_element_t) * file->data_format_n);
  for(i = 0; i < file->data_format_n; i++) {
      data[i].name =file->data_format[i];
      data[i].value = 0;
      data[i].next = 0;
      data[i].data_format_n = file->data_format_n;
  }

  return data;
}

void
mdtm_csvdata_free(void *data)
{
  mdtm_csv_data_element_t *     data_elem = (mdtm_csv_data_element_t *)data;
  if(data_elem) {
      if(data_elem->svalue)
        free(data_elem->svalue);
    free(data_elem);
  }
}

int
mdtm_csvdata_set(void* data, char* name, size_t value)
{
  mdtm_csv_data_element_t *     data_element = (mdtm_csv_data_element_t *) data;
  int                           result = -1;
  int                           count = 0;

  while(data_element && count++ < data_element->data_format_n) {
      if(data_element->name == 0)
        break;
      if(!strcmp(data_element->name, name)) {
          data_element->value = value;
          result = 0;
          break;
      }
      else
        data_element = data_element + 1;
  }
  return result;
}


int
mdtm_csvdata_set_str(void* data, char* name, char* value)
{
  mdtm_csv_data_element_t *     data_element = (mdtm_csv_data_element_t *) data;
  int                           result = -1;
  int                           count = 0;

  while(data_element && count++ < data_element->data_format_n) {
      if(data_element->name == 0)
        break;
      if(!strcmp(data_element->name, name)) {
          if(data_element->svalue) free(data_element->svalue);
          data_element->svalue = strdup(value);
          result = 0;
          break;
      }
      else
        data_element = data_element + 1;
  }
  return result;
}

size_t
mdtm_csvdata_get(void* data, char* name)
{
  mdtm_csv_data_element_t *data_element = (mdtm_csv_data_element_t *) data;

  while(data_element) {
      if(data_element->name == 0)
        break;
      if(!strcmp(data_element->name, name)) {
          return data_element->value;
      }
      else
        data_element = data_element + 1;
  }
  return -1;
}

#if 0
int
mdtm_csvfile_write(void *csvfile, void* data)
{
  char **                       argv;
  int                           argc = 0, offset;
  char                          tmpstr[MDTM_CSV_DATA_ELEM_SIZE];
  char *                        format;
  int                           consumed, n, i;
  mdtm_csv_file_t *             file = csvfile;
  mdtm_csv_data_element_t *     data_element = (mdtm_csv_data_element_t *) data;

  if(!file->created)
    mdtm_csvfile_create(csvfile);

  argv = (char**)malloc(
      (sizeof(char*) + MDTM_CSV_OPT_ELEM_SIZE) * MDTM_CSV_OPT_ELEM_MAXNUM +
      (sizeof(char*) + MDTM_CSV_DATA_ELEM_SIZE) * MDTM_CSV_DATA_ELEM_MAXNUM);
  offset = sizeof(char*) * (MDTM_CSV_OPT_ELEM_MAXNUM + MDTM_CSV_DATA_ELEM_MAXNUM);

  //write file path
  argv[argc] = (char*)argv + offset;
  n = snprintf(argv[argc++], MDTM_CSV_OPT_ELEM_SIZE, "%s", "update") + 1;
  offset += n;
  argv[argc] = (char*)argv + offset;
  n = snprintf(argv[argc++], MDTM_CSV_OPT_ELEM_SIZE, "%s", file->fullpath) + 1;
  offset += n;

  //write options & data elements
  consumed = 0;
  n = sprintf(tmpstr + consumed, "%s", "N");
  consumed += n;
  for(i = 0; i < MDTM_CSV_DATA_ELEM_MAXNUM; i++) {
      format = file->data_format[i];
      if(format == 0)
        break;
      if(strcmp(format, data_element->name))
        break;
      n = sprintf(tmpstr + consumed, ":%d", data_element->value);
      consumed += n;
      data_element += 1;
  }
  argv[argc] = (char*)argv + offset;
  snprintf(argv[argc++], MDTM_CSV_DATA_ELEM_SIZE, "%s",tmpstr);

  // flush to csv file
  if(i==file->data_format_n) {
      csv_update(argc, argv);
      if (csv_test_error()) {
          fprintf(stdout, "ERROR: %s\n", csv_get_error());
          csv_clear_error();
          return -1;
      }
      return 0;
  }
  else
    return -1;
}
#endif

int
mdtm_csvfile_add_data(mdtm_csv_file_t *csvfile, void *data)
{
  mdtm_csv_file_t *             file = csvfile;
  mdtm_csv_data_element_t *     data_element = (mdtm_csv_data_element_t *) data, *begin, *end;


  if(!csvfile || !data)
    return -1;

  begin = (mdtm_csv_data_element_t *)file->data_list_begin;
  end = (mdtm_csv_data_element_t *)file->data_list_end;


  if(!begin)
    begin = end = data_element;
  else {
      end->next = data_element;
      end = data_element;
  }

  file->data_list_begin = begin;
  file->data_list_end = end;

  return 0;
}

void*
mdtm_csvfile_lookup_data(mdtm_csv_file_t *csvfile, char* name, int value)
{
  mdtm_csv_file_t *             file = csvfile;
  mdtm_csv_data_element_t *     ptr = 0;
  int                           found = 0, i;

  for(ptr = (mdtm_csv_data_element_t *)file->data_list_begin; ptr != 0; ptr = ptr->next) {
      for(i = 0; i < file->data_format_n; i++) {
          if(!strcmp(ptr[i].name, name) && (ptr[i].value == value)) {
              found = 1;
              break;
          }
      }
      if(found)
        break;
  }
  return found? (void*)ptr : 0;
}

void
mdtm_csvfile_remove_data(mdtm_csv_file_t *csvfile, void* data)
{
  mdtm_csv_file_t *             file = csvfile;
  mdtm_csv_data_element_t       *cur_ptr, *prev_ptr;

  prev_ptr= (mdtm_csv_data_element_t *)file->data_list_begin;
  for(cur_ptr = (mdtm_csv_data_element_t *)file->data_list_begin; cur_ptr != 0; cur_ptr = cur_ptr->next) {
      if(cur_ptr == (mdtm_csv_data_element_t *)data) {
          prev_ptr->next = cur_ptr->next;
          if((void*)cur_ptr == file->data_list_begin) {
              file->data_list_begin = cur_ptr->next;
          }
          if((void*)cur_ptr == file->data_list_end)
            file->data_list_end = (void*)prev_ptr;
          break;
      }
      prev_ptr = cur_ptr;
  }
  return;
}

int
mdtm_csvfile_flush_data(mdtm_csv_file_t *csvfile)
{
  mdtm_csv_file_t *             file = (mdtm_csv_file_t *)csvfile;
  mdtm_csv_data_element_t *     ptr = 0;
  int                           i;

  if(!file)
    return -1;

  if(!file->created)
    if(mdtm_csvfile_create(file) < 0)
      return -1;

  fprintf(file->fp, "#");
  for(i = 0; i < file->data_format_n - 1; i++) {
      if(strcmp(file->data_format[i], "dir"))
        fprintf(file->fp, "%s,", file->data_format[i]);
  }
  fprintf(file->fp, "%s\n", file->data_format[i]);

  for(ptr = (mdtm_csv_data_element_t *)file->data_list_begin; ptr != 0; ptr = ptr->next) {
      for(i = 0; i < file->data_format_n - 1; i++) {
          if(strcmp(ptr[i].name, "dir"))
            fprintf(file->fp, "%llu,", (long long)ptr[i].value);
      }
      fprintf(file->fp, "%s\n", ptr[i].svalue);       //TODO: hard code. Added type flag
  }
  mdtm_csvfile_destroy(file);

  return 0;
}

int
mdtm_csvfile_aggregate_data(
    mdtm_csv_file_t *csvfile,
    mdtm_cvs_aggr_t *aggr_in,
    mdtm_cvs_aggr_t *aggr_out)
{
  mdtm_csv_file_t *             file = (mdtm_csv_file_t *)csvfile;
  mdtm_csv_data_element_t *     ptr = 0;
  int                           i, count_in, count_out, in0out1, *count;
  int                           local_ip = 0;
  mdtm_cvs_aggr_t *             aggr = 0;

  if(!file || !aggr_in || !aggr_out)
    return -1;

//  if(!file->created)
//    mdtm_csvfile_create(file);

  aggr_in->nsid = aggr_out->nsid = 0;
  aggr_in->size = aggr_out->size = 0;
  aggr_in->xfr = aggr_out->xfr = 0;
  aggr_in->rate = aggr_out->rate =0;
  count_in = count_out = 0;

  ptr = (mdtm_csv_data_element_t *)file->data_list_begin;
  if(ptr){
      for(; ptr != 0; ptr = ptr->next) {
          in0out1 = -1;
          for(i = 0; i < file->data_format_n ; i++) {
              if(!strcmp(ptr[i].name, "dir")) {
                in0out1 = (int)ptr[i].value;
                break;
              }
          }
          if(in0out1 < 0)
            return -1;
          else if(in0out1 == 0) {
            aggr = aggr_in;
            count = &count_in;
          }
          else {
            aggr = aggr_out;
            count = &count_out;
          }
          for(i = 0; i < file->data_format_n ; i++) {
              if(!strcmp(ptr[i].name, "size"))
                aggr->size += ptr[i].value;
              if(!strcmp(ptr[i].name, "xfr"))
                aggr->xfr += ptr[i].value;
              if(!strcmp(ptr[i].name, "rate"))
                aggr->rate += ptr[i].value;
          }
          (*count) += 1;
      }
      aggr_in->nsid = count_in;
      aggr_out->nsid = count_out;
  }
//  mdtm_csvfile_destroy(file);

  return 0;
}



