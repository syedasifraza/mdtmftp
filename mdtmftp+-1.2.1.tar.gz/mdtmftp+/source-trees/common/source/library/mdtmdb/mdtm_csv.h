/*
 * mdtm_csv.h
 *
 *  Created on: Jul 29, 2015
 *      Author: liangz
 */

#ifndef MDTM_CSV_H_
#define MDTM_CSV_H_

#define MDTM_CSV_OPT_ELEM_MAXNUM        16
#define MDTM_CSV_OPT_ELEM_SIZE          128
#define MDTM_CSV_DATA_ELEM_MAXNUM       64
#define MDTM_CSV_DATA_ELEM_SIZE         256

typedef struct {
  int           step;
  int           rra_avg;
  int           rra_last;
}mdtm_csv_option_t;

typedef struct _csv_file_ {
  int                           created;
  char *                        fullpath;
  FILE *                        fp;
  char *                        data_format[MDTM_CSV_DATA_ELEM_MAXNUM];
  int                           data_format_n;
  void *                        data;
  mdtm_csv_option_t             options;
  void *                        data_list_begin;
  void *                        data_list_end;
}mdtm_csv_file_t;

typedef struct _mdtm_csv_dataelem_{
  struct _mdtm_csv_dataelem_ *          next;
  char *                                name;
  size_t                                value;
  char *                                svalue;
  int                                   data_format_n;
}mdtm_csv_data_element_t;

typedef struct {
  int           nsid;
  size_t        size;
  size_t        xfr;
  size_t        rate;
} mdtm_cvs_aggr_t;

mdtm_csv_file_t*
mdtm_csvfile_open(char* path);

void
mdtm_csvfile_close(mdtm_csv_file_t* csvfile);

void
mdtm_csvfile_setformat(mdtm_csv_file_t* csvfile, char* format);

mdtm_csv_data_element_t*
mdtm_csvdata_alloc(mdtm_csv_file_t *csvfile);

void
mdtm_csvdata_free(void *data);

int
mdtm_csvdata_set(void* data, char* name, size_t value);

size_t
mdtm_csvdata_get(void* data, char* name);

int
mdtm_csvdata_set_str(void* data, char* name, char* value);

/*
 * Adding data to the list for csvfile.
 */
int
mdtm_csvfile_add_data(mdtm_csv_file_t *csvfile, void *data);

void*
mdtm_csvfile_lookup_data(mdtm_csv_file_t *csvfile, char* name, int value);

/*
 * Removing data from the list for csvfile.
 */
void
mdtm_csvfile_remove_data(mdtm_csv_file_t *csvfile, void* data);

int
mdtm_csvfile_flush_data(mdtm_csv_file_t *csvfile);

int
mdtm_csvfile_aggregate_data(
    mdtm_csv_file_t *csvfile,
    mdtm_cvs_aggr_t *aggr_in,
    mdtm_cvs_aggr_t *aggr_out);


#endif /* MDTM_CSV_H_ */
