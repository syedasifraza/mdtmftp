/*
 * mdtm_rrd.h
 *
 *  Created on: Jul 28, 2015
 *      Author: liangz
 */

#ifndef MDTM_RRD_H_
#define MDTM_RRD_H_

#define MDTM_RRD_OPT_ELEM_MAXNUM        10
#define MDTM_RRD_OPT_ELEM_SIZE          128
#define MDTM_RRD_DATA_ELEM_MAXNUM       50
#define MDTM_RRD_DATA_ELEM_SIZE         256

typedef struct {
  int           step;
  int           rra_avg;
  int           rra_last;
}mdtm_rrd_option_t;

typedef struct _rrd_file_ {
  int                           created;
  char *                        fullpath;
  char *                        data_format[MDTM_RRD_DATA_ELEM_MAXNUM];
  int                           data_format_n;
  void *                        data;
  mdtm_rrd_option_t             options;
}mdtm_rrd_file_t;

typedef struct {
  char *        name;
  size_t        value;
}mdtm_rrd_data_element_t;

mdtm_rrd_file_t*
mdtm_rrdfile_open(char* path);

void
mdtm_rrdfile_close(mdtm_rrd_file_t* rrdfile);

void
mdtm_rrdfile_setformat(mdtm_rrd_file_t* rrdfile, char* format);

int
mdtm_rrdfile_write(mdtm_rrd_file_t *rrdfile, void* data);

mdtm_rrd_data_element_t*
mdtm_rrddata_alloc(mdtm_rrd_file_t *rrdfile);

void
mdtm_rrddata_free(void *data);

int
mdtm_rrddata_set(void* data, char* name, size_t value);

void
mdtm_rrddata_get(void* data);


#endif /* MDTM_RRD_H_ */
