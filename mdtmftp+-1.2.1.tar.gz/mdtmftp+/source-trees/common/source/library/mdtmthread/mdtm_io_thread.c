#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <globus_callback.h>
#include <globus_thread_pool.h>
#include <globus_libc.h>
#include <globus_thread_common.h>
//#include <globus_xio_system.h>
//#include "globus_ftp_control.h"
#include "mdtm.h"
#include "mdtm_io_thread.h"
#include "mdtmdb/mdtm_csv.h"

//typedef struct {
//  unsigned char flags;
//  pid_t pid;
//  pthread_t tid;
//  char* firstdevice;
//  char* secondarydevice;
//  unsigned boundcpu;
//}mdtm_thread_desc_t;

//extern
//globus_result_t
//globus_l_ftp_data_stripe_poll(globus_i_ftp_dc_handle_t *dc_handle);

#define MDTM_IO_TABLE_PRENUMBER                 MDTM_IO_THREADS_MAX
#define MDTM_IO_THREAD_START_TIMER_COUNT        (100)     // time slot count
#define MDTM_IO_THREAD_START_TIMER_SLOT         (50000)   // 50 ms each time slot
#define MDTM_EVENTQ_POLL_INTERVAL               (20)     // us

typedef struct {
  struct mdtm_device_s* device_info;
  mdtm_io_table_t* io_table;
  void* (*io_table_register)(void*, void*);
  void (*io_table_unregister)(void*, void*);
  mdtm_xio_activate_func        xio_act_func;
  mdtm_xio_setevent_func        xio_setevent_func;
} mdtm_thread_user_data_t;

//typedef struct
//{
//  globus_callback_func_t                func;
//    void *                              func_user_arg;
//} mdtm_thread_task_t;

///----------------
typedef struct {
  void (*func)(void*);
  void *data;
}mdtm_disk_thread_data_t;

typedef struct {
  void  (*func)(void*, void*,int);
  void  *data1;
  void  *data2;
  int   data3;
}mdtm_nic_thread_data_t;

//-----------


static mdtm_io_table_t *global_io_table = 0;

static pthread_mutex_t  mdtm_thread_mutex;

//TODO:
//static __thread globus_callback_handle_t          mdtm_ftp_write_callback_handle;
//static __thread globus_callback_handle_t          mdtm_disk_read_callback_handle;
//static void *gMonitor = 0;
void* (*gFunc)(void*);

//static __thread long long       thread_count= 0;

static mdtm_thread_desc_t *                             global_thread_descs = 0;
static int                                              global_thread_descs_count = 0;

static int                                              global_cpu_assigns_count = 128;
static int                                              global_cpu_assigns[128];

static int                                              global_preassign_cpus[3][128];


/*-----------------------------------------------------
 * MDTM IO table
 *-----------------------------------------------------*/
void
mdtm_io_table_init(mdtm_io_table_t **table)
{
  struct mdtm_io_entry_s **cur_ent;
  mdtm_io_table_t *t;

  t = (mdtm_io_table_t*) malloc(sizeof(mdtm_io_table_t) +
          sizeof(struct mdtm_io_entry_s*) * MDTM_IO_TABLE_PRENUMBER);
  assert(t);

  globus_mutex_init(&t->mutex, GLOBUS_NULL);
  pthread_mutex_init(&t->pmutex, NULL);
  t->number = 0;
  t->capacity = MDTM_IO_TABLE_PRENUMBER;
  t->entry = cur_ent = (struct mdtm_io_entry_s**) (t + 1);
  *table = t;
  return;
}

void
mdtm_io_table_deinit(mdtm_io_table_t *table)
{
//  int i;
//  for( i = 0; i < table->number;) {
//    free(&table->entry[i]);
//    i += MDTM_IO_TABLE_PRENUMBER;
//  }
//  free(table);
}

void
mdtm_io_table_add_entry(mdtm_io_table_t *table, struct mdtm_io_entry_s *ent)       //char *devname, void* eventq)
{
  globus_mutex_lock(&table->mutex);
  pthread_mutex_lock(&table->pmutex);
  if(table->number + 1 > table->capacity) {
      table->entry[table->number-1]->next = (struct mdtm_io_entry_s**)
          malloc(sizeof(struct mdtm_io_entry_s*) * MDTM_IO_TABLE_PRENUMBER);
      table->capacity += MDTM_IO_TABLE_PRENUMBER;
  }
//  table->entry[table->number].devname = strdup(devname);
//  table->entry[table->number].tid = pthread_self();
//  table->entry[table->number].eq = eventq;

  //TODO: critical: cross the boundary
  table->entry[table->number] = ent;
  table->number++;
  pthread_mutex_unlock(&table->pmutex);
  globus_mutex_unlock(&table->mutex);
}

void
mdtm_io_table_del_entry(mdtm_io_table_t *table, char *devname)
{
  //TODO: release resource
  return;
}

mdtm_event_queue_t*
mdtm_io_table_get_eventq(mdtm_io_table_t *table, char *dev)
{
  int i,num;
  mdtm_event_queue_t *eq;

  globus_mutex_lock(&table->mutex);
  pthread_mutex_lock(&table->pmutex);
  for(i = 0; i < table->number; i++) {
      if(!strcmp(table->entry[i]->devname, dev)) {
          eq = &table->entry[i]->eq;
          break;
      }
  }
  num = table->number;
  pthread_mutex_unlock(&table->pmutex);
  globus_mutex_unlock(&table->mutex);

  if( i == num)
    return 0;
  else
    //TODO: bounce up the queue ref count
    return eq;
}

int
mdtm_io_table_get_thread_desc(mdtm_io_table_t *table, mdtm_thread_desc_t * thread_descs)
{
  int i;

  if(table->number <= 0) return 0;

  globus_mutex_lock(&table->mutex);
  pthread_mutex_lock(&table->pmutex);
  for(i = 0; i < table->number; i++) {
      thread_descs[i].id.tid = table->entry[i]->tid;
      thread_descs[i].devices[0] = strdup(table->entry[i]->devname);
      thread_descs[i].flags = MDTM_CPUBIND_THREAD;
      thread_descs[i].numaindex = -1;
      thread_descs[i].type = table->entry[i]->type;
  }
  pthread_mutex_unlock(&table->pmutex);
  globus_mutex_unlock(&table->mutex);
  return i;
}

void*
mdtm_io_table_register( void* t, void *data)
{
  mdtm_io_table_t* table = (mdtm_io_table_t*)t;
  struct mdtm_io_entry_s *ent = (struct mdtm_io_entry_s *)data; //, *ent;

//  globus_mutex_lock(&table->mutex);
//  ent = &table->entry[table->number++];
//  ent->devname = strdup(e->devname);
//  ent->tid = e->tid;
//  ent->eq = e->eq;
//  globus_mutex_unlock(&table->mutex);
  mdtm_io_table_add_entry(table, ent);

  return 0;
}

void
mdtm_io_table_unregister( mdtm_io_table_t* table, char* devname)
{
  //TODO
  return;
}

/*-----------------------------------------------------
 * End of MDTM IO table
 *-----------------------------------------------------*/

// Nulll function
void mdtm_callback_unreg_cb(void* data)
{
  return;
}

void mdtm_eventq_poll(void* arg)
{
  mdtm_event_queue_t *eventq = (mdtm_event_queue_t *)arg;
  mdtm_thread_task_t  *task;

  //          globus_cond_timedwait(&eventq._cond, &eventq._mutex, 0);
  globus_mutex_lock(&eventq->_mutex);
  pthread_mutex_lock(&eventq->_pmutex);
  if(! globus_fifo_empty(&eventq->q)) {
      /* Execute task */
      //              globus_l_thread_pool_active_threads++;
      //              globus_l_thread_pool_idle_threads--;
      task = globus_fifo_dequeue(&eventq->q);
      //              globus_l_thread_pool_pending_tasks--;

      // stop polling event queue
      //      {
      //        globus_callback_unregister(
      //            mdtm_disk_read_callback_handle,
      //            mdtm_callback_unreg_cb,
      //            0,
      //            GLOBUS_NULL);
      //      }

      pthread_mutex_unlock(&eventq->_pmutex);
      globus_mutex_unlock(&eventq->_mutex);
      {
        task->func(task->func_user_arg);
        globus_free(task);
        //                globus_thread_blocking_reset();
        //                globus_l_thread_pool_key_clean();
        //                globus_libc_free(task);
      }
      //              globus_mutex_lock(&eventq._mutex);

      //              globus_l_thread_pool_idle_threads++;
      //              globus_l_thread_pool_active_threads--;
      //              timeout = globus_i_abstime_infinity;
  }
  else{
      pthread_mutex_unlock(&eventq->_pmutex);
      globus_mutex_unlock(&eventq->_mutex);
  }

  return;
}

/*-----------------------------------------------------
 * IO thread functions
 *-----------------------------------------------------*/
void*
mdtm_disk_io_thread(void *user_arg)
{
  globus_mutex_t                        globus_l_mutex;
  globus_cond_t                         globus_l_cond;
  globus_bool_t                         globus_l_closed = GLOBUS_FALSE;
  globus_condattr_t                     condattr;
  globus_callback_space_t               globus_l_space;
  mdtm_thread_user_data_t *             userdata;
  mdtm_event_queue_t *                  eventq;
  struct mdtm_io_entry_s *              ent;

  // activate callback
  mdtm_globus_l_callback_activate();

  globus_callback_space_init(&globus_l_space, NULL);
  globus_condattr_init(&condattr);
  globus_condattr_setspace(&condattr, globus_l_space);
  globus_cond_init(&globus_l_cond, &condattr);
  globus_mutex_init(&globus_l_mutex, NULL);

  //  mdtm_thread_globus_l_xio_system_activate(globus_l_space);
  userdata = (mdtm_thread_user_data_t*)user_arg;
  userdata->xio_act_func(globus_l_space);

  // init thread event queue and save it to the global io table
  {
    int efd;

    efd = eventfd(0, 0);
    if (efd == -1) {
      fprintf(stderr, "%s: eventfd failed. %s\n", __FUNCTION__, strerror(errno));
      return NULL;
    }

    ent = (struct mdtm_io_entry_s *)calloc(1, sizeof(struct mdtm_io_entry_s));
    ent->devname = userdata->device_info->name;
    ent->tid = pthread_self();
    ent->type = userdata->device_info->classid;
    globus_fifo_init(&ent->eq.q);
    globus_mutex_init(&ent->eq._mutex, GLOBUS_NULL);
    assert(pthread_mutex_init(&ent->eq._pmutex, GLOBUS_NULL) == 0);
    userdata->io_table_register(userdata->io_table, ent);
    eventq = &ent->eq;
    eventq->eventfd = efd;

    // register event queue with XIO
    if(userdata->xio_setevent_func(   //mdtm_xio_register_read_eventfd
        efd,(void *) eventq) != GLOBUS_SUCCESS) {
        fprintf(stderr, "%s: mdtm_xio_register_read_eventfd failed. %s\n", __FUNCTION__, strerror(errno));
        close(efd);
        return NULL;
    }
  }

  //mdtmftp: DEBUG: add one more thread
  {
    printf("[%lu]%s %d: %s: IO thread Ready on device %s: evenq=%p\n",
        syscall(SYS_gettid),__FILE__, __LINE__, __FUNCTION__,
        userdata->device_info->name, eventq);
  }
  //mdtmftp: DEBUG

  globus_mutex_lock(&globus_l_mutex);
  {
    while(!globus_l_closed)
      {
        globus_cond_wait(&globus_l_cond, &globus_l_mutex);
      }
  }
  globus_mutex_unlock(&globus_l_mutex);

//  userdata->io_table_unregister(userdata->io_table, &threadid);

  pthread_mutex_destroy(&ent->eq._pmutex);
  globus_mutex_destroy(&ent->eq._mutex);
  globus_fifo_destroy(&ent->eq.q);
  close(ent->eq.eventfd);
  free(ent);

//  mdtm_thread_globus_l_xio_system_deactivate();
  globus_mutex_destroy(&globus_l_mutex);
  globus_cond_destroy(&globus_l_cond);
  globus_condattr_destroy(&condattr);
  globus_callback_space_destroy(globus_l_space);
  mdtm_globus_l_callback_deactivate();

  return 0;
}

//int
//mdtm_gridftp_server_write(void *monitor, void* buffer, int nbytes, void(*func)(void*, void*, int))
//{
//  static pthread_t sender_threadid;
//  mdtm_nic_thread_data_t *user_arg = (mdtm_nic_thread_data_t*)malloc(sizeof(mdtm_nic_thread_data_t));
//
//  static int thread_created = 0;
//  if(!thread_created) {
//      user_arg->func = func;
//      user_arg->data1 = monitor;
//      user_arg->data2 = buffer;
//      user_arg->data3 = nbytes;
//      pthread_create(&sender_threadid, NULL, &mdtm_nic_write_thread, user_arg);
//      thread_created = 1;
//  }
//  return 0;
//}

//------------------------------

//typedef struct {
//  void (*func)(void*);
//  void *data;
//}mdtm_ftp_thread_data_t;

void*
mdtm_net_io_thread(void *user_arg)
{
  globus_mutex_t                        globus_l_mutex;
  globus_cond_t                         globus_l_cond;
  globus_bool_t                         globus_l_closed = GLOBUS_FALSE;
  globus_condattr_t                     condattr;
  globus_callback_space_t               globus_l_space;
  mdtm_thread_user_data_t *             userdata;
  mdtm_event_queue_t *                  eventq;
  int                                   err;
  struct mdtm_io_entry_s *              ent;

  //activate thread_common module for blocking callbacks
  pthread_mutex_lock(&mdtm_thread_mutex);
  err = globus_i_thread_common_module.activation_func();
  pthread_mutex_unlock(&mdtm_thread_mutex);
  assert(err == GLOBUS_SUCCESS);

  // activate callback
  mdtm_globus_l_callback_activate();

  globus_callback_space_init(&globus_l_space, NULL);
  globus_condattr_init(&condattr);
  globus_condattr_setspace(&condattr, globus_l_space);
  globus_cond_init(&globus_l_cond, &condattr);
  globus_mutex_init(&globus_l_mutex, NULL);

  // activate xio
  userdata = (mdtm_thread_user_data_t*)user_arg;
  userdata->xio_act_func(globus_l_space);       // ==>mdtm_thread_globus_l_xio_system_activate

  // initialize thread's event queue and register this thread with the thread table
  {
    int efd;

    efd = eventfd(0, 0);
    if (efd == -1) {
      fprintf(stderr, "%s: eventfd failed. %s\n", __FUNCTION__, strerror(errno));
      return NULL;
    }

    ent = (struct mdtm_io_entry_s *)calloc(1, sizeof(struct mdtm_io_entry_s));
    ent->devname = userdata->device_info->name;
    ent->tid = pthread_self();
    ent->type = userdata->device_info->classid;
    globus_fifo_init(&ent->eq.q);
    globus_mutex_init(&ent->eq._mutex, GLOBUS_NULL);
    assert(pthread_mutex_init(&ent->eq._pmutex, GLOBUS_NULL) == 0);
    userdata->io_table_register(userdata->io_table, ent);
    eventq = &ent->eq;
    eventq->eventfd = efd;

    // register event queue with XIO
    if(userdata->xio_setevent_func(   //mdtm_xio_register_read_eventfd
        efd,
        (void *) eventq) != GLOBUS_SUCCESS) {
        fprintf(stderr, "%s: mdtm_xio_register_read_eventfd failed. %s\n", __FUNCTION__, strerror(errno));
        close(efd);
        return NULL;
    }
  }

  //mdtmftp: DEBUG: add one more thread
  {
    printf("[%lu]%s %d: %s: IO thread Ready on device %s: evenq=%p\n",
        syscall(SYS_gettid),__FILE__, __LINE__, __FUNCTION__,
        userdata->device_info->name, eventq);
  }
  //mdtmftp: DEBUG

  globus_mutex_lock(&globus_l_mutex);
  {
    while(!globus_l_closed)
      {
        globus_cond_wait(&globus_l_cond, &globus_l_mutex);
      }
  }
  globus_mutex_unlock(&globus_l_mutex);

  pthread_mutex_destroy(&ent->eq._pmutex);
  globus_mutex_destroy(&ent->eq._mutex);
  globus_fifo_destroy(&ent->eq.q);
  close(ent->eq.eventfd);
  free(ent);

  //  mdtm_thread_globus_l_xio_system_deactivate();
  globus_mutex_destroy(&globus_l_mutex);
  globus_cond_destroy(&globus_l_cond);
  globus_condattr_destroy(&condattr);
  globus_callback_space_destroy(globus_l_space);
  mdtm_globus_l_callback_deactivate();

  return 0;

}

void
mdtm_set_dchandle(void* handle){

}

/*-----------------------------------------------------
 * End of IO thread functions
 *-----------------------------------------------------*/

/*-----------------------------------------------------
 * Being of mdtm_io_thrd_mgr
 *-----------------------------------------------------*/
mdtm_io_thrd_mgr_list_t *global_io_thrd_mgr_list = 0;

static
mdtm_io_thrd_mgr_list_t*
mdtm_io_thrd_mgr_list_create()
{
  int ndevices = 64;     //TODO: call mdtm api to get the ndevices value
  mdtm_io_thrd_mgr_list_t *temp;

  temp =
      (mdtm_io_thrd_mgr_list_t*) malloc(sizeof(mdtm_io_thrd_mgr_list_t) + ndevices * sizeof(mdtm_io_thrd_mgr_t*));
  if(temp) {
      temp->entry = (mdtm_io_thrd_mgr_t**)(temp + 1);
      temp->capacity = ndevices;
      temp->used = 0;
  }

  return temp;
}

/* \brief
 *
 */
static
int
mdtm_io_thrd_mgr_list_insert(mdtm_io_thrd_mgr_t *mgr)
{
  if(!global_io_thrd_mgr_list) {
      global_io_thrd_mgr_list = mdtm_io_thrd_mgr_list_create();
  }

  if(!global_io_thrd_mgr_list || (global_io_thrd_mgr_list->used >= global_io_thrd_mgr_list->capacity))
    return -1;

  global_io_thrd_mgr_list->entry[global_io_thrd_mgr_list->used++] = mgr;
  return global_io_thrd_mgr_list->used;
}

/* \brief get the mgr if the criteria matches
 *
 */
mdtm_io_thrd_mgr_t *
mdtm_io_thrd_mgr_list_get(const char *devname)
{
  int i, found = 0, min;

  if(!global_io_thrd_mgr_list)
    return 0;

  min = (global_io_thrd_mgr_list->capacity < global_io_thrd_mgr_list->used)?global_io_thrd_mgr_list->capacity:global_io_thrd_mgr_list->used;
  for(i = 0; i < min; i++) {
      if(!strcmp(global_io_thrd_mgr_list->entry[i]->devio_info->name, devname)){
          found = 1;
          break;
      }
  }
  return found==1?global_io_thrd_mgr_list->entry[i] : 0;
}

/* \brief get the mgr if the criteria matches
 *
 */
mdtm_io_thrd_mgr_t *
mdtm_io_thrd_mgr_list_get2(const char *devname, const int type)
{
  int i, found = 0, min;

  if(!global_io_thrd_mgr_list)
    return 0;

  if(devname)
    return mdtm_io_thrd_mgr_list_get(devname);

  min = (global_io_thrd_mgr_list->capacity < global_io_thrd_mgr_list->used)?global_io_thrd_mgr_list->capacity:global_io_thrd_mgr_list->used;

  for(i = 0; i < min; i++) {
      if(global_io_thrd_mgr_list->entry[i]->devio_info->classid == type) {
          found = 1;
          break;
      }
  }
  return found==1?global_io_thrd_mgr_list->entry[i] : 0;
}

/* \brief Get the number threads for the given thread manager
 *
 */
int
mdtm_io_thrd_mgr_getthrdnum(mdtm_io_thrd_mgr_t *mgr)
{
  return mgr->num_iothreads;
}

/* \brief
 *
 * @param       cand    bitmask of the scheduled threads
 * @param       policy  scheduling policy. RR by default.
 * @return              number of scheduled threads
 */
int
mdtm_io_thrd_mgr_sched(mdtm_io_thrd_mgr_t *mgr, int ntask, unsigned int *cand, int policy)
{
  int nthreads, count = -1;

 //LZ: TODO: default scheduling policy is round robin
  switch(policy)
  {
  case 0:
  default:
    {
      int start, next, size, i;

      pthread_mutex_lock(&mgr->lock);
      nthreads = mdtm_io_thrd_mgr_getthrdnum(mgr);
      start = mgr->next_thread;
      size = mgr->num_iothreads;
      *cand  = 0;
      count = ((ntask > 0) && (ntask <= nthreads))? ntask : nthreads;
      for(i = 0; i < count; i++) {
        *cand |=   1 << ((start + i) % size);
        next = ++mgr->next_thread % size;
        mgr->next_thread = next;
      }
      pthread_mutex_unlock(&mgr->lock);
    }
  }
  return count;
}

/* \brief check if all threads already started. Time out after 1 second
 *
 */
static
int
mdtm_io_thrd_isstarted(mdtm_io_table_t *table, int target)
{
  int count = MDTM_IO_THREAD_START_TIMER_COUNT;
  int done = 0;

  while(count--) {
      globus_mutex_lock(&table->mutex);
      pthread_mutex_lock(&table->pmutex);
      if(table->number >= target) {
          done = 1;
          globus_mutex_unlock(&table->mutex);
          pthread_mutex_unlock(&table->pmutex);
          break;
      }
      pthread_mutex_unlock(&table->pmutex);
      globus_mutex_unlock(&table->mutex);
      usleep(MDTM_IO_THREAD_START_TIMER_SLOT);
  }
  return done? 1 : 0;
}

/* \brief Start IO threads on the given device
 *
 * @param mgr   Pointer to the device IO thread manager
 *
 * @return      Status of the threads. 1: started 0: not started yet
 */
static
int
mdtm_io_thrd_start(mdtm_io_thrd_mgr_t *mgr, mdtm_thread_func_set_t *funcset)
{
  mdtm_thread_user_data_t *user_data = (mdtm_thread_user_data_t *)malloc(sizeof(mdtm_thread_user_data_t));
  void* (*func)(void*);
  int num_threads = 0, n = 0;

  user_data->device_info = mgr->devio_info;
  user_data->io_table = mgr->iothreads; //global_io_table;
  user_data->io_table_register = mdtm_io_table_register;
  user_data->io_table_unregister = 0;
  user_data->xio_act_func = funcset->actfunc;
  user_data->xio_setevent_func = funcset->seteventfunc;
  num_threads = mdtm_config_get_threadsperdevice(mgr->devio_info->name);
  if(num_threads > MDTM_IO_THREADS_MAX)
    num_threads = MDTM_IO_THREADS_MAX;

  switch(mgr->devio_info->classid) {
  case MDTM_DEVICE_CLASS_STORAGE:
    func = funcset->diskfunc;   //mdtm_disk_io_thread;
    n = num_threads;
    break;
  case MDTM_DEVICE_CLASS_NETWORK:
    func = funcset->netfunc;    //mdtm_net_io_thread;
    n = num_threads;
    break;
  case MDTM_DEVICE_CLASS_VIRTUAL:
    func = funcset->manfunc;    //mdtm_man_thread;
    n = num_threads;
    break;
  default:
    break;
  }

  while(n-- > 0) {
      if(func)
        globus_i_thread_start(func, user_data);
  }

  //check if the threads are started within 1 second
  return mdtm_io_thrd_isstarted(mgr->iothreads, num_threads)? num_threads : 0;
}

/* \brief Create IO thread manager object
 *
 *@param        mgr     pointer to the thread manager of the device
 *@param        devio   device information
 *@param        funcset functions
 *
 * @return:      number of threads allocated for device if success, -1 if failed
 */
static
int
mdtm_io_thrd_mgr_create(
    mdtm_io_thrd_mgr_t **       mgr,
    struct mdtm_device_s*       devio,
    mdtm_thread_func_set_t *    funcset)
{
  mdtm_io_thrd_mgr_t *  temp;
  int                   rc;

  if((temp = (mdtm_io_thrd_mgr_t *)
      calloc(1, sizeof(mdtm_io_thrd_mgr_t))) == 0)
    return -1;

  temp->devio_info = devio;
  mdtm_io_table_init(&temp->iothreads);
  temp->num_iothreads = rc = mdtm_io_thrd_start(temp, funcset);
  if(temp->num_iothreads <= 0) {
      free(temp);
      return rc;
  }
  assert(pthread_mutex_init(&temp->lock, GLOBUS_NULL) == 0);
  temp->next_thread = 0;

//  mdtm_io_thrd_mgr_list_insert(temp);
  *mgr = temp;
  return rc;
}

static int g_eventq_table_handle = -1;

/* \brief
 *
 */
int
mdtm_thrd_eventq_insert(void*key, void*eventq)
{
  if(!eventq|| !key)
    return -1;
  if(g_eventq_table_handle < 0)
    g_eventq_table_handle = mdtm_map_create();
  mdtm_map_insert(g_eventq_table_handle, key, eventq);
  return 0;
}

/* \brief
 *
 */
void*
mdtm_thrd_eventq_remove(void* key)
{
  void *value = 0;
  if((g_eventq_table_handle < 0) || !key)
    return 0;
  value = mdtm_map_remove(g_eventq_table_handle, key);
  return value;
}

/* \brief
 *
 */
void
mdtm_thrd_dispatch(
    void *q,
    globus_callback_func_t func,
    void *user_arg)
{
  mdtm_thread_task_t *task;
  mdtm_event_queue_t *eventq = (mdtm_event_queue_t*)q;

  if(!q)
    return;

  // break down the reading task
  task  = (mdtm_thread_task_t*)malloc(sizeof(mdtm_thread_task_t));
  if(!task) {
      printf("MDTM error @%s:%s: memory not available\n", __FILE__, __FUNCTION__);
      return;
  }
  task->func = func;
  task->func_user_arg = user_arg;

  // assign the tasks to reading thread eventq
  globus_mutex_lock(&eventq->_mutex);
//  pthread_mutex_lock(&eventq->_pmutex);
  if(globus_fifo_enqueue(&eventq->q, task) < 0) {
      printf("MDTM error @%s:%s: fifo enqueue failed\n", __FILE__, __FUNCTION__);
//      pthread_mutex_unlock(&eventq->_pmutex);
      globus_mutex_unlock(&eventq->_mutex);
      return;
  }
//  pthread_mutex_unlock(&eventq->_pmutex);
  globus_mutex_unlock(&eventq->_mutex);
}

globus_result_t
mdtm_thrd_dispatch_task(
    mdtm_event_queue_t *        eventq,
    globus_callback_func_t      func,
    void *                      user_arg)
{
  mdtm_thread_task_t *  task;

//  eventq = &(mgr->iothreads->entry[id]->eq);
  if(!eventq) {
      fprintf(stderr, "MDTM error @%s:%s: eventq not found\n", __FILE__, __FUNCTION__);
      return GLOBUS_FAILURE;
  }

  // create the task
  task  = (mdtm_thread_task_t*)malloc(sizeof(mdtm_thread_task_t));
  if(!task) {
      fprintf(stderr, "MDTM error @%s:%s: memory not available\n", __FILE__, __FUNCTION__);
      return GLOBUS_FAILURE;
  }
  task->func = func;
  task->func_user_arg = user_arg;

  // enqueue the task
  globus_mutex_lock(&eventq->_mutex);
  pthread_mutex_lock(&eventq->_pmutex);

  if(globus_fifo_enqueue(&eventq->q, task) < 0) {
      fprintf(stderr, "MDTM error @%s:%s: fifo enqueue failed\n", __FILE__, __FUNCTION__);
      pthread_mutex_unlock(&eventq->_pmutex);
      globus_mutex_unlock(&eventq->_mutex);
      return GLOBUS_FAILURE;
  }

  // notify that a new task has been put into queue
  {
    uint64_t    u = 1;
    ssize_t     s;

    s = write(eventq->eventfd, &u, sizeof(uint64_t));
    if(s != sizeof(uint64_t))
      fprintf(stderr, "%s: write to eventfd failed: %s\n", __FUNCTION__, strerror(errno));
  }

  pthread_mutex_unlock(&eventq->_pmutex);
  globus_mutex_unlock(&eventq->_mutex);

  return GLOBUS_SUCCESS;
}

/* \brief  Dispatch the input function to a running thread using round-robin policy
 *
 * @param       mgr             pointer to the io-thread manager
 * @param       func            pointer to the function to be dispatched
 * @param       user_arg        argument to the function
 *
 * @return                      return 0 if successful; otherwise negative value
 */
int
mdtm_io_thrd_mgr_dispatch(
    mdtm_io_thrd_mgr_t *mgr,
    globus_callback_func_t func,
    void *user_arg)
{

  mdtm_event_queue_t *eventq;
  mdtm_thread_task_t *task;
  int next;

  // round robin
  eventq = &(mgr->iothreads->entry[mgr->next_thread]->eq);
  if(!eventq) {
      printf("MDTM error @%s:%s: eventq not found\n", __FILE__, __FUNCTION__);
      return -1;
  }
  printf("DBG: %s:%d mgr=%s eventq=%p\n",__FILE__,__LINE__, mgr->devio_info->name, eventq);

  next = ++(mgr->next_thread) % mgr->num_iothreads;
  mgr->next_thread = next;

  // break down the reading task
  task  = (mdtm_thread_task_t*)malloc(sizeof(mdtm_thread_task_t));
  if(!task) {
      printf("MDTM error @%s:%s: memory not available\n", __FILE__, __FUNCTION__);
      return -1;
  }
  task->func = func;
  task->func_user_arg = user_arg;

  // assign the tasks to reading thread eventq
  globus_mutex_lock(&eventq->_mutex);
  if(globus_fifo_enqueue(&eventq->q, task) < 0) {
      printf("MDTM error @%s:%s: fifo enqueue failed\n", __FILE__, __FUNCTION__);
      globus_mutex_unlock(&eventq->_mutex);
      return -1;
  }
  //      globus_cond_signal(&eventq->_cond);
  globus_mutex_unlock(&eventq->_mutex);

  return 0;
}

/* \brief  Wrap the given function into a task and dispatch it to the event queue of
 *         the specified IO thread
 *
 * @param       mgr             pointer to the io-thread manager of device
 * @param       id              index of the io-thread that would execute the function
 * @param       func            pointer to the function
 * @param       user_arg        argument to the function
 *
 * @return                      return 0 if successful; otherwise negative value
 */
int
mdtm_io_thrd_mgr_dispatch_to(
    mdtm_io_thrd_mgr_t *        mgr,
    int                         id,
    globus_callback_func_t      func,
    void *                      user_arg)
{
  mdtm_event_queue_t *  eventq;

  if ((id < 0) || (id >= mgr->num_iothreads))
      return -1;

  eventq = &(mgr->iothreads->entry[id]->eq);
  if(!eventq) {
      printf("MDTM error @%s:%s: eventq not found\n", __FILE__, __FUNCTION__);
      return -1;
  }

  if( mdtm_thrd_dispatch_task(eventq, func, user_arg) != GLOBUS_SUCCESS ) {
      fprintf(stderr,"%s: mdtm_thrd_dispatch_task failed.\n",__FUNCTION__);
      return -1;
  }

//  printf("DBG: %s:%d mgr=%s eventq=%p id=%d size=%d\n",__FILE__,__LINE__, mgr->devio_info->name, eventq, id, globus_fifo_size(&eventq->q));

  return 0;
}

int
mdtm_io_thrd_mgr_dispatch_all(
    mdtm_io_thrd_mgr_t *mgr,
    globus_callback_func_t func,
    void *user_arg)
{
  int                   id;
  mdtm_event_queue_t *  eventq;

  for(id = 0; id < mgr->num_iothreads; id++) {
      eventq = &(mgr->iothreads->entry[id]->eq);
      if(!eventq) {
          printf("MDTM error @%s:%s: eventq not found\n", __FILE__, __FUNCTION__);
          return -1;
      }

      if( mdtm_thrd_dispatch_task(eventq, func, user_arg) != GLOBUS_SUCCESS ) {
          fprintf(stderr,"%s: mdtm_thrd_dispatch_task failed.\n",__FUNCTION__);
          return -1;
      }
  }

  return 0;
}

const
struct mdtm_device_s*
mdtm_io_thrd_mgr_getdevinfo(mdtm_io_thrd_mgr_t *mgr)
{
  return mgr->devio_info;
}

const
char *
mdtm_io_thrd_mgr_getdevname(mdtm_io_thrd_mgr_t *mgr)
{
	return mgr->devio_info->name;
}

/* \brief Return the pthread_t of the thread with the given index in the thread array
 *
 */
pthread_t
mdtm_io_thrd_mgr_get_pthreadid(void* mgr, int index)
{
  mdtm_io_thrd_mgr_t *thrmgr = (mdtm_io_thrd_mgr_t *)mgr;

  if(index >= thrmgr->num_iothreads)
    return -1;

  return thrmgr->iothreads->entry[index]->tid;
}

/* \brief
 *
 */
int
isPowerOfTwo(unsigned int x)
{
  return ((x & (x - 1)) == 0);
}

/* \brief
 *
 */
// Returns position of the only set bit in 'n'
int findPosition(unsigned n)
{
    if (!isPowerOfTwo(n))
        return -1;

    unsigned i = 1, pos = 1;

    // Iterate through bits of n till we find a set bit
    // i&n will be non-zero only when 'i' and 'n' have a set bit
    // at same position
    while (!(i & n))
    {
        // Unset current bit and set the next bit in 'i'
        i = i << 1;

        // increment position
        ++pos;
    }

    return pos;
}

/* \brief
 *
 */
int
nthsetbit(unsigned value, int n)
{
  int i;

  for (i=0; i<n-1; i++) {
      value &= value-1; // remove the least significant bit
  }
  return value & ~(value-1); // extract the least significant bit
}

/* \brief
 *
 */
int
mdtm_util_nthsetbit(unsigned value, int n)
{
  return findPosition(nthsetbit(value,n));
}

/* \brief
 *
 */
int
mdtm_util_countsetbits(unsigned int bitmap)
{
  unsigned int count = 0;
  while (bitmap)
    {
      bitmap &= (bitmap - 1) ;
      count++;
    }
  return count;
}

#define MDTM_BIGNUME_1G         (1024ULL*1024ULL*1024ULL)
#define MDTM_BIGNUME_1M         (1024ULL*1024ULL)
int
mdtm_util_round(long long in, long long *out)
{
  long long around = 0;

  if(!out) return -1;

  while(around < in) {
      around += MDTM_BIGNUME_1M;
  }
  *out = around;

  return 0;
}
/* \brief
 *
 */
void
mdtm_io_thrd_mgr_delete()
{
  return;
}

/*-----------------------------------------------------
 * End of mdtm_iothrdmgr
 *-----------------------------------------------------*/


/*-----------------------------------------------------
 * API functions
 *-----------------------------------------------------*/
struct mdtm_io_thread_handle_s {
  struct mdtm_device_s* devices;        // pointer to the info of devices
  int ndevices;         // the number of devices
  int nactive;          // the number of active devices
  mdtm_thread_user_data_t *user_data;   //pointer to the first user data
  mdtm_io_table_t *io_table;    // pointer to the io table
};

/* \brief
 * Create threads for each NIC or DISK IO device and bind them to local CPU cores.
 *
 * Return       pointer to the device io handle or 0 if failed.
 */
void*
mdtm_io_thread_init(mdtm_thread_func_set_t *funcset, void * userdata)
{
  struct mdtm_device_s *        devices;
  int                           nDevices;
  int                           i, rc, numofdescs;
  mdtm_io_thrd_mgr_t *          mgr;
  char                          *cpufile = (char *) userdata;
  int                           cpu_place_enabled = 0;
  int                           ns, nn, nv;

  // Initialize mdtm module
  if(!mdtm_is_inited())
    return 0;

  // Initialize mutex between IO threads
  pthread_mutex_init(&mdtm_thread_mutex, NULL);

  // Get online device info
  nDevices = mdtm_config_getpcidevices(&devices);
  if (nDevices <= 0) {
      return 0;
  }

  if(!global_thread_descs) {
    global_thread_descs = (mdtm_thread_desc_t *)
      calloc(nDevices * MDTM_IO_THREADS_MAX, sizeof(mdtm_thread_desc_t));
    if ( global_thread_descs == NULL )
      return 0;
  }

  // Create mgr for each device and collect all thread information
  for(i = 0; i < nDevices; i++) {
      if(((devices[i].classid != MDTM_DEVICE_CLASS_NETWORK) &&
          (devices[i].classid != MDTM_DEVICE_CLASS_STORAGE) &&
          (devices[i].classid != MDTM_DEVICE_CLASS_VIRTUAL)) ||
          ((devices[i].classid == MDTM_DEVICE_CLASS_NETWORK)
              && !strcmp(devices[i].attr.network.operstate, "down")))
        continue;

      rc = mdtm_io_thrd_mgr_create(&mgr, &devices[i], funcset);
      if(rc <= 0) {
          fprintf(stderr,
              "[mdtmftp] warning: mdtm_io_thrd_mgr_create() on %s return %d.\n",
              devices[i].name, rc);
          continue;
      }
      mdtm_io_thrd_mgr_list_insert(mgr);
      numofdescs = mdtm_io_table_get_thread_desc(
          mgr->iothreads,
          &global_thread_descs[global_thread_descs_count]);
      global_thread_descs_count += numofdescs;
  }

  // place cpus on target devices if assigned in the configuration file
  if ( (mdtm_config_get_ncpu(&ns, &nn, &nv) == 0) && ns && ns) {
    int disk_count = 0, nic_count = 0, vir_count = 0;

    mdtm_config_get_cpus(
        global_preassign_cpus[0], 128,
        global_preassign_cpus[1], 128,
        global_preassign_cpus[2], 128);

    fprintf(stderr, "Storage:\n");
    for( i = 0; i < ns; i++)
      fprintf(stderr, "%d ", global_preassign_cpus[0][i]);
    fprintf(stderr, "\n");

    fprintf(stderr, "Network:\n");
    for( i = 0; i < nn; i++)
      fprintf(stderr, "%d ", global_preassign_cpus[1][i]);
    fprintf(stderr, "\n");

    fprintf(stderr, "Virtual:\n");
    for( i = 0; i < nv; i++)
      fprintf(stderr, "%d ", global_preassign_cpus[2][i]);
    fprintf(stderr, "\n");


    for ( i = 0; i < global_thread_descs_count; i++ ) {
      switch(global_thread_descs[i].type) {

      case 1:
        // nic
        global_cpu_assigns[i] = global_preassign_cpus[1][nic_count++%nn];
        break;

      case 2:
        // disk
        global_cpu_assigns[i] = global_preassign_cpus[0][disk_count++%ns];
        break;

      case MDTM_DEVICE_CLASS_VIRTUAL:
        if(nv > 0)
          global_cpu_assigns[i] = global_preassign_cpus[2][vir_count++%nv];
        else {
          fprintf(stderr, "ERROR: no cpus assigned to virtual devices.\n");
          return 0;
        }

        break;
      default:
        break;
      }
    }

    if(mdtm_place_threads(global_thread_descs, global_thread_descs_count, global_cpu_assigns, global_cpu_assigns_count) >= 0)
      cpu_place_enabled = 1;
  }

  if(!cpu_place_enabled) {
      // schedule threads on CPU cores
      if(mdtm_schedule_threads(global_thread_descs, global_thread_descs_count) < 0) {
          return 0;
      }
  }

  return (void*)devices;
}

/* \brief
 * Release the resources hold by IO threads
 */
void
mdtm_io_thread_deinit(void* handle)
{
  struct mdtm_io_thread_handle_s * h = (struct mdtm_io_thread_handle_s *)handle;

  if(h) {
      free(h->io_table);
      free(h);
  }
  mdtm_deinit();
}

/* \brief Send writing request to network IO thread
 *
 */
int
mdtm_ftp_dispatch_write(void *data, void (*func)(void*))
{
    //TODO: determine which disks the file locates at
    char *devname = "eth2";
    //TODO: search the io_table to locate the event queue of the disks
    //TODO: post read requests to the event queues
    {
      mdtm_event_queue_t *eventq;
      mdtm_thread_task_t *task;

      eventq = mdtm_io_table_get_eventq(global_io_table, devname);
      if(!eventq) {
          printf("MDTM Error @%s:%s: eventq not found!\n", __FILE__, __FUNCTION__);
          return -1;
      }
      task = (mdtm_thread_task_t*)malloc(sizeof(mdtm_thread_task_t));
      if(!task) {
          printf("MDTM Error @%s:%s: memory not available\n", __FILE__, __FUNCTION__);
          return -1;
      }
      task->func = (globus_callback_func_t)func;
      task->func_user_arg = data;
      globus_mutex_lock(&eventq->_mutex);
      if(globus_fifo_enqueue(&eventq->q, task) < 0) {
          printf("MDTM Error @%s:%s: fifo enqueue failed\n", __FILE__, __FUNCTION__);
          globus_mutex_unlock(&eventq->_mutex);
          return -1;
      }
//      globus_cond_signal(&eventq->_cond);
      globus_mutex_unlock(&eventq->_mutex);
    }

  return 0;
}


/* \brief Send reading request to the disk thread
 * NOTE: not used
 */
int
mdtm_file_dispatch_read(void *monitor, char* path, void (*func)(void*))
{
  {
    mdtm_io_table_t *   table = (mdtm_io_table_t*)global_io_table;
    char *              devname;
    mdtm_lv_seg_t *     segments;
    int                 rc;

    // find the disk responding to the path
    rc = mdtm_map_file2(path, 0, &segments);
    if(rc <= 0)
      return -1;
    devname = segments[0].dev;
    mdtm_map_file_free(segments, rc);

    //TODO: search the io_table to locate the event queue of the disks
    //TODO: post read requests to the event queues

#if LZ_HACK
    gMonitor = monitor;
    gFunc = func;
#else
    {
      mdtm_event_queue_t *eventq;
      mdtm_thread_task_t *task;

      // find the eventq of the disk reading threads
      eventq = mdtm_io_table_get_eventq(table, devname);
      if(!eventq) {
          printf("MDTM error @%s:%s: eventq not found\n", __FILE__, __FUNCTION__);
          return -1;
      }

      // break down the reading task
      task  = (mdtm_thread_task_t*)malloc(sizeof(mdtm_thread_task_t));
      if(!task) {
          printf("MDTM error @%s:%s: memory not available\n", __FILE__, __FUNCTION__);
          return -1;
      }
      task->func = func;
      task->func_user_arg = monitor;

      // assign the tasks to reading thread eventq
      globus_mutex_lock(&eventq->_mutex);
      if(globus_fifo_enqueue(&eventq->q, task) < 0) {
        printf("MDTM error @%s:%s: fifo enqueue failed\n", __FILE__, __FUNCTION__);
        globus_mutex_unlock(&eventq->_mutex);
        return -1;
      }
//      globus_cond_signal(&eventq->_cond);
      globus_mutex_unlock(&eventq->_mutex);
    }
#endif
  }
  return 0;
}

static __thread mdtm_event_queue_t *g_eventq = 0;
static __thread globus_callback_handle_t mdtm_eventq_poll_callback_handle;

void
mdtm_thrd_activate_eventq()
{
  globus_reltime_t                    period;

  g_eventq = globus_malloc(sizeof(mdtm_event_queue_t));
  assert(g_eventq);
  globus_fifo_init(&g_eventq->q);
  globus_mutex_init(&g_eventq->_mutex, GLOBUS_NULL);
  pthread_mutex_init(&g_eventq->_pmutex, GLOBUS_NULL);

  GlobusTimeReltimeSet(period, 1, 0);
  globus_callback_space_register_periodic(
      &mdtm_eventq_poll_callback_handle,
      0,
      &period,
      mdtm_eventq_poll,
      g_eventq,
      mdtm_thread_get_space());
  return;
}

mdtm_event_queue_t*
mdtm_thrd_get_eventq()
{
  return g_eventq;
}

int
mdtm_calculate_parallel(char* netif, char* disk)
{
  char devname[64];
  mdtm_io_thrd_mgr_t *netif_mgr, *disk_mgr;
  int netif_parallel = -1, disk_parallel = -1;

  if(!netif)
    mdtm_config_get_netif(devname, 64);
  else
    strncpy(devname, netif, 64);
  if((netif_mgr = mdtm_io_thrd_mgr_list_get((const char*)devname)) != 0)
    netif_parallel = mdtm_io_thrd_mgr_getthrdnum(netif_mgr);

  if(disk &&
     ((disk_mgr = mdtm_io_thrd_mgr_list_get((const char*)devname)) != 0))
    disk_parallel = mdtm_io_thrd_mgr_getthrdnum(disk_mgr);

  return ((unsigned)netif_parallel < (unsigned)disk_parallel)? netif_parallel : disk_parallel;
}


// LZ: TODO: return copy rather than reference
int
mdtm_io_thread_get_threaddescs(mdtm_thread_desc_t ** p_desc)
{
  *p_desc = global_thread_descs;
  return global_thread_descs_count;
}
