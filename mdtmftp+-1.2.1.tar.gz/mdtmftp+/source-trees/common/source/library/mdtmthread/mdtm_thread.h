/*
 * mdtm_threaad.h
 *
 *  Created on: Aug 1, 2015
 *      Author: liangz
 */

#ifndef MDTM_THREAAD_H_
#define MDTM_THREAAD_H_

#include "mdtm.h"
#include "mdtm_io_thread.h"

typedef struct {
  struct mdtm_device_s* device_info;
  mdtm_io_table_t* io_table;
  void* (*io_table_register)(void*, void*);
  void (*io_table_unregister)(void*, void*);
  mdtm_xio_activate_func        xio_act_func;
} mdtm_thread_user_data_t;


#endif /* MDTM_THREAAD_H_ */
