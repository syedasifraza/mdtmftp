#ifndef __MDTM_IO_THREAD_H__
#define __MDTM_IO_THREAD_H__

#include "globus_fifo.h"
#include "globus_thread.h"
#include "globus_callback.h"
#include "mdtm.h"
#include <sys/eventfd.h>

#define MDTM_IO_THREADS_MAX     (16)

typedef struct {
  globus_fifo_t       q;
  globus_mutex_t      _mutex;
  globus_cond_t       _cond;
  pthread_mutex_t     _pmutex;
  int                 eventfd;
} mdtm_event_queue_t;

struct mdtm_io_entry_s{
  pthread_t tid;
  char* devname;
  int   type;
  mdtm_event_queue_t eq;
  struct mdtm_io_entry_s **next;
};

typedef struct _mdtm_io_table_ {
  globus_mutex_t mutex;
  pthread_mutex_t pmutex;
  int number;
  int capacity;
  int totalthreads;
  struct mdtm_io_entry_s **entry;
} mdtm_io_table_t;

typedef struct {
  pthread_t             threadid;
  mdtm_event_queue_t    *eventq;
}mdtm_io_thrd_t;

typedef struct mdtm_io_thrd_mgr_s {
  struct mdtm_device_s *devio_info;
//  mdtm_io_thrd_t *iothreads;
  mdtm_io_table_t *iothreads;
  int num_iothreads;
  int next_thread;
  pthread_mutex_t lock;
  void* (*create_threads)();
  void* (*dispatch)();
  void* (*delete_threads)();
}mdtm_io_thrd_mgr_t;

typedef struct {
  int used;
  int capacity;
  mdtm_io_thrd_mgr_t **entry;
}mdtm_io_thrd_mgr_list_t;

typedef struct
{
  globus_callback_func_t                func;
  void *                                func_user_arg;
} mdtm_thread_task_t;

typedef int     (*mdtm_xio_activate_func)(int);
typedef void*   (*mdtm_io_thread_func)(void*);
typedef globus_result_t (*mdtm_xio_setevent_func)(int, void*);

typedef struct _func_set_
{
  mdtm_io_thread_func           diskfunc;
  mdtm_io_thread_func           netfunc;
  mdtm_io_thread_func           manfunc;
  mdtm_xio_activate_func        actfunc;
  mdtm_xio_setevent_func        seteventfunc;
} mdtm_thread_func_set_t;

void*
mdtm_io_thread_init(mdtm_thread_func_set_t *funcset, void *userdata);

void*
mdtm_disk_io_thread(void *user_arg);

void*
mdtm_net_io_thread(void *user_arg);

int
mdtm_file_dispatch_read(void *monitor, char* path, void (*func)(void*));

int
mdtm_ftp_dispatch_write(void *data, void (*func)(void*));

mdtm_io_thrd_mgr_t *
mdtm_io_thrd_mgr_list_get(const char *devname);

mdtm_io_thrd_mgr_t *
mdtm_io_thrd_mgr_list_get2(const char *devname, const int type);

/* \brief Get the number threads for the given thread manager
 *
 * It returns the number of threads for the given thread manager. It is not protected
 * by the mutex.
 *
 * @param       mgr     pointer to the thread manager
 * @return      The number of threads.
 */
int
mdtm_io_thrd_mgr_getthrdnum(mdtm_io_thrd_mgr_t *mgr);

/* \brief  Dispatch the input function to a running thread using round-robin policy
 *
 * @param       mgr             pointer to the io-thread manager
 * @param       func            pointer to the function to be dispatched
 * @param       user_arg        argument to the function
 *
 * @return                      return 0 if successful; otherwise negative value
 */
int
mdtm_io_thrd_mgr_dispatch(
    mdtm_io_thrd_mgr_t *        mgr,
    globus_callback_func_t      func,
    void *                      user_arg);

int
mdtm_io_thrd_mgr_dispatch_to(
    mdtm_io_thrd_mgr_t *mgr,
    int id,
    globus_callback_func_t func,
    void *user_arg);

int
mdtm_io_thrd_mgr_dispatch_all(
    mdtm_io_thrd_mgr_t *mgr,
    globus_callback_func_t func,
    void *user_arg);

const
struct mdtm_device_s*
mdtm_io_thrd_mgr_getdevinfo(mdtm_io_thrd_mgr_t *mgr);

const
char *
mdtm_io_thrd_mgr_getdevname(mdtm_io_thrd_mgr_t *mgr);

int
mdtm_io_thrd_mgr_sched(
    mdtm_io_thrd_mgr_t *mgr,
    int ntask,
    unsigned int *cand,
    int policy);

pthread_t
mdtm_io_thrd_mgr_get_pthreadid(void* mgr, int index);

int
mdtm_util_nthsetbit(unsigned value, int n);

int
mdtm_util_countsetbits(unsigned int bitmap);

/* \brief Calculate the lower round number
 *
 * It calculates the lower round number of the input value.
 *
 * @param       in      input value
 * @param       out     pointer to the output around value
 * @return      0 if success, -1 if failed.
 */
int
mdtm_util_round(long long in, long long *out);

void
mdtm_eventq_poll(void* arg);

int
mdtm_thrd_eventq_insert(void*key, void*eventq);

void*
mdtm_thrd_eventq_remove(void* key);

void
mdtm_thrd_dispatch(
    void *                      eventq,
    globus_callback_func_t      func,
    void *                      user_arg);

/* \brief Dispatch a task to specified event queue
 *
 * This function creates a task and enqueue it to the given event queue
 * where the task would be handled in associated thread.
 *
 */
globus_result_t
mdtm_thrd_dispatch_task(
    mdtm_event_queue_t *        eventq,
    globus_callback_func_t      func,
    void *                      user_arg);

/* \brief Operate a thread local event queue with high tolerance of delay
 *
 * These functions create a event queue which is thread local. It has to
 * be polled every second to check if any events come.
 *
 * NOTE: this queue is used only in cases where the delay is not critical.
 *       Otherwise use the wait/notify mechanism as those employed in
 *       i/o thread cases.
 *
 */
void
mdtm_thrd_activate_eventq();

mdtm_event_queue_t*
mdtm_thrd_get_eventq();

/* \brief Calculate the number of parallel(threads) used for mdtm operation
 *
 * @param       netif   network interface name string; null pointer for default value
 * @param       disk    disk name string; null pointer for default value
 * @return      parallel number if success, -1 if failed
 */
int
mdtm_calculate_parallel(char* netif, char* disk);

int
mdtm_io_table_get_thread_desc(
    mdtm_io_table_t *           table,
    mdtm_thread_desc_t *        thread_descs);

int
mdtm_io_thread_get_threaddescs(mdtm_thread_desc_t **);

/* \brief
 * Release the resources hold by IO threads
 */
void
mdtm_io_thread_deinit(void* handle);

#endif
