#!/bin/bash

exec "$@"

